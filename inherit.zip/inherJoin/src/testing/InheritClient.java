package  testing;

import com.htc.joinStrategy.domain.BookMaterial;
import com.htc.joinStrategy.domain.DocMaterial;
import com.htc.joinStrategy.domain.PrintMaterial;
import com.htc.jpa.joinstrategy.utils.InheritJoin;
import com.htc.jpa.joinstrategy.utils.InheritJoinImpl;

public class InheritClient {
 
     
  public static void main(String[] args)
    throws java.io.IOException {
    boolean  created = false;
    
    System.out.println("\nBegin Inheritance-Client...\n");
    try {

     InheritJoin dao =  new InheritJoinImpl();

     System.out.println("\nGot dao object..\n");
     
     PrintMaterial pm = new PrintMaterial("a110",200);
     BookMaterial bm = new BookMaterial("a120",400,"JEE");
     DocMaterial dm = new DocMaterial("a130",20,"Inheritance");
     
     created = dao.savePrintMaterial(pm);
     System.out.println("\nStatement PrintMaterial Created is...:"
                         +created);
 
     created = dao.saveBookMaterial(bm); 
      
     System.out.println("\nStatement BookMaterial Created is...:"
                         +created);

     created = dao.saveDocMaterial(dm);
                           
      
     System.out.println("\nStatement DocMaterial is...:"
                         +created);
 
   }catch(Exception e) {
     System.out.println(e.getMessage());
  }
 }

}