package com.htc.jpa.joinstrategy.utils;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import com.htc.joinStrategy.domain.BookMaterial;
import com.htc.joinStrategy.domain.DocMaterial;
import com.htc.joinStrategy.domain.PrintMaterial;

public class InheritJoinImpl implements InheritJoin {
 
    EntityManager em;
    EntityTransaction trans;
	
    public InheritJoinImpl() {
     EntityManagerFactory factory = 
  	   Persistence.createEntityManagerFactory("myDb");
     em = factory.createEntityManager();
    }
   

    public boolean savePrintMaterial(PrintMaterial printMaterial){
     boolean  ret = false;
     trans = em.getTransaction();
     trans.begin();
     try {
      em.persist(printMaterial);
      ret = true;
      trans.commit();
     }catch(Exception e) {
       e.printStackTrace();
       trans.rollback();
     }
     return  ret; 
   }

    public boolean saveBookMaterial(BookMaterial bookMaterial) {
     boolean  ret = false;
     trans = em.getTransaction();
     trans.begin();
     try {
      em.persist(bookMaterial);
      ret = true;
      trans.commit();
     }catch(Exception e) {
      e.printStackTrace();
      trans.rollback();
     }
     return  ret; 
   } 
    
    public boolean saveDocMaterial(DocMaterial docMaterial) {
     boolean  ret = false;
     trans = em.getTransaction();
     trans.begin();
     try {
      em.persist(docMaterial);
      ret = true;
      trans.commit();
     }catch(Exception e){
       e.printStackTrace();
       trans.rollback();
     }
     return  ret; 
   }         

}