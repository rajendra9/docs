package com.htc.jpa.joinstrategy.utils;

import java.io.Serializable;

import com.htc.joinStrategy.domain.BookMaterial;
import com.htc.joinStrategy.domain.DocMaterial;
import com.htc.joinStrategy.domain.PrintMaterial;

public interface InheritJoin extends Serializable {
    
  public boolean savePrintMaterial(PrintMaterial printMaterial);
  public boolean saveBookMaterial(BookMaterial bookMaterial);
  public boolean saveDocMaterial(DocMaterial docMaterial);
  
}
