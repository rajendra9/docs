package com.htc.joinStrategy.domain;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;


@Entity
@Table(name="BOOKMATERIAL")
@SuppressWarnings("serial")
public class BookMaterial extends PrintMaterial {
	
   public BookMaterial(String isbn,
                      int nop,
                      String bookName) {
     super(isbn, nop);
     this.bookName = bookName;
   }

   @Column(name="BOOK_NAME")
   private String bookName;

   public BookMaterial() {
   }

   public String getBookName() {
     return this.bookName;
   }

   public void setBookName(String bookName) {
      this.bookName = bookName;
   }  

}