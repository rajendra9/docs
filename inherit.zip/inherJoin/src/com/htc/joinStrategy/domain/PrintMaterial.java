package com.htc.joinStrategy.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Table(name="PRINTMATERIAL")
@Inheritance(strategy=InheritanceType.JOINED)
@SuppressWarnings("serial")
public class PrintMaterial implements Serializable {
	
   @Id
   private String isbn;

   private int nop;

   public PrintMaterial() {   }

   
   public PrintMaterial(String isbn, int nop) {
    super();
    this.isbn = isbn;
    this.nop = nop;
   } 

   public String getIsbn() {
     return this.isbn;
   }

   public void setIsbn(String isbn) {
     this.isbn = isbn;
   }

   public int getNop() {
      return this.nop;
   }

   public void setNop(int nop) {
     this.nop = nop;
   }

}