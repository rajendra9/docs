package com.htc.joinStrategy.domain;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;


@Entity
@Table(name="DOCMATERIAL")
@SuppressWarnings("serial")
public class DocMaterial extends PrintMaterial implements Serializable {
 
  @Column(name="DOC_NAME")
  private String docName;

  public DocMaterial() {
  }
  
  public DocMaterial(String isbn,
                     int nop,
                     String docName) {
    super(isbn, nop);
    this.docName = docName;
  }


  public String getDocName() {
    return this.docName;
  }

  public void setDocName(String docName) {
    this.docName = docName;
  }

}