select * from printmaterial;
select * from bookmaterial;
select * from docmaterial;
