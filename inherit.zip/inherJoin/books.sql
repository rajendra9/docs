drop table if exists bookmaterial;

drop table if exists docmaterial;

drop table if exists printmaterial ;


create table printmaterial(isbn varchar(20) constraint pm_PK primary key,
nop integer);

create table bookmaterial(isbn varchar(20) not null,
book_name varchar(20),
constraint book_FK foreign key(isbn) references printmaterial);

create table docmaterial(isbn varchar(20) not null,
doc_name varchar(20),
constraint doc_FK foreign key(isbn) references printmaterial);  