package  testing;

import com.htc.sepClStrategy.domain.Bus;
import com.htc.sepClStrategy.domain.Car;
import com.htc.sepClStrategy.domain.Vehicle;
import com.htc.sepClStrategy.utils.InheritSepClasseDao;
import com.htc.sepClStrategy.utils.InheritSepClasseDaoImpl;

public class InheritClient {
 
     
  public static void main(String[] args)
    throws java.io.IOException {
    boolean  created = false;
    
    System.out.println("\nBegin Inheritance-Client...\n");
    try {

     InheritSepClasseDao dao =  new InheritSepClasseDaoImpl();

     System.out.println("\nGot dao object..\n");
     
     Vehicle veh = new Vehicle("TN Az 4323","road",80);
     Car car = new Car("TN AS 5434","road",4,"Alto","Maruthi",2012,312543.0);
     Bus bus = new Bus("TN AD 6542","road",60,"G18","Leyland","TNagar");
     
     created = dao.saveVehicle(veh);
     System.out.println("\nStatement Vehicle Created is...:"
                         +created);
 
     created = dao.saveCar(car); 
      
     System.out.println("\nStatement Car Created is...:"
                         +created);

     created = dao.saveBus(bus);
                           
      
     System.out.println("\nStatement Bus Created is...:"
                         +created);
  
   }catch(Exception e) {
     System.out.println(e.getMessage());
  }
 }

}