package com.htc.sepClStrategy.domain;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.Column;
import javax.persistence.InheritanceType;


@Entity
@Table(name="VEHICLES")
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
@SuppressWarnings("serial")
public class Vehicle implements Serializable {

    @Id
    @Column(name="REG_NO")
    private String regNo;
    
    private String medium;

    @Column(name="PERSONS")
    private int personsCanCarry;

    public Vehicle() {
    }    
    
    public Vehicle(String regNo) {
        super();
        this.regNo = regNo;
    }
    
    public Vehicle(String regNo,
                   String medium, 
                   int personsCanCarry) {
        super();
        this.regNo = regNo;
        this.medium = medium;
        this.personsCanCarry = personsCanCarry;
    }

    public String getRegNo() {
      return this.regNo;
    }

    public void setRegNo(String regNo) {
      this.regNo = regNo;
    }

    public String getMedium() {
       return this.medium;
    }

    public void setMedium(String medium) {
       this.medium = medium;
    }

    public int getPersonsCanCarry() {
      return this.personsCanCarry;
    }

    public void setPersonsCanCarry(int personsCanCarry) {
      this.personsCanCarry = personsCanCarry;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((regNo == null) ? 0 : regNo.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Vehicle other = (Vehicle) obj;
        if (regNo == null) {
            if (other.regNo != null)
                return false;
        } else if (!regNo.equals(other.regNo))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "Vehicle [regNo=" + regNo + ", medium=" + medium
                + ", personsCanCarry=" + personsCanCarry + "]";
    }   

}