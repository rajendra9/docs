package com.htc.sepClStrategy.domain;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name="BUSES")
@SuppressWarnings("serial")
public class Bus extends Vehicle implements Serializable {
	
    private String depo;

    private String model; 

    private String route;

    public Bus() {
    }     

    public Bus(String regNo, 
               String medium, 
               int personsCanCarry,
               String depo,
               String model,               
               String route) {
        super(regNo, medium, personsCanCarry);
        this.depo = depo;
        this.model = model;        
        this.route = route;
    }



    public String getDepo() {
	return this.depo;
    }

    public void setDepo(String depo) {
      this.depo = depo;
    }

    public String getModel() {
      return this.model;
    }

    public void setModel(String model) {
      this.model = model;
    }   

    public String getRoute() {
      return this.route;
    }

    public void setRoute(String route) {
      this.route = route;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((route == null) ? 0 : route.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Bus other = (Bus) obj;
        if (route == null) {
            if (other.route != null)
                return false;
        } else if (!route.equals(other.route))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "Bus [depo=" + depo + ", model=" + model + ", route=" + route
                + ", getRegNo()=" + getRegNo() + ", getMedium()=" + getMedium()
                + ", getPersonsCanCarry()=" + getPersonsCanCarry() + "]";
    }   

}