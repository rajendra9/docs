package com.htc.sepClStrategy.utils;

import java.io.Serializable;

import com.htc.sepClStrategy.domain.Bus;
import com.htc.sepClStrategy.domain.Car;
import com.htc.sepClStrategy.domain.Vehicle;

public interface InheritSepClasseDao extends Serializable {
    
  public boolean saveVehicle(Vehicle vehicle);
  public boolean saveCar(Car car);
  public boolean saveBus(Bus bus);
  
}
