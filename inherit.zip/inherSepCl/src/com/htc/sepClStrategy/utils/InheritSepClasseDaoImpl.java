package com.htc.sepClStrategy.utils;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import com.htc.sepClStrategy.domain.Bus;
import com.htc.sepClStrategy.domain.Car;
import com.htc.sepClStrategy.domain.Vehicle;

@SuppressWarnings("serial")
public class InheritSepClasseDaoImpl implements InheritSepClasseDao {
 
    EntityManager em;
    EntityTransaction trans;
	
    public InheritSepClasseDaoImpl() {
     EntityManagerFactory factory = 
  	   Persistence.createEntityManagerFactory("myDb");
     em = factory.createEntityManager();
    }
   

    public boolean saveVehicle(Vehicle vehicle){
     boolean  ret = false;
     trans = em.getTransaction();
     trans.begin();
     try {
      em.persist(vehicle);
      ret = true;
      trans.commit();
     }catch(Exception e) {
       e.printStackTrace();
       trans.rollback();
     }
     return  ret; 
   }

    public boolean saveCar(Car car) {
     boolean  ret = false;
     trans = em.getTransaction();
     trans.begin();
     try {
      em.persist(car);
      ret = true;
      trans.commit();
     }catch(Exception e) {
      e.printStackTrace();
      trans.rollback();
     }
     return  ret; 
   } 
    
    public boolean saveBus(Bus bus) {
     boolean  ret = false;
     trans = em.getTransaction();
     trans.begin();
     try {
      em.persist(bus);
      ret = true;
      trans.commit();
     }catch(Exception e){
       e.printStackTrace();
       trans.rollback();
     }
     return  ret; 
   }         

}