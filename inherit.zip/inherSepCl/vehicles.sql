drop table if exists  cars;

drop table if exists buses;
drop table if exists vehicles;

create table vehicles(reg_no  varchar(20) constraint veh_PK primary key,
persons integer,medium varchar(20));

create table cars(reg_no  varchar(20) constraint cars_PK primary key,
persons integer,medium varchar(20),
car_brand varchar(20),
company varchar(20),
model_year integer,
pur_cost float8);

create table buses(reg_no  varchar(20) constraint buses_PK primary key,
persons integer,medium varchar(20),route varchar(6),
model varchar(20),
depo varchar(20));  