select * from vehicles;
select * from buses;
select * from cars;
