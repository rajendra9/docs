import React, { Component }  from 'react';

class Rect extends Component {
  render(){
      var styles={
          width: '120px',
          backgroundColor: 'orange',
          height: '55px',
          border: '4px solid red'
        };
        var styles2={
            width: '120px',
            backgroundColor: 'white',
            height: '24px',
            borderTop: 'none',
            borderBottom: '4px solid red',
            borderRight: '4px solid red',
            borderLeft: '4px solid red'
          }
        return (
            <div>
            <div style={styles}></div>
            <div  style={styles2}><label>Rectangle</label></div>
            </div>
        );
  }
}

export default Rect;