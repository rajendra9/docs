import React, { Component }  from 'react';
import Rect from './rect';
import Square from './square';
import { Column, Row }  from 'simple-flexbox';
/*
/The flex-grow property specifies
 how much the item will grow relative 
 to the rest of the flexible items inside
 the same container.
*/
class FlowBase extends Component {
  render(){
        return (
            <div>
                
<Column flexGrow={1}>
    <Row horizontal='center'>
        <h1>HEADER</h1>
    </Row>
    <Row vertical='center'>
        <Column flexGrow={1} horizontal='center'>
            <h3> Column 1 </h3>
            <span><Rect/> </span>
        </Column>
        <Column flexGrow={1} horizontal='center'>
            <h3> Column 2 </h3>
            <span> <Square/> </span>
        </Column>
        <Column flexGrow={1} horizontal='center'>
            <h3> Column 3 </h3>
            <span> <Rect/> </span>
        </Column>
        <Column flexGrow={1} horizontal='center'>
            <h3> Column 4 </h3>
            <span> <Square/> </span>
        </Column>
    </Row>
    <Row vertical='center'>
        <Column flexGrow={1} horizontal='center'>
            <h3> Column 1 </h3>
            <span><Rect/> </span>
        </Column>
        <Column flexGrow={1} horizontal='center'>
            <h3> Column 2 </h3>
            <span> <Square/> </span>
        </Column>
        <Column flexGrow={1} horizontal='center'>
            <h3> Column 3 </h3>
            <span> <Rect/> </span>
        </Column>
        <Column flexGrow={1} horizontal='center'>
            <h3> Column 4 </h3>
            <span> <Square/> </span>
        </Column>
    </Row>
</Column>



            </div>
        );
  }
}

export default FlowBase;