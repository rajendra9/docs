import React, { Component }  from 'react';

class Square extends Component {
  render(){
      var styles={
          width: '120px',
          backgroundColor: 'magenta',
          height: '120px',
          border: '4px solid green'
        }
        var styles2={
            width: '120px',
            backgroundColor: 'white',
            height: '24px',
            borderTop: 'none',
            borderBottom: '4px solid green',
            borderRight: '4px solid green',
            borderLeft: '4px solid green'
            
            
          }
        return (
            <div>
            <div style={styles}></div>
            <div style={styles2}><label>Square</label></div>
            </div>
        );
  }
}

export default Square;