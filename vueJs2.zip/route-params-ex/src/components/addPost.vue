<template>
  <div id="add-blog">
      <h2>Add a new Blog Post</h2>
      <form v-if="!submitted">
        <table>
           <tr><td><label>Post Title:</label></td><td><input type="text" v-model.lazy="blog.title" required/></td></tr> 
           <tr><td><label>Post Content:</label></td><td><textarea v-model.lazy="blog.content"> </textarea></td></tr>
        </table>
        <div id="checkboxes">
           <label>Globe Events:</label><input type="checkbox" v-model="blog.categories" value="glob-evts" />   
           <label>Globe Politics:</label><input type="checkbox" v-model="blog.categories" value="glob-politrics" />
           <label>Nation Politics:</label><input type="checkbox" v-model="blog.categories" value="ind-politrics" />
           <label>Lighter:</label><input type="checkbox" v-model="blog.categories" value="entertainment" />
        </div>
        <label>Author</label>
        <select v-model="blog.author">
        <option v-for="(author,index) in knownAuthors" v-bind:key="index">{{author}}</option>
        </select>
        <button v-on:click.prevent="postBlog">Post Blog</button> 
      </form>
      <div v-if="submitted">
          <h3>Thanks for posting your blog</h3>
      </div>
      <div id="preview">
          <h3>Preview Block</h3>
          <p>Blog Title:{{blog.title}}</p>
          <p>Blog Categories:</p>
           <ul>
             <li v-for="(category,index) in blog.categories" v-bind:key="index">{{category}}</li>
           </ul>
          <p>Blog Content:</p>
          <p>{{blog.content}}</p>    
          <p>Author:{{blog.author}}</p>      
      </div>
  </div>
</template>

<script>
export default {
 
  data () {
    return {
        blog:{
           title: '',
           categories: [],
           content:'',
           author: ''    
        },
        knownAuthors: ['Ninja-Vuejs','Viswas-Angular','Harish Patel-ReactJs'],
        submitted: false
    }
    
  },
  methods: {
      postBlog: function(){
        this.$http.post('http://jsonplaceholder.typicode.com/posts',{
            title: this.blog.title,
            body: this.blog.content,
            userId: 101
        }).then(function(data){
           console.log(data);
           this.submitted = true;
        });  
      }
  }

}
</script>

<style>
#add-blog *{
    box-sizing: border-box;
}
#add-blog{
    margin:20px auto;
    max-width: 500px;
}
label{
    display: block;
    margin: 20px 0 10px;
}
input[type="text"], textarea{
    display: block;
    width: 100%;
    padding:8px;
}
#preview{
    padding: 10px 20px;
    border: 1px dotted #ccc;
    margin:30px 0;
}
h3{
  margin-top: 10px;
}
#checkboxes input{
  display: inline-block;
  margin-right:10px;
}
#checkboxes label{
    display: inline-block;
}
</style>
