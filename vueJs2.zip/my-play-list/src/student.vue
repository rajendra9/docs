<template>
  <div>
    <h1>List of Students</h1>
    <ui>
        <li v-for='student in students'>{{student}}</li>
    </ui>    
    
  </div>
</template>

<script>
export default {
  
  data () {    
    return {
      students: ['Newton', 'Kathir Vel', 'Harish', 'Muthu Kumar']
    }
  },
  methods:{
   
  }
}
</script>

<style scoped>
 li{
    list-style: none;    
  }
  h1{
    color: green;
  }
</style>
