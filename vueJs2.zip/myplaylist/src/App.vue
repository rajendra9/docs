<template>
  <div id="app">
    <img src="./assets/logo.png">
    <h1>{{title}}</h1>
    <p>{{greeting()}}</p>
  </div>
</template>

<script>
export default {
  
  data () {    
    return {
      title: 'Your First Application'
    }
  },
  methods:{
    greeting: function(){
      return 'Heeye Cow Boy';
    }
  }
}
</script>

<style>

</style>
