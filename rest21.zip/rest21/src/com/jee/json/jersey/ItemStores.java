package com.jee.json.jersey;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

@SuppressWarnings("serial")
public class ItemStores implements Serializable {
  
	EntityTransaction trans;
    EntityManagerFactory factory;
    EntityManager em;
    
    {
    	factory = Persistence.createEntityManagerFactory("myDB");
        em = factory.createEntityManager();	
    }
    
    public ItemForJson toItemJson(ItemInfo info) {
    	return new ItemForJson(info.getItemId(),
    			              info.getItemName(),
    			              info.getItemType(),
    			              info.getItemPrice(),
    			              info.getCustomer());    			
    }
    
    public ItemInfo fromItemJson(ItemForJson item) {
    	return new ItemInfo(item.getItemId(),
    			            item.getItemName(),
    			            item.getItemType(),
    			            item.getItemPrice(),
    			            item.getCustomer());    			
    }
    
    public ItemForJson searchItem(String id) {
	  trans = em.getTransaction();
	  trans.begin();
	  ItemInfo itemInfo = new ItemInfo();
	  try {
		itemInfo = em.getReference(ItemInfo.class, id);
		trans.commit();
	  }catch(Exception ex) {
		 ex.printStackTrace();
		 trans.rollback();
	  }	 
	  ItemForJson itemJson = this.toItemJson(itemInfo);
	  return itemJson;
    }
    
   public ItemForJson[] retrieveAll() {
  	  trans = em.getTransaction();
  	  trans.begin();
  	  List<ItemForJson> list = new ArrayList<>();
  	  try {
  		TypedQuery<ItemInfo> qry = em.createNamedQuery("all.items", ItemInfo.class);  
  		List<ItemInfo>  infoList = qry.getResultList();
  		for(ItemInfo info : infoList) {
  			list.add(this.toItemJson(info));
  		}
  		
  		trans.commit();
  	  }catch(Exception ex) {
  		 ex.printStackTrace();
  		 trans.rollback();
  	  }	   	  
  	  return list.toArray(new ItemForJson[] { new ItemForJson()});
      }
    
    public String saveItem(ItemForJson item) {
	   String ret = "Problems in saving";
	   trans = em.getTransaction();
	   trans.begin();
	   try {
		 ItemInfo itemInfo = this.fromItemJson(item); 
		 em.persist(itemInfo);
		 trans.commit();
		 ret = item.toString() + " is saved.";
	   }catch(Exception ex) {
		  ex.printStackTrace();
		  trans.rollback();
	   }	  
	   return ret;
     }
 
   
  
}
