package com.jee.json.jersey;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ProdInfo implements Serializable {

	private String  prodId;
	private String  prodName;
	private double  prodCost;
	private String  supplier;
	
	public ProdInfo() {
		super();
	}

	public ProdInfo(String prodId, String prodName, double prodCost, String supplier) {
		super();
		this.prodId = prodId;
		this.prodName = prodName;
		this.prodCost = prodCost;
		this.supplier = supplier;
	}

	public String getProdId() {
		return prodId;
	}

	public void setProdId(String prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public double getProdCost() {
		return prodCost;
	}

	public void setProdCost(double prodCost) {
		this.prodCost = prodCost;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((prodId == null) ? 0 : prodId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProdInfo other = (ProdInfo) obj;
		if (prodId == null) {
			if (other.prodId != null)
				return false;
		} else if (!prodId.equals(other.prodId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ProdInfo [prodId=" + prodId + ", prodName=" + prodName + ", prodCost=" + prodCost + ", supplier="
				+ supplier + "]";
	}
	
	
	
	
}
    		
	
	
	
	
	
	

