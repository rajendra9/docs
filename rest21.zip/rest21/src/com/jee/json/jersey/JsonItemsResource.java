package com.jee.json.jersey;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.json.bind.JsonbBuilder;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/jsonItems")
public class JsonItemsResource {
    
	ItemStores itemStores = new ItemStores();
    
	@GET
	public String contact() {
		return "<h2 align='center'>Welcome to JaxRs-2.1 Item Resource</h2"; 
	}
	
	@GET
	@Path("/{itemId}")
	public ItemForJson  searchItem(@PathParam("itemId") String itemId) {
	     return itemStores.searchItem(itemId);	
	}
	
	@GET
	@Path("/all")
	public ItemForJson[]  searchforAll() {
	     return itemStores.retrieveAll();	
	}
	
	@POST
	@Path("/saveItem")
	public String  saveItem(InputStream inStream) {
		System.out.println("Contacted");
		ItemForJson item = new ItemForJson();
      try { 
		BufferedReader in = 
	    		new BufferedReader(new InputStreamReader(inStream));
	    String jsonStr = in.readLine();
	    item = JsonbBuilder.create().fromJson(jsonStr, ItemForJson.class);;
	   
	  }catch(Exception ex) {
		   ex.printStackTrace();
	  }
	  return this.itemStores.saveItem(item);	
	}
	
	
}
