package com.jee.json.jersey;

import java.io.Serializable;

import javax.json.bind.JsonbBuilder;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

@SuppressWarnings("serial")
public class ProductStore implements Serializable {
  
	EntityTransaction trans;
    EntityManagerFactory factory;
    EntityManager em;
    
    {
    	factory = Persistence.createEntityManagerFactory("myDB");
        em = factory.createEntityManager();	
    }
    
    public ProdDto toDto(ProdInfo info) {
    	return new ProdDto(info.getProdId(),
    			              info.getProdName(),
    			              info.getProdCost(),
    			              info.getSupplier());    			
    }
    public ProdInfo fromDto(ProdDto dto) {
    	return new ProdInfo(dto.getProdId(),
    			            dto.getProdName(),
    			            dto.getProdCost(),
    			            dto.getSupplier());    			
    }
    
    
    public String searchRetAsJson(String id) {
	  System.out.println(id);
	  trans = em.getTransaction();
	  trans.begin();
	  ProdDto dto = new ProdDto();
	  try {
		dto = em.getReference(ProdDto.class, id);
		trans.commit();
	  }catch(Exception ex) {
		 ex.printStackTrace();
		 trans.rollback();
	  }
	 ProdInfo prod = this.fromDto(dto);
	 return JsonbBuilder.create().toJson(prod);
  }
  
  public String saveProduct(ProdInfo prod) {
	  String ret = "Problems in saving";
	  ProdDto toBeSaved = this.toDto(prod);
	  trans = em.getTransaction();
	  trans.begin();
	  try {
		em.persist(toBeSaved);
		trans.commit();
		ret = prod.toString() + " is saved.";
	  }catch(Exception ex) {
		 ex.printStackTrace();
		 trans.rollback();
	  }	  
	  return ret;
  }
 
   
  
}
