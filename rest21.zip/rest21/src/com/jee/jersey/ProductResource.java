package com.jee.jersey;


import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.jee.jersey.utils.ProductDAO;
import com.jee.jersey.utils.ProductDTO;


// The Java class will be hosted at the URI path "/prods"
@Path("/prods")
public class ProductResource {

  
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String loadInput() {
	   StringBuffer sb = new StringBuffer("<html><head><title>");
	   sb.append("Product Creation Page</title></head><body>");
	   sb.append("<div align=center>");
	   sb.append("<h2>Product Creation Page</h2>");
	   sb.append("<form action='/webRest/rest/prods/add' method='post'>");
	   sb.append("<table><tr><td>Enter Prod Id Here:</td>");
	   sb.append("<td><input name='prodId'/></td></tr>");
	   sb.append("<tr><td>Enter Prod Name Here:</td>");
	   sb.append("<td><input name='prodName'/></td></tr>");
	   sb.append("<tr><td>Enter Prod Cost Here:</td>");
	   sb.append("<td><input name='prodCost'/></td></tr></table>");
	   sb.append("<br/><hr/><input type='submit' value='create Product'/></form>");
	   sb.append("</div></body><html>");
	   return sb.toString();	   
	}
	
    @POST
    @Produces("text/plain")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Path("/add")
    public Response addPerson(
              @FormParam("prodId") int prodId,
              @FormParam("prodName")String prodName,
              @FormParam("prodCost")double prodCost){
      System.out.println("...."+prodId);
      ProductDTO dto = new ProductDTO(prodId, prodName, prodCost);
      ProductDAO dao = new ProductDAO();
      Response response = null;
      boolean saved = dao.saveProduct(dto);
      if(saved) {
       Response.ResponseBuilder builder = Response.status(200);       
       builder = 
         builder.entity("addProduct is called with "+dto.toString());
       response = builder.build();  
      }
      return response;
    }

    @GET 
    @Produces(MediaType.TEXT_PLAIN)
    @Path("/search")
    public String searchPerson(
              @QueryParam("prodid") int prodId){
      ProductDAO dao = new ProductDAO();
      String res = dao.getProduct(prodId);
      return res;
    }
    

}
