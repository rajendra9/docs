package com.jee.jersey;

import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.jee.jersey.utils.ItemDTO;
import com.jee.jersey.utils.StoreItems;


// The Java class will be hosted at the URI path "/items"
@Path("/items")
public class ItemResource {
    
    StoreItems items = new StoreItems();
    
    @GET 
    public String wish(){
        return "<span style='text-align:center;color:blue;'>Welcome To ItemService</span>";
    }
    
    // The Java method will process HTTP GET requests
    @GET 
    @Produces(MediaType.APPLICATION_XML)
    @Path("/{id: [0-9]+}")
    public ItemDTO getParam(@PathParam("id") int itemId) {
      return items.getItem(itemId);
    }   
    
    
    @GET
    @Path("/itemJson/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String sendItemAsJson(@PathParam("id")int id){
      return items.getItemJson(id);
    }
    
    @GET
    @Path("/addItem")
    public String addItemToStores(
    		@MatrixParam("id") String idStr,
    		@MatrixParam("itName") String itemName,
    		@MatrixParam("costStr") String cstStr) {
      boolean boo = 
    		  items.addItem(idStr, itemName, cstStr);
      if(boo) {
    	  return "item with id-" + idStr + "added";
      }
      else {
    	  return "failure in addition";
      }  
      
      
    }
    
    
    @POST
    @Path("/itemPlus")
    public String plusItemToStores(
    		@MatrixParam("id") String idStr,
    		@MatrixParam("itName") String itemName,
    		@MatrixParam("costStr") String cstStr) {
      boolean boo = 
    		  items.addItem(idStr, itemName, cstStr);
      if(boo) {
    	  return "item with id-" + idStr + "added";
      }
      else {
    	  return "failure in addition";
      }  
      
      
    }
}