package com.jee.jersey;

import java.io.File;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

@Path("/pics")
public class ImgResource {

	@GET
	@Path("/myImg/{name}")
	@Produces("image/jpg")
	public  Response   getFile(@PathParam("name") String imgName) {  
       String picName = imgName + ".jpg"; 
       String sep = File.separator;
	   File file = new File("c:" + sep + "images" + sep + picName);
       
	   String fname= file.getName();
	   System.out.println(fname);
	   return Response.ok(file, "image/jpg").header("Inline", "filename=\""+fname+ "\"").build();
    }

}
