package com.jee.jersey;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.jee.jersey.utils.Student;
import com.jee.jersey.utils.Students;
import com.jee.jersey.utils.XmlStudentDelegate;


@Path("/xmlStudents")
public class XmlStudentResource {
 
   XmlStudentDelegate delegate = 
            new XmlStudentDelegate();
     

   @GET 
   @Path("/all")
   @Produces(MediaType.APPLICATION_XML)
   public Students getAll(){
       List<Student> stuList = this.delegate.getStudents();
       Students ret = new Students();
       ret.setStudents(stuList);
       return ret;
   }
   
   
  
}
