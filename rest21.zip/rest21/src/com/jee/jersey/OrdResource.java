package com.jee.jersey;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.jee.jersey.utils.CustOrder;
import com.jee.jersey.utils.CustOrderMap;



@Path("/custOrder")
public class OrdResource {

  @GET  
  public String getOrder(@QueryParam("ordId") String orderNo) {
         System.out.println("LLLL"+orderNo);
	  CustOrder order = new CustOrder();
	  CustOrderMap map = new CustOrderMap();
	  int ordNo = Integer.parseInt(orderNo);
	  order = map.getCustOrder(ordNo); 
      return order.toString();
		
   }
  
  @GET
  @Path("/myLink/{id}")  
  public Response sendHateoasLink(@PathParam("id") String id) {
	System.out.println("Method invoked"+id); 
	String hrefStr="../../custOrder?ordId="+id;
	String ordLink = "<a href="+hrefStr+">Access Order</a>";
	  System.out.println(ordLink);
      Response response = Response.ok().entity(ordLink).build();
	  System.out.println(response);
	  return response;
  }


}


