package com.jee.jersey.utils;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Serializable;

@SuppressWarnings("serial")
public class StudentReaderAndWriter implements Serializable {
  
   public StudentTO readStudent(InputStream is) {
     StudentTO ret = new StudentTO();
    try {
     DocumentBuilderFactory dFactory =
             DocumentBuilderFactory.newInstance();
     DocumentBuilder docBuilder = dFactory.newDocumentBuilder();
     Document doc = docBuilder.parse(is);
     Element stuElt = doc.getDocumentElement();
     String idVal = stuElt.getAttribute("id");
     if(idVal != null && (!idVal.isEmpty())){ 
      ret.setStuId(idVal);
     }
     NodeList list = stuElt.getChildNodes();
     int len = list.getLength();
     for(int i=0;i<len;i++){
       org.w3c.dom.Element elt = (org.w3c.dom.Element)list.item(i);
       if(elt.getTagName().equalsIgnoreCase("stu-name")){
          ret.setStuName(elt.getFirstChild().getNodeValue());  
       }
       if(elt.getTagName().equalsIgnoreCase("course")){
           ret.setCourse(elt.getFirstChild().getNodeValue());  
       }
       if(elt.getTagName().equalsIgnoreCase("address")){
           ret.setAddress(elt.getFirstChild().getNodeValue());  
       }
     }
    }catch(Exception ex){
        ex.printStackTrace();
    }
     return ret;     
   }
   
   public void sendStudent(OutputStream out,StudentTO student)throws IOException {
     PrintWriter pw = new PrintWriter(out);  
     pw.println("<student id='"+student.getStuId()+"'><stu-name>");
     pw.println(student.getStuName()+"</stu-name>");
     pw.println("<course>"+student.getCourse()+"</course>");
     pw.println("<address>"+student.getAddress()+"</address></student>");
     pw.flush();
   }
}
