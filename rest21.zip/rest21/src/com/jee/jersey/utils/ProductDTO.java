package com.jee.jersey.utils;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Id;

@Entity
@Table(name="RSPRODUCTS")
@SuppressWarnings("serial")
public class ProductDTO implements Serializable {
   private  int     prodId;
   private  String  prodName;
   private  double  prodCost;
  
   public ProductDTO() {
    super();
   }

   public ProductDTO(int prodId, 
                     String prodName,
                     double prodCost) {
     super();
     this.prodId = prodId;
     this.prodName = prodName;
     this.prodCost = prodCost;
   }
 
   @Id
   @Column(name="PROD_ID")
   public int getProdId() {
    return prodId;
   }

   public void setProdId(int prodId) {
      this.prodId = prodId;
   }

   @Column(name="PROD_NAME")
   public String getProdName() {
    return prodName;
   }

   public void setProdName(String prodName) {
     this.prodName = prodName;
   }

   @Column(name="PROD_COST")
   public double getProdCost() {
     return prodCost;
   }

   public void setProdCost(double prodCost) {
      this.prodCost = prodCost;
   }

   @Override
   public int hashCode() {
     final int prime = 31;
     int result = 1;
     result = prime * result + prodId;
     return result;
   }

   @Override
   public boolean equals(Object obj) {
     if (this == obj)
         return true;
     if (obj == null)
         return false;
     if (getClass() != obj.getClass())
         return false;
     ProductDTO other = (ProductDTO) obj;
     if (prodId != other.prodId)
         return false;
      return true;
   }

   @Override
   public String toString() {
       return "ProductDTO [prodId=" + prodId + ", prodName=" + prodName
              + ", prodCost=" + prodCost + "]";  
   }
   
   
   
   
    
    
}
