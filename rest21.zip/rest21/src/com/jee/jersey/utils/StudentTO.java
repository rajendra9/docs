package com.jee.jersey.utils;

import java.io.Serializable;

@SuppressWarnings("serial")
public class StudentTO implements Serializable {
   private  String  stuId;
   private  String  stuName;
   private  String  course;
   private  String  address;
   
   public StudentTO() {
     super();    
   }

   public StudentTO(String stuId, 
                    String stuName, 
                    String course, 
                    String address) {
    super();
    this.stuId = stuId;
    this.stuName = stuName;
    this.course = course;
    this.address = address;
   }

   public String getStuId() {
     return stuId;
   }

   public String getStuName() {
      return stuName;
   }

   public String getCourse() {
     return course;
   }

   public String getAddress() {
      return address;
   }

   
   
   @Override
   public String toString() {
      return "StudentTO [stuId=" + stuId + ", stuName=" + stuName + ", course="
            + course + ", address=" + address + "]";
   }

   public void setStuId(String stuId) {
     this.stuId = stuId;
   }

   public void setStuName(String stuName) {
      this.stuName = stuName;
   }

   public void setCourse(String course) {
      this.course = course;
   }

   public void setAddress(String address) {
     this.address = address;
   }

   @Override
   public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((stuId == null) ? 0 : stuId.hashCode());
    return result; 
   }

  @Override
  public boolean equals(Object obj) {
     if (this == obj)
         return true;
     if (obj == null)
         return false;
     if (getClass() != obj.getClass())
        return false;
     StudentTO other = (StudentTO) obj;
     if (stuId == null) {
         if (other.stuId != null)
            return false;
     } else if (!stuId.equals(other.stuId))
        return false;
     return true; 
  }

  public StudentTO(String stuId) {
    super();
    this.stuId = stuId;
  }
  
   
   
   
}