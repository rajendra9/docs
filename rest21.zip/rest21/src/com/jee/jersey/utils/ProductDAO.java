package com.jee.jersey.utils;


import javax.persistence.Persistence;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;


public class ProductDAO {
  EntityManager em;
  EntityTransaction trans;
  
  public ProductDAO() {
    super();
    try {
      EntityManagerFactory factory =
              Persistence.createEntityManagerFactory("myDB");
      em = factory.createEntityManager();
    }catch(Exception ex){
        ex.printStackTrace();
    }
  }
  
  public boolean saveProduct(ProductDTO prod){
      boolean ret = false;
      trans = em.getTransaction();
      try {
        trans.begin();
        em.persist(prod);
        ret = true;
        trans.commit();
      }catch(Exception ex){
       trans.rollback();   
       ex.printStackTrace();
      }
      return ret;
   }
  
   public String getProduct(int id){
      String ret = "";
      trans = em.getTransaction();
      try {
        trans.begin();
        ProductDTO prod = 
            em.getReference(ProductDTO.class, new Integer(id));
        ret = prod.toString();
        trans.commit();
      }catch(Exception ex){
        trans.rollback();  
        ex.printStackTrace();
      }
      return ret;
   }
   
    
}
