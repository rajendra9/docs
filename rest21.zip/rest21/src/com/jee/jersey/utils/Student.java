package com.jee.jersey.utils;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlAccessType;


@XmlType(name="student",propOrder={"stuId","stuName", "course","address"})
@XmlAccessorType(value=XmlAccessType.PUBLIC_MEMBER)
public class Student {

    private String stuId;
    private String stuName;
    private String course;
    private String address;

  
    public Student(){}   
   
  
    public String getStuId() {
        return stuId;
    }
    
    @XmlElement(required=true)
    public void setStuId(String stuId) {
        this.stuId = stuId;
    }

    public String getStuName() {
        return stuName;
    }
    
    @XmlElement(required=true)
    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public String getCourse() {
        return course;
    }

    @XmlElement(required=true)
    public void setCourse(String course) {
        this.course = course;
    }  
    
    public String getAddress() {
        return address;
    }
    
    @XmlElement(required=true)  
    public void setAddress(String address)  {
        this.address = address;
    }


	public Student(String stuId, String stuName, String course, String address) {
		super();
		this.stuId = stuId;
		this.stuName = stuName;
		this.course = course;
		this.address = address;
	}
    
     

}