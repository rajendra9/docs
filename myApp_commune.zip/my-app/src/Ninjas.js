import React, { Component } from 'react';

class Ninjas extends Component{
  render() {
      return(
          <div className="ninjas">
            <div>Name: Sandeep</div>
            <div>Course: Karate</div>   
            <div>Belt: Black</div>
          </div>    
      )
  }
}

export  default Ninjas;