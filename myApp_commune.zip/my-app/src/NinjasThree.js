import React, { Component } from 'react';

class NinjasThree extends Component{
  render() {
     const ninjas = this.props.ninjas;
     return(
          < table align='center'>
            <tbody>
          {
              ninjas.map((ninja)=>{
              return <tr key={ninja.id}><td>{ninja.name}</td>
              <td>{ninja.course}</td>
              <td>{ninja.belt}</td>
              </tr>
            })              
          }   
          </tbody>
          </table> 
      )
  }
}

export  default NinjasThree;