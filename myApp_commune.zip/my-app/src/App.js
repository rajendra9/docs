import React, { Component } from 'react';

import './App.css';
import Ninjas from './Ninjas';
import NinjasTwo from './NinjasTwo';
import NinjasThree from './NinjasThree';

class App extends Component {
    state = {
      ninjaList: [
          {id: 1, name: 'Rayanna', course: 'Boxing', belt: 'Red'},
          {id: 2, name: 'David', course: 'Kick Boxing', belt: 'Green'},
          {id: 3, name: 'Sukaro', course: 'Muay Thai', belt: 'Blue'}
      ]
           
    }
  
  
  render() {    
    
    return (
      <div className="App">
       <Ninjas/><br/>
       <NinjasTwo name="Bijoy" course="karate" belt="Yellow"/><br/>
       <NinjasTwo name="Samarth" course="Judo" belt="Orange"/><br/><br/>
       <NinjasThree ninjas={this.state.ninjaList} />

      </div>
    );
  }
}

export default App;
