import React, { Component } from 'react';

class NinjasTwo extends Component{
  render() {
     /*console.log(this.props);
      to make them (props) available as  
      should have same names
      */
     const { name, course, belt} = this.props;
     return(
          <div className="ninjas">
            <div>Name: {name}</div>
            <div>Course: {course}</div>   
            <div>Belt: {belt}</div>
          </div>    
      )
  }
}

export  default NinjasTwo;