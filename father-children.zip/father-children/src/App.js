import React, { Component } from 'react';

import './App.css';
import ShowHomes from './components/showHomes';
import AddHome from './components/addHome';

class App extends Component {
  
  state = {
    homeList: [
       {id: 1, location: 'Mahendra Hills', area: '560 sq yrds', constructed: '1200ft'},
       {id: 2, location: 'Red Hills', area: '520 sq yrds', constructed: '1220ft'} 
    ]         
  }
 addAHome = (newHome) => {
   newHome.id = Math.round(1000 * Math.random());
   //const listCopy = Object.assign([], this.state.homeList);
   const listCopy = [...this.state.homeList, newHome];
   //listCopy.push(newHome);
   this.setState({homeList: listCopy});
   //console.log(newHome);
 }
 deleteAHome= (homeId) => {
  const listCopy = [ ...this.state.homeList ]
  let filtered = listCopy.filter((home)=>{
    return (home.id !== homeId);
  });
  this.setState({homeList: filtered});
  
 //console.log(homeId);
 }

render() {    
  
  return (
    <div className="App">
      <AddHome addHome={this.addAHome}/> <br/>
     <ShowHomes deleteHome={this.deleteAHome} homes={this.state.homeList} />

    </div>
  );
}

}

export default App;
