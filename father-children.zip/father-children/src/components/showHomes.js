import React from 'react';

const ShowHomes = (props) => {
     const homes = props.homes;
     const del = props.deleteHome;
     return(
            
          < table align='center'>
            <caption>Home's Details</caption>
            <tbody>
               {
              homes.map((home)=>{
              return <tr key={home.id}><td>{home.location}</td>
              <td>{home.area}</td>
              <td>{home.constructed}</td>
              <td><button onClick={()=> {del(home.id)}}>Delete Home</button></td>
              </tr>
            })              
          }   
          </tbody>
          </table> 
      )
  
}

export  default ShowHomes;