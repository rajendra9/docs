import React, { Component }  from 'react';


class AddHome extends Component {
    state = {
        location: null,
        area: null,
        constructed: null
    }
    handleChange=(event)=>{
        this.setState({
          [event.target.id]: event.target.value  
        });
    }
    handleSubmit = (event) => {
        event.preventDefault();
       // console.log(this.state);
       this.props.addHome({location: this.state.location,
                           area: this.state.area,
                           constructed:this.state.constructed});
    }
    render(){
        return(
         <div align='center'>
             <h2>Adding a New Home</h2>
          <form onSubmit={this.handleSubmit}>
              <table><tbody>
                  <tr>
                   <td><label htmlFor="location">Enter Location:</label></td>
                   <td><input type='text' id="location" onChange={this.handleChange}/></td>                 
                  </tr>
                  <tr>
                   <td><label htmlFor="area">Enter Area Of House:</label></td>
                   <td><input type='text' id="area" onChange={this.handleChange}/></td>                 
                  </tr>
                  <tr>
                   <td><label htmlFor="constructed">Enter Constructed Plinth Area</label></td>
                   <td><input type='text' id="constructed" onChange={this.handleChange}/></td>                 
                  </tr>                  
               </tbody></table>
               <br/>
               <hr/>
               <button type="submit"> Add Home</button>
          </form>
         </div>
        )
    }
}
export default AddHome;