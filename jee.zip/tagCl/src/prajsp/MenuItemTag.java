package prajsp;

import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.JspTagException;

@SuppressWarnings("serial")
public class MenuItemTag extends TagSupport  {

 private String name;

 public void setName(String newName) {
  name = newName;
 }
   
 public int doStartTag() throws JspTagException {
   MenuTag menu = (MenuTag)this.getParent(); 
   menu.addNavigator(name);
   return SKIP_BODY;
 }


}