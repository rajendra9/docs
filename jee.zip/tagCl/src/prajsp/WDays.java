package prajsp;

import java.util.ArrayList;
import  java.text.DateFormatSymbols;

public class WDays {
  public ArrayList<String> days;
  public WDays()
   {
    days=new ArrayList<String>();
    DateFormatSymbols dfs=new DateFormatSymbols();
    String[] wds=dfs.getWeekdays();
    for(int i=0;i<wds.length;i++) {
       days.add(wds[i]);
    }       
   }

   public ArrayList<String> getDays() {
     return days;
   }
  
   public void setDays(ArrayList<String> newDays) {
      days = newDays;
   }

}  
    