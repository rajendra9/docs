package prajsp;

import java.util.ArrayList;

@SuppressWarnings("serial")
public class CourseVO implements Comparable<CourseVO>, java.io.Serializable {
  int                      courseId;
  String                   courseName;
  ArrayList<StudentVO>     students;
  
  public CourseVO()
  {
   students = new ArrayList<StudentVO>();
   }
  
  public CourseVO(int courseId, String courseName)
  {
	super();
	this.courseId = courseId;
	this.courseName = courseName;
        students = new ArrayList<StudentVO>();
                   
  }

  public int getCourseId() {
	return courseId;
  }

  public int compareTo(CourseVO arg0){
	return new Integer(this.courseId).compareTo(arg0.courseId);
  }	 

  public void setCourseId(int courseId) {
	this.courseId = courseId;
  }

  public String getCourseName() {
	return courseName;
  }

  public void setCourseName(String courseName) {
	this.courseName = courseName;
  }
  
  public ArrayList<StudentVO> getStudents() {
	return students;
  }

  public void setStudents(ArrayList<StudentVO> students) {
	this.students = students;
  }

  public void addStudent(StudentVO student) {
   getStudents().add(student);
  }

  public String toString() {
	StringBuffer sb = new StringBuffer();
	sb.append("Id:"+courseId+" Name:"+courseName);
	sb.append(" students are:"+students);
	return sb.toString();
  }

}
