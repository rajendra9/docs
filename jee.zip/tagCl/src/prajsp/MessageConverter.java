package prajsp;

public class MessageConverter {

 public static String getMessage(String id) {
  String ret = "";
  int messageId = Integer.parseInt(id); 

  switch(messageId) {

   case 1: ret = "Wish you best of luck";
                  break;
   case 2: ret = "Many Happy returns of the day";
                 break;
   case 3: ret = "Congratulations on your success";
                   break;
   case 4: ret = "Keep it up,further successes"+
                 " in offing";
                   break; 
   default: ret="All The Best";
                 break;
  }
   return ret;
 }

}