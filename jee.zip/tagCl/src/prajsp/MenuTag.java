package prajsp;

import java.io.IOException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class MenuTag extends TagSupport {
 
 private List<String> list;
   
 private String navigation;
  
 public MenuTag() {
  list = new ArrayList<String>();
 }

 public void setNavigation(String newNav) {
  navigation = newNav;
 }
   
 public void addNavigator(String n) {
  list.add(n);
 }

 public int doStartTag()throws JspTagException {      
  return  EVAL_BODY_INCLUDE;
 }

 public int doEndTag()throws JspTagException {      
  try {
   JspWriter out = pageContext.getOut();
   out.write("<h2>"+navigation+" Navigations</h2>");
   for(String s : list) {       
    out.write("<br><a href='"+s+".jsp' >"+
              "navigation to "+s+"</a><br>");       
   }
  }
  catch(IOException e) {
   throw new  
      JspTagException("Fatal Error:no write to jsp out");
  }      
  return  EVAL_PAGE;
 }

  public void release() {
    list.clear();
  }

}