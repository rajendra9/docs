package prajsp;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public class ShopItems implements Serializable {
   List<ShopItem> itemsList = new ArrayList<>();
   private ShopItem shopItem;
   
 
   public void setShopItem(ShopItem shopItem) {
       this.shopItem = shopItem;
       this.itemsList.add(shopItem);
   }

   public List<ShopItem> getItemsList() {
      return itemsList;
   }

   public void setItemsList(List<ShopItem> itemsList) {
       this.itemsList = itemsList;
   }

   public ShopItem getShopItem() {
	  return shopItem;
   }   
    
}
