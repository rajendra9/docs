package prajsp;

@SuppressWarnings("serial")
 public class StudentVO implements 
      Comparable<StudentVO>,java.io.Serializable {
  int     stuId;
  String  stuName;
  String  address;
  
  public StudentVO(){}
  
  public StudentVO(int stuId, String stuName) {
	super();	
	this.stuId = stuId;
	this.stuName = stuName;
  }

  public String getAddress() {
	return address;
  }
  
  public void setAddress(String address) {
	this.address = address;
  }
  
  public int getStuId() {
	return stuId;
  }

  public void setStuId(int stuId) {
	this.stuId = stuId;
  }

  public String getStuName() {
	return stuName;
  }

  public void setStuName(String stuName) {
	this.stuName = stuName;
  }

  public int compareTo(StudentVO other) {
	 return this.stuId-other.stuId;
  }
	
  public String toString() {
	StringBuffer sb = new StringBuffer();
	sb.append("Id:"+stuId+" Name:"+stuName);
	sb.append(" address:"+address.trim());
	return sb.toString();
  }
  
 }
