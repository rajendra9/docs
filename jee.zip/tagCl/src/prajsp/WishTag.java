package prajsp;

import java.io.IOException;

import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class WishTag extends SimpleTagSupport {
   private String name;

  public void setName(String name) {
	  this.name = name;
  }
  public void doTag() throws JspException,IOException {
	  JspContext ctx = this.getJspContext();
	  JspWriter out = ctx.getOut();
      String result = "Hi, " + name + " Welcome to Tag Libraries"; 
      out.println(result);
      out.flush();
  }
}
