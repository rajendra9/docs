package prajsp;

import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class  MarksEntryTag   extends  SimpleTagSupport {

 private String student;
 private String[] subjects; 
   
 public void setStudent(String student) {
    this.student = student;
 }

 public void setSubjects(String[] subjects) {
    this.subjects = subjects;
 }

 public void doTag() throws JspException {
  try {
   JspContext ctx = getJspContext();
   JspWriter out = getJspContext().getOut(); 
   
   out.println("<h1>");
   getJspBody().invoke(out);
   out.println("</h1>");
   out.println("<form action='entered.jsp' method='post'>");
   out.println("<table cellspacing='5' cellpadding='5'>");
   for(int i=0;i<this.subjects.length;i++) {
     out.println("<tr><td>Marks for "+subjects[i]+":&nbsp;</td>");
     out.println("<td><input type='text' name='marks' /></td></tr>");
   }
   out.println("</table><br/><hr/>");
   out.println("<input type='submit'/></form>");
   ctx.setAttribute("name",this.student,PageContext.SESSION_SCOPE);
   ctx.setAttribute("subjects",this.subjects,PageContext.SESSION_SCOPE);

  }
  catch(Exception e){
   e.printStackTrace(); 
  }
 }

}