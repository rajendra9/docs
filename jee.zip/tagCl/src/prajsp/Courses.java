package prajsp;

import java.util.ArrayList;

@SuppressWarnings("serial")
public class Courses extends ArrayList<CourseVO> {

 ArrayList<StudentVO> eec = new ArrayList<StudentVO>();
 ArrayList<StudentVO> eee = new ArrayList<StudentVO>();
 ArrayList<StudentVO> cec = new ArrayList<StudentVO>();
 CourseVO cvo = null;
 public Courses() {
  eec.add(new StudentVO(100,"Satish"));
  eec.add(new StudentVO(200,"Krishnan"));
  eec.add(new StudentVO(300,"Mukund"));
  
  eee.add(new StudentVO(400,"Lalitha"));
  eee.add(new StudentVO(500,"HansRaj"));
  eee.add(new StudentVO(600,"Damodaran")); 
  
  cec.add(new StudentVO(700,"UttaraKumar"));
  cec.add(new StudentVO(800,"Ramesh"));
  cec.add(new StudentVO(900,"AlagRaj"));
  cvo = new CourseVO(120,"EEC");
  cvo.setStudents(eec);
  add(cvo);
  cvo = new CourseVO(130,"EEE");
  cvo.setStudents(eee);
  add(cvo);
  cvo = new CourseVO(140,"CEC");
  cvo.setStudents(cec);
  add(cvo);  
 }
 
}