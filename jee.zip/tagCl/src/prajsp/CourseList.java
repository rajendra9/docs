package prajsp;

import java.util.ArrayList;


@SuppressWarnings("serial")
public class CourseList extends ArrayList<String> {

	public CourseList()
	{
	  add("B.Sc");
	  add("B.A");
	  add("B.Com");
	  add("BCA");
          add("MCA");
	}

	
}
