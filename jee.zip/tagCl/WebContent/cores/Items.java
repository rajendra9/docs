package corehelper;
import java.util.*;
public class Items extends ArrayList<Integer>
 {
  public Items()
   {
    super();
    for(int i=0;i<10;i++)
     add(new Integer(i+1));
    }
} 
    