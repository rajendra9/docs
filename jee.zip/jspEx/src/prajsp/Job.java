package prajsp;

public enum Job {
   CLERK, SUPERVISOR, FOREMAN, ASST_MANAGER, DY_MANAGER, MANAGER;
}
