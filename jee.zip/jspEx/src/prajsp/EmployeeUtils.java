package prajsp;

import java.io.Serializable;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
@SuppressWarnings("serial")
public class EmployeeUtils implements Serializable {
    
  List<Employee> emps = new ArrayList<>();
  {
    Collections.addAll(emps,
       new Employee(120, "Sameer", 18500.5, Job.SUPERVISOR, Gender.MALE, Dept.STORES ),
       new Employee(130, "Manoharan", 23500.5, Job.ASST_MANAGER, Gender.MALE,  Dept.PRODUCTION ),
       new Employee(140, "Ganapathy", 16500.5, Job.CLERK, Gender.MALE, Dept.PURCHASE ),
       new Employee(150, "Sethupathy", 22500.5, Job.ASST_MANAGER, Gender.MALE, Dept.SHIPPING ),
       new Employee(160, "Venkat Rao", 28500.5, Job.DY_MANAGER, Gender.MALE, Dept.FINANCE ),
       new Employee(170, "Manimaran", 26500.5, Job.DY_MANAGER, Gender.MALE, Dept.PURCHASE ),
       new Employee(180, "Vasanthi", 20500.5, Job.FOREMAN, Gender.FEMALE, Dept.DISPATCH ),
       new Employee(190, "Mrinalini", 17500.5, Job.SUPERVISOR, Gender.FEMALE, Dept.STORES ),
       new Employee(200, "Madivanan", 24500.5, Job.ASST_MANAGER, Gender.MALE, Dept.PRODUCTION ),
       new Employee(210, "Gunasekharan", 18500.5, Job.CLERK, Gender.MALE, Dept.PURCHASE ),
       new Employee(220, "Madhavi", 23500.5, Job.ASST_MANAGER, Gender.FEMALE, Dept.SHIPPING ),
       new Employee(230, "Subba Rao", 29500.5, Job.DY_MANAGER, Gender.MALE, Dept.FINANCE ),
       new Employee(240, "Manikantan", 24500.5, Job.DY_MANAGER, Gender.MALE, Dept.PURCHASE ),
       new Employee(250, "Vimala", 21500.5, Job.FOREMAN, Gender.FEMALE, Dept.DISPATCH )
       );
      }
	 
      public String getRounded(double input){
	NumberFormat numFormat = NumberFormat.getInstance();
	DecimalFormat deciFormat = new DecimalFormat();
	if(numFormat instanceof DecimalFormat){
	  deciFormat = (DecimalFormat)numFormat;  	
	}
	deciFormat.applyPattern("####00000.00");
        return deciFormat.format(input);
       }

       public List<Employee> getEmps() {
         return emps;
       }

       public void setEmps(List<Employee> emps) {
          this.emps = emps;
       }
	 
	 
}
