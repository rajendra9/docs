package prajsp;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
@SuppressWarnings("serial")
public class DateUseBean implements Serializable {
    private Date  dbDate;
    SimpleDateFormat sdf;
    private String dob; 
    {
      sdf = new SimpleDateFormat("yyyy-MM-dd");
    }

    @Override
	public String toString() {
		return "DateUseBean [dbDate=" + dbDate + ", sdf=" + sdf + ", dob=" + dob + "]";
	}

	public String getDob() {
        return sdf.format(dbDate);
    }

    public void setDob(String dob) {
        this.dob = dob;
        try{
          dbDate = sdf.parse(dob);  
        }catch(ParseException pe){
          throw new RuntimeException(pe.getMessage());  
        }
    }

    public Date getDbDate() {
        return dbDate;
    }

    public void setDbDate(Date dbDate) {
        this.dbDate = dbDate;
    }
    
    
    
}
