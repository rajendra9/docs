package prajsp;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class MyBean implements java.io.Serializable {
 
 private String myName;
 private String course;
 private Map<String,String> map;
 private List<String> names;

 public MyBean() {
  myName = "sunder";
  map = new HashMap<String,String>();
  map.put("1","Venkat");
  map.put("two","Anish Kumar");
  map.put("three","Ashok ayyappan");
  map.put("four","Mahesh Raja");
  map.put("five","Sujana");

  names = new  ArrayList<String>();
  names.add("Tamilnadu");
  names.add("Andhra Pradesh");
  names.add("Delhi");
 }
  
 public void setMap(Map<String,String> newMap) {
  map = newMap;
 }
 
 public Map<String,String> getMap() {
  return map;
 }

 public void setNames(List<String> newNames) {
  names = newNames;
 }
 
 public List<String> getNames(){
  return names;
 }
 
 public void setMyName(String str) {
  myName = str;
 }

 public String getCourse() {
  return course;
 }
   
 public void setCourse(String str) {
  course = str;
 }
   
 public String getMyName() {
  return myName;
 }

 public String upper(String str) {
  return str.toUpperCase();
 }
 
}