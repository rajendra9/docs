package prajsp;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.sql.DataSource;
import javax.naming.InitialContext;
import java.io.Serializable; 

@SuppressWarnings("serial")
public class DataAccessBean implements Serializable {
 
 Connection con;
 Statement stmt;
 ResultSet rs;
 ResultSetMetaData rsmd;
 PreparedStatement pstmt = null;
 int result = 0;

 public void setConnection() {
  try {
   InitialContext ctx = new InitialContext();
   DataSource ds = 
       (DataSource)ctx.lookup("java:comp/env/jdbc/myPostgres");
   con = ds.getConnection();
   stmt = con.createStatement();
  }
  catch(Exception e) {
   System.out.println(e.getMessage());
  }
 }
 
 
 public String getResults(String table)throws SQLException {
  StringBuffer sb = new StringBuffer(200);
  rs = stmt.executeQuery("select * from "+table);
  rsmd = rs.getMetaData();    
  int colcnt = rsmd.getColumnCount();
  for(int i=0;i<colcnt;i++) {
   sb.append("<span style='text-decoration:underline;'>" 
         + rsmd.getColumnName(i + 1) + "&nbsp;&nbsp;</span>");
  }
  sb.append("<br>");
  while(rs.next()) {
   for(int i=0;i<colcnt;i++) {
    sb.append(rs.getString(i+1) + "  ");
   }
   sb.append("<br>");
  }
   return sb.toString();
 }
 
 public void closeConnection()throws SQLException {
  if(con != null) con.close();
 }

}