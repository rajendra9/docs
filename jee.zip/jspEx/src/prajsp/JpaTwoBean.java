package prajsp;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

@SuppressWarnings("serial")
public class JpaTwoBean implements Serializable {
	
  EntityManager em;
  EntityTransaction trans;
    
  public JpaTwoBean() {
    EntityManagerFactory factory = 
      Persistence.createEntityManagerFactory("myDB");
    em = factory.createEntityManager();		
  }     

	
  public boolean saveDocument(DocumentTO docTO, String[] topics) {
    boolean  ret = false;
    List<String> topicList = docTO.getTopics();
    for(String topic : topics) {
     topicList.add(topic);
    }	
    trans = em.getTransaction();
    try {
     trans.begin();
     em.persist(docTO);
     ret = true;
     trans.commit();	  
    }catch(Exception ex) {
      ex.printStackTrace();
      trans.rollback();
    }           
    return  ret;
  }

  public List<DocumentTO> getDocuments() {
   List<DocumentTO> list = new ArrayList<DocumentTO>(); 
   trans = em.getTransaction();
   trans.begin();
   try {
    TypedQuery<DocumentTO> qry = em.createNamedQuery("allDocs", DocumentTO.class);
    list = qry.getResultList();
    
    trans.commit();
   }catch(Exception ex) {
      trans.rollback();
   }
   return list;
 }   

}