package prajsp;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Employee implements Serializable {
   
   private  int     empNum;
   private  String  empName;
   private  double  salary;
   private  Dept    dept;
   private  Job     job;
   private  Gender  gender;   
   public Employee() {
	 super();	
   }

   public Employee(int empNum, 
		           String empName, 
		           double salary, 
		           Job job,
		           Gender gender,
		           Dept deptName
		           ) {
	 super();
	 this.empNum = empNum;
	 this.empName = empName;
	 this.salary = salary;
	 this.dept  = deptName;
	 this.gender = gender;
	 this.job = job;
   }
   

   public Gender getGender() {
	 return gender;
   }

   public void setGender(Gender gender) {
	  this.gender = gender;
   }

   public int getEmpNum() {
	  return empNum;
   }

   public void setEmpNum(int empNum) {
	  this.empNum = empNum;
   }

   public String getEmpName() {
	  return empName;
   }

   public void setEmpName(String empName) {
	  this.empName = empName;
   }

   public double getSalary() {
	  return salary;
   }
   
   public double getAnnSalary() {
		  return salary * 12;
   }

   public void setSalary(double salary) {
	  this.salary = salary;
   }

   public Dept getDept() {
	  return dept;
   }

   public void setDeptName(Dept dept) {
	  this.dept = dept;
   }

   public Job getJob() {
	  return job;
   }

   public void setJob(Job job) {
	  this.job = job;
   }

   @Override
   public int hashCode() {
	  final int prime = 31;
	  int result = 1;
	  result = prime * result + empNum;
	  return result;
   }

   @Override
   public boolean equals(Object obj) {
	  if (this == obj)
		 return true;
	  if (obj == null)
		 return false;
	  if (getClass() != obj.getClass())
		 return false;
	  Employee other = (Employee) obj;
	  if (empNum != other.empNum)
	     return false;
	   return true;
    }

    @Override
    public String toString() {
	  return "Employee [empNum=" + empNum + ", empName=" + empName + ", salary="
			+ salary + ", dept=" + dept + ", job=" + job + ", gender=" + gender
			+ "]";
    }  

}
