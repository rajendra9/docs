package prajsp;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

@SuppressWarnings("serial")
public class ReadInitParam extends TagSupport {

    String myParam;

    public void setMyParam(String myParam) {
        this.myParam = myParam;
    }

    @Override
    public int doEndTag() throws JspException {
        ServletConfig config = pageContext.getServletConfig();
        String value = config.getInitParameter(myParam);

        JspWriter out = pageContext.getOut();
        try {
            out.println(myParam + "'s value is:" + value);
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        return EVAL_PAGE;
    }

}
