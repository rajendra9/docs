package prajsp;

public enum Gender {
   MALE,FEMALE;
}
