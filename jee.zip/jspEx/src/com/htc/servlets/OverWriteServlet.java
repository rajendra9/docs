package com.htc.servlets;


import static java.nio.file.StandardOpenOption.CREATE;
import static java.nio.file.StandardOpenOption.READ;


import static java.nio.file.StandardOpenOption.WRITE;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/overWrite")
public class OverWriteServlet extends HttpServlet {
    
      public static final String FILENAME = "userDetails.dat";
      
      String sep = FileSystems.getDefault().getSeparator();
    
      protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          ServletContext stx = this.getServletContext(); 
          String loc = stx.getRealPath("/users");
          System.out.println(loc);
          Path p = Paths.get(loc+sep+FILENAME);
          Charset chSet = Charset.forName("UTF-8");
          BufferedReader in = Files.newBufferedReader(p, chSet);
          String line = in.readLine();
          System.out.println(line);
          in.close();
          Path newP = Paths.get(loc+sep+"userDetails_new.dat");
          PrintWriter out = new PrintWriter(Files.newBufferedWriter(newP, chSet, CREATE,WRITE));
          out.println("I am from next One");
          out.close();
          Files.delete(p);
          Files.move(newP, p);
          response.getWriter().println("check file ovewrite");
          response.getWriter().close();
      }

	
      protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          doGet(request,response);
      }

}
