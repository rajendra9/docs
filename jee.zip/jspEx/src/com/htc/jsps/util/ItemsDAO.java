package com.htc.jsps.util;

import java.io.Serializable;
import java.util.List;

public interface ItemsDAO extends Serializable {
   public boolean saveItem(ItemPoly item);
   public List<ItemPoly> getAllItems();
   public ItemPoly searchItem(int itemId);
}
