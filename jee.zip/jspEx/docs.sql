drop table if exists subtopics;

drop table if exists mydocs;

create table mydocs(doc_id varchar(10)primary key,
doc_desc  varchar(30),
author  varchar(20),
no_of_pages integer);

insert into mydocs values('C3211','Anthropology','Darwin',360);
insert into mydocs values('C4331','Endian History','Kapilan',550);

insert into mydocs values('C5233','Tanjore Scripts','VairaMuthu',520);

insert into mydocs values('C4843','Madurai Carvings','Vali',475);


create table subtopics(doc_id varchar(10) not null,
                             subtopic varchar(30),
 constraint subtopics_fk foreign key(doc_id) references mydocs);

insert into subtopics values('C3211','Early Days');

insert into subtopics values('C3211','Food Habits');

insert into subtopics values('C4331','Mughals');

insert into subtopics values('C4331','Hunas');

insert into subtopics values('C5233','Temple Scripts');

insert into subtopics values('C5233','Tanjore Cultivation');

insert into subtopics values('C4843','Temple Construction');

insert into subtopics values('C4843','Temple Paintings');


commit;