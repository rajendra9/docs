package prajq;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Map;
import java.util.HashMap;

@WebServlet("/forJq")
@SuppressWarnings("serial")
public class CustExistsServlet extends HttpServlet {
  Map<Integer, CustomerVO> customers;
  
  public void init() {
    customers = new HashMap<Integer,CustomerVO>();
    customers.put(100,
       new CustomerVO(100,"M/s MurugaDoss & Bros",
                      "Tambaram","23234543"));
    customers.put(200,
       new CustomerVO(200,"M/s Kamaluddin & Co",
                      "Guindy","98787665234"));
    customers.put(300,
       new CustomerVO(300,"M/s Vijay Paul & Co",
                      "Nanganallur","27654874"));
    customers.put(400,
       new CustomerVO(400,"M/s Sanjay Bangar",
                      "Nungabakkam","91234332745"));    
     
  }

  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
       throws IOException,ServletException {
   PrintWriter out = response.getWriter(); 
   response.setContentType("text/html");
   String custIdStr = request.getParameter("cid");
   int custId = Integer.parseInt(custIdStr); 
   System.out.println("MMMM"+custId); 
   String message = ""; 
   if(customers.containsKey(custId)){
     message = "<h3 style='color:red;font-weight:bold;'>"+
               " Customer already exists</h3>";
   }
   else {
         message = "<h3 style='color:blue;font-weight:bold;'>"+
               " Customer not existing</h3>";
   }
  
   out.println(message);
   out.close();
  }
  public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
       throws IOException,ServletException {
   PrintWriter out = response.getWriter(); 
   response.setContentType("text/html");
   String custIdStr = request.getParameter("cid");
   int custId = Integer.parseInt(custIdStr); 
   String custName = request.getParameter("cName");
   String location = request.getParameter("loc");
   String contact = request.getParameter("contactNum");
   CustomerVO customer = 
      new CustomerVO(custId, custName, location, contact);   
   customers.put(custId,customer); 
   String message = "<h1 style='text-align:center;color:red;'>Customer added<h1>"; 
   out.println(message);
   out.close();
  }

}