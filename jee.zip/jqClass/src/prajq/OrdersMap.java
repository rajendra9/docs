package prajq;

import java.io.Serializable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Calendar;

@SuppressWarnings("serial")
public class OrdersMap extends 
    ConcurrentHashMap<Integer,OrderVO>  
        implements Serializable {

  public OrdersMap() {
   this.populate();
  }

  public OrdersMap(int initialCapacity) {
   super(initialCapacity);
   this.populate();
  }

  private void populate() {
   GregorianCalendar gc = 
      new  GregorianCalendar(2008, Calendar.FEBRUARY, 12);
   Date dt = gc.getTime();
   OrderVO order = new OrderVO(1000, dt, "M/s Cheran Co", 3245.80);
   this.put(new Integer(order.getOrderId()), order);
     
   gc = new  GregorianCalendar(2008, Calendar.MARCH, 18);
   dt = gc.getTime();
   order = new OrderVO(2000, dt, "M/s Rally Co", 4345.80);
   this.put(new Integer(order.getOrderId()),order);
     
   gc = new  GregorianCalendar(2008, Calendar.MARCH, 28);
   dt = gc.getTime();
   order = new OrderVO(3000, dt, "M/s Vali Co", 3845.80);
   this.put(new Integer(order.getOrderId()), order);
     
   gc = new GregorianCalendar(2006, Calendar.APRIL, 12);
   dt = gc.getTime();
   order = new OrderVO(4000, dt, "M/s Velan Co", 3812.80);
   this.put(new Integer(order.getOrderId()), order);
     
   gc = new  GregorianCalendar(2006, Calendar.MAY, 13);
   dt = gc.getTime();
   order = new OrderVO(5000, dt, "M/s Alazhan Co", 3245.80);
   this.put(new Integer(order.getOrderId()), order);
     
  }

  public OrderVO getOrder(int  id) {
   return this.get(new Integer(id));
  }

}