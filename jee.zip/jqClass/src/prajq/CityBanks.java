package prajq;

import java.io.Serializable;

import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class CityBanks implements Serializable {
    

  List<String> banks;
  {
    banks = new ArrayList<>();
    banks.add("Indian Bank-Rajaji Road,Paris");
    banks.add("Indian Bank-Tambaram West");
    banks.add("Indian Bank-Selayur");
    banks.add("Indian Bank-Adyar");
    banks.add("Indian Bank-Nungambakkam");
    banks.add("Indian Bank-Medavakkam");
    banks.add("Indian Bank-Nandanam");    
    banks.add("Indian Bank-Abhiramapuram");
    banks.add("Indian Bank-Adithanadsalai");
    banks.add("Indian Bank-Alwarpet");
    banks.add("Indian Bank-Anna Salai");
    banks.add("Indian Bank-Anna Nagar");
    banks.add("Indian Bank-Arumbakkam");
    banks.add("Indian Bank-AshokNagar");
    banks.add("Indian Bank-Asiad Colony");
    banks.add("Indian Bank-Ayanavaram");
    banks.add("Indian Bank-BesantNagar");
    banks.add("Indian Bank-Chetpet");
    banks.add("Indian Bank-ChindriPet");
    banks.add("Indian Bank-Chetlapakam");
    banks.add("Indian Bank-Cholaimedu");    
    banks.add("Indian Bank-ClockTower");
    banks.add("Indian Bank-CMDA");
    banks.add("Indian Bank-CMS-HUB-Chennai");
    banks.add("Indian Bank-DOTE Campus");
    banks.add("Indian Bank-CORPORATE BRANCH CHENNAI");
    banks.add("Indian Bank-DB JAIN COLLEGE BR");
    banks.add("Indian Bank-Dr. Alagappa Road");
    banks.add("Indian Bank-Dr.R K Salai");
    banks.add("Indian Bank-East Abiramapuram");
    banks.add("Indian Bank-East Raja Annamalaipuram");
    banks.add("Indian Bank-DOTE Campus");
    banks.add("Indian Bank-EGMORE");
    banks.add("Indian Bank-ENNORE");
    banks.add("Indian Bank-Erukkancherri");
    banks.add("Axis Bank-Purasawalkam");
    banks.add("Axis Bank-SAIDAPET");
    banks.add("Axis Bank-SALIGRAMAM");
    banks.add("Axis Bank-KOYAMBEDU");
    banks.add("Axis Bank-KOTTURPURAM");
    banks.add("Axis Bank-RATAN BAZAAR");
    banks.add("Axis Bank-T.Nagar");
    banks.add("Axis Bank-TEYNAMPET");
    banks.add("Axis Bank-THIRUVOTTRIYUR");
    banks.add("Canara Bank-RADHA NAGAR");
    banks.add("Canara Bank-SANTHOME HIGH ROAD");
    banks.add("Canara Bank-ABHIRAMAPURAM");
    banks.add("Canara Bank-ANNANAGAR");
    banks.add("Canara Bank-BESANTNAGAR");
    banks.add("Canara Bank-ASHOK NAGAR");
    banks.add("Canara Bank-AMBATTHUR");
    banks.add("Canara Bank-NRI BRANCH");
    banks.add("Canara Bank-BROADWAY");
  } 
  
  public String getBanks(){
    StringBuilder sb = new StringBuilder("[");
    int len = banks.size();
    for(int i=0;i<len;i++){
     String str = banks.get(i);
     if(i==(len-1)){               
       sb.append("\""+str+"\""); 
     }
     else{
       sb.append("\""+str+"\",");  
     }
    }       
    sb.append("]");
    return sb.toString();
   }   
  
}
