package prajq;

import java.io.Serializable;

@SuppressWarnings("serial")
public class CustomerVO implements Serializable,Comparable<CustomerVO> {

  private  int        custId;
  private  String     custName;
  private  String     address;
  private  String     contact;
        
  public CustomerVO(int id, String name,
     String address, String contact) {
   super();
   this.custId = id;
   this.custName = name;
   this.address = address;
   this.contact = contact;
  }

  public CustomerVO(){}
        
  public int compareTo(CustomerVO customer) {
   return this.custId-customer.custId;
  }

  public String getAddress() {
   return address;
  }

  public void setAddress(String address){
   this.address = address;
  }

  public String getCustName() {
   return custName;
  }

  public void setCustName(String name){
   this.custName = name;
  }

  public String getContact() {
   return contact;
  }

  public void setContact(String contact) {
   this.contact = contact;
  }

  public int getCustId() {
   return custId;
  }

  public void setCustId(int custId) {
    this.custId = custId;
  }

  @Override
  public int hashCode() {
   final int PRIME = 31;
   int result = 1;
   result = PRIME * result + custId;
   return result;
  }

  @Override
  public boolean equals(Object obj) {
   if (this == obj)
    return true;
   if (obj == null)
    return false;
   if (getClass() != obj.getClass())
    return false;
   final CustomerVO other = (CustomerVO) obj;
   if (custId != other.custId)
    return false;
   return true;
  }

  @Override
  public String toString() {        
   return this.custId+"::"+this.custName+"::"+this.address+"::"+this.contact;
  }
        
}