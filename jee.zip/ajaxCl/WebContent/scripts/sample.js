

function getRequestObject() {
   if(window.ActiveXObject) {
    return (new ActiveXObject("Microsoft.XMLHTTP"));
   }
   else if(window.XMLHttpRequest) {
    return (new XMLHttpRequest());
   }
   else {
     return (null);
   }
 }

 function addToUrl(url,name,id){
  var elem = document.getElementById(id);
  var val = encodeURIComponent(elem.value);
  url = url+name+"="+val; 
  return url;
 }

 function sendRequest(address,id) {
  var request = getRequestObject();
  
  request.onreadystatechange =
    function(){ handleResponse(request,id); }
  
  request.open("GET" , address, true);
  
  request.send(null);
 }

 function handleResponse(request,id) {
  if((request.readyState==4) && 
     (request.status==200)) { 
   var content = request.responseText;   
   alert(content);
   updatePage(id,content);
  }
 }

 function updatePage(id,content) {
  var divNode = document.getElementById(id);
  divNode.innerHTML=content;
 }
  
  
