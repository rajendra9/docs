drop table enamelist;

create  table enamelist(id integer primary key,
empname  varchar(20));

insert into enamelist  values(1,'Samuel');
insert into enamelist  values(2,'Santanu');
insert into enamelist  values(3,'Samy');
insert into enamelist  values(4,'Samson');
insert into enamelist  values(5,'Salora');
insert into enamelist  values(6,'Sameer');
insert into enamelist  values(7,'Sandeep');
insert into enamelist  values(8,'Saralan');
insert into enamelist  values(9,'Manish');
insert into enamelist  values(10,'Maruthu');
insert into enamelist  values(11,'Madivanan');
insert into enamelist  values(12,'Mouli');
insert into enamelist  values(13,'Meera');
insert into enamelist  values(14,'Meena');
insert into enamelist  values(15,'Muthu');
insert into enamelist  values(16,'Madhavan');
insert into enamelist  values(17,'Mandira');
insert into enamelist  values(18,'Mrinalini');

commit;
