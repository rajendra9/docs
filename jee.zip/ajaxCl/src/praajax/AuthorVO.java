package praajax;

import java.io.Serializable;

@SuppressWarnings("serial")
public class AuthorVO implements Serializable,
     Comparable<AuthorVO> {
 private int     ISAN;
 private String  name;
 private String  authorField;
 private String  publisher;
    
 public AuthorVO(int ISAN, String name, String authorField) {
  super();
  this.ISAN = ISAN;
  this.name = name;
  this.authorField = authorField;
 }

 public AuthorVO() {}

 public int compareTo(AuthorVO o) {       
  return this.ISAN-o.ISAN;
 }

 public String getAuthorField() {
  return authorField;
 }

 public void setAuthorField(String authorField) {
  this.authorField = authorField;
 }

 public String getName() {
  return name;
 }

 public void setName(String name) {
  this.name = name;
 }

 public String getPublisher() {
        return publisher;
 }

 public void setPublisher(String publisher) {
  this.publisher = publisher;
 }

 @Override
  public String toString() {        
   return this.ISAN+":"+this.name+":"+
          this.authorField+":"+this.publisher;
  }

  public int getISAN(){
   return ISAN;
  }

  public void setISAN(int isan) {
   ISAN = isan;
  }

  @Override
  public int hashCode() {
   final int PRIME = 31;
   int result = 1;
   result = PRIME * result + (ISAN ^ (ISAN >>> 32));
   return result;
  }

  @Override
  public boolean equals(Object obj) {
   if (this == obj)
    return true;
   if (obj == null)
    return false;
   if (getClass() != obj.getClass())
    return false;
   final AuthorVO other = (AuthorVO) obj;
   if (ISAN != other.ISAN)
    return false;
   return true;
  }

}