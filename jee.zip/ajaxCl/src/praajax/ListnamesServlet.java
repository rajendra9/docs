package praajax;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import praajax.jdbc.EnamesDAO;

@WebServlet("/listNames")
@SuppressWarnings("serial")
public class ListnamesServlet extends HttpServlet {
	
  private EnamesDAO dao;
  	
	
  public void init() throws ServletException {
    dao = new EnamesDAO();
  }


  public void destroy() {
    dao = null;
  }

  protected void doGet(HttpServletRequest request,
                       HttpServletResponse response) 
     throws ServletException, IOException {
     String patt = request.getParameter("pattern");
     System.out.println("..."+patt);
     PrintWriter out = response.getWriter();
     response.setContentType("application/xml");
     String list = dao.getNames(patt);
     System.out.println("%%%"+list);
     out.println("<names>"+list+"</names>");
     out.flush();
  }

  protected void doPost(HttpServletRequest request,
                        HttpServletResponse response) 
      throws ServletException, IOException {
      PrintWriter out = response.getWriter();
      out.println("<center>The name is to be added</center>");
      out.close();  
  }

}