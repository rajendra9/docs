package  praajax;

import  java.io.IOException;
import  java.io.PrintWriter;
import  javax.servlet.http.HttpServletResponse;
import  javax.servlet.http.HttpServletRequest;
import  javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import  javax.servlet.http.HttpServlet;

@WebServlet("/ajaxPost")
@SuppressWarnings("serial")
public class AjaxPostServlet  extends HttpServlet  {
   
 public static final String OK = "<message>valid</message>";
 public static final String NOTOK = "<message>invalid</message>";

 public void doPost(HttpServletRequest req,
                    HttpServletResponse res)
   throws IOException,ServletException {      
   String  uname = req.getParameter("id");
   System.out.println("llll "+uname);
   res.setContentType("text/xml");
   res.setHeader("Cache-Control","no-cache");
   PrintWriter out = res.getWriter();
   if(  uname.equalsIgnoreCase("prasad")
      ||uname.equalsIgnoreCase("santosh")
      ||uname.equalsIgnoreCase("narayanan")
      ||uname.equalsIgnoreCase("venkat")) {
    out.write(OK);
   }
   else {
    out.write(NOTOK);
   }
   out.close(); 
  }
    
  public void doGet(HttpServletRequest req,
                    HttpServletResponse res)
   throws IOException, ServletException {   
   res.setContentType("text/html");  
   PrintWriter out = res.getWriter();
   String  uname = req.getParameter("id");
   String  pwd = req.getParameter("pwd");
   out.println("<center><h1>Hi! "+uname+
               " Welcome to ajax validation<br>");
   out.println(" Your new password is:"+pwd+"</h1>");
   out.println("</center>");
   out.close(); 
  }

}