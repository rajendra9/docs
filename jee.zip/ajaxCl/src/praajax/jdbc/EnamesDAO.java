package praajax.jdbc;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.naming.InitialContext;
import javax.sql.DataSource;

@SuppressWarnings("serial")
public class EnamesDAO implements Serializable {
  private String url = "java:comp/env/jdbc/postgres";
  private Connection conn;
  
  public EnamesDAO() {
   try {
     InitialContext ctx = new InitialContext();
     DataSource ds = (DataSource)ctx.lookup(url);
     conn = ds.getConnection();
   }catch(Exception e) {
      e.printStackTrace();
   }
  }

  public String getNames(String pattern) {
   String ret = "";
   pattern = pattern.toLowerCase();
   String sql = "select empname from enamelist "+
                " where lower(empname) like '"+pattern+"%'";
   try {
     Statement stmt = conn.createStatement();
     ResultSet rs = stmt.executeQuery(sql);
     int count = -1;
     while(rs.next()) {
      if(count >= 0) {
       ret += "|"+rs.getString(1);	  
      }
      else {
       ret += rs.getString(1);
      }
      count++;
     }
   }catch(Exception e) {
     e.printStackTrace();  
   } 
   return ret;
 }
   
}