package praajax.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.io.Serializable; 

@SuppressWarnings("serial")
public class AjaxEmpDAO implements   Serializable {
    
 Connection conn;
 ResultSet rs;
 PreparedStatement pstmt = null;
 int result = 0;
 DataSource ds;
 ArrayList<AjaxEmpVO> emps;
 
 public AjaxEmpDAO() {
  try {
   InitialContext ctx = new InitialContext();     
   ds = (DataSource)ctx.lookup("java:comp/env/jdbc/postgres");  
   conn = ds.getConnection(); 
   emps = this.getEmployees();  
  }     
  catch(Exception e) {
   System.out.println(e.getMessage());
  }
 }

 public void closeConn()throws SQLException {
  if(conn != null) {
   conn.close();
  }
 }
 
 public int getTotalRecords() {
  int ret = 0;
  try {
      
   String sql = "select count(1) from emp ";
      
    pstmt = conn.prepareStatement(sql);
    rs = pstmt.executeQuery();
    if(rs.next()) {  
     ret = rs.getInt(1);
    } 
   }
   catch(Exception sqe) {
      System.out.println("eno not there");    
   }
   return ret;  
 }
 public ArrayList<AjaxEmpVO> getEmps() {
     return emps;
 }

 public void setEmps(ArrayList<AjaxEmpVO> emps) {
     this.emps = emps;
 }
 
 public String getEmpDetails(String empNo)
     throws SQLException  {
  StringBuffer sb = new StringBuffer(400);
  int eno = Integer.parseInt(empNo);
  System.out.println("..."+eno);  
  emps = this.getEmployees();   
  try {
   if(emps.contains(new AjaxEmpVO(eno))) {
       
    for(AjaxEmpVO emp : emps ) {
    
     if(emp.getEmpId() == eno) {
      sb.append("<employee>\n");
      sb.append("<emp-no>"+emp.getEmpId()+"</emp-no>\n");
      sb.append("<emp-name>"+emp.getEmpName()+"</emp-name>\n");
      sb.append("<emp-job>"+emp.getJob()+"</emp-job>\n");
      sb.append("<hire-date>"+emp.getHiredate().toString()+"</hire-date>\n");
      sb.append("<emp-salary>"+emp.getSalary()+"</emp-salary>\n");
      sb.append("<dept-no>"+emp.getDeptId()+"</dept-no>\n");
      sb.append("</employee>"); 
      break;
     }
    }
   }
   else {
    sb.append("<employee>\n");
    sb.append("<emp-no>Invalid employee number</emp-no>\n");
    sb.append("</employee>");
   }
  }
  catch(Exception sqe) {
   System.out.println("eno not there");    
  }  
  return sb.toString();
 }

 public ArrayList<AjaxEmpVO> getEmployees()  
  throws SQLException  {
     
  ArrayList<AjaxEmpVO> list = new ArrayList<AjaxEmpVO>();
   
  try {
   
   String sql = "select empno,ename,job,hiredate," +
                "sal,deptno from emp ";
   
   pstmt = conn.prepareStatement(sql);
   rs = pstmt.executeQuery();
   AjaxEmpVO emp = null;
   while(rs.next()) {
    emp = new AjaxEmpVO();
    emp.setEmpId(rs.getInt(1));
    emp.setEmpName(rs.getString(2));
    emp.setJob(rs.getString(3));
    emp.setHiredate(rs.getDate(4));
    emp.setSalary(rs.getDouble(5));
    emp.setDeptId(rs.getInt(6));
    list.add(emp);      
   }   
  }
  catch(Exception sqe) {
   System.out.println("eno not there");    
  }  
  return list;
 }
  
  public boolean addAnEmployee(String eNumber, String name, String job,
                               String dateStr, String sal, String dNumber) {
   
   boolean  ret = false;
   int eno = 0, dno = 0 ;
   double salary = 0.0;
   java.sql.Date date = null;
   
   eno = Integer.parseInt(eNumber);
   
   dno = Integer.parseInt(dNumber);
      
   salary = Double.parseDouble(sal);
   
   date = java.sql.Date.valueOf(dateStr);
      
        
   try {
        
     String sql = "insert into emp(empno,ename,job,hiredate," +
                      "sal,deptno) values(?, ?, ?, ?, ?, ?)";
         
     pstmt = conn.prepareStatement(sql);
     pstmt.setInt(1, eno);
     pstmt.setString(2, name);
     pstmt.setString(3, job);
     pstmt.setDate(4, date);
     pstmt.setDouble(5, salary);
     pstmt.setInt(6, dno);
     
     int result = pstmt.executeUpdate();
     System.out.println("$$$$"+result);
     if(result>0) {      
      ret = true;
     }     
    }
    catch(Exception e) {
        e.printStackTrace();
    }    
   return  ret;
  }
  
  public boolean updateAnEmployee(String eNumber, String name, String job,
                                  String dateStr, String sal, String dNumber) {
   boolean  ret = false; 
   int eno = 0, dno = 0 ;
   double salary = 0.0; 
   java.sql.Date date = null;

   eno = Integer.parseInt(eNumber);
   
   dno = Integer.parseInt(dNumber);
      
   salary = Double.parseDouble(sal); 
   
   date = java.sql.Date.valueOf(dateStr);
      

   try {

     String sql = "update emp  set ename=?, job=?, hiredate=?," +
                  " sal=?, deptno=? where empno=? ";

     pstmt = conn.prepareStatement(sql);
     pstmt.setString(1, name);
     pstmt.setString(2, job);
     pstmt.setDate(3, date);
     pstmt.setDouble(4, salary);
     pstmt.setInt(5, dno);
     pstmt.setInt(6, eno);

     int result = pstmt.executeUpdate();
     if(result>0) {      
      ret = true;
     }     
    }
    catch(Exception e) {
     e.printStackTrace();
    }    
    return  ret;
  }

  public boolean deleteAnEmployee(String eNumber) {
   boolean  ret = false;
   int eno = Integer.parseInt(eNumber);
   try {
    String sql = "delete from  emp where empno=?";

    pstmt = conn.prepareStatement(sql);
    pstmt.setInt(1, eno);

    int result = pstmt.executeUpdate();
    if(result>0) {      
     ret = true;
    }      
  }
  catch(Exception e) {
    e.printStackTrace();
  }    
  return  ret;
 }
 
} 