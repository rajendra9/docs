package praajax;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import praajax.utils.BookTypes;
import praajax.utils.ChoiceList;
import praajax.utils.Cosmetics;
import praajax.utils.Sports;

import java.util.Iterator;
import java.util.Set;
import java.util.Map;

@WebServlet("/dblList")
@SuppressWarnings("serial")
public class DoubleSelectServlet extends HttpServlet {
	

  private String retResponse(String[] arr) {
    String ret = "";
    for (int i=0;i<arr.length;i++) {
      if(!(i==arr.length-1)) {
        ret = ret+arr[i]+"|";   
      }
      else {
       ret = ret+arr[i];   
      }
    }
    return ret;
   }
	
   protected void doGet(HttpServletRequest request,
                        HttpServletResponse response)
      throws ServletException, IOException {
      PrintWriter out = response.getWriter();
      response.setContentType("text/xml");
      String[] vals = null;
      String choice = request.getParameter("choice");
      ChoiceList choiceList = null;
      if(choice != null) {
        if(choice.equalsIgnoreCase("sports")) {
          choiceList = new Sports();
        }
        else if(choice.equalsIgnoreCase("cosmetics")) {
          choiceList = new Cosmetics();
        }
        else if(choice.equalsIgnoreCase("books")) {
          choiceList = new BookTypes();
        }
        vals = choiceList.getVals();
      }
      else {
        System.out.println("No data");   
      }
      String resStr = this.retResponse(vals);
      out.println("<newList>"+resStr+"</newList>");
      out.flush();
    }

    protected void doPost(HttpServletRequest request,
	       HttpServletResponse response)
         throws ServletException, IOException {
      PrintWriter out = response.getWriter();
      out.println("<center>");
      response.setContentType("text/html");
      Map<String,String[]> map = request.getParameterMap();
      Set<Map.Entry<String,String[]>> entries = map.entrySet();
      Iterator<Map.Entry<String,String[]>> iter = entries.iterator();
      while(iter.hasNext()) {
       Map.Entry<String,String[]> entry = iter.next();
       out.println((String)entry.getKey()+"::");
       String[] vals = (String[])entry.getValue();
       out.println(vals[0]+"<br/>");
      }
       out.println("</center>");
       out.close();
    }

}