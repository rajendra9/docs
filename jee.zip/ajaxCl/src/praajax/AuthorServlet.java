package praajax;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;

@WebServlet("/addAuthor")
@SuppressWarnings("serial")
public class AuthorServlet extends HttpServlet {
   public static final String CORRECTLENGTH = 
       "<input-length>OK</input-length>";
   public static final String INCORRECTLENGTH = 
       "<input-length>NotOK</input-length>";

   public static final String EXISTS = 
       "<is-id-exists>true</is-id-exists>";
   public static final String NOTEXISTS = 
       "<is-id-exists>false</is-id-exists>";
   
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response) 
   throws ServletException, IOException {
   response.setContentType("text/xml");
   response.setHeader("Cache-Control","no-cache");
   PrintWriter out = response.getWriter(); 
   String idVal = request.getParameter("isan");
   System.out.println(idVal);
   int id = 0;
   if(idVal != null) {    
    id = Integer.parseInt(idVal);  
   }
   RegAuthors authors = new RegAuthors();
   boolean corLen = authors.isValidISBN(id);
   boolean doesExist = false;
   if(corLen) {
    doesExist = authors.isAlreadyPresent(id);
    System.out.println(".."+doesExist);
    if(doesExist) {
     out.println("<result>"+CORRECTLENGTH);
     System.out.println(CORRECTLENGTH);
     out.println(EXISTS+"</result>");
     System.out.println(EXISTS);
    }
    else {
     out.println("<result>"+CORRECTLENGTH);
     System.out.println(CORRECTLENGTH);
     out.println(NOTEXISTS+"</result>");  
     System.out.println(NOTEXISTS);
    }
   }
   else {
    out.println("<result>"+INCORRECTLENGTH+"</result>");
   }
   out.close();
  } 	
	
  public void doPost(HttpServletRequest request,
                     HttpServletResponse response) 
   throws ServletException, IOException {
   String isanStr = 
       request.getParameter("isan");
   int isan = Integer.parseInt(isanStr);
   String aName = 
       request.getParameter("authorName");
   String aField = 
       request.getParameter("authoringArea");
   String pName = 
       request.getParameter("publisherName");
   RegAuthors authors = new RegAuthors();
   AuthorVO auth = new AuthorVO(isan,aName,aField);                        
   auth.setPublisher(pName);
   authors.addAuthor(auth);
   response.setContentType("text/html");
   response.setHeader("Cache-Control","no-cache");
   PrintWriter out = response.getWriter(); 
   out.println("<center><h2>Author Added successfully");
   out.println("<br/>Added Author is:"+auth+"</h2></center>");
   out.close();
  } 
  	  	    
}