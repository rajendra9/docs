package praajax.utils;


@SuppressWarnings("serial")
public class BookTypes extends ChoiceList {
 
 public BookTypes() {
  add("JavaEE7.0");
  add("ASP.Net");
  add("DB2");
  add("Oracle11g");
 }
 
}
