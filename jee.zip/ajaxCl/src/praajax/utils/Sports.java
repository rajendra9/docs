package praajax.utils;

@SuppressWarnings("serial")
public class Sports extends ChoiceList {

 public Sports () {
  super();
  add("Cricket");
  add("Hockey");
  add("Tennis");
  add("Foot-Ball");
  add("Table-Tennis");
 }

}
