package praajax.utils;

import java.util.ArrayList;

@SuppressWarnings("serial")
public abstract class ChoiceList extends ArrayList<String> 
  implements java.io.Serializable {
 
 public String[] getVals() {
  String[]  ret = {""};
  ret = this.toArray(new String[]{" "});
  return ret;
 }
 
}
