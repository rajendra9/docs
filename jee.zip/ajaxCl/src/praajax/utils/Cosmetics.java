package praajax.utils;


@SuppressWarnings("serial")
public class Cosmetics extends ChoiceList {

 public Cosmetics () {
  super();
  add("Lakme Face Cream");
  add("Ponds Powder");
  add("Cuticura Powder");
  add("Himalaya Snow");      
 }

}
