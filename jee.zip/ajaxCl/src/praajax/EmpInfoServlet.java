package praajax;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import praajax.jdbc.AjaxEmpDAO;
import java.sql.SQLException;
import javax.servlet.http.HttpServlet; 

@WebServlet("/empInfo")
@SuppressWarnings("serial")
 public class EmpInfoServlet extends HttpServlet {
  AjaxEmpDAO dao;

  public void init()throws ServletException {
   dao = new AjaxEmpDAO();
  }

  public void doGet(HttpServletRequest request,
                   HttpServletResponse response) 
   throws ServletException, IOException {
    
   response.setContentType("text/xml");
   response.setHeader("Cache-Control","no-cache");
   PrintWriter out = response.getWriter(); 
   
   String eno = request.getParameter("eno");
   System.out.println("###"+eno);  
   
   String result = "";  
   try {
    result = dao.getEmpDetails(eno);
    System.out.println("..."+result);
   }
   catch(SQLException sqe)
   { }
   
   out.println(result);
   out.close();
 } 	

 public void destroy() {
  try {
   dao.closeConn();
  }
  catch(SQLException e){}
 }
	
  public void doPost(HttpServletRequest request,
                     HttpServletResponse response) 
    throws ServletException, IOException {
  
   response.setContentType("text/html");
   
   PrintWriter out = response.getWriter(); 
   out.println("<center><font size='+2'color='blue'>Have Seen "+
                "auto-refresh by ajax,nice is it not</font>");
   out.close();
  }   	  	    
}