update emp
set sal=12000
where empno=7788;

commit;

