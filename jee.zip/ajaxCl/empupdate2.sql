update emp
set sal=3000
where empno=7788;

commit;

