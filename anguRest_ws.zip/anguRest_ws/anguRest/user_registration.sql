drop table if exists user_registration;

create table user_registration(first_name varchar(20),
last_name  varchar(25),
username varchar(20),
password varchar(20),
role_name  varchar(20),
email varchar(55),
hobby varchar(20),
constraint users_PK primary key(email));

select * from user_registration;
delete from user_registration;