package com.jee.jersey;

import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.jee.jersey.utils.ItemDTO;
import com.jee.jersey.utils.StoreItems;

// The Java class will be hosted at the URI path "/items"
@Path("/items")
public class ItemResource {
    
    StoreItems items = new StoreItems();
    
    @GET 
    public String wish(){
        return "Welcome To ItemService";
    }
    
    // The Java method will process HTTP GET requests
    @GET 
    @Produces(MediaType.APPLICATION_XML)
    @Path("/{itemId: [0-9]+}")
    public ItemDTO getParam(@PathParam("itemId") int itemId) {
      return items.getItem(itemId);
    }   
    
    
    @GET
    @Path("/itemJson/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String sendItemAsJson(@PathParam("id")int id){
      return items.getItemJson(id);
    }
    
    @GET
    @Path("/itemAsJson")
    @Produces(MediaType.APPLICATION_JSON)
    public String sendJsonItem(@QueryParam("itemId")int id){
      System.out.println("RRRRRR "+id);
      return items.getItemJson(id);
    }
    
    
    @GET
    @Path("/addItem")
    public String addItem(@MatrixParam("idStr")String idStr,
            @MatrixParam("itName")String itName,
            @MatrixParam("cstStr")String cstStr){
      boolean ret = items.addItem(idStr, itName, cstStr);
      if(ret) {
        return "ItemDTO object with id-" + idStr + " has been added";  
      }
      else {
          return "ItemDTO object addition failed";
      }      
    }
}