package com.jee.jersey;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.jee.jersey.utils.AnguEnrollDao;
import com.jee.jersey.utils.AnguEnrollService;
import com.jee.jersey.utils.AnguPersonDAO;
import com.jee.jersey.utils.AnguPersonService;
import com.jee.jersey.utils.UserRegistrationDAO;
import com.jee.jersey.utils.UserRegistrationService;


// The Java class will be hosted at the URI path "/items"
@Path("/ang")
public class AnguResource {
    
	AnguPersonDAO persDao = new AnguPersonService();
    UserRegistrationDAO userDao = new UserRegistrationService(); 
    AnguEnrollDao enrollDao = new AnguEnrollService();
    
    @GET    
    public Response wish(){
       Response.ResponseBuilder builder = Response.status(200);    
       builder = builder.entity("{\"msg\":\"Welcome To Angular Resource\"}");
               // .header("Access-Control-Allow-Origin", "*");
       return builder.build();
    }
    
    @GET
    @Path("/enroll")
    @Produces(MediaType.APPLICATION_JSON)
    public JsonObject enrollIntoForums(@QueryParam("email") String email) {
    	System.out.println(email+ " received for enroll");
       	JsonObject ret =  enrollDao.enrollPerson(email);
       	System.out.println(ret);
       	return ret;
    }
    
    @GET
    @Path("/all")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll(){
        System.out.println("contacted");
        Response.ResponseBuilder builder = Response.status(200);
        JsonArray arr = this.persDao.getJsonPersons(); 
        builder = builder.entity( arr);                 
        return builder.build();
     }
    
     @POST
     @Path("/register")
     @Produces(MediaType.APPLICATION_JSON)
     public Response registerUser(InputStream in) {
         System.out.println("Registration Contacted");
         Response.ResponseBuilder builder = Response.status(200);
         boolean isSaved = this.readAndSaveUserRegistration(in); 
         String msgStr = "";
         if(isSaved) {
             msgStr = "User Registration is done with success"; 
         }
         else {
             msgStr = "User Registration had Problems";  
         }
         System.out.println(msgStr);
         JsonObjectBuilder objBuilder = Json.createObjectBuilder();
         objBuilder.add("msg",  msgStr);
         JsonObject reply = objBuilder.build();
         builder = builder.entity( reply.toString());                 
         return builder.build();
     }
     
 /* fName=" + fiName + "&lName=" + laName + "&uName=" + 
  * user + "&pwd=" + password + "&rName=" + rlName + 
  * "&email=" + email + "&hb=" + hobby*/
     private boolean readAndSaveUserRegistration(InputStream inStream) {
        boolean ret = false;
        try {
         BufferedReader in = new BufferedReader(new InputStreamReader(inStream));
         String line = in.readLine();
         System.out.println(line);
         String fiName = "",laName="", uname="", pwd = "",em = "", rlName="", hobby = "";
         String[] firstSplitTokens = line.split("[&]");
         for(String firstSplitToken : firstSplitTokens) {
             String[] secondSplitTokens = firstSplitToken.split("[=]");
             if(secondSplitTokens[0].equalsIgnoreCase("fName")) {
                 fiName = secondSplitTokens[1];                 
             }
             else if(secondSplitTokens[0].equalsIgnoreCase("lName")) {
                 laName = secondSplitTokens[1];                 
             } 
             else if(secondSplitTokens[0].equalsIgnoreCase("uName")) {
                 uname = secondSplitTokens[1];                 
             }
             else if(secondSplitTokens[0].equalsIgnoreCase("pwd")) {
                 pwd = secondSplitTokens[1];                 
             }
             else if(secondSplitTokens[0].equalsIgnoreCase("rName")) {
                 rlName = secondSplitTokens[1];                 
             }
             else if(secondSplitTokens[0].equalsIgnoreCase("email")) {
                 em = secondSplitTokens[1];                 
             }
             else if(secondSplitTokens[0].equalsIgnoreCase("hb")) {
                 hobby = secondSplitTokens[1];                 
             }
         }
         ret = userDao.saveUser(em, fiName, laName, uname, pwd, rlName, hobby);         
        }catch(IOException ex) {
           ex.printStackTrace(); 
        }finally {
            userDao.closeEM();
        }
        return ret;
     }
}