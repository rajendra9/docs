package com.jee.jersey.utils;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="user_registration")
@NamedQuery(name="user_all", query=" select u from UserRegistration u")
@SuppressWarnings("serial")
public class UserRegistration implements java.io.Serializable{

    private  String  email;
    private  String  firstName;
    private  String  lastName;
    private  String  username;
    private  String  password;
    private  String  roleName;
    private  String  hobby;
       
    public UserRegistration(String email, 
                            String firstName,
                            String lastName, 
                            String username,
                            String password,
                            String roleName,
                            String hobby) {
        super();
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.roleName = roleName;
        this.hobby = hobby;
    }

    public UserRegistration() {
    }
   
    @Id
    @Column
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
   
    @Column(name="first_name")    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Column(name="last_name")
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Column
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Column
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Column(name="role_name")
    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
    
    @Column
    public String getHobby() {
        return hobby;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((email == null) ? 0 : email.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        UserRegistration other = (UserRegistration) obj;
        if (email == null) {
            if (other.email != null)
                return false;
        } else if (!email.equals(other.email))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "UserRegistration [email=" + email + ", firstName=" + firstName + ", lastName=" + lastName
                + ", username=" + username + ", password=" + password + ", roleName=" + roleName + ", hobby=" + hobby
                + "]";
    }
    
}
