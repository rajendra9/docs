package com.jee.jersey.utils;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.FlushModeType;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class UserRegistrationService implements UserRegistrationDAO {
    
    EntityManagerFactory factory;
    EntityManager em;
    EntityTransaction trans;    
    
    public UserRegistrationService() {
      factory = Persistence.createEntityManagerFactory("myPostgres");
      em = factory.createEntityManager();
      em.setFlushMode(FlushModeType.AUTO);
    }

    private String getField(String fld) {
        if(fld==null) {
            return "";
        }
        else {
            return fld;
        }
    }
    @Override
    public boolean saveUser(String email, String fiName, String laName, String username, String password, String roleName, String hobby){
      boolean ret = false;
      UserRegistration obj = new UserRegistration(email,
              fiName, laName, username, password, this.getField(roleName), this.getField(hobby));
      trans = em.getTransaction();
      try {
        trans.begin();
        em.persist(obj);
        trans.commit();
        ret = true;
      }catch(Exception ex){
        trans.rollback();
        ex.printStackTrace();
      }
      return ret;
    }

    @Override
    public List<UserRegistration> getAll() {
      List<UserRegistration> ret = new ArrayList<>();
      trans = em.getTransaction();
      trans.begin();
      try {
       TypedQuery<UserRegistration> qry = em.createNamedQuery("user_all",UserRegistration.class);   
       ret = qry.getResultList();
       trans.commit();
      }
      catch(Exception e){
         e.printStackTrace();
         trans.rollback();
      }      
       return ret;
    }

    @Override
    public void closeEM() {
      if(factory != null){
          em.close();
          factory.close();         
      }
    }

}
