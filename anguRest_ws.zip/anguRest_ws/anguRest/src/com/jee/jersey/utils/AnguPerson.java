package com.jee.jersey.utils;


import java.io.Serializable;
import java.time.LocalDate;


public class AnguPerson  implements Serializable {

   private  String  adharId;

   private String personName;

   private String job;

   private double  income;
   
   private LocalDate dob;

   public LocalDate getDob() {
     return dob;
   }

   public void setDob(LocalDate dob) {
      this.dob = dob;
   }

   public AnguPerson(){}

   
   public AnguPerson(String adharId, String personName, String job, LocalDate dob, double income) {
      super();
      this.adharId = adharId;
      this.personName = personName;
      this.job = job;
      this.dob = dob;
      this.income = income;
   }

   public String getAdharId() {
       return adharId;
   }

   public void setAdharId(String adharId) {
      this.adharId = adharId;
   }

   public String getPersonName() {
       return personName;
   }

   public void setPersonName(String personName) {
      this.personName = personName;
   }

   public String getJob() {
      return job;
   }

   public void setJob(String job) {
      this.job = job;
   }

   public double getIncome() {
      return income;
   }

   public void setIncome(double income) {
      this.income = income;
   }

   @Override
   public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + ((adharId == null) ? 0 : adharId.hashCode());
      return result;
   }

   @Override
   public boolean equals(Object obj) {
      if (this == obj)
          return true;
      if (obj == null)
          return false;
      if (getClass() != obj.getClass())
          return false;
      AnguPerson other = (AnguPerson) obj;
      if (adharId == null) {
          if (other.adharId != null)
            return false;
      } else if (!adharId.equals(other.adharId))
          return false;
      return true;
    }

   @Override
   public String toString() {
        return "AnguPerson [adharId=" + adharId + ", personName=" + personName + ", job=" + job + ", income=" + income
                + ", dob=" + dob + "]";
   }

   
   
}
       
