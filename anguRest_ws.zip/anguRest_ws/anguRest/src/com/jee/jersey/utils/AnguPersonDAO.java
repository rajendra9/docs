package com.jee.jersey.utils;

import java.io.Serializable;

import javax.json.JsonArray;

public interface AnguPersonDAO extends Serializable {
  String PERSONS_SQL = "select adhar_id, person_name, dob, occupation, income from angu_persons";  
  public JsonArray getJsonPersons();
}
