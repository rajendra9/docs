package com.jee.jersey.utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

public class AnguPersonService implements AnguPersonDAO {
   MyDataSource ds;
   
   {
       ds = new MyDataSource();
   }
    
    @Override
    public JsonArray getJsonPersons() {
       JsonArrayBuilder arrBuilder = Json.createArrayBuilder();
       JsonObjectBuilder objBuilder = null;
       JsonObject obj = null;
       Connection conn = null;
       try {
         conn = ds.getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(PERSONS_SQL);
         while(rs.next()) {
             objBuilder = Json.createObjectBuilder();
             objBuilder.add("adharId", rs.getString(1));
             objBuilder.add("personName", rs.getString(2));
             objBuilder.add("dob", rs.getDate(3).toString());             
             objBuilder.add("job", rs.getString(4));
             objBuilder.add("income", rs.getDouble(5));
             obj = objBuilder.build();
             arrBuilder.add(obj);
         }
       }catch(SQLException ex) {
           throw new RuntimeException(ex.getMessage());
       }
       finally {
           try {
             if(conn != null) {
                 conn.close();
             }
           }catch(Exception ex) {}
       }
       return arrBuilder.build();
    }

}
