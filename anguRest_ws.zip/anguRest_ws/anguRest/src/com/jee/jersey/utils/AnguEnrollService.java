package com.jee.jersey.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

public class AnguEnrollService implements AnguEnrollDao {
	MyDataSource ds;
	   
   {
	ds = new MyDataSource();
   }
   
   @Override
   public JsonObject enrollPerson(String email) {
	  String msg = "problems in Insert";  
	  Connection conn = null;
      try {
        conn = ds.getConnection();
        PreparedStatement pstmt = conn.prepareStatement(ENROLL_SQL);
        pstmt.setString(1, email);
        int rows = pstmt.executeUpdate();
        if(rows>0) {
        	msg = "Data is Inserted";
        }	
      }catch(SQLException ex) {
         throw new RuntimeException(ex.getMessage());
      }
      finally {
          try {
            if(conn != null) {
                conn.close();
            }
          }catch(Exception ex) {}
      }
      JsonObjectBuilder objBuilder = Json.createObjectBuilder();
      objBuilder.add("msg", msg);
      return objBuilder.build();
	  
	}    

}
