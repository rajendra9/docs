package com.jee.jersey.utils;

import java.io.Serializable;
import java.io.StringReader;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

@SuppressWarnings("serial")
public class ProductStore implements Serializable {
   ConcurrentMap<String, ProductInfo> store = new ConcurrentHashMap<>();
   
   {
     ProductInfo info = new ProductInfo("s121","Lux", 38.5, "M/sSannidhi Stores,Chennai");
     store.put(info.getProdId(), info);
     info = new ProductInfo("s152","Cinthol", 31.5, "M/sMaruthi General Stores,Madurai");
     store.put(info.getProdId(), info);
     info = new ProductInfo("s174","Dove", 49.2, "M/sSolomonRaj Suplliers,Kovai");
     store.put(info.getProdId(), info);
         
   }
   
   public JsonObject getUserAsJson(String prodId) {
       JsonObjectBuilder objBuilder = Json.createObjectBuilder();
       ProductInfo prod = null;
       if(store.containsKey(prodId)) {
          prod = store.get(prodId);
          objBuilder.add("prodId", prodId);
          objBuilder.add("prodName", prod.getProdName());
          objBuilder.add("prodCost", prod.getProdCost());
          objBuilder.add("supplier", prod.getSupplier());
          return objBuilder.build();
       }
       else {
           objBuilder.add("prodId", "Product Not available");
           return objBuilder.build();
       }  
       
   }
   
   public JsonObject saveProdGotAsJson(String str) {
       JsonParser parser = Json.createParser(new StringReader(str));
       String pId = "",pName = "", suppl = ""; 
       double pCost = 0.0;
       StringBuilder sb = new StringBuilder(); 
       while(parser.hasNext()) {
          Event evt =  parser.next();
          if(evt == Event.VALUE_STRING) {
              sb.append(parser.getString()+"|");
          }
          else if(evt == Event.VALUE_NUMBER) {
            pCost = parser.getBigDecimal().doubleValue();   
          }
       }
       String parsedContent = sb.toString();
       parsedContent = parsedContent.substring(0, parsedContent.length()-1);
       String[] tokens = parsedContent.split("[|]");
       pId = tokens[0];
       pName = tokens[1];
       suppl = tokens[2];
       ProductInfo info = new ProductInfo(pId, pName, pCost, suppl);
       boolean boo = false;
       if(!store.containsKey(pId)) {
          store.put(pId,  info);
          boo = true;
       }
       else {
          boo = false;
       }
       JsonObjectBuilder objBuilder = Json.createObjectBuilder();
       if(boo) {
         objBuilder.add("msg", "Product with "+ pId + " Saved");    
       }else {
         objBuilder.add("msg", "Product with "+ pId + " not Saved, problems");      
       }
       return objBuilder.build();
   }
   
   
   
   

}
