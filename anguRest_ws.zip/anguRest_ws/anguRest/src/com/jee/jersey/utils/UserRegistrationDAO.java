package com.jee.jersey.utils;

import java.io.Serializable;
import java.util.List;

public interface UserRegistrationDAO extends Serializable {
   public boolean saveUser(String email, String fiName, String laName, String username, String password, String roleName, String hobby);
   public List<UserRegistration> getAll();
   public void closeEM();
}
