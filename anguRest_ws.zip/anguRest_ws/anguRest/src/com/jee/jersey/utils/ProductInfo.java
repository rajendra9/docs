package com.jee.jersey.utils;

@SuppressWarnings("serial")
public class ProductInfo implements java.io.Serializable {
   private String prodId;
   private String prodName;
   private double prodCost;
   private String supplier;
 
   public ProductInfo() {
        // TODO Auto-generated constructor stub
   }

   public ProductInfo(String prodId, 
                      String prodName, 
                      double prodCost, 
                      String supplier) {
      super();
      this.prodId = prodId;
      this.prodName = prodName;
      this.prodCost = prodCost;
      this.supplier = supplier;
   }

   public String getProdId() {
       return prodId;
   }

   public void setProdId(String prodId) {
      this.prodId = prodId;
   }

   public String getProdName() {
      return prodName;
   }

   public void setProdName(String prodName) {
      this.prodName = prodName;
   }

   public double getProdCost() {
       return prodCost;
   }

   public void setProdCost(double prodCost) {
      this.prodCost = prodCost;
   }

   public String getSupplier() {
      return supplier;
   }

   public void setSupplier(String supplier) {
      this.supplier = supplier;
   }

   @Override
   public int hashCode() {
      final int prime = 31;
       int result = 1;
      result = prime * result + ((prodId == null) ? 0 : prodId.hashCode());
      return result; 
   }

   @Override
   public boolean equals(Object obj) {
      if (this == obj)
          return true;
      if (obj == null)
          return false;
      if (getClass() != obj.getClass())
          return false;
      ProductInfo other = (ProductInfo) obj;
      if (prodId == null) {
           if (other.prodId != null)
              return false;
      } else if (!prodId.equals(other.prodId))
       return false;
      return true;
    }

    @Override
    public String toString() {
          return "ProductInfo [prodId=" + prodId + ", prodName=" + prodName + ", prodCost=" + prodCost + ", supplier="
               + supplier + "]";
    }

    
}
