package com.jee.jersey.utils;

import java.io.Serializable;

import javax.json.JsonObject;



public interface AnguEnrollDao extends Serializable {
  String ENROLL_SQL = "insert into spring_forums(person_email) values(?)";  
  public JsonObject enrollPerson(String email);
}
