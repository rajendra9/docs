package com.jee.jersey.utils;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class MyDataSource {
 
 public Connection getConnection()  {
   Connection conn = null; 
  try{
    Context ctx = new InitialContext();
    DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/myPostgres");
    conn = ds.getConnection();
  }catch(NamingException | SQLException e){
     e.printStackTrace();
  }      
 
  return conn;
 }

}

