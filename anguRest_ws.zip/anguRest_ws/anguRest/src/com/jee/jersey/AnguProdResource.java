package com.jee.jersey;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


import javax.json.JsonObject;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.jee.jersey.utils.ProductStore;


// The Java class will be hosted at the URI path "/items"
@Path("/products")
public class AnguProdResource {
    ProductStore store = new ProductStore();
        
    @GET
    @Path("/search/{prodId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response searchProd(@PathParam("prodId")String email){
       Response.ResponseBuilder builder = Response.status(200);
       JsonObject info = store.getUserAsJson(email);
       builder = builder.entity(info);
               // .header("Access-Control-Allow-Origin", "*");
       return builder.build();
    }
    
    @GET
    @Path("/{prodNum}")
    @Produces(MediaType.APPLICATION_JSON)
    public JsonObject search(@PathParam("prodNum")String prodNum){
       JsonObject info = store.getUserAsJson(prodNum);
       return info;
    }
    
    @POST
    @Path("/saveProdInfo")
    @Produces(MediaType.APPLICATION_JSON)
    public JsonObject saveProduct(InputStream inStream) {
        System.out.println("Registration Contacted");
        String line = "";
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(inStream));
            line = in.readLine();
            in.close();   
        }catch(IOException ex) {
            ex.printStackTrace();
        }
        JsonObject reply = this.store.saveProdGotAsJson(line);                 
        return reply;
    }
    

}