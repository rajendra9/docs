drop table if exists angu_persons;

create table angu_persons(adhar_id varchar(14) primary key,
person_name  varchar(30),dob date,occupation varchar(30),income decimal(10,2));

insert into angu_persons values('3243 2123 4532', 'Keshavan', '1995-09-12', 'State_Govt_Service', 36500.7);
insert into angu_persons values('4356 5123 4875', 'Madhavan', '1995-11-23','Business',  42500.7);
insert into angu_persons values('2123 6539 1709', 'Kalaiselvan','1996-07-21', 'Central_Govt_Service',  45600.7);
insert into angu_persons values('2312 7687 3232', 'Muthu Kumar', '1992-03-09','Gas_Dealership',  125900.7);
insert into angu_persons values('1324 6545 6565', 'Madivanan', '1995-12-19', 'Central_Govt_Service',  43600.7);
insert into angu_persons values('1812 7686 4487', 'Mrunalini','1997-01-08', 'State_Govt_Service',  54760.7);
insert into angu_persons values('5412 2188 4989', 'MuthuVelu','1997-01-08', 'Contract_Labor',  24160.7);
commit;

