package dommanip;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import org.w3c.dom.Text;

import domvalid.DocParser;
import domvalid.ParsedDocSaver;

public class SimpAdd  {

 public static void main(String[] args)
  throws Exception {

  DocParser dParser = new DocParser();
  Document document = dParser.getParseSchemaDocument("users.xml");

  String ns = document.getNamespaceURI();
  Node rootNode = document.getDocumentElement();
  Element newUserNode = document.createElementNS(ns,"user");
  newUserNode.setAttributeNS(ns,"id", "htc3213");
  newUserNode.setIdAttribute("id", true);
  
  Element newUsernameNode = 
        document.createElementNS(ns,"username");
  Text tNode = document.createTextNode("murugan");
  newUsernameNode.appendChild(tNode);
  
  Element newPwdNode = 
        document.createElementNS(ns,"password");
  tNode = document.createTextNode("muru123");
  newPwdNode.appendChild(tNode); 
  
  Element isActiveNode = 
        document.createElementNS(ns,"is-active");
  tNode = document.createTextNode("true");
  isActiveNode.appendChild(tNode); 

  Element roleNameNode = 
	        document.createElementNS(ns,"role-name");
  tNode = document.createTextNode("Tester");
  roleNameNode.appendChild(tNode); 

  newUserNode.appendChild(newUsernameNode);
  newUserNode.appendChild(newPwdNode);
  newUserNode.appendChild(isActiveNode);
  newUserNode.appendChild(roleNameNode);
  newUserNode.normalize();
  
  rootNode.appendChild(newUserNode);
  document.normalizeDocument();
 
  ParsedDocSaver docSaver = new ParsedDocSaver();
  String fPath = "file:///D:/xmls/users_new.xml";
  boolean boo = docSaver.saveDoc(document, fPath); 
  if(boo) {
    System.out.println("New User is Saved to Users.xml");
  }
  }

}