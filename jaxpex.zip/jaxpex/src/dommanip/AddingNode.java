package dommanip;

/* in reading tree heirarchy
   <student>^^^^
    <name>HHHHH</name>^^^^
    ..................^^^^
   </student>^^^^
  ^^^^ --> are considered as textual nodes
  use always getElementById(" ")
  on parsed Document object to get one set of nodes  
*/
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import domvalid.DocParser;
import domvalid.ParsedDocSaver;

public class AddingNode  {

 public static void main(String[] args)
  throws Exception {

  DocParser dParser = new DocParser();
  Document document = dParser.getParseDocument("engstu.xml");

  String ns = document.getNamespaceURI();
  Node rootNode = document.getDocumentElement();
  NodeList nodeList = document.getElementsByTagName("student");
  
  outer:
   for(int i=0;i<nodeList.getLength();i++) {
    Node stuNode = nodeList.item(i);     
    NodeList stuChilds = stuNode.getChildNodes();
    
    for(int j=0;j<stuChilds.getLength();j++) {
     Node chNode = stuChilds.item(j);
     if(chNode == null) {
      continue;
     }
     if(!(chNode.getFirstChild() instanceof org.w3c.dom.Text)) {
      continue;
     }
        
     String data = chNode.getFirstChild().getNodeValue();       
     if(!data.equals("soman")) {
      continue;
     }
     Element newStudentNode = 
        document.createElementNS(ns,"student");

     Element newIdNode = 
        document.createElementNS(ns,"sid");
     Text tNode = document.createTextNode("105");
     newIdNode.appendChild(tNode);
  
     Element newNameNode = 
        document.createElementNS(ns,"name");
     tNode = document.createTextNode("Thiramaisali");
     newNameNode.appendChild(tNode); 
  
     Element newYearNode = 
        document.createElementNS(ns,"year");
     tNode = document.createTextNode("2");
     newYearNode.appendChild(tNode); 
      
     newStudentNode.appendChild(newIdNode);
     newStudentNode.appendChild(newNameNode);
     newStudentNode.appendChild(newYearNode);
     newStudentNode.normalize();
     
     rootNode.insertBefore(newStudentNode,stuNode);
     document.normalizeDocument();
     break outer;
    }
   }

   ParsedDocSaver docSaver = new ParsedDocSaver();
   String fPath = "file:///D:/xmls/engstu_new.xml";
   boolean boo = docSaver.saveDoc(document, fPath); 
   if(boo) {
    System.out.println("document saved");
   }
  }

}