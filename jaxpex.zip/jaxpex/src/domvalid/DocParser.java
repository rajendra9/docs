package domvalid;
import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import javax.xml.XMLConstants;

public class DocParser {

 static final String JAXP_SCHEMA_LANGUAGE =
        "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
 
 public Document getParseDocument(String xmlFile) { 
  Document doc = null;
  try {
   DocumentBuilderFactory dbf =     
      this.getFactory(false);
   DocumentBuilder db = dbf.newDocumentBuilder();
   MyDefHandler dh = new MyDefHandler();
   db.setErrorHandler(dh);
   doc = db.parse(new File(xmlFile));
  }catch(Exception e) {
    e.printStackTrace();
  }
  return doc;
 }
 
 public DocumentBuilderFactory getFactory(boolean forSchema) {
   DocumentBuilderFactory    
      dbf = DocumentBuilderFactory.newInstance();
   dbf.setValidating(true);
   dbf.setNamespaceAware(true);
   dbf.setIgnoringElementContentWhitespace(true);
   dbf.setIgnoringComments(true);
   dbf.setExpandEntityReferences(true);
   //enables CDATA sections to be read as plain text
   dbf.setCoalescing(true);
   if(forSchema) {
    try {
      dbf.setAttribute(JAXP_SCHEMA_LANGUAGE,XMLConstants.W3C_XML_SCHEMA_NS_URI);
    }catch(IllegalArgumentException iae) {
      iae.printStackTrace();   
    }
   }            
   return dbf;       
 }
 
 
 public Document getParseSchemaDocument(String xmlFile) {
  Document doc = null;
  try {
   DocumentBuilderFactory dbf = this.getFactory(true); 
   DocumentBuilder db = dbf.newDocumentBuilder();
   MyDefHandler dh = new MyDefHandler();
   db.setErrorHandler(dh);
   doc = db.parse(new File(xmlFile));
  }
  catch(Exception e) {
   e.printStackTrace();
  }
  return doc;
 }
    
}