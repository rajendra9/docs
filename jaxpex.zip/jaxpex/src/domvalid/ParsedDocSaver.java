package domvalid;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.Document;
import org.w3c.dom.ls.LSSerializer;

public class ParsedDocSaver {

 public boolean saveDoc(Document doc, String filePath) {
  boolean ret = false;
  try {
           DOMImplementation impl = doc.getImplementation();

           DOMImplementationLS implLS =
                        (DOMImplementationLS) impl.getFeature("LS","3.0");

           MyDocErrHandler docErr =  new MyDocErrHandler();

           LSSerializer writer =   implLS.createLSSerializer(); 

            writer.getDomConfig().setParameter(
                                   "error-handler",docErr);

             ret = writer.writeToURI(doc,filePath);
                
        } catch(Exception e) {
                                 System.out.println(e);
        }
          return ret;
      }

}  