package forstax;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Schema;
import javax.xml.validation.Validator;
import javax.xml.transform.stream.StreamSource;
import java.io.FileWriter;
import java.io.Writer;
import java.io.File;
import  java.util.Scanner;

public class StaxValidDemo {

 public static void main(String[] args) {
  Scanner scan = new Scanner(System.in);
  System.out.println("Enter xmlFile name");
  String xmlFile = scan.nextLine();
  System.out.println("Is it Schema true/false");
  boolean isSchema = Boolean.parseBoolean(scan.nextLine());
  String xsdFile = "";
  if(isSchema) {
      System.out.println("Enter Schema file");
       xsdFile = scan.nextLine();
  }
  System.out.println("Enter new file name");
  String newXmlFile = scan.nextLine();
  try {

   XMLInputFactory iFactory = 
           XMLInputFactory.newInstance();

  iFactory.setProperty(
     XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES,
      Boolean.TRUE);
  
  iFactory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES,
       Boolean.FALSE );
   iFactory.setProperty(XMLInputFactory.SUPPORT_DTD,
                         Boolean.TRUE);
    
   iFactory.setProperty(
         XMLInputFactory.IS_COALESCING,new Boolean(false)); 
      
   iFactory.setProperty(
        XMLInputFactory.IS_NAMESPACE_AWARE,true);
   
    String language = javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI;
    SchemaFactory scf = SchemaFactory.newInstance(language);
   

    StreamSource xsdSource = new StreamSource(new File(xsdFile));
    Schema schema = scf.newSchema(xsdSource); 
   
    Validator validator = schema.newValidator();
    MyDefHandler eh = new MyDefHandler();
    validator.setErrorHandler(eh);
    StreamSource xmlSource = new StreamSource(new File(xmlFile)); 
    validator.validate(xmlSource);
   

   XMLStreamReader parser = 
           iFactory.createXMLStreamReader(xmlSource);
   
   Writer out = new FileWriter(newXmlFile);
   XMLOutputFactory oFactory = 
               XMLOutputFactory.newInstance();
   XMLStreamWriter writer = 
               oFactory.createXMLStreamWriter(out);
     

  String  sep = "\r\n";
  int eventType = 0;

  while(parser.hasNext()) {
   
    eventType = parser.getEventType();
   switch(eventType) {
    
    case XMLStreamConstants.START_DOCUMENT:
     writer.writeStartDocument();                 
     break;         
  
    case XMLStreamConstants.END_DOCUMENT: 
     System.out.println("END-DOCUMENT");
     writer.writeEndDocument();
     break;
     
    case XMLStreamConstants.START_ELEMENT: 
     String sElm = parser.getLocalName();
     System.out.println(sElm);
     if(sElm.equals("name")) {
      sElm = "course-name";       
     }
     writer.writeStartElement(sElm);             
     int count = parser.getAttributeCount();


     for(int i=0;i<count;i++) {
      String attrNS = parser.getNamespaceURI(i); 
      String prefix = parser.getAttributePrefix(i);
      String aName = parser.getAttributeLocalName(i);
      String val = parser.getAttributeValue(i);
      if(attrNS != null){
       writer.setPrefix(prefix,attrNS);
       writer.setDefaultNamespace(attrNS);
       writer.writeNamespace(prefix,attrNS);
       writer.writeAttribute(prefix+":"+aName,val);
      } 
      else {
       writer.writeAttribute(aName,val); 
      } 
     }
     break;    
            
    case XMLStreamConstants.END_ELEMENT: 
     writer.writeEndElement(); 
     writer.writeCharacters(sep);
     sElm = parser.getLocalName();
      
     break; 
       
     case XMLStreamConstants.DTD:
      String str = parser.getText();
      writer.writeDTD(str);
      break;
       
     case XMLStreamConstants.CDATA:
      writer.writeCData(parser.getText());        
      break;  
     
     case XMLStreamConstants.CHARACTERS:
      writer.writeCharacters(parser.getText());
      break;
               
     case XMLStreamConstants.SPACE: 
     // writer.writeCharacters(sep);
       break;
     }
     if(eventType != XMLStreamConstants.END_DOCUMENT) {  
      parser.next();
     }
     else {
      parser.close();
      break;
     }
    }//while closes
    writer.flush();
    writer.close();
    out.close();
   }
   catch(Exception e){
    e.printStackTrace();
   }      
   scan.close();
 }

}