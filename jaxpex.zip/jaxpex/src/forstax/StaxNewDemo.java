package forstax;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.XMLStreamConstants;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Writer;
import  java.util.Scanner;

public class StaxNewDemo {

 public static void main(String[] args) {
  Scanner scan = new Scanner(System.in);
  System.out.println("Enter xmlFile name");
  String xmlFile = scan.nextLine();
  System.out.println("Enter new file name");
  String newXmlFile = scan.nextLine();
 
  try {

   XMLInputFactory iFactory = 
           XMLInputFactory.newInstance();

  /*  iFactory.setProperty("XMLInputFactory.IS_VALIDATING",
      Boolean.TRUE);
  */

   iFactory.setProperty(
     XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES,
      Boolean.TRUE);
   iFactory.setProperty(XMLInputFactory.SUPPORT_DTD,
                         Boolean.TRUE);
    
   iFactory.setProperty(
         XMLInputFactory.IS_COALESCING,new Boolean(false)); 
      
   iFactory.setProperty(
        XMLInputFactory.IS_NAMESPACE_AWARE,true);
   
   FileReader in = new FileReader(xmlFile);

   XMLStreamReader parser = 
           iFactory.createXMLStreamReader(in);
      
   
   Writer out = new FileWriter(newXmlFile);
   XMLOutputFactory oFactory = 
               XMLOutputFactory.newInstance();
   XMLStreamWriter writer = 
               oFactory.createXMLStreamWriter(out);
     

  String  sep = "\r\n";
   int eventType = 0;
    
   while(true){ 

    eventType = parser.getEventType(); 

    switch(eventType) {
    
    case XMLStreamConstants.START_DOCUMENT:
     System.out.println("Start Document"); 
     writer.writeStartDocument();                 
     break;         
  
    case XMLStreamConstants.END_DOCUMENT: 
     System.out.println("END-DOCUMENT");
     writer.writeEndDocument();
     break;
     
    case XMLStreamConstants.START_ELEMENT: 
     String sElm = parser.getLocalName();
     System.out.println(sElm);
     if(sElm.equals("name")) {
      sElm = "dname";       
     }
     writer.writeStartElement(sElm);             
     int count = parser.getAttributeCount();
     

     for(int i=0;i<count;i++) {
      String aName = parser.getAttributeLocalName(i);
      String val = parser.getAttributeValue(i);
      writer.writeAttribute(aName,val); 
      } 
     
     break;    
            
    case XMLStreamConstants.END_ELEMENT: 
     writer.writeEndElement(); 
     writer.writeCharacters(sep);
     sElm = parser.getLocalName();
   
     if(sElm.equals("dept")){  
      writer.writeCharacters(sep);
      writer.writeStartElement("job-details");
      writer.writeCharacters(sep);
      writer.writeStartElement("job");
      writer.writeCharacters("ANALYST");
      writer.writeEndElement(); 
      writer.writeCharacters(sep);
      writer.writeEndElement(); 
      writer.writeCharacters(sep);
     }                    
     break; 
       
     case XMLStreamConstants.DTD:
      String str = parser.getText();       
      writer.writeDTD(str);
      break;
       
     case XMLStreamConstants.CDATA:
      System.out.println("blah");
      writer.writeCData(parser.getText());        
      break;  
     
     case XMLStreamConstants.CHARACTERS:
      writer.writeCharacters(parser.getText());
      break;
               
     case XMLStreamConstants.SPACE: 
      writer.writeCharacters(sep);
       break;
     }
     if(eventType != XMLStreamConstants.END_DOCUMENT) {  
      parser.next();
     }
     else {
      parser.close();
      break;
     }
    }    
    writer.flush();
    writer.close();
    out.close();
   }
   catch(Exception e){
    e.printStackTrace();
   }      
   scan.close();
 }

}