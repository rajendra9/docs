package saxmanip;

import domvalid.MyDefHandler;

import saxvalid.SaxParse;

import org.xml.sax.Attributes;

import javax.xml.parsers.SAXParser;
import java.io.File;
import org.xml.sax.SAXException;


class MyContentHandler extends MyDefHandler {

 String elt = "";
 boolean found = false;
 
 public MyContentHandler(String elt) {
  this.elt = elt;
 }
  
 public void startElement(String uri, String localname,
                          String qname, Attributes attrs)
  throws SAXException {
   
   if(qname.equalsIgnoreCase(elt)){ 
    found = true;
   }
 }
 
 public void characters(char[] ch, int start, int length){
 
  if(found) {
   System.out.println(elt+"-->"+new String(ch,start,length));
   found = false;
  }
 }
}   

public class ContentFinder {

 public static void main(String[] args)throws Exception {

	 java.util.Scanner scan = new java.util.Scanner(System.in);
	  System.out.println("enter xml file");
	  String xmlF = scan.nextLine();
	   
	  System.out.println("is it Schema based say 'true/false'");
	  boolean isSchema = Boolean.parseBoolean(scan.nextLine());
	  SAXParser parser = null;
	  String xsdF = "";
	  if(isSchema) {
	   System.out.println("enter xsd file");
	   xsdF = scan.nextLine(); 
	   parser = new SaxParse().getParser(xsdF);
	  }
	  else {    
	   parser = new SaxParse().getParser(); 
	  } 

	  System.out.println("enter the element whose content yu want");

	  String elt = scan.nextLine();
      MyContentHandler mh = new MyContentHandler(elt);
      parser.parse(new File(xmlF), mh);   
      scan.close();
 }
  
}  

/*
  use AttrDept.xml 
*/