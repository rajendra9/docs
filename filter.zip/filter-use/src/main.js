import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false
Vue.filter('to_uppercase',function(value){
  return value.toUpperCase();
})
Vue.filter('to_Local_date',function(value){
  let dt = Date.parse(value);
  return new Date(dt).toJSON();
})
new Vue({
  render: h => h(App),
}).$mount('#app')
