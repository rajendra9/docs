<template>
  <div id="app">
      <table id="celebs">
       <tr v-for="(celeb, index) in celebs" v-bind:key="index">
         <td>{{celeb.name | to_uppercase }}</td><td>{{celeb.field}}</td><td>{{celeb.date_of_entry|to_Local_date}}</td>
      </tr>
  
      </table>
  </div>
</template>

<script>


export default {
  
  components: {
   
  },
  data(){
    return{
       celebs:[
             {name:'Sachin Tendulkar', field: 'Cricket', date_of_entry: '1985-03-12'},
             {name:'Sindhu', field: 'Shuttle', date_of_entry: '2011-05-02'},
             {name:'Baichung Bhutia', field: 'Football', date_of_entry: '1985-03-12'},
             {name:'Anna Hazare', field: 'Social Work', date_of_entry: '1971-08-19'},
             {name:'Bharat Chetri', field: 'Hockey', date_of_entry: '1998-03-12'},
             {name:'Amir Khan', field: 'Bollywood', date_of_entry: '1981-09-30'}             
           ],

    }
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: blue;
    margin-top: 30px;
}
#celebs{
  max-width:70%;
  margin: 0 auto;
}
td{
  margin: 10px;
  padding: 10px;
}
</style>
