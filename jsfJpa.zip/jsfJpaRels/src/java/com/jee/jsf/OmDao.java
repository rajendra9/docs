package com.jee.jsf;

public interface OmDao extends java.io.Serializable {
    
    public boolean saveCourse(MasterCourse course);
    
    public boolean saveStudent(ChildStudents student);
    
    public boolean addStudentToCourse(int courseId, int studentId);
    
    public void close();
    
    
}
