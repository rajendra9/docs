package com.jee.jsf;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="child_students")
public class ChildStudents implements java.io.Serializable {    
    private  int studentId;
    private  String studentName;
    private  String address;

    @Id
    @Column(name="student_id")
    public int getStudentId() {
        return studentId;
    }
    
    @Column(name="student_name")
    public String getStudentName() {
        return studentName;
    }

    @Column
    public String getAddress() {
        return address;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 23 * hash + this.studentId;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ChildStudents other = (ChildStudents) obj;
        if (this.studentId != other.studentId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ChildStudents{" + "studentId=" + studentId + ", studentName=" + studentName + ", address=" + address + '}';
    }
    
    
    
    
}
