package com.jee.jsf;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named("relBean")
@SessionScoped
public class RelationManageBean implements java.io.Serializable {
    MasterCourse course;
    ChildStudents student;
    OmDao dao;
    String resultMsg;
    int courseId;
    int studentId;

    {
        course = new MasterCourse();
        student = new ChildStudents();
        dao = new OmDaoImpl(); 
    }
    
    public int getCourseId() {
        return courseId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }
    
    public MasterCourse getCourse() {
        return course;
    }

    public ChildStudents getStudent() {
        return student;
    }

    public String getResultMsg() {
        return resultMsg;
    }

    public void setCourse(MasterCourse course) {
        this.course = course;
    }

    public void setStudent(ChildStudents student) {
        this.student = student;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }    
    
    public String persistCourse(){
        boolean  ret = dao.saveCourse(course);
        if(ret){
            this.setResultMsg("Course with " + 
                        course.getCourseId() +
                    "is saved successfully");
            return "success";
        }
        return "failure";
    }
    
     public String persistStudent(){
        boolean  ret = dao.saveStudent(student);
        if(ret){
            this.setResultMsg("Course with " + 
                        student.getStudentId() +
                    "is saved successfully");
            return "success";
        }
        return "failure";
    }
    public String putStudentInCourse(){
        boolean  ret = dao.addStudentToCourse(courseId, studentId);
        if(ret){
            this.setResultMsg("student with " + 
                        this.studentId +
                    "is placed in course with id:" + this.courseId);
            return "success";
        }
        return "failure";
    } 
     
}
