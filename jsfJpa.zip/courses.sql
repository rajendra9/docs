drop table if exists child_students;

drop table if exists master_course;


create table master_course(course_id integer constraint cr_PK primary key,
        course_name varchar(20));

create table child_students(student_id integer constraint sm_PK primary key ,
student_name varchar(25),address varchar(35), course_id integer references master_course(course_id));


insert into master_course values(100,'M.Sc');

insert into master_course values(200,'M.C.A');

insert into  master_course values(300,'M.Com');

insert into child_students values(1000,'Sathish','Guindy',100);
insert into child_students values(1010,'Sajid','Chrome Pet',100);

insert into child_students values(1020,'Velan','TNagar',300);
insert into child_students values(1030,'Varsha','Chrome Pet',300);

commit;
