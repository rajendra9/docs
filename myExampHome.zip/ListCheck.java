package basic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.validation.constraints.NotNull;

public class ListCheck {

   List<String>  list = new ArrayList<>();
   
   {
	// Collections.addAll(list,"Gambhir",null,"Ganguly",null,"Tendulai","Rahul Dravid");   
	 Collections.addAll(list,"Gambhir", "Doshi", "Ganguly", "Kumble", "Tendulai", "Rahul Dravid");
   }
	
   public void printInUpper() {
	   list.stream().map((@NotNull String s) -> s.toUpperCase()).forEach(System.out::println); 
   }
	
	public static void main(String[] args) {
		ListCheck listCheck = new ListCheck();
		listCheck.printInUpper();
	}

}
