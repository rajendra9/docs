package basic;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.function.Predicate;

public class ReadFile {
    File file = new File("linedemo.txt"); 
  
    public void myReadLines() {
	   Path p = file.toPath();
	   try {
	     List<String> lines = Files.readAllLines(p, Charset.defaultCharset());
	     Predicate<String> filtering = (s)->s.isBlank();
	     filtering = Predicate.not(filtering);
	     lines.stream().filter(filtering).forEach(System.out::println);	     
	   }catch(Exception ex) {
		   ex.printStackTrace();
	   }   
	}
	
	public static void main(String[] args) {
		ReadFile readFile = new ReadFile();
		readFile.myReadLines();
	}

}
