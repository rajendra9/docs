package com.htc.kafka.consumers;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public class SimpleConsumer {

   private Properties readProperties() {
        Properties ret = new Properties();
        try {
          BufferedReader in = new BufferedReader(new FileReader("Consumers.properties"));
          ret.load(in);
          in.close();
        }catch(Exception ex) {
            throw new RuntimeException(ex.getMessage());
       }
        return ret;
   }  

   public void receiveAndPrintMessages(String topicName) {
       Properties props = this.readProperties();
       KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props);
       consumer.subscribe(Arrays.asList(topicName));
       System.out.println("Subscribed to topic:"+topicName);
       while(true) {
         ConsumerRecords<String,String> records = consumer.poll(100);
System.out.print("------"+records);
        for(ConsumerRecord<String,String> record: records){     
             System.out.printf("offset=%d, prod-Name= %s, prodQty=%s", record.offset(), record.key(), record.value());        
        }
       }
   }
    
    public static void main(String[] args) {
       SimpleConsumer simpConsumer = new SimpleConsumer();
       simpConsumer.receiveAndPrintMessages("sampTopic"); 
      
    }

}
