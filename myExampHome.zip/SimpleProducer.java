package com.htc.kafka.producers;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;



public class SimpleProducer {
   
    private ConcurrentMap<String,Integer> buildSalesData(){
        ConcurrentMap<String, Integer> sales = new ConcurrentHashMap<>();
        sales.putIfAbsent("Desktops", 10);
        sales.putIfAbsent("Laptops", 30);
        sales.putIfAbsent("Smart Mobiles", 1230);
        sales.putIfAbsent("Normal Mobiles", 2500);
        sales.putIfAbsent("Backpacks", 546);
        return sales;
    }
    private Properties readProperties() {
       Properties ret = new Properties();
       try {
         BufferedReader in = new BufferedReader(new FileReader("./Producers.properties"));
         ret.load(in);
         in.close();
       }catch(Exception ex) {
           throw new RuntimeException(ex.getMessage());
       }
       return ret;
    }  
    
    private ProducerRecord<String, String> createRecord(String topicName,String itemName, Integer itemQty){
         return new ProducerRecord<>(topicName, itemName, Integer.toString(itemQty));
    }
    public void sendSalesData(String topicName) {
        Properties props = this.readProperties();
        ConcurrentMap<String,Integer>  data = this.buildSalesData();
        Producer<String, String> topicSender = new KafkaProducer<>(props);
        data.forEach((k,v)->{
            ProducerRecord<String,String> record =this.createRecord(topicName,  k,  v);
            topicSender.send(record);
            System.out.println("Record sent");
        });
        topicSender.close();
    } 
    public static void main(String[] args) {
        SimpleProducer simpProducer = new SimpleProducer();
        simpProducer.sendSalesData("sampTopic"); 
    }

}
