package prajsp;

import java.io.Serializable;
import java.sql.Date;

public class EmpVO implements Serializable {

 private   int transId=0;
 private   int empId=0;
 private   String name="";
 private   java.sql.Date subDate;
 private   java.sql.Date sanDate;
 private   double subAmount=0.0;
 private   double sanAmount=0.0;
 
 public EmpVO(){}

 public int getEmpId() {
  return empId;
 }
 
 public void setEmpId(int newEmpId) {
  empId = newEmpId;
 }
 
 public int getTransId() {
  return transId;
 }
 
 public void setTransId(int newTransId) {
  transId = newTransId;
 }

 public String getName() {
  return name;
 }
 
 public void setName(String newName) {
  name = newName;
 }
 
 public double getSubAmount() {
  return subAmount;
 } 
 
 public void setSubAmount(double newAmount) {
  subAmount = newAmount;
 }

 public double getSanAmount() {
  return sanAmount;
 }

 public void setSanAmount(double newAmount) {
   sanAmount = newAmount;
 }

  public Date getSubDate() {
   return subDate;
  }
  
  public void setSubDate(Date newDate) {
   subDate = newDate;
  }  
 
  public Date getSanDate() {
   return sanDate;
  }
  
  public void setSanDate(Date newDate){
   sanDate = newDate;
  }  
   
  public int hashCode(){
   return empId*4; 
  }

  public boolean equals(Object other) {
   if(other instanceof EmpVO) {
    EmpVO evo=(EmpVO)other;
    return (empId==evo.empId);
   }
   return false;
  }

  public String toString() {
   StringBuilder sb = new StringBuilder();
   sb.append("EmpId: " + empId + "<br>"); 
   sb.append("Name: " + name + "<br>");
   sb.append("submitted-Date: " + subDate + "<br>");
   sb.append("submitted-amount: " + subAmount + "<br>");
   sb.append("sanctioned-amount: " + sanAmount + "<br>");
   sb.append("sanctioned-Date: " + sanDate + "<br>");
   return sb.toString();
  }

}