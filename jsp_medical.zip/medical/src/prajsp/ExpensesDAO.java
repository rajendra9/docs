package prajsp;

import java.util.ArrayList;
import java.sql.Connection; 
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public final class ExpensesDAO {
  
 boolean result;
 Connection con = null;
 PreparedStatement pstmt = null;
 Statement stmt = null;
 ResultSet rs = null; 

 public Connection getConnection() {
  Connection cn = null;
  try {
   InitialContext ctx = new InitialContext();
   DataSource ds = 
		(DataSource)ctx.lookup("java:comp/env/jdbc/myPostgres");
   cn = ds.getConnection();
   
  }
  catch(SQLException | NamingException sqe){ 
	  sqe.printStackTrace();
  }
   return cn;
 }

  public void closeConnection() {
   try {
    if(pstmt != null)pstmt.close();
    if(con != null)con.close();
   }
   catch(SQLException sqle){}
  }
   
  public boolean validateUser(String user, String pword, String role) {
    System.out.println(user+ "::" + pword + "::" + role);
   int result = 0; 
   boolean ret = false;
   try {
    con = this.getConnection();
    System.out.println(con);
    String sqlStr = "select count(*) from expenseslog "+
              " where userid='" + user + "' and pword='" +
                pword +"' and rolename='" + role + "'"; 
    System.out.println(sqlStr);
    stmt = con.createStatement();
    rs = stmt.executeQuery(sqlStr);
    if(rs.next()) {
     result = rs.getInt(1);
     System.out.println("****" + result);
    } 
    if(result>0){
      ret = true;
    }
   }
   catch(Exception e){}
   finally {
    try {
     closeConnection();
    }
    catch(Exception se){}
   }
   return ret;
  }

  public ArrayList<EmpVO> getEmployees(String boss) {
   ArrayList<EmpVO> list = new ArrayList<EmpVO>();
   EmpVO evo = null;
   java.sql.Date dt = null;
   double amount = 0.0;
   try {
    con = getConnection();
    String sqlstr = "select trans_id,empid,ename,do_sub,"+
               "coalesce(amt_sub,0),do_san,coalesce(amt_san,0)  "+
              " from expenses where boss=? and do_san is null"; 
    pstmt = con.prepareStatement(sqlstr);
    pstmt.setString(1,boss);
    rs = pstmt.executeQuery();
    while(rs.next()) {
     evo = new EmpVO();
     evo.setTransId(rs.getInt(1));
     evo.setEmpId(rs.getInt(2));
     evo.setName(rs.getString(3));
     dt = rs.getDate(4);
     if(dt != null) {
       evo.setSubDate(dt);
     }
     amount = rs.getDouble(5);
     if(amount != 0.0) { 
      evo.setSubAmount(amount);
     }
     dt = rs.getDate(6);
     if(dt != null) {
      evo.setSanDate(dt);
     }  
     amount = rs.getDouble(7);
     if(amount != 0.0) { 
      evo.setSanAmount(amount);
     }   
     list.add(evo);
    }
   }
   catch(SQLException se){
    se.printStackTrace();
   }
   finally {
    try {
     closeConnection();
    }
    catch(Exception se){}
   }
   return list;
  }
  
  public int getCurrentTransId() {
   int current = 0;
   try {
    con = getConnection();
    String sqlstr ="select max(trans_id)+1 from expenses"; 
    stmt = con.createStatement();
    rs = stmt.executeQuery(sqlstr);
    if(rs.next()) {
     current = rs.getInt(1);
    }
   }
   catch(Exception e){}
   finally {
    try {
     closeConnection();
    }
    catch(Exception se){}
   }
   return current;
  }

   public boolean addExpenses(int tno, int eno,
                              String name, String boss,
                              String sDate, double amt) {
   boolean ret = false;
   int rows = 0;
   try {
    con = getConnection();
    String sqlstr = "insert into expenses(trans_id,empid,"+
                    "ename,boss,do_sub,amt_sub)"+
                    " values(?,?,?,?,?,?)"; 
    pstmt = con.prepareStatement(sqlstr);
    pstmt.setInt(1,tno);    
    pstmt.setInt(2,eno);
    pstmt.setString(3,name);
    pstmt.setString(4,boss);
    java.sql.Date dt = java.sql.Date.valueOf(sDate);
    pstmt.setDate(5,dt);
    pstmt.setDouble(6,amt);
    rows = pstmt.executeUpdate();
   }
   catch(Exception e) {
    e.printStackTrace();
   }
   finally {
    try {
     closeConnection();
    }
    catch(Exception se){}
   }

   if(rows>0)ret = true;  
   return ret;
  }

   public boolean updateExpenses(int transid,
                 String sanDate, double sanAmount) {
    boolean ret = false;
    int rows = 0;
    try {
     con = getConnection();
     String sqlstr = "update expenses set do_san=?,"+
                     " amt_san=? where trans_id=?"; 
     pstmt = con.prepareStatement(sqlstr);
     java.sql.Date sanDt = java.sql.Date.valueOf(sanDate); 
     pstmt.setDate(1,sanDt);
     pstmt.setDouble(2,sanAmount);
     pstmt.setInt(3,transid);
     rows = pstmt.executeUpdate();
   }
   catch(Exception e) {
    e.printStackTrace();
   }
   finally {
    try {
     closeConnection();
    }
    catch(Exception se){}
   }

   if(rows>0)ret = true;  
    return ret;
  }

  public String[] getManagers() {
   String[] ret = null;
   ArrayList<String> list = new ArrayList<String>();
   try {
    con = getConnection();
    String sqlstr = "select userid from expenseslog where rolename='M'"; 
    stmt = con.createStatement();
    rs = stmt.executeQuery(sqlstr);
    while(rs.next()) {
     list.add(rs.getString(1));
    } 
    ret =new String[list.size()];
    int k = 0;
    for(String s: list) {
     ret[k] = s;
     k++;
    }
   }
   catch(Exception e){}
   finally {
    try {
     closeConnection();
    }
    catch(Exception se){}
   }
   return ret;
  }
 
 }