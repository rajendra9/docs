package com.htc.jsps.util;

import java.io.Serializable;

public class ItemPoly implements Serializable {
    private  int     itemId;
    private  String  itemName;
    private  double  itemCost;
    private  String customer;
    
    public ItemPoly() {
        
    }

    public ItemPoly(int itemId, 
                   String itemName, 
                   double itemCost,
                   String customer) {
        super();
        this.itemId = itemId;
        this.itemName = itemName;
        this.itemCost = itemCost;
        this.customer = customer;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public double getItemCost() {
        return itemCost;
    }

    public void setItemCost(double itemCost) {
        this.itemCost = itemCost;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + itemId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ItemPoly other = (ItemPoly) obj;
        if (itemId != other.itemId)
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "{itemId:" + itemId + ", itemName:'" + itemName
                + "', itemCost:" + itemCost + ", customer:'" + customer + "'}";
    }
    
    

}
