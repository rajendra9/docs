package com.htc.jsps.util;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class ItemsService implements ItemsDAO {
	   
   ConcurrentMap<Integer,ItemPoly> items;
   
   {
     items = new ConcurrentHashMap<>();
     ItemPoly item = new ItemPoly(1200,"HTC Casio",12254.35,"M/s Katirvel & Bros");
     items.put(item.getItemId(), item);
     item = new ItemPoly(1300,"Nokia 2X",8765.5,"M/s Kathirvan & Associates");
     items.put(item.getItemId(), item);
     item = new ItemPoly(1400,"Samsung Galaxy",24000.15,"M/s Maithreyan & Co");
     items.put(item.getItemId(), item);
     item = new ItemPoly(1500,"LG white",12455.5,"M/s Shakeel Stores");
     items.put(item.getItemId(), item);   
   }
   
   public List<ItemPoly> getAllItems() {
	   List<ItemPoly> ret = new ArrayList<>();
	   ret.addAll(items.values());
	   return ret;
   }

   public ItemPoly searchItem(int itemId){
	   ItemPoly searched = new ItemPoly();
	   if(this.items.containsKey(itemId)){
		  searched = this.items.get(itemId); 
	   }
	   return searched;
   }
   
   public void setItems(ConcurrentMap<Integer, ItemPoly> items) {
	 this.items = items;
   }

   public boolean saveItem(ItemPoly item) {
     int id = item.getItemId();
     if(!items.containsKey(id)){
        items.put(id, item);
        System.out.println(items);
        return true;
     }          
     return false;
   }
   
}
