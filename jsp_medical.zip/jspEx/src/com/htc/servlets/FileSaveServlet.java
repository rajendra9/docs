package com.htc.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static java.nio.file.StandardOpenOption.CREATE;
import static java.nio.file.StandardOpenOption.WRITE;


@WebServlet("/fileSave")
public class FileSaveServlet extends HttpServlet {
    
	public static final String FILENAME = "userDetails.dat";
    
	String sep = FileSystems.getDefault().getSeparator();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
           ServletContext stx = this.getServletContext(); 
	   String loc = stx.getRealPath("/users");
           System.out.println(loc);
           Path p = Paths.get(loc+sep+FILENAME);
           Charset chSet = Charset.forName("UTF-8");
           PrintWriter out = new PrintWriter(Files.newBufferedWriter(p, chSet, CREATE,WRITE));
           out.println("I am from One");
           out.close();
           RequestDispatcher rd = stx.getRequestDispatcher("/overWrite");
           rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
             doGet(request,response);
	}

}
