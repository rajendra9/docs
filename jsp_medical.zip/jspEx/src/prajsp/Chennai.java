package prajsp;

import java.io.Serializable;

public enum Chennai implements Serializable {
   NORTH(20),SOUTH(32),WEST(22),EAST(21);
   int distanceFromCenter;
   Chennai(int distance){
     distanceFromCenter = distance;  
   }
   public int getDistanceFromCenter(){
       return distanceFromCenter;
   }
   
}
