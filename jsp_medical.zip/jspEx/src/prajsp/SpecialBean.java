package prajsp;

import java.util.List;
import java.util.ArrayList;


public class SpecialBean implements java.io.Serializable {
 
  public SpecialBean() {
     System.out.println("This is From Special Bean"); 
  }

  public SpecialBean(String name) {
      this.name = name; 
  }
  
  String name;

  @Override
  public String toString() {
    return "SpecialBean [name=" + name + "]";
  }

List<Double> dblList = new ArrayList<>();
   
  {
   dblList.add(new Double(3.6));
   dblList.add(new Double(6.5));
   dblList.add(new Double(16.5));
   dblList.add(new Double(32.5));
   dblList.add(new Double(14.5));
   dblList.add(new Double(21.5));
   name = "Parameswaran";
  }

  
  
  public List<Double> getDblList(){
    return dblList;
  }
   
  public void setDblList(List<Double> list){
    this.dblList = list;
  }

  public String getName(){
    return name;
  }
   
  public void setName(String name){
    this.name = name;
  }

  
  public String show() {
    StringBuffer sb = new StringBuffer();
    for(double d: dblList){
     sb.append(d+"<br/>");
    }
    return sb.toString();
  }

  public String upper(String src){
    return src.toUpperCase();
  }

  public String add(double dbl){
    dblList.add(dbl);
    return this.show();
  }

  public  String displayList(List<Employee> emps){
      StringBuffer sb = new StringBuffer();
      for(Employee e: emps){
       sb.append(e+"<br/>");
      }
      return sb.toString();  
  }
}  