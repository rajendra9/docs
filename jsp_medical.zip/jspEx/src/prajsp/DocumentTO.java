package prajsp;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.NamedQuery;
import javax.persistence.ElementCollection;
import javax.persistence.CollectionTable;
import javax.persistence.JoinColumn;
import javax.persistence.FetchType;
import javax.persistence.OrderColumn;
import java.util.List;
import java.util.ArrayList;


@Entity
@Table(name="MYDOCS")
@NamedQuery(name="allDocs",query="select d from DocumentTO d")
public class DocumentTO implements Serializable {
    
   private  String   docId;
   private  String   docDesc;
   private  String   author;
   private  int      nop;
    
   private  List<String>  topics;
   
   {
    topics = new ArrayList<String>();    
   }
    
    
   
   public DocumentTO() {       
   }

   public DocumentTO(String docId, 
                     String docDesc,
                     String author,
                     int nop) {
     super();
     this.docId = docId;
     this.docDesc = docDesc;
     this.author = author;
     this.nop = nop;
   }

   @Id
   @Column(name="DOC_ID")
   public String getDocId() {
     return docId;
   }

   public void setDocId(String docId) {
     this.docId = docId;
   }

   @Column(name="DOC_DESC")
   public String getDocDesc() {
     return docDesc;
   }

   public void setDocDesc(String docDesc) {
     this.docDesc = docDesc;
   }

   @Column
   public String getAuthor() {
     return author;
   }

   public void setAuthor(String author) {
     this.author = author;
   }
  
   @Column(name="NO_OF_PAGES")
   public int getNop() {
     return nop;
   }

   public void setNop(int nop) {
     this.nop = nop;
   }
    
   @ElementCollection(fetch=FetchType.EAGER)
   @CollectionTable(name="SUBTOPICS",
   joinColumns=@JoinColumn(name="DOC_ID"))
   @Column(name="SUBTOPIC")        
   public List<String> getTopics() {
     return topics;
   }

   public void setTopics(List<String> topics) {
     this.topics = topics;
   }

   @Override
   public String toString() {
     return "DocumentTO [docId=" + docId + ", docDesc=" + docDesc
            + ", author=" + author + ", nop=" + nop + "]";
   }    
    
}