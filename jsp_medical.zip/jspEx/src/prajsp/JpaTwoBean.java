package prajsp;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import java.util.List;
import java.util.ArrayList;

public class JpaTwoBean  {
	
  EntityManager em;
  EntityTransaction trans;
    
  public JpaTwoBean() {
    EntityManagerFactory factory = 
      Persistence.createEntityManagerFactory("myDB");
    em = factory.createEntityManager();		
  }     

	
  public boolean saveDocument(DocumentTO docTO, String[] topics) {
    boolean  ret = false;
    List<String> topicList = docTO.getTopics();
    for(String topic : topics) {
     topicList.add(topic);
    }	
    trans = em.getTransaction();
    try {
     trans.begin();
     em.persist(docTO);
     ret = true;
     trans.commit();	  
    }catch(Exception ex) {
      ex.printStackTrace();
      trans.rollback();
    }           
    return  ret;
  }

  public List<DocumentTO> getDocuments() {
   List<DocumentTO> list = new ArrayList<DocumentTO>(); 
   trans = em.getTransaction();
   trans.begin();
   try {
    Query qry = em.createNamedQuery("allDocs");
    List li = qry.getResultList();
    list.addAll(li);
    trans.commit();
   }catch(Exception ex) {
      trans.rollback();
   }
   return list;
 }   

}