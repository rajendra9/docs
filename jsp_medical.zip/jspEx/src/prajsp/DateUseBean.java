package prajsp;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUseBean implements Serializable {
    private Date  dbDate;
    private String dob; 
    SimpleDateFormat sdf;
    
    {
      sdf = new SimpleDateFormat("yyyy-MM-dd");
    }

    public String getDob() {
        return sdf.format(dbDate);
    }

    public void setDob(String dob) {
        this.dob = dob;
        try{
          dbDate = sdf.parse(dob);  
        }catch(ParseException pe){
          throw new RuntimeException(pe.getMessage());  
        }
    }

    public Date getDbDate() {
        return dbDate;
    }

    public void setDbDate(Date dbDate) {
        this.dbDate = dbDate;
    }
    
    
    
}
