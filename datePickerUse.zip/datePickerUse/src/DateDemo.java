import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
public class DateDemo {


    public static void main(String[] args) {
       String dtStr = "12-02-2017";
       DateTimeFormatter dtp = DateTimeFormatter.ofPattern("dd-MM-yyyy");
       LocalDate locDate = LocalDate.parse(dtStr, dtp);
       System.out.println(locDate);
    }

}
