package com.htc.javafx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.net.URL;

public class ForStudent extends Application {

	@Override
   public void start(Stage primaryStage) {
	 URL location = ForStudent.class.getResource("forStudent.fxml");
	 try{
	   AnchorPane page =
	         (AnchorPane)FXMLLoader.load(location);
	   Scene scene = new Scene(page);
	   primaryStage.setScene(scene);
	   primaryStage.show();
     }catch(Exception ex){
         ex.printStackTrace();
     }
	}
	public static void main(String[] args) {
		launch(args);
	}
}
