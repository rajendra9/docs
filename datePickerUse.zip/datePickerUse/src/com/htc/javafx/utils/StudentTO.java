package com.htc.javafx.utils;

import java.io.Serializable;
import java.time.LocalDate;

public class StudentTO implements java.io.Serializable {
    private int stuId;
    private String stuName;
    private LocalDate  dateOfJoining;
    private String  course;
    private String  parentEmail;

    public StudentTO(String stuName,
                     LocalDate dateOfJoining,
                     String course,
                     String parentEmail) {
        super();
        this.stuName = stuName;
        this.dateOfJoining = dateOfJoining;
        this.course = course;
        this.parentEmail = parentEmail;
    }

    public StudentTO() {
        super();
    }

    public int getStuId() {
        return stuId;
    }

    public void setStuId(int stuId) {
        this.stuId = stuId;
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public LocalDate getDateOfJoining() {
        return dateOfJoining;
    }

    public void setDateOfJoining(LocalDate dateOfJoining) {
        this.dateOfJoining = dateOfJoining;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getParentEmail() {
        return parentEmail;
    }

    public void setParentEmail(String parentEmail) {
        this.parentEmail = parentEmail;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((parentEmail == null) ? 0 : parentEmail.hashCode());
        result = prime * result + ((stuName == null) ? 0 : stuName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        StudentTO other = (StudentTO) obj;
        if (parentEmail == null) {
            if (other.parentEmail != null)
                return false;
        } else if (!parentEmail.equals(other.parentEmail))
            return false;
        if (stuName == null) {
            if (other.stuName != null)
                return false;
        } else if (!stuName.equals(other.stuName))
            return false;
        return true;
    }
    

    @Override
    public String toString() {
        return "StudentTO [stuId=" + stuId + ", stuName=" + stuName
                + ", dateOfJoining=" + dateOfJoining + ", course=" + course
                + ", parentEmail=" + parentEmail + "]";
    }




}
