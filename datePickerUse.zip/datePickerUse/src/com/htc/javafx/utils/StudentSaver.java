package com.htc.javafx.utils;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Collection;

public class StudentSaver {
   ConcurrentMap<Integer,StudentTO>  students;
   AtomicInteger idGen = new AtomicInteger(10);

   {
     students = new ConcurrentHashMap<>();
   }

   public  boolean  addStudent(StudentTO student){
     System.out.println(student);
     boolean ret = false;
     if(!students.values().contains(student)){
      int slNum = idGen.incrementAndGet();
      student.setStuId(slNum);
      students.put(student.getStuId(),student);
      ret = true;
     }
    return ret;
   }
   public int getStudentId(StudentTO student){
       int ret = 0;
       String name = student.getStuName();
       String pEmail = student.getParentEmail();
       Collection<StudentTO> stus = students.values();
       System.out.println(stus);
       for(StudentTO st : stus){
         if(  st.getStuName().equalsIgnoreCase(name)
            && st.getParentEmail().equalsIgnoreCase(pEmail)){
           ret = st.getStuId();
           break;
         }
       }
       System.out.println("****" + ret);
       return ret;
   }

   public boolean  updateStudent(StudentTO student){
      System.out.println(student);
      int stuId = this.getStudentId(student);
      System.out.println(stuId);
      boolean  ret = false;
      if(stuId>0){
       students.put(student.getStuId(),student);
       ret = true;
      }
      return ret;
   }
}
