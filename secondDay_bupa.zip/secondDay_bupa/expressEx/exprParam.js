// JavaScript Document
var express = require('express');
var Map = require('collections/Map');
var persMap = new Map();
function Person(personId,personName,address,income){
  this.personId = personId;
  this.personName = personName;
  this.address = address;
  this.income = income;
  this.info=function(){
    return 'Id:'+this.personId+' Name:'+this.personName+' Address:'+this.address+' Income:'+this.income;
  }
}
persMap.set('ch2100',new Person('ch2100', 'Lingusamy', 'Guindy,Chennai',28000.0));
persMap.set('ko3200',new Person('ko3200', 'Parameswaran', 'VictoriaTown,Kovai',328000.0));
persMap.set('ch2500',new Person('ch2500', 'Sadashivan', 'Pallavaram,Chennai',31500.0));
persMap.set('ch2540',new Person('ch2540', 'Sarala', 'Avadi,Chennai',31500.0));
persMap.set('ma1200',new Person('ma1200', 'Sunder', 'Goripalayam,Madurai',28000.0));
function getPerson(id){
  if(persMap.has(id)){
    person = persMap.get(id);
    return person.info();
  }
  else{
    return 'Not Available';
  }
}    

var app = new express();
var router = express.Router();
router.use(function(req,res,next){
  console.log('Time:'+Date.now());
  next();
})


router.use('/person/:persId',function(req,res,next){
    if(req.params.persId==0){
      res.send('parameter not given');
    }
    else{
      id =  req.params.persId;
      data = getPerson(id);
      res.send(data);
    }  
});
app.use('/',router);
var server = app.listen(5000,function(){
  console.log('Server is running at 5000 port');
});  