var express = require('express');
var path = require('path');
var Map = require('collections/Map');
var usersMap = new Map();
usersMap.set('prasad','pras123');
usersMap.set('raghu','raghu123');
usersMap.set('neeraj','neeru23');
function validate(user,pwd){
  if(usersMap.has(user)){
	if(usersMap.get(user)==pwd){
		return true;
	}  
  }	
  return false;
}

var app = new express();
var bodyParser = require('body-parser'); 

app.use(bodyParser.urlencoded({extended:false}));

app.get('/',function(request,response){
   response.sendFile(path.join(__dirname,'login.html'));	
});

app.post('/login',function(request,response){
  var username = request.body.username;
  var password = request.body.credential;
  if(validate(username,password)){
	 response.send('Authenticated, Go Ahead for Shopping');	
  } 
  
});
var server = app.listen(5000,function(){
	console.log('Server started at 5000');
});