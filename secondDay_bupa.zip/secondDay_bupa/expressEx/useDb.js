var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');
var mysql = require('mysql');
var connection = mysql.createConnection({
    host:"localhost",
    port:3306,
    user:"dtrprasad",
    password:"prasad"
    });
  
 connection.query("use samp");

 
 function saveSales(salesman,month,revenue){
 
  id = parseInt('1000',10);
  rev = parseFloat(revenue);
  var params = [id, salesman, month, rev];
  connection.query('insert into sales(sale_id,salesman,salesmonth,revenue) values (?,?,?,?)',
                params,function(err){
    if(err){
      console.error(err);      
    }
    else{
      console.info('data inserted');              
    }    
  });
}

process.on('exit', function(){
  connection.end();
  console.log('program is exiting');
 });
var app = new express();


app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

app.get('/',function(request,response){
   response.sendFile('saveSales.html',{root:path.join(__dirname,'./public')});   
});

app.post('/',function(request,response){
	console.log('llll');
	var salesman = request.body.salesman;
	var salesmonth = request.body.salesmonth;
	var revenue = request.body.revenue;
  saveSales(salesman,salesmonth,revenue);
  
  response.end('<h3 align="center">Salesman info saved</h3>');	
});
var server = app.listen(5000,function(){
	console.log('Server started at 5000');
});

setTimeout(function(){
  process.exit(1);
},250000);