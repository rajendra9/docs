var exp = require('express');
var querystring = require('querystring');
var bodyParser = require('body-parser');

var app = exp();
app.use(bodyParser.urlencoded({ extended: false }));  
app.use(bodyParser.json());

app.get("/",function(request,response){
    response.end('Hello world')});

app.get('/hello',function(request,response){
        response.end("Hello Hi I am Express framework");
});
    
app.get('/helloParam',function(request,response,next){
    response.set('Content-Type', 'text/html');    
    
    if(request.query.name !=null){
        var nameVal = request.query.name;    
        response.end('<h1>Hello Hi ' + nameVal + 'Welcome To Express framework</h1>');
    }  
    response.end('Hello Hi param name missing');
});

    
     

app.listen(5000, function(){
    console.log("Server  started at 5000");
})