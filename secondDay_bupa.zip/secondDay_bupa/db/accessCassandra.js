var cassandra = require('cassandra-driver');
var async = require('async');


var conn = new cassandra.Client({contactPoints:['127.0.0.1:9042'],keyspace:'my_hr'});
conn.execute('select empno,ename,job,sal,deptno from emp',function(err,result){
  if(err){
   console.error(err);
  }
  else{
    if(result.rows.length>0){
	 for(var i=0;i<result.rows.length;i++){
	   var emp = result.rows[i];
	   console.log(emp.empno+', '+emp.ename+', '+emp.job+', '+emp.sal+', '+emp.deptno);
	 }
	 process.exit(1);
   }
   else{
	  console.log('error in execution'); 
   }
  }
});