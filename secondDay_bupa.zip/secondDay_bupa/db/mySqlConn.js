// JavaScript Document
var mysql = require('mysql');

var connection = mysql.createConnection({
   host:"localhost",
   port:3306,
   user:"dtrprasad",
   password:"prasad"
   });
   function showResults(rows){
     var data = "";
     for(row in rows){
       data += rows[row].bird_id+" "+rows[row].bird_name+" "+rows[row].doi+"\r\n";
     }
    console.log(data);
   }
   connection.query("use samp");
   var qryStr = "select bird_id,bird_name,date_format(doi,'%D,%m,%Y') doi from birds";
   connection.query(qryStr,function(err, rows){
     if(err){
       console.log("Error in fetching");
     }
     else{
      showResults(rows);
     }
     });
     connection.end();    
