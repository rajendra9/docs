var mysql = require('mysql');
function updateRec(id, newIncome){
  var connection = mysql.createConnection({
    host:"localhost",
    port:3306,
    user:"dtrprasad",
    password:"prasad"
    });
  
    connection.query("use samp");
    var qryStr = "update persons set income=? where ssn = ?";      
    connection.query(qryStr, [newIncome, id],function(err, result){
     if(err){
       console.log("Error in fetching");
     }
     else{
      console.log(result);
     }
    });
    connection.end();    
}
updateRec('s100',620000.5);
