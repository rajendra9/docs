drop table if exists persons;

create table persons(ssn varchar(12) primary key, name varchar(25),location varchar(20),income double);