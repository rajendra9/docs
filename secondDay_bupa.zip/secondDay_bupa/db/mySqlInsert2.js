var mysql = require('mysql');

function insertRec(id,  na, loc, ic){
  var connection = mysql.createConnection({
    host:"localhost",
    port:3306,
    user:"dtrprasad",
    password:"prasad"
    });
  
    connection.query("use samp");
    var pers = {'ssn':  id , 'name' : na, 'location' : loc, 'income' : ic};
    var qryStr = "insert into persons set ?";      
    connection.query(qryStr, pers, function(err, result){
     if(err){
       console.log("Error in fetching");
     }
     else{
      console.log(result);
     }
    });
    connection.end();    
}
insertRec('s200','Santosh','Chennai',550000.5);
