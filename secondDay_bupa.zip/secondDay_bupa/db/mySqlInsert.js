var mysql = require('mysql');

function insertRec(id,  na, loc, ic){
  var connection = mysql.createConnection({
    host:"localhost",
    port:3306,
    user:"dtrprasad",
    password:"prasad"
    });
  
    connection.query("use samp");
   
    var qryStr = "insert into persons values('"+id+"','"+na+"','"+loc+"',"+ic+")";      
    connection.query(qryStr,function(err, result){
     if(err){
       console.log("Error in inserting");
     }
     else{
      console.log(result);
     }
    });
    connection.end();    
}
insertRec("s100","Sudarshan","Chennai",540000.5);
