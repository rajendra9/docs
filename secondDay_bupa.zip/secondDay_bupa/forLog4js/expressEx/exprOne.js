var express = require('express');
var app = express();

app.get('/hello',function(request,response){
    response.send("Hello world");
});

var server = app.listen(5000,
     function()
     {
    console.log("Server  started at 5000");
})