package com.jee.jaxb;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="employee",
        propOrder={"empNum","empName","job","salary","deptName"})
@SuppressWarnings("serial")
public class Employee implements Serializable {
  
   @XmlElement(type=String.class)
   private  String empNum;
   
   @XmlElement(type=String.class)
   private  String empName;
   
   @XmlElement(type=String.class)
   private  String job;
   
   @XmlElement(type=Double.class)
   private  double salary;
   
   @XmlElement(type=String.class)
   private  String deptName;
 
   public Employee() {
	super();	
   }
   
   @Override
    public String toString() {
	return "Employee [empNum=" + empNum + ", empName=" + empName + ", job=" + job + ", salary=" + salary + ", deptName="
			+ deptName + "]";
    }

   public Employee(String empNum, String empName, String job, double salary, String deptName) {
       super();
	   this.empNum = empNum;
	   this.empName = empName;
	   this.job = job;
	   this.salary = salary;
	   this.deptName = deptName;
   }


   public String getEmpNum() {
	 return empNum;
   }

   public void setEmpNum(String empNum) {
    	this.empNum = empNum;
   }

   public String getEmpName() {
	  return empName;
   }

   public void setEmpName(String empName) {
	  this.empName = empName;
   }

   public String getJob() {
	  return job;
   }

   public void setJob(String job) {
	  this.job = job;
   }

   public double getSalary() {
	  return salary;
   }

   public void setSalary(double salary) {
	   this.salary = salary;
   }

   public String getDeptName() {
	  return deptName;
   }

   public void setDeptName(String deptName) {
	  this.deptName = deptName;
   }

   @Override
   public int hashCode() {
	  final int prime = 31;
	  int result = 1;
	  result = prime * result + ((empNum == null) ? 0 : empNum.hashCode());
	 return result;
   }

   @Override
   public boolean equals(Object obj) {
	  if (this == obj)
		return true;
      if (obj == null)
		return false;
	  if (getClass() != obj.getClass())
		return false;
	  Employee other = (Employee) obj;
	  if (empNum == null) {
		if (other.empNum != null)
			return false;
    	} else if (!empNum.equals(other.empNum))
		return false;
	  return true;
   }

   
}
