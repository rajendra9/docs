package com.jee.jaxb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@SuppressWarnings("serial")
public class Employees implements Serializable {

	public Employees() {
		// TODO Auto-generated constructor stub
	}
	
    List<Employee> emps = new ArrayList<>();
	
    
    public List<Employee> getEmployees() {
		return emps;
	}
    
    @XmlElement(name="employee")
	public void setEmployees(List<Employee> emps) {
		this.emps = emps;
	}
	
	public void add(Employee emp) {
		if(!this.emps.contains(emp)) {
			this.emps.add(emp);
		}
	}
}
