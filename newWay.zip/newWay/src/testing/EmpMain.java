package testing;

import java.io.File;
import java.io.PrintWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;

import com.jee.jaxb.Employee;
import com.jee.jaxb.Employees;

public class EmpMain {
    
	Marshaller marshaller;
    Unmarshaller unmarshaller;
    
    public EmpMain()throws Exception
	{
	  JAXBContext ctx = 
			  JAXBContext.newInstance(com.jee.jaxb.Employees.class);
	  marshaller = ctx.createMarshaller();
	  unmarshaller = ctx.createUnmarshaller();
	}
	
	public Employees createEmps() {
		Employees emps = new Employees();
		Employee emp = 
			new Employee("M654", "Aneesh", "Developer", 30000.5, "APFarms");
		emps.add(emp);
		emp = new Employee("M684", "Satish", "Developer", 31000.5, "CICS");
		emps.add(emp);
		emp = new Employee("M764", "Raghu", "Developer", 32000.5, "APFarms");
		emps.add(emp);
		return emps;
	}
	
	public void saveAsXml(String name) throws Exception{
		Employees emps = this.createEmps();
		PrintWriter out = new PrintWriter(name);
		//QName qname = new QName(emps.getClass().getSimpleName());
		//JAXBElement<Employees> rootJaxb = new JAXBElement<>(qname, com.jee.jaxb.Employees.class, emps);
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(emps, out);
		marshaller.marshal(emps, System.out);
		out.close();		
	}
	
	public void readXml(String name) throws Exception {
		Employees emps =
				(Employees)unmarshaller.unmarshal(new File(name));	   
	    emps.getEmployees().forEach(System.out::println);
	}
	public static void main(String[] args) {
	  try {
		EmpMain empMain = new EmpMain();
		empMain.saveAsXml("emps.xml");
		empMain.readXml("emps.xml");
	  }catch(Exception ex) {
		  ex.printStackTrace();
	  }
	}

}
