package com.htc.rest.utils;

import java.io.Serializable;
import java.io.StringReader;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.json.bind.JsonbBuilder;


public class ProductStore implements Serializable {
  ConcurrentMap<String, ProdInfo> prodStore = new ConcurrentHashMap<>();
  
  {
	ProdInfo prod = new ProdInfo("s121", "Lux", 32.5, "M/s Ganesh Store");
	prodStore.put(prod.getProdId(), prod);
	
	prod = new ProdInfo("s154", "Cinthol", 26.5, "M/s Madhavan Soaps");
	prodStore.put(prod.getProdId(), prod);
	
	prod = new ProdInfo("s165", "Dove", 46.5, "M/s Nirmal Markets");
	prodStore.put(prod.getProdId(), prod);
	
	
  }
  
  public String searchRetAsJson(String id) {
	 System.out.println(id);
	 ProdInfo prod = this.prodStore.get(id);
	 return JsonbBuilder.create().toJson(prod);
  }
 
 /* public JsonObject saveProddGotAsJson(String objJsonStr) {
	 JsonObjectBuilder objBuilder = Json.createObjectBuilder();
     JsonParser parser = Json.createParser(new StringReader(objJsonStr));
	 String id = "", pName="", suppl = "";
	 double cost = 0.0;
	 StringBuffer sb = new StringBuffer();
     while(parser.hasNext()) { 
		Event evt = parser.next();
		if(evt==Event.VALUE_STRING) {
		  sb.append(parser.getString()+"|");
		}
		else if(evt == Event.VALUE_NUMBER){
		  cost = parser.getBigDecimal().doubleValue(); 	
		}
	  }
	  String[] tokens = sb.toString().split("[|]");
	  id = tokens[0];
	  pName = tokens[1];
	  suppl = tokens[2];
	  ProdInfo forSave = new ProdInfo(id, pName, cost, suppl);
	  if(!prodStore.containsKey(id)) {
		  prodStore.put(id,  forSave);
		  objBuilder.add("msg","product with:" + id + " has been Saved");
	  }else {
		  objBuilder.add("msg","product with:" + id + " could not be Saved"); 
	  }
	  return objBuilder.build();
	  }
   */
  
  
}
