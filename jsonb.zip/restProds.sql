drop table if exists rest_prods;

create  table rest_prods(prod_id varchar(10) primary key, prod_name  varchar(30),
cost decimal(8,2),supplier varchar(40));

insert into rest_prods values('s121', 'Lux', 32.5, 'M/s Ganesh Store');
	
insert into rest_prods values('s154', 'Cinthol', 26.5, 'M/s Madhavan Soaps');
insert into rest_prods values('s165', 'Dove', 46.5, 'M/s Nirmal Markets');

select *  from rest_prods;

	
