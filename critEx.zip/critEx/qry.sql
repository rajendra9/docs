select * from  products;






