package com.htc.hibers;

public class TestProdDao {
	public static void main(String[] args)throws Exception {
		  ProdDaoImpl ht = new ProdDaoImpl();
		  
		  Product p1 = new Product(10, "Lux", "N",19.50);
		  Product p2 = new Product(20, "Pears", "R",25.80);        
		  Product p3 = new Product(30, "Cinthol", "N",19.80);
		  Product p4 = new Product(40, "Dove", "R", 32.80); 
		  Product p5 = new Product(50, "Fa","R", 35.80);           
		  Product p6 = new Product(60, "Marvel", "R", 23.50); 
		   
		  ht.persistProduct(p1);
		  ht.persistProduct(p2);
		  ht.persistProduct(p3);
		  ht.persistProduct(p4);
		  ht.persistProduct(p5);
		  ht.persistProduct(p6);

		  System.out.println("Products created");

		  p1.setCost(24.50);
		  ht.updateProduct(p1);
		  System.out.println("\nProduct updated\n");

		  System.out.println("Before Removal\n");
		  System.out.println(ht.getAll());
		  ht.removeProduct(p2); 
		  System.out.println("\nProduct removed,after removal\n");
		  System.out.println(ht.getAll());
		     

		  System.out.println("\nShowing products by cost "+
		                     " higher than Rs30/-\n");
		  double limit = 30.00f;
		  System.out.println(ht.getProductsCostlierThan(limit));

		 
		 }

		
				    
}
