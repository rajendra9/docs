package com.htc.hibers;

import java.io.Serializable;
import java.util.List;

public interface ProdDao extends Serializable {
	 public void updateProduct(Product p);
	 public void persistProduct(Product p);
	 public void removeProduct(Product p);
	 public List<Product> getAll();
	 public List<Product> getProductsCostlierThan(double d);

}
