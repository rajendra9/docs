package com.htc.hibers;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="htc_products")
public class Product implements Comparable<Product>, java.io.Serializable  {
  
 private  int     prodId;
 private  String  prodName;
 private  String  prodType;
 private  double  cost;  
  
 public Product() {
  super();
 }

 
public Product(int prodId, String prodName, String prodType, double cost) {
	super();
	this.prodId = prodId;
	this.prodName = prodName;
	this.prodType = prodType;
	this.cost = cost;
}


@Column
 public double getCost() {
  return cost;
 }

 public void setCost(double cost) {
  this.cost = cost;
 }
 
 @Id
 @Column
 public int getProdId(){
  return prodId;
 }

 public void setProdId(int prodId) {
  this.prodId = prodId;
 }

 @Column(name="pname")
 public String getProdName() {
  return prodName;
 }

 public void setProdName(String prodName) {
  this.prodName = prodName;
 } 
 @Column(name="prod_type")
 public String getProdType() {
  return prodType;
 }

 public void setProdType(String prodTy) {
  this.prodType = prodTy;
 } 

 @Override
 public String toString() {
  StringBuffer sb = new StringBuffer();
  sb.append("Prod-Id:" + prodId +" Name: " + prodName +
            " Type: " + prodType + " Cost:" + cost);
  return sb.toString();
 }

 public int compareTo(Product arg0) {
  return this.prodId - arg0.prodId;
 }   
	
}