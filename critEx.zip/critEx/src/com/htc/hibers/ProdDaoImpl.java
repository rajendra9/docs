package  com.htc.hibers;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Root;

//import org.hibernate.criterion.Order;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;  

@SuppressWarnings("serial")
public class ProdDaoImpl  implements ProdDao {
 
 
 static SessionFactory sf;
 static {
  try {
   sf = HibernateBoot.getFactory();
  }
  catch(Exception e) {
   e.printStackTrace();
  }
 }

 public void updateProduct(Product p){
  Session session = sf.openSession();
  Transaction tx = session.beginTransaction();
  try {
   session.update(p);
   
  }
  catch(Exception e){
   tx.rollback();
  }
  tx.commit(); 
  session.close();
 }   

 public void persistProduct(Product p) {
  Session session = sf.openSession();
  Transaction tx = session.beginTransaction();
  try {
   session.save(p);
 
  } 
  catch(Exception e) {
   tx.rollback();
  } 
  tx.commit(); 
  session.close();
 } 

 public void removeProduct(Product p) {
  Session session = sf.openSession();
  Transaction tx = session.beginTransaction();
  try {
   session.delete(p);
   
  }
  catch(Exception e) {
   tx.rollback();
  }
  tx.commit(); 
  session.close();
 }
 
 

 public List<Product> getAll() {
	  Session session = sf.openSession();
	  Transaction tx = session.beginTransaction();
	  List<Product> list = new ArrayList<Product>();
	  try {      
	   
	   CriteriaBuilder critBuilder = session.getCriteriaBuilder();
	   CriteriaQuery<Product> critQry = critBuilder.createQuery(Product.class);
	   Root<Product> root = critQry.from(Product.class);
	   critQry.select(root);
	   critQry.orderBy(critBuilder.desc(root.get("prodName")));
	   Query<Product> qry = session.createQuery(critQry);
	   list = qry.list();   
	   tx.commit(); 
	     
	  }
	  catch(Exception e) {
	   tx.rollback();
	  }
	  
	  session.close();
	  return list;
	 }
	 

 public List<Product> getCostRestrictedProducts(double d) {
  Session session = sf.openSession();
  Transaction tx = session.beginTransaction();
  List<Product> list = new ArrayList<Product>();
  try {      
   
   CriteriaBuilder critBuilder = session.getCriteriaBuilder();
   CriteriaQuery<Product> critQry = critBuilder.createQuery(Product.class);
   Root<Product> root = critQry.from(Product.class);
   critQry.where(critBuilder.gt(root.get("cost"), new Double(d)));
   Query<Product> qry = session.createQuery(critQry);
   list = qry.list();   
   tx.commit(); 
     
  }
  catch(Exception e) {
   tx.rollback();
  }
  
  session.close();
  return list;
 }
 public void getCostProjections() {
	 Session session = sf.openSession();
	 Transaction tx = session.beginTransaction();
	 try {      
	   
	   CriteriaBuilder critBuilder = session.getCriteriaBuilder();
	   CriteriaQuery<Object[]> critQry = critBuilder.createQuery(Object[].class);
	   Root<Product> root = critQry.from(Product.class);
	   critQry.multiselect(root.get("prodType"), critBuilder.sumAsDouble(root.get("cost")));
	   critQry.groupBy(root.get("prodType"));
	   Query<Object[]> qry = session.createQuery(critQry);
	   List<Object[]> result = qry.list();
	   for(Object[] obj : result) {		   
		String type = (String)obj[0];
		Double sumCost = (Double)obj[1];
		System.out.println("ProdType->" + type + " SumCost --> " +sumCost);
		
	   }
	   tx.commit(); 
	   
       }catch(Exception e) {
		   tx.rollback();
	   }	  
	   session.close();
     }  
}
 