import React, {Component} from 'react';
import {connect}  from 'react-redux';

class StuSearch extends Component {

render(){

    return(
       <div align="center">
         <table>
          <tbody>      
           <tr><td><label>Enter Student Id:</label></td>
            <td><input type='text' onBlur={this.props.onSearchId.bind(this)} /></td>
           </tr>           
         </tbody>
        </table>
        <hr/>
        <button onClick={this.props.onAddStudent}>Add Student</button><br/>
        {this.props.student}
      </div>
       
    )
}   

}
const  mapStateToProps = (state)=>{
  return {
    student: state.student,
    students: state.students
  }
 };
 
const mapDispatchToProps = (dispatch)=>{
   return {
     onSearchId: (event)=>dispatch({type: 'SEARCH_ID', value: event.target.value}),   
     onSearchStudent: ()=> dispatch({type: 'SEARCH'}),       
};
 
}
 


 export default connect(mapStateToProps, mapDispatchToProps)(StuAdder);
