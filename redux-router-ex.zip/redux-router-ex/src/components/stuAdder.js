import React, {Component} from 'react';
import {connect}  from 'react-redux';

class StuAdder extends Component {
  
/*  changeId(event){
        this.setState({student:{stuId : event.target.value}});        
  }

  changeName(event){
    this.setState({student:{stuName: event.target.value}}); 
  }
  changeCourse(event){
    this.setState({student:{course: event.target.value}});        
  }
  */
  render(){
      return(
         <div align="center">
           <table>
            <tbody>      
             <tr><td><label>Enter Student Id:</label></td>
              <td><input type='text' onBlur={this.props.onChangeId.bind(this)} /></td>
             </tr>
             <tr><td><label>Enter Student Name:</label></td>
              <td><input type='text' onBlur={this.props.onChangeName.bind(this)} /></td>
             </tr>
             <tr><td><label>Enter Student Course:</label></td>
              <td><input type='text' onBlur={this.props.onChangeCourse.bind(this)} /></td>
             </tr>
           </tbody>
          </table>
          <hr/>
          <button onClick={this.props.onAddStudent}>Add Student</button>
          
        </div>
         
      )
  }   

}
const  mapStateToProps = (state)=>{
    return {
      student: state.student,
      students: state.students
    }
   };
   
  const mapDispatchToProps = (dispatch)=>{
     return {
       onChangeId: (event)=>dispatch({type: 'CHANGE_ID', value: event.target.value}),
       onChangeName: (event)=>dispatch({type: 'CHANGE_NAME', value: event.target.value}),
       onChangeCourse: (event)=>dispatch({type: 'CHANGE_COURSE', value: event.target.value}),
       onAddStudent: ()=> dispatch({type: 'ADD'}),       
  };
   
}
   


   export default connect(mapStateToProps, mapDispatchToProps)(StuAdder);
