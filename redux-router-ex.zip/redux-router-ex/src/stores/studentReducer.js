const startState = {
    student: {
        stuId: 0,
        stuName: '',
        course: ''
    },
    students: [{stuId: 1, stuName: 'Jaggu', course: 'JEE'}]
}
const changeId = (obj, val) =>{
    obj.stuId = val;
    return obj;
};
const changeName = (obj, val) =>{
    obj.stuName = val;
    return obj;
};
const changeCourse = (obj, val) =>{
    obj.course = val;
    return obj;
};
/*const addAndReset = (arr,obj) =>{
    arr.concat(obj);
    return arr;    
};*/

const StudentReducer = (state = startState, action) => {
    const existingState = {...state};
    if(action.type === "CHANGE_ID"){
        return {...state,
        student: state.student = changeId(state.student,action.value)  
       };       
    }
    else if(action.type === "CHANGE_NAME"){
        return {...state,
            student: state.student = changeName(state.student,action.value)
        };       
    }
    else if(action.type === "CHANGE_COURSE"){
        return {...state,
            student: state.student = changeCourse(state.student,action.value)
        };       
    }
    else if(action.type === "ADD"){ 
        console.log(state.student);
        return {...state,                      
             student: state.student,
             students: state.students.concat(state.student)
        };
             
    }  
    else if(action.type === "SEARCH_ID"){
        return {...state,
        student: state.student = changeId(state.student,action.value)  
       };       
    }
                 
    else if(action.type === "SEARCH"){
        let id = state.student.stuId; 
        return {...state,
                student: state.students.filter(stu=>{
                return stu.stuId === id ? stu : state.student;                                
        })              }
     }                       
     return existingState;             
   }
export default StudentReducer;