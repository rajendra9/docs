import React, { Component } from 'react';
import './App.css';
import {connect}  from 'react-redux';
import StuAdder from './components/stuAdder';


class App extends Component {
  render() {
    return (
      <div className="App">
        <StuAdder/><hr/>
      <div align="center">
          <table><tbody>
            {
              this.props.students.map((st,index)=>{
                return(<tr key={index}> 
                <td>{st.stuId} </td><td>{st.stuName}</td><td>{st.course}</td>
                </tr>)
              })
            }
          </tbody></table>
        </div>
       </div> 
    );
  }
}

const  mapStateToProps = (state)=>{
  return {
    student: state.student,
    students: state.students
  }
 };
 
const mapDispatchToProps = (dispatch)=>{
   return {
     onAddStudent: ()=> dispatch({type: 'ADD',value: this.props.student}),       
   }; 
}
 
export default connect(mapStateToProps,mapDispatchToProps)(App);
