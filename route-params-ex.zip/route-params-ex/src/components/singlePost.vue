<template>
<div class="single-post">
  <h1>{{searchedPost.title}}</h1>
  <article>{{searchedPost.body}}</article>


</div>
</template>

<script>
export default{

 data() {
    return {
        id: this.$route.params.id,
        searchedPost:{ }
    }
},
created(){
  this.$http.get('http://jsonplaceholder.typicode.com/posts/' + this.id)
            .then(function(data){
                console.log(data);
                this.searchedPost = data.body;
            });
}
}
</script>

<style scoped>
 .single-post{
     max-width: 960px;
     margin: 0 auto;
 }

</style>