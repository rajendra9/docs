package fordependson;


import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

@Configuration

public class TestDependsOn {

   	
	
   @Bean
   @DependsOn({"billPrepare","bankOpen"})
   public BillPay initBillPay() {
	   return new BillPay();
   }
   @Bean("bankOpen")
   public BankOpen openBank() {
	   return new BankOpen();
   }
   
   @Bean(name="billPrepare")
   public BillPrepare getBillPrepare() {
	  return new BillPrepare();   
   }
   
   
   
   public static void main(String[] args) {
      AnnotationConfigApplicationContext ctx =
    		  new AnnotationConfigApplicationContext(TestDependsOn.class); 
      BillPay billPay  = ctx.getBean(BillPay.class);
      billPay.performPaying();
      ctx.close();
    }

}
