package fordependson;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class BankOpen {

	ConcurrentMap<String, Double> payments;
	
	public BankOpen() {
	  payments = new ConcurrentHashMap<>();	
	  System.out.println("Bank is opened now");	
	}

	public boolean acceptBillPayment(String billNum, double amt) {
	   if(!payments.containsKey(billNum)) {
		   payments.put(billNum, amt);
		   return true;
	   }
	   return false;
	}
	
}
