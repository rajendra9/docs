package fordependson;


public class BillPay {

	
	public BillPay() {	
		System.out.println("BillPay Constructor");
	}

	public void performPaying() {
		System.out.println("Payment for Bills, this month completed");
	}
	
}
