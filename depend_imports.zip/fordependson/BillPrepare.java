package fordependson;

import java.util.concurrent.atomic.AtomicInteger;




public class BillPrepare {

	AtomicInteger counter = new AtomicInteger(1000);
	
	public BillPrepare() {
		System.out.println("BillPrepare Constructor");
	}
	
	public String preparationComplete() {
		int next = counter.incrementAndGet();
		String preparedBill = ""+next;
		System.out.println("Bill preparation ccomplete");
		return preparedBill;
	}
	

}
