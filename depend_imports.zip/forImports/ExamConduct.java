package forImports;

import java.time.LocalDate;

public class ExamConduct {

	public ExamConduct() {
	  System.out.println("ExamConduct is initialized");
	}
	
	public void conductExams() {
		System.out.println("Exams will be conducted from 9A.M onwards ");
	}

}
