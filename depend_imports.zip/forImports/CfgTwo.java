package forImports;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;

@Import(CfgOne.class)
public class CfgTwo {

	@Bean
	public  ExamConduct  getExamConduct() {
		return new ExamConduct();
	}
	@Bean
	public  ExamResults  getExamResults() {
		return new ExamResults();
	}
	

}
