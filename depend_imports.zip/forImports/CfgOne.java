package forImports;

import org.springframework.context.annotation.Bean;

public class CfgOne {

	@Bean
	public  ExamAnnounce  getExamAnnounce() {
		return new ExamAnnounce();
	}
	@Bean
	public  ExamPrepare  getExamPrepare() {
		return new ExamPrepare();
	}
	

}
