package forImports;

import java.time.LocalDate;

public class ExamAnnounce {

	public ExamAnnounce() {
	  System.out.println("ExamAnnounce is initialized");
	}
	
	public String announceExamDates(String course,LocalDate locDate) {
		return " Exams for "+ course + " will start from " + locDate;
	}

}
