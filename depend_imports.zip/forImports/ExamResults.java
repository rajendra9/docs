package forImports;

import java.time.LocalDate;

public class ExamResults {

	public ExamResults() {
	  System.out.println("ExamResults is initialized");
	}
	
	public void announceResults(String course, int year) {
		System.out.println(" Results for  "+ course + " for " + year + "is 55% I st class, 75% Pass ");
	}

}
