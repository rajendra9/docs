package forImports;

import java.time.LocalDate;
import java.time.Month;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import fordependson.TestDependsOn;

public class TestImports {

	
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx =
		  new AnnotationConfigApplicationContext(); 
        ctx.register(CfgTwo.class);
        ctx.refresh();
        ExamAnnounce examAnnounce = (ExamAnnounce)ctx.getBean(ExamAnnounce.class);
        System.out.println(examAnnounce.announceExamDates("B.Sc", LocalDate.of(2019, Month.MARCH, 21)));
        
        ExamPrepare examPrepare = (ExamPrepare)ctx.getBean(ExamPrepare.class);
	    examPrepare.prepareExams("B.Sc");
	
	    ExamConduct examConduct = (ExamConduct)ctx.getBean(ExamConduct.class);
	    examConduct.conductExams();
	    
	    ExamResults examResults = (ExamResults)ctx.getBean(ExamResults.class);
	    examResults.announceResults("B.Sc", 2019);
	    
	    ctx.close();
	}

}
