package forImports;

import java.time.LocalDate;

public class ExamPrepare {

	public ExamPrepare() {
	  System.out.println("ExamPrepare is initialized");
	}
	
	public void prepareExams(String course) {
		System.out.println(" Preparation for  "+ course + " Exam  started in right earnest");
	}

}
