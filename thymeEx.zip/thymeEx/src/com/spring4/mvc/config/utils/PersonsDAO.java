package com.spring4.mvc.config.utils;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

public interface PersonsDAO extends Serializable {
  public List<Person>  getPeople();
  public Optional<Person> searchPeople(String adharId);
  public boolean savePerson(Person person);
}
