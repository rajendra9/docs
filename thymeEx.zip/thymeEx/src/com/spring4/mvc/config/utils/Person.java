package com.spring4.mvc.config.utils;

import java.io.Serializable;
import java.util.Arrays;


import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

@SuppressWarnings("serial")
public class Person implements Serializable {
    
    @NotEmpty
    @Length(min=14,max=14)
    private String adharId;
    
    @NotEmpty
    @Size(min=6,max=15)
    private String firstName;
    
    @NotEmpty
    @Size(min=6,max=15)
    private String lastName;
    
    @NotEmpty
    private String address;
    
    @DecimalMax("3000000.0")
    @DecimalMin("300000.0")
    private double income;
    
    private double[] earnings;
    
    /*private List<Double> earningsList;
    
    {
       earningsList = new ArrayList<>();       
    }
    */
    public double[] getEarnings() {
		return earnings;
	}

	public void setEarnings(double[] earnings) {
		this.earnings = earnings;
	}

	
	
	public Person(String adharId, 
                  String firstName, 
                  String lastName,
                  String address,
                  double income,
                  double ... earns) {
        super();
        this.adharId = adharId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.income = income;
        this.earnings = earns;
    }

   /* public List<Double> getEarningsList() {
		if(earnings != null) {
			for(double dbl : earnings) {
				this.earningsList.add(dbl);
			}
		}
		return earningsList; 
	}

	public void setEarningsList(List<Double> earningsList) {
		this.earningsList = earningsList;
		Double[] arr = this.earningsList.toArray(new Double[] {0.0});
		int ind = -1;
		for(Double dbl : arr) {
		  earnings[++ind] = dbl.doubleValue();
		}
	}*/

	public Person() {
        // TODO Auto-generated constructor stub
    }

    public String getAdharId() {
        return adharId;
    }

    public void setAdharId(String adharId) {
        this.adharId = adharId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((adharId == null) ? 0 : adharId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Person other = (Person) obj;
        if (adharId == null) {
            if (other.adharId != null)
                return false;
        } else if (!adharId.equals(other.adharId))
            return false;
        return true;
    }

    
    @Override
	public String toString() {
		return "Person [adharId=" + adharId + ", firstName=" + firstName + ", lastName=" + lastName + ", address="
				+ address + ", income=" + income + ", earnings=" + Arrays.toString(earnings) + "]";
	}

	public Person(String adharId) {
        super();
        this.adharId = adharId;
    }   

}
