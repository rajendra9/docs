package com.spring4.mvc.config;

import org.springframework.context.annotation.ComponentScan;

import java.util.Locale;
import java.util.Properties;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;
import org.springframework.web.servlet.i18n.CookieLocaleResolver;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.thymeleaf.extras.java8time.dialect.Java8TimeDialect;
import org.thymeleaf.extras.springsecurity4.dialect.SpringSecurityDialect;
import org.thymeleaf.spring4.SpringTemplateEngine;
import org.thymeleaf.spring4.templateresolver.SpringResourceTemplateResolver;
import org.thymeleaf.spring4.view.ThymeleafViewResolver;
import org.thymeleaf.templatemode.TemplateMode;



//Marks this class as configuration
@Configuration
//it sees it's own package and sub-packages
@ComponentScan({"com.spring4.mvc.config","com.spring4.mvc.config.controllers","com.spring4.mvc.config.utils"})
//Enables Spring's annotations
@EnableWebMvc
public class SprConfig extends WebMvcConfigurerAdapter implements ApplicationContextAware {
      
    ApplicationContext applicationContext;
    
    @Override
    public void setApplicationContext(ApplicationContext ctx) throws BeansException {
       this.applicationContext = ctx;        
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
      registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");   
    }
  
    public SpringResourceTemplateResolver templateResolver(){
        SpringResourceTemplateResolver resolver =
                  new SpringResourceTemplateResolver(); 
        resolver.setApplicationContext(applicationContext);
        resolver.setPrefix("/WEB-INF/sprviews/");
        resolver.setTemplateMode(TemplateMode.HTML);
        resolver.setSuffix(".html");
        resolver.setCacheable(false);
        return resolver;
    }
    
    @Bean 
    public SpringTemplateEngine templateEngine(){
        SpringTemplateEngine engine = new SpringTemplateEngine();
        engine.setTemplateResolver(templateResolver());
        engine.setEnableSpringELCompiler(true);
       // engine.addDialect(new SpringStandardDialect()); //available by default
        engine.addDialect(new SpringSecurityDialect());
        engine.addDialect(new Java8TimeDialect());
        return engine;        
    }
    
    @Bean
    public ViewResolver  viewResolver(){
        ThymeleafViewResolver viewResolver = new ThymeleafViewResolver();
        viewResolver.setTemplateEngine(templateEngine());
        viewResolver.setCharacterEncoding("UTF-8");
        System.out.println("View Resolver created");
        return viewResolver;
    }

    @Bean(name="simpleMappingExceptionResolver")
    public SimpleMappingExceptionResolver createSimpleMappingResolver(){
        SimpleMappingExceptionResolver excepResolver =
                new SimpleMappingExceptionResolver();
        Properties mappings = new Properties();
        mappings.setProperty("DataAccessException", "dataAccessError");
        mappings.setProperty("HibernateJdbcException", "dataAccessError");
        mappings.setProperty("IOException", "ioError");
        mappings.setProperty("RuntimeException", "excep");
        excepResolver.setExceptionMappings(mappings);
        excepResolver.setDefaultErrorView("error");
        excepResolver.setExceptionAttribute("ex");
        return excepResolver;
    }
    
   @Bean(name="messageSource")
   public MessageSource createMesageSource(){
      ReloadableResourceBundleMessageSource messageSource
                    = new ReloadableResourceBundleMessageSource();
      messageSource.setBasename("/resources/ApplicationResources");
      messageSource.setDefaultEncoding("UTF-8");
      return messageSource;
   }
    
   @Bean(name="localeResolver")
   public LocaleResolver createLocaleResolver(){
      CookieLocaleResolver resolver = new CookieLocaleResolver();
      resolver.setDefaultLocale(new Locale("en"));
      resolver.setCookieName("myLocaleCookie");
      resolver.setCookieMaxAge(4800);
      return resolver;       
   }
   @Override
   public void addInterceptors(InterceptorRegistry registry) {
      LocaleChangeInterceptor interceptor 
                     = new LocaleChangeInterceptor();
      interceptor.setParamName("locale");
      registry.addInterceptor(interceptor);
   }
}

