package com.spring4.mvc.config.controllers;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.NoHandlerFoundException;

@ControllerAdvice
public class ThymeViewSendControllerAdvice {
 
    @ExceptionHandler(NoHandlerFoundException.class)
    public String noUrl(){
        System.out.println("No url");
        return "noUrl";    
    }    
    
}
