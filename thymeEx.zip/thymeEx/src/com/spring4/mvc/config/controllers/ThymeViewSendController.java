package com.spring4.mvc.config.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;

import javax.validation.Valid;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.spring4.mvc.config.utils.Person;
import com.spring4.mvc.config.utils.PersonsDAO;

@Controller
public class ThymeViewSendController {

   @Autowired
   PersonsDAO personService;
   String[] prjBases = {"hiber", "jpa", "rest" };
   
   private String getProjBase(){
	   ThreadLocalRandom rand = ThreadLocalRandom.current();
	   return prjBases[Math.abs(rand.nextInt(2))];
   }
   
   {
     System.out.println("Controller created");  
   }
   
   @RequestMapping(value="/", method=RequestMethod.GET)
   public String index(){
     System.out.println("root context");  
     return "index";
   }
   
   @RequestMapping(value="/home",method=RequestMethod.GET)
   public String home(Model model){
     System.out.println("LLLL");  
     model.addAttribute("wish", "Welcome Thymeleaf usage in Spring MVC");  
     LocalDate locDate = LocalDate.now();
     DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
     model.addAttribute("locDt", locDate);
     
     model.addAttribute("locDtStr", formatter.format(locDate));
     model.addAttribute("oldDt", new java.util.Date());
     model.addAttribute("proj", this.getProjBase());
     
     List<Person> people = personService.getPeople();
     System.out.println(people);
     model.addAttribute("people",people);
     return "show";
   }
	
   @GetMapping("/search")
   public String searchScreen(Model model){
      model.addAttribute("pers", new Person());
       return "searcher";  
   }
     
   @PostMapping("/search")
   public String submitSearch(@ModelAttribute Person pers, Model model){
      Optional<Person> optSearch = personService.searchPeople(pers.getAdharId());
      if(optSearch.isPresent()){
          model.addAttribute("searchResult", optSearch.get());
      }
      return "searched";  
   }
   
   @RequestMapping(value="/search/{adharId}",method=RequestMethod.GET)
   public String searchPerson(@PathVariable String adharId, Model model){
     model.addAttribute("searchResult",personService.searchPeople(adharId).get());
     return "searched";  
   }
   
   @GetMapping("/save")
   public String saveScreen(Model model){
      model.addAttribute("pers", new Person());
      return "addPerson";  
   }
     

   
   @PostMapping("/save")
   public String submitSave(@Valid @ModelAttribute("pers") Person pers, BindingResult result){
     if(result.hasErrors()){
        System.out.println("Errors");
         return "addPerson"; 
     }
     else {
      boolean isSaved = personService.savePerson(pers);
      if(isSaved){
         return "redirect:/search/"+pers.getAdharId();
      }
      else {
        return  "error";
      }
     } 
   }
	
	
}
