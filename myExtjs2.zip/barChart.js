Ext.onReady(function() {

   var dataStore= Ext.create('Ext.data.JsonStore',{
     autoLoad: true,
     fields:[
       {name:'deptName',type: 'string'},
       {name:'totalSalaries',type: 'float'}
       ],
     data:[
        {'deptName':'Services','totalSalaries':546543.5},
        {'deptName':'HP','totalSalaries':826573.5},
        {'deptName':'PPMA','totalSalaries':441533.5},
        {'deptName':'Developers','totalSalaries':1746563.5},
        {'deptName':'QC','totalSalaries':341563.5}
     ] 
  });
 var chart = Ext.create('Ext.chart.Chart',{
          store: dataStore,
          renderTo: 'chartDiv',
          width: 500,
          height: 320,
          animate: true,
          legend: true,
          axes:[{
             type:'Numeric',
             position: 'bottom',
             fields: ['totalSalaries'],
             label: {
               renderer: Ext.util.Format.numberRenderer('0,0')
             },
             title: 'Dept Salaries', 
             grid: true,
             minimum: 0
            },
            {
             type: 'Category',
             position: 'left',
             fields: ['deptName'],
             title:'Sample data' 
            }],
           series:[{
              type: 'bar',
              axis: 'bottom',
              highlight:true,
              tips: {
                trackMouse: true,
                width: 140,
                height: 30, 
                renderer: function(storeItem, item) {
                    this.setTitle(storeItem.get('deptName')+': Rs '+
                    storeItem.get('totalSalaries'));  
                }
              },
              label: {
                display: 'insideEnd', 
                field: 'totalSalaries',
                renderer : Ext.util.Format.numberRenderer('0,0'),
                orientation: 'horizontal',
                color: '#333',  
                'text-anchor': 'middle'
               },   
              xField: 'deptName',
              yField: 'totalSalaries'                         
             }]
  });

 
});      
               
