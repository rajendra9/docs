Ext.onReady(function(){
  Ext.define('Htc.ext.Person',{
    persId:0,
    name:'ZZZ',
  
    constructor:function(persId,name) {
      if(name) {
       this.persId = persId;
       this.name=name; 
    }
    return this;
  },
  work:function(workField) {
    alert(this.name+' with '+this.persId+" is working in " +workField);
    return this;
   }  
 });

  var person = Ext.create('Htc.ext.Person',120,'Sachin');
  person.work('Cricket');   

});


