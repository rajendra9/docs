Ext.require([
  'Ext.data.*',
  'Ext.form.field.ComboBox',
  'Ext.data.Model'
]);

 Ext.define('State',{
   extend: 'Ext.data.Model',
   fields: [
            {name: 'name'},
            {name: 'country'},
            {name: 'shortName'}
            ]}
 );


Ext.onReady(function() {
   

   var pattVal = ''; 
   
   var stateStore = new Ext.data.Store({
     autoDestroy: true,
     model: 'State',
        proxy: {
           type: 'ajax',
           url: 'statesSend?patt='+pattVal,
           reader: {
               type: 'json',
               root: 'states'
           }   	
         },
         autoLoad: true     
      });     
   var  autoCombo = new Ext.form.field.ComboBox({
                    fieldLabel: 'Select a State',
                    displayField: 'name',
                    valueField: 'shortName',
                    id:'simpstate', 
                    renderTo: 'simpState',
                    width: 300,
                    store: stateStore,
                    selectOnFocus: true,                   
                    forceSelection: true,  
                    typeAhead: true,
                    hideTrigger:true,   
                    mode: 'remote',
                    minChars: 2
                   });
 
  }); 
           
     
           



   
