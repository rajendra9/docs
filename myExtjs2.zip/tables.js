Ext.onReady(function() {
var reqPanel = Ext.create('Ext.panel.Panel',{
      title: 'Request For Items',
      minWidth:335,
      minHeight:250,
      margin:'20',
      defaults:{
        xtype: 'textfield',
        margin: 20
      }, 
      items:[
        {
         fieldLabel: 'Item-Id',
         name: 'itemId',
         allowBlank: false
        },
        {
         fieldLabel: 'Item-Name',
         name: 'itemName'       
        },
        {
         fieldLabel: 'Item-Qty',
         name: 'reqQty',
         allowBlank: false       
        }
      ],
      buttons: [          
         {
           xtype:'tbfill'
         },
         {
           text:'submit',
           handler: function() {
                console.log(' purchase request submitted');
           }
         },
         {
           xtype:'tbfill'
         }
       ],
        listeners: {
         render: function() {
          console.log('purchase request sending');
         }
       }
      });  
var purPanel = Ext.create('Ext.panel.Panel',{
      title: 'Placing order For Items',
      minWidth:335,
      minHeight:270,
      margin: '20',
      defaults:{
        xtype: 'textfield',
        margin: 20
      }, 
      items:[
        {         
         fieldLabel: 'PurOrder-Id',
         name: 'orderId',
         allowBlank: false
        },
        {         
         fieldLabel: 'Item-Id',
         name: 'itemId'       
        },
        {         
         fieldLabel: 'Customer',
         name: 'customer',
         allowBlank: false       
        },
        {         
         fieldLabel: 'Qty',
         name: 'qty',
         allowBlank: false       
        },
        {
         xtype: 'datefield',
         fieldLabel: 'Expected Date',
         name: 'expDate',
         padding:10,
         allowBlank: false       
        }

      ],
      buttons: [        
         {
           xtype:'tbfill'
         },
         {
           text:'submit',
           handler: function() {
                console.log(' purchase order Placed');
           }
         },
         {
           xtype:'tbfill'
         }
       ],
       listeners: {
         render: function() {
          console.log('Purchase order placement')
         }
       }  
       
  });  
  
  Ext.create('Ext.panel.Panel',{
    renderTo: 'tabDiv',
    title: '<center>Item Procurement</center>',
    height:400,
    width:800,
    layout:{
      type:'table',
      columns: 2
    },    
    items:[
           reqPanel,
           purPanel
    ] 
   });
 });


         
