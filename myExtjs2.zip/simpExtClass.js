Ext.onReady(function(){  

  Ext.define('Htc.ext.Address',{
   statics:{
      factoryMethod: function(ar,cy,pin){
        return new this({
                area:ar,
                city:cy,
                pincode:pin 
               });  
       }
    },    
    config: {
    area:'',
    city:'',
    pincode:0,
   },  
   constructor:function(config){
    this.initConfig(config);  
    return this; 
   }  
  });
 
 var addr = Htc.ext.Address.factoryMethod('Medavakkam','Chennai',600002);
  
    
  Ext.define('Htc.ext.Blogger',{
   blogging:function(blogTopic) {
    console.log('can blog about '+blogTopic+' any no of hours');
   }
  }); 



 Ext.define('Htc.ext.Person',{
    statics:{
      objCount:0
    },
    mixins: {
      blog: 'Htc.ext.Blogger'
    },
    config: {
      name: 'unknown',
      persId: 0,
      address:Ext.create('Htc.ext.Address',{
          area: '..',
          city: '..',
          pincode: 600002
       })
    }, 
    constructor:function(config){
     this.initConfig(config);  
     this.self.objCount++;
     return this; 
    },
    applyPersId:function(persId) {
     if(persId<=0) {
      alert('Wrong id given');
     }
     else {
      return persId;
     }
   },
   applyAddress: function(address){
    if(!Ext.isString(address.city) ||address.pincode<=0) {
     alert('Wrong address given');    
    }
    else {
      if(!this.address) {
        console.log('KKKKK'+address.area);
        return Ext.create('Htc.ext.Address',{
          area: address.area,
          city: address.city,
          pincode: address.pincode       
        })  
      } 
      else {       
       this.address.setConfig(address);
      }  
    } 
   } 
  });

  var person = Ext.create('Htc.ext.Person',{
           name:'Viswanath Anandan',
           persId:102,
           address:addr
      });
   alert(person.getName());
   alert(person.getAddress().getArea());
   person.blogging('Chess');
   var addr2 = Htc.ext.Address.factoryMethod('Worli','Mumbai',400002); 
   person = Ext.create('Htc.ext.Person',{
      name:'Sachin',
      persId:120,
      address:addr2
   });
   alert(person.getName());   
   alert(Htc.ext.Person.objCount); 
   var person = Ext.create('Htc.ext.Person',{
      name:'FFF',
      persId:0,
      address:{
        area:1,
        city:'Mumbai',
        pincode:0
      }
   });
});


