Ext.onReady(function() {

   var dataStore= Ext.create('Ext.data.JsonStore',{
     autoLoad: true,
     fields:[
       {name:'deptName',type: 'string'},
       {name:'totalSalaries',type: 'float'}
       ],
     data:[
        {'deptName':'Services','totalSalaries':546543.5},
        {'deptName':'HP','totalSalaries':826573.5},
        {'deptName':'PPMA','totalSalaries':441533.5},
        {'deptName':'Developers','totalSalaries':1746563.5},
        {'deptName':'QC','totalSalaries':341563.5}
     ] 
  });

 var chart = Ext.create('Ext.chart.Chart',{
          store: dataStore,
          renderTo: 'chartDiv',
          width: 450,
          height: 350,
          animate: true,
          theme:'Base:gradients',
          series:[{
              type: 'pie',
              field: 'totalSalaries',
              showInLegend: true,  
              tips: {
                trackMouse: true,
                width: 140,
                height: 28,
                renderer: function(storeItem, item) {
                    this.setTitle(storeItem.get('deptName')+': Rs '+
                    storeItem.get('totalSalaries'));  
                }
               },
               highlight: {
                    segment: {
                      margin: 15
                    }
                },
                label: {
                 field: 'deptName',
                 display: 'rotate',
                 contrast: true,
                 font: '18px Arial'
                } 
               }]

  });

 
});      
               
