

Ext.onReady(function() {


var myPanel = Ext.create('Ext.panel.Panel',{
    floating: true,
    draggable: true,
    shadow: 'sides',
    shadowOffset: 20,
    width:400,
    height:200, 
    alignTo:'panelDiv',
    items:[
    {
     xtype: 'image',
     src: 'images/grapes.gif',
     height:100,
     width:'50%', 
     autoEl:'div',
     style:{
       border: '1 solid'
     }     
    },
    {
     xtype:'panel',
     html:'Hi hello',    
     height:100,
     width:'50%',
     style:{
      border: '1 solid'
     }  
    }	
   ]
});
 
   
 myPanel.show();

});
