Ext.onReady(function() {
var reqPanel = Ext.create('Ext.panel.Panel',{
      title: 'Request For Items',
      id:'card-0',
      maxWidth:335,
      maxHeight:250,
      margin:15,
      defaults:{
        xtype: 'textfield',
        margin: 20
      }, 
      items:[
        {
         fieldLabel: 'Item-Id',
         name: 'itemId',
         allowBlank: false
        },
        {
         fieldLabel: 'Item-Name',
         name: 'itemName'       
        },
        {
         fieldLabel: 'Item-Qty',
         name: 'reqQty',
         allowBlank: false       
        }
      ],
      buttons: [          
         {
           xtype:'tbfill'
         },
         {
           text:'submit',
           handler: function() {
                console.log(' purchase request submitted');
           }
         },
         {
           xtype:'tbfill'
         }
       ],
        listeners: {
         render: function() {
          console.log('purchase request sending');
         }
       }
      });  
var purPanel = Ext.create('Ext.panel.Panel',{
      title: 'Placing order For Items',
      id:'card-1',
      maxWidth:335,
      maxHeight:270,
      margin: 15,
      defaults:{
        xtype: 'textfield',
        margin: 5
      }, 
      items:[
        {         
         fieldLabel: 'PurOrder-Id',
         name: 'orderId',
         allowBlank: false
        },
        {         
         fieldLabel: 'Item-Id',
         name: 'itemId'       
        },
        {         
         fieldLabel: 'Customer',
         name: 'customer',
         allowBlank: false       
        },
        {         
         fieldLabel: 'Qty',
         name: 'qty',
         allowBlank: false       
        },
        {
         xtype: 'datefield',
         fieldLabel: 'Expected Date',
         name: 'expDate',
         padding:10,
         allowBlank: false       
        }

      ],
      buttons: [        
         {
           xtype:'tbfill'
         },
         {
           text:'submit',
           handler: function() {
                console.log(' purchase order Placed');
           }
         },
         {
           xtype:'tbfill'
         }
       ],
       listeners: {
         render: function() {
          console.log('Purchase order placement')
         }
       }  
       
  });  

  var resultPanel = Ext.create('Ext.panel.Panel',{
      title: 'Result End for Items',
      id:'card-2',
      minWidth:335,
      minHeight:250,
      html:'<center>Procurement Finished'
  }); 
  var navigate = function(panel,direction) {
   var layout = panel.getLayout();
   layout[direction]();
   Ext.getCmp('card-prev').setDisabled(!layout.getPrev());
   Ext.getCmp('card-next').setDisabled(!layout.getNext());  
  };
  Ext.create('Ext.panel.Panel',{
    id:'cards',
    renderTo: 'tabDiv',
    title: '<center>Item Procurement</center>',
    height:370,
    width:550,
    layout:'card',
    activeItem: 0,
    bbar: ['->',
     {
       id:'card-prev',
       text: '&laquo; Previous',
       handler:function(button) {
          navigate(button.up('panel'),'prev');
       }
     },
     {
       id:'card-next',
       text: 'Next &raquo;',
       handler:function(button) {
          navigate(button.up('panel'),'next');
       } 
     }],          
    items:[
       reqPanel,
       purPanel,
       resultPanel
    ] 
   });
   
 });


         
