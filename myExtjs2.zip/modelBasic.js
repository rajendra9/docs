Ext.define('person',{
  extend: 'Ext.data.Model',
  fields:[
   {name:'ssn', type:'string'},
   {name:'name', type:'string'},
   {name:'dob', type:'date',format:'Y-m-d'},
   {name:'income', type: 'float'}
   ],
   validations:[
     {type: 'presence', name: 'ssn',message:'required Field'},
     {type: 'length', name: 'ssn' ,min: 5,message:'should be correct length'},
     {type: 'format', name: 'income', matcher: /\d+/} 

   ]
 });
var personStores = Ext.create('Ext.data.Store',{
    model: 'person',
    autoLoad: true,
    sorters: ['ssn'],
   /* filters:{
      property: 'name',
      value: 'Sita'
    },*/
    proxy:{
      type: 'ajax',
      url: 'persons.json',
      reader: {
          type: 'json',
          root: 'persons',
          successProperty: 'success'
      }
    }, 
    groupField: 'income',
    groupDir: 'DESC'       
    
}); 
 Ext.onReady(function() {

   var gridPanel = Ext.create('Ext.grid.Panel',{
        store: personStores, 
        width: 500,
        height: 250,
        hidden: true,
        renderTo: 'personDiv',
        title: '<center>Personal Information</center>',
        columns: [
          {header: 'SSN', width:80, dataIndex:'ssn'},
          {header: 'Name', width:120, dataIndex:'name'},
          {header: 'DOB', width:200, dataIndex:'dob'},
          {header: 'Income', width:100, dataIndex:'income'}
       ],
       beforeShow: function(comp,opts) {
        console.log('HHHH');
        var pers = Ext.create('person',{
          name: 'Pollathavan',
          dob: '1987-02-11',
          income:0
         });
        var errors = pers.validate();
        var objs = errors.getByField('ssn');
        var cnt = objs.length;
        for(var i=0;i<cnt;i++){ 
         console.log(objs[i].field+':'+objs[i].message);               
        }   
      }
       
       
   });
   gridPanel.show();      
});
