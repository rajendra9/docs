Ext.require([
'Ext.data.Model',
'Ext.form.Panel']
);
Ext.define('HTCItem',{
 extend: 'Ext.data.Model',
 fields: [
  {name: 'itemId',type: 'int'},
  {name: 'itemName',type: 'string'},
  {name: 'itemCost',type: 'float'}
 ]
});
var myPanel = 
     Ext.create('Ext.form.Panel',{
       width: 370,
       height: 280,
       bodyPadding: 40,
       defaults: {
       xtype: 'textfield',
       labelAlign: 'left',                
      }, 
      layout: {
         type: 'vbox'
      }, 
      url: 'itemAdd',
      items: [
        {
         fieldLabel: '<b>Item-Id</b>',
         name: 'itemId',
         id: 'itemId',
         margins:'10 5 5 5',
        },
        {
         fieldLabel: '<b>Item-Name</b>',
         name: 'itemName',
         id: 'itemName',
         margins:'10 5 5 5' 
       },
       {
         fieldLabel: '<b>Item-Cost</b>',
         name: 'itemCost',
         id: 'itemCost',
         margins:'10 5 5 5' 
      }],   
      dockedItems: [
        {
         xtype:'toolbar',
         padding:'5 2 5 2',
         dock: 'bottom',
         ui: 'footer',
         items:[
           {
            xtype: 'tbfill'
           },
           {
             text:'<b>Save-Item</b>', 
             width:85,
             height:40,
                
             handler: function() {
             var form = this.up('form').getForm();
             if(form.isValid()) {
              form.submit({
              success: function(form, action) {
              Ext.Msg.alert('Success',action.result.msg);
             },
             failure: function(form, action) {
              Ext.Msg.alert('Failure',action.result.msg);         
            }
          });
         } else {
             Ext.Msg.alert('Invalid Data', 'Please correct form errors'); 
         }        
       }
    } ,
    {
      xtype: 'tbfill'
    },
    {
     text:'<b>Reset</b>',
     width:85,
     height:40,   
     handler: function() {
         var form = this.up('form').getForm().reset();
     }
    },
    {
      xtype: 'tbfill'  
    }]
   }] 

 });  

Ext.onReady(function() {

 var win = Ext.create('Ext.window.Window',{
                 applyTo:Ext.getBody(),
                                  
                 title: '<h1 align=center>Item Details</h1>',
                 width: 400,
                 height: 320,
                 layout: 'fit',
                 closeAction: 'hide',
                 items:[myPanel]
              });
     win.show();    
   
   
});
