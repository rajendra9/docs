Ext.define('HtcProduct',{
   extend: 'Ext.data.Model',
   fields : [
       {name: 'prodId' ,type: 'string',mapping: '@id'},
       {name: 'prodName' ,type: 'string',mapping: 'prod-name'},
       {name: 'brand',type: 'string'},
       {name: 'dealer',type: 'string'},        
       {name: 'qty',type: 'int'},        
       {name: 'prodCost',type: 'float',mapping: 'prod-cost'}
      ]
 });
Ext.onReady(function() {
var xmlStore = Ext.create('Ext.data.Store', {
                model: 'HtcProduct',
                proxy: {
                  type: 'ajax',
                  url: 'products.xml',
                  reader: {
                     type: 'xml',
                     root: 'products',
                     model: 'HtcProduct', 
                     record: 'product'
                  }
                 }
              });
    xmlStore.load();
var xmlGrid = 
       Ext.create('Ext.grid.Panel',{
          store: xmlStore,
          title: '<center>Product-Information</center>',
          stripeRows: true,
          columns: [
           {id: 'prodId',header: 'Prod-Id',width:80,sortable:true,dataIndex:'prodId'},
           {header: 'Prod-Name',width:120,dataIndex:'prodName'},
           {header: 'Brand',width:80,dataIndex:'brand'},
           {header: 'Prod-Cost',width:100,dataIndex:'prodCost'},       
           {header: 'Dealer',width:150,dataIndex:'dealer'},    
           {header: 'Qty',width:80,dataIndex:'qty'}
          ],      
          width:610,
          height:350
         });     
   
     xmlGrid.render('xml-grid');
});     
