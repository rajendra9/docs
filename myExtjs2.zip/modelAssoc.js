Ext.define('Person',{
  extend: 'Ext.data.Model',
  fields:[
   {name:'ssn', type:'string'},
   {name:'name', type:'string'},
   {name:'dob', type:'date',format:'Y-m-d'},
   {name:'income', type: 'float'}
   ],
   hasMany: {model:'DealerShip',name: 'deals'}   
 });
Ext.define('DealerShip',{
  extend: 'Ext.data.Model',
  fields: [
     {name: 'product', type: 'string'},
     {name: 'prodType',type: 'string'},
     {name: 'approxQtySold', type:'int'},
     {name: 'ssn', type:'string'}
   ],
  belongTo: 'Person'
});  


   


 Ext.onReady(function() {

  var personStores = Ext.create('Ext.data.Store',{
   model: 'Person',
   autoLoad: true,
    proxy:{
      type: 'ajax',
      url: 'dealerPersons.json',
      reader: {
          type: 'json',
          root: 'persons'
      }
    }    
  });
  
  Ext.create('Ext.grid.Panel',{
        store: personStores, 
        width: 850,
        height: 300,
        renderTo: 'personDiv',
        title: '<center>Personal Information</center>',
        columns: [
          {header: 'SSN', width:80, dataIndex:'ssn'},
          {header: 'Name', width:120, dataIndex:'name'},
          {header: 'DOB', width:200, dataIndex:'dob'},
          {header: 'Income', width:100, dataIndex:'income'},
          {
          header:'Dealings',
          width: 300,
          renderer: function(value, cell, doc, idx){
           var dealings;
           var ret = '';
           if(doc.hasOwnProperty('dealsStore')){
             dealings = doc.dealsStore;
             var recs = dealings.getCount();
             console.log('kkk'+recs);
             for(var i = 0;i<recs;i++){
              var rec = dealings.getAt(i);
               ret = ret+'[ '+rec.get('product')+', '+rec.get('prodType')+
                         ', '+rec.get('approxQtySold')+' ]';
             } 
             return ret; 
           }
          }
         } 
         
       ]
   });
      
});