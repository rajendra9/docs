Ext.onReady(function() {

var treeStores = Ext.create('Ext.data.TreeStore', {
    root: {
      expanded: true,
      text: 'computer',
      children:[
        {text: 'Drive C', expanded: true,
           children: [
                  {text:'pras', expanded: true,
                    children:[
                      {text: 'ios',leaf: true},
                      {text: 'i18n',leaf: true},
                      {text: 'nios',leaf: true}
                    ]},                                        
                  {text:'xmls', expanded: true,children:[
                     {text: 'jaxb',leaf: true},
                     {text: 'xsds',leaf: true},
                     {text: 'stax',leaf: true},
                     {text: 'sax',leaf: true},
                     {text: 'dom',leaf: true}                 
                   ]},
                  {text:'pra_jpa', leaf: true}
                 ]
         },
         {text: 'Drive D', expanded: true,
           children: [
                  {text:'javaclasses', leaf: true},
                  {text:'eccat', leaf: true},
                  {text:'Cognos', leaf: true}
                 ]
         } 
       ]
     },
     autoLoad: true,
 });
  
  Ext.create('Ext.tree.Panel',{
     store:treeStores,
     autoScroll:true,
     width:300,
     height:350,
     renderTo:'treeDiv',
     rootVisible:true
   });

});  