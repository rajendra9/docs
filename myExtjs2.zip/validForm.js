 var subjectRadios = Ext.create('Ext.form.RadioGroup',{
          fieldLabel: 'RelatedArea',
          labelAlign: 'top',
          layout:'vbox',                
          margin: '10 0 0 0',
          items: [
           {boxLabel: 'Computers', name: 'bookArea' ,itemValue:'computers'},
           {boxLabel: 'Fiction', name: 'bookArea', itemValue: 'fiction'},
           {boxLabel: 'History', name: 'bookArea', inputValue: 'history'},
           {boxLabel: 'Comics', name: 'bookArea', inputValue:'comics'}
          ]
        }); 
  var pubBoxes = Ext.create('Ext.form.CheckboxGroup',{
          fieldLabel: 'Publishers',
          labelAlign: 'top',
          layout: 'vbox',                
          margin: '10 0 0 0',
          items: [
           {boxLabel: 'M/s Wiley & Co', name:'publishers', itemValue:'Wiley'},
           {boxLabel: 'M/s Wrox Publishers', name:'publishers', itemValue:'Wrox'},
           {boxLabel: 'M/s APress & Co', name: 'publishers',itemValue:'APress'},
           {boxLabel: 'M/s SChand & Bros', name: 'publishers', itemValue: 'Schand'}           
          ]
        }); 
 var myPanel =  Ext.create('Ext.form.Panel',{
      url: 'regBook',
      width: 560,
      height: 500,
      bodyPadding: 5,      
      items:[{
       layout: 'column',
       padding:5,
       items:[{ 
     
         xtype:'container',
         columnWidth:0.5,
         padding:10,
         items:[
         {
           xtype:'textfield',
           fieldLabel: 'Book ISBN',
           labelAlign: 'top',
           name: 'isbn',
           allowBlank: false,
           msgTarget: 'under'   
         },
         {
           xtype:'textfield',
           fieldLabel: 'Author',
           labelAlign: 'top',
           name: 'author',
           allowBlank: false,
           msgTarget: 'under'  
         },
         {
          xtype:'datefield',
          fieldLabel: 'Purchased-Date',      
          labelAlign: 'top',
          name: 'purDate',
          format: 'Y/m/d',
          allowBlank: false,
          msgTarget: 'under',
          invalidText: '"{0}" is not correct,be in "{1}" format'  
         },
         pubBoxes
         ]
        },
        {
         xtype:'container',
         columnWidth:0.5,
         padding:10,
         items:[ 
          {
           xtype: 'textfield',
           fieldLabel: 'Book Name',
           labelAlign: 'top',
           name: 'bookName',
           allowBlank: false,
           msgTarget: 'under'           
         },
         {
          xtype:'textfield',
          vtype:'email',
          fieldLabel: 'Author Email',
          labelAlign: 'top',
          name: 'email',
          allowBlank: false,
          msgTarget: 'under',
          invalidText: '"{0}" is not correct,be in "{1}" format'  
         },
         {
           xtype:'numberfield',
           fieldLabel: 'Book Cost',
           labelAlign: 'top',
           name: 'bookCost',
           minValue: 50.0,
           maxValue:5000.0,
           msgTarget: 'under',
         },
          subjectRadios]
      },
      {
       xtype:'container',
       columnWidth:1.0,
       padding:'0 5 10 100',
       items:[ 
         {
            xtype:'htmleditor',
            fieldLabel:'Comments',
            name:'comments',
            labelAlign:'top'   
         }
       ]
       } 
     ]

   }],    
     
     buttons: [
              {
               xtype: 'tbfill'
              },
              {
               text: '<b>Submit</b>',
               width:85,
               height:40,
               handler: function(){
                   var form = this.up('form').getForm();
                   if(form.isValid()){
                     form.submit({
                       success:function(form, action) {
                         Ext.Msg.alert('Success',action.result.msg);
                       },
                       failure:function(form, action) {
                         Ext.Msg.alert('Failure',action.result.msg);
                       }
                      });
                    }
                    else {
                        Ext.Msg.alert('Invalid Data','Please correct form errors');   
                    }
                   }
                },
               {
                xtype: 'tbfill'  
               },
               {
               text:'<b>Reset</b>',
               width:85,
               height:40,   
               handler: function() {
                var form = this.up('form').getForm().reset();
               }
           },
           {
            xtype: 'tbfill'
           }
         ]   
   });
Ext.onReady(function() {

 var win = Ext.create('Ext.window.Window',{
                applyTo : 'bookForm',                                
                title: '<center>Books Information</center>',
                width: 570,
                height: 520,
                layout: 'fit',
                closeAction: 'hide',
                items:[myPanel]
              });
     win.show();    
   
  
});
