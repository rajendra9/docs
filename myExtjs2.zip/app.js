Ext.require('Ext.container.Viewport');
Ext.application({
  name:'HelloExt',
  launch:function(){
      Ext.create('Ext.container.Viewport',{
             layout:'fit',
             items: [
                {
                 title: '<h3 style="color:blue;text-align:center;">Hello Ext.</h3>',
                 html: '<h2 style="color:red;text-align:center;">Hello! Welcome to Ext JS.</h2>'
                }
             ]
             });
            }
         });       