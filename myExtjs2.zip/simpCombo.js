Ext.require([
  'Ext.data.*',
  'Ext.form.field.ComboBox' 
]);

 Ext.define('State',{
   extend: 'Ext.data.Model',
   fields: [
            {name: 'name'},
            {name: 'country'},
            {name: 'shortName'}
            ]}
 );
 Ext.define('City',{
   extend: 'Ext.data.Model',
   fields: [
            {name: 'name'},
            {name: 'knownYear', type: 'int'},
            {name: 'population',type: 'int'}
            ]}
 );


 var states = [
     {"name":"New Delhi","country":"India","shortName":"ND"},
     {"name":"Tamilnadu","country":"India","shortName":"TN"},
     {"name":"Andhra Pradesh","country":"India","shortName":"AP"},
     {"name":"New York","country":"USA","shortName":"NY"},
     {"name":"California","country":"USA","shortName":"CF"},
     {"name":"Karnataka","country":"India","shortName":"KT"}
  ];

 var stateStore = new Ext.data.Store({
     autoDestroy: true,
     model: 'State',
     data: states
   });
 var cityList;  
 function showChildList(jsonFile) {
  
  var cityStore = Ext.create('Ext.data.Store',
      {
        model : 'City',
        proxy: {
           type: 'ajax',
           url:jsonFile+'.json',
           reader: {
               type: 'json',
               root: 'cities'
           }   	
         },
         autoLoad: true     
      });     
 
   if(cityList == null) {
       alert('hhhh');  
      cityList = Ext.create('Ext.form.field.ComboBox',{
       transform:'citySelect',
       store:cityStore,
       id:'citySelect',
       displayField:'name',
       valueField:'name',
       fieldLabel:'Select City',
       queryMode:'remote'    
      });
   }
   else {
      cityList.destroy();
      cityList = Ext.create('Ext.form.field.ComboBox',{
       renderTo:'citySelect',
       store:cityStore,
       id:'cityselect',
       displayField:'name',
       valueField:'name',
       fieldLabel:'Select City',
       queryMode:'remote'    
      });
   }      
    

 }

Ext.onReady(function() {
     Ext.tip.QuickTipManager.init();
      
   var simpCombo = new Ext.form.field.ComboBox({
                    fieldLabel: 'Select a State',
                    displayField: 'name',
                    valueField: 'shortName',
                    id:'state', 
                    renderTo: 'simpState',
                    width: 300,
                    labelWidth: 120,
                    store: stateStore,
                    typeAhead: true,
                    queryMode: 'local'
     });
    simpCombo.on('change',function() {          
       var selValue = simpCombo.getValue();
       showChildList(selValue); 
      },
    this);
    

}); 
           
     
           



   