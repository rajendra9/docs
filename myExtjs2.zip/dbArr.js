Ext.require('Ext.data.JsonStore');
Ext.require('Ext.grid.GridPanel');
Ext.onReady(function() {

    Ext.define('Programmer',{
     extend: 'Ext.data.Model',
     fields: [
      {name: 'ambition'},
      {name: 'area'},
      {name: 'devId',type: 'int'},
      {name: 'name'},
      {name: 'rank'}    
    ]
   });
 
  var javaCompData = Ext.create('Ext.data.Store',
      {
        model : 'Programmer',
        proxy: {
           type: 'ajax',
           url:'devList.jsp',
           reader: {
               type: 'json',
               root: 'developers'
           }   	
         },
         autoLoad: true     
      });     

   ; 


   var myGrid = new Ext.grid.GridPanel({
        store: javaCompData,
        columns: [
          {id: 'devId',header: 'DEVELOPER-ID',width: 100,sortable: true,dataIndex: 'devId'},
          {header: 'NAME',width: 80,dataIndex: 'name'},
          {header: 'AREA',width: 80,dataIndex: 'area'},
          {header: 'RANK',width: 80,dataIndex: 'rank'},
          {header: 'AMBITION',width: 220,dataIndex: 'ambition'},
          {
           xtype: 'actionColumn',
           width: 100,
           items:[
            {
            },
            {
            }]
          } 
        ],
        stripeRows: true,
        width:590,
        height:200,
        title:'Developers-Details'        
   });
    myGrid.render('db-grid');
});
