Ext.onReady(function() {
var reqPanel = Ext.create('Ext.panel.Panel',{
      title: 'Request For Items',
      margin: '10 15 15 10',
      padding: 5,
      items:[
        {
         xtype: 'textfield',
         fieldLabel: 'Item-Id',
         name: 'itemId',
         allowBlank: false
        },
        {
         xtype: 'textfield',
         fieldLabel: 'Item-Name',
         name: 'itemName'       
        },
        {
         xtype: 'textfield',
         fieldLabel: 'Item-Qty',
         name: 'reqQty',
         allowBlank: false       
        }
      ],
      buttons: [          
         {
           xtype:'tbfill'
         },
         {
           text:'submit',
           handler: function() {
                console.log(' purchase request submitted');
           }
         },
         {
           xtype:'tbfill'
         }
       ],
        listeners: {
         render: function() {
          console.log('purchase request sending');
         }
       }
      });  
var purPanel = Ext.create('Ext.panel.Panel',{
      title: 'Placing order For Items',
      margin: '10 5 5 0',
      padding: '5 5 5 0',
      items:[
        {
         xtype: 'textfield',
         fieldLabel: 'PurOrder-Id',
         name: 'orderId',
         allowBlank: false
        },
        {
         xtype: 'textfield',
         fieldLabel: 'Item-Id',
         name: 'itemId'       
        },
        {
         xtype: 'textfield',
         fieldLabel: 'Customer',
         name: 'customer',
         allowBlank: false       
        },
        {
         xtype: 'textfield',
         fieldLabel: 'Qty',
         name: 'qty',
         allowBlank: false       
        },
        {
         xtype: 'datefield',
         fieldLabel: 'Expected Date',
         name: 'expDate',
         padding:10,
         allowBlank: false       
        }

      ],
      buttons: [        
         {
           xtype:'tbfill'
         },
         {
           text:'submit',
           handler: function() {
                console.log(' purchase order Placed');
           }
         },
         {
           xtype:'tbfill'
         }
       ],
       listeners: {
         render: function() {
          console.log('Purchase order placement')
         }
       }  
       
  });  
  
  Ext.create('Ext.tab.Panel',{
    renderTo: 'tabDiv',
    title: '<center>Item Procurement</center>',
    height:250,
    width:350,    
    items:[reqPanel, purPanel]
   });
 });


         
