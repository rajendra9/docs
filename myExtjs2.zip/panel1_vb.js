

Ext.onReady(function() {


Ext.create('Ext.panel.Panel',{
    renderTo:'panelDiv',
    width:400,
    height:200, 
    layout:'vbox',
    items:[
    {
     xtype: 'image',
     src: 'images/grapes.gif',
     height:100,
     width:100,
     autoEl:'div',
     style:{
       border: '1 solid'
     }     
    },
    {
     xtype:'panel',
     html:'Hi hello',    
     height:100,
     width:100,
     style:{
      border: '1 solid'
     }  
    }	
   ]
});



});
