Ext.onReady(function() {

   var dataStore= Ext.create('Ext.data.JsonStore',{
     autoLoad: true,
     fields:[
       {name:'deptName',type: 'string'},
       {name:'totalSalaries',type: 'float'}
       ],
     data:[
        {'deptName':'Services','totalSalaries':546543.5},
        {'deptName':'HP','totalSalaries':826573.5},
        {'deptName':'PPMA','totalSalaries':441533.5},
        {'deptName':'Developers','totalSalaries':1746563.5},
        {'deptName':'QC','totalSalaries':341563.5}
     ] 
  });
 var chart = Ext.create('Ext.chart.Chart',{
          store: dataStore,
          renderTo: 'chartDiv',
          width: 500,
          height: 320,
          animate: true,
          legend: true,
          axes:[{
             type:'Numeric',
             position: 'left',
             fields: ['totalSalaries'],
             label: {
               renderer: Ext.util.Format.numberRenderer('0,0')
             },
             title: 'Dept Salaries', 
             grid: true,
             minimum: 0
            },
            {
             type: 'Category',
             position: 'bottom',
             fields: ['deptName'],
             title:'Sample data' 
            }],
           series:[{
              type: 'line',
              highlight:{
                 size:70,
                 radius: 7    
              }, 
              axis: 'left',
              xField: 'deptName',
              yField: 'totalSalaries',
              markerConfig: {
                 type:'cross',
                 size: 4,
                 radius: 4,
                 'stroke-width': 0
              }           
             }
            ]
  });

 
});      
               
