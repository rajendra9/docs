package com.htc.extjs.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Set;
import java.util.HashSet;

public class ItemAddServlet extends HttpServlet {
  private static final String OK = 
         "{\"success\": true ,\"msg\": \"Item added successfully\"}";

  private static final String NOTOK = 
         "{\"success\": false ,\"msg\": \"Problem in Item addition\"}";

  Set<String> items;
  public void init(){
   System.out.println("GGGGGG");
   items = new HashSet<String>();    
  }

  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    process(request, response);        
  }

  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws    ServletException, IOException {
      process(request, response);    
  }

  private void process(HttpServletRequest request, 
          HttpServletResponse response)
          throws ServletException, IOException {
    String idStr = request.getParameter("itemId");
    String itemName = request.getParameter("itemName");
    String costStr = request.getParameter("itemCost");
    int itemId = 0;
    double itemCost = 0.0;
    if(idStr != null) {
      itemId = Integer.parseInt(idStr);
    }
    if(costStr != null) {
      itemCost = Double.parseDouble(costStr);
    } 
    PrintWriter out = response.getWriter();
    if(itemId>0){
     items.add(idStr.trim()+":"+itemName+":"+costStr);
     System.out.println(items);
     out.println(OK);
    }
    else {
     out.println(NOTOK); 
    }   
    out.flush();    
  }
  
}
