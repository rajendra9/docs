package com.htc.ext.utils;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.sql.Timestamp;
import java.util.Random;
import com.htc.ext.domain.CompanyShare;

public class CompanyShares implements Serializable {
    Map<String,List<CompanyShare>> sharesMap;
	public CompanyShares() {
		super();
		Random rand = new Random();
		sharesMap = new HashMap<>();
		Timestamp ts = new Timestamp(System.currentTimeMillis());
		double val = 1000*rand.nextDouble(); 
		CompanyShare share = new CompanyShare("infosys",val,ts);
		List<CompanyShare> shares = new ArrayList<CompanyShare>();
		shares.add(share);
		sharesMap.put(share.getCompanyName(), shares);
		ts = new Timestamp(System.currentTimeMillis());
		val = 1000*rand.nextDouble(); 
		share = new CompanyShare("wipro",val,ts);
	    shares = new ArrayList<CompanyShare>();
		shares.add(share);
		sharesMap.put(share.getCompanyName(), shares);
		ts = new Timestamp(System.currentTimeMillis());
		val = 1000*rand.nextDouble(); 
		share = new CompanyShare("accenture",val,ts);
	    shares = new ArrayList<CompanyShare>();
		shares.add(share);
		sharesMap.put(share.getCompanyName(), shares);
	}

	public boolean isListed(String company) {
		boolean ret = false;
		Collection<List<CompanyShare>> shares = sharesMap.values();
		outer: { 
		for(List<CompanyShare> list : shares){
		   for(CompanyShare share: list){
			 if(share.getCompanyName().equalsIgnoreCase(company)){
				 ret = true;
				 break outer;
			 }
		   }
		 }
		}
		return ret;
	}
	
	public String showDetails(String company) {
	   List<CompanyShare> list = sharesMap.get(company);
	   Random rand = new Random();
	   Timestamp ts = new Timestamp(System.currentTimeMillis());
	   double val = 1000*rand.nextDouble(); 
	   CompanyShare share = new CompanyShare("accenture",val,ts);
	   list.add(share);
	   sharesMap.put(share.getCompanyName(),list);
	   
	   StringBuffer sb = new StringBuffer(250);
	   list = sharesMap.get(company);
	   sb.append("<h2>Share details of "+company+"</h2>");
	   for(CompanyShare sh : list) {
		   NumberFormat nf = NumberFormat.getInstance();
		   DecimalFormat df = null;
		   if(nf instanceof DecimalFormat) {
			   df = (DecimalFormat)nf;
			   df.applyPattern("##000.00");
		   }
	       String  deci  = df.format(sh.getSharePrice());
		   sb.append(sh.getTimestamp()+"----"+deci+"<br/>");
	       
	   }
	   return sb.toString();
	}
}
