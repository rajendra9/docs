package com.htc.ext.domain;

import java.io.Serializable;

public class StateDTO implements Serializable, Comparable<StateDTO> {
    private String  name;
    private String  shortName;
    private String  country;   
    
    public StateDTO() {		
    }

    public int compareTo(StateDTO dto) {
      return this.name.compareTo(dto.name);
    }
    public StateDTO(String name, 
                    String shortName,
                    String country) {
       super();
       this.name = name;
       this.shortName = shortName;
       this.country = country;
    }

    public String getName() {
       return name;
    }

    public void setName(String name) {
      this.name = name;
    }

    public String getShortName() {
      return shortName;
    }

    public void setShortName(String shortName) {
       this.shortName = shortName;
    }

    public String getCountry() {
       return country;
    }

    public void setCountry(String country) {
      this.country = country;
    }

    @Override
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + ((name == null) ? 0 : name.hashCode());
      return result;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj)
       return true;
      if (obj == null)
       return false;
      if (getClass() != obj.getClass())
       return false;
      StateDTO other = (StateDTO) obj;
      if (name == null) {
       if (other.name != null)
 	return false;
       } else if (!name.equals(other.name))
         return false;
      return true;
    }

    @Override
    public String toString() {
       return "StateDTO [name=" + name + ", shortName=" + shortName
              + ", country=" + country + "]";
    }

}