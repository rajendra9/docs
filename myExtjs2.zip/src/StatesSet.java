package com.htc.ext.utils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import com.htc.ext.domain.StateDTO;

public class StatesSet extends HashSet<StateDTO> {

	public StatesSet() {
	  super();
	  StateDTO dto = new StateDTO("New Delhi", "ND", "India");
	  this.add(dto);
	  
	  dto = new StateDTO("New York", "NY", "USA");
	  this.add(dto);
	  
	  dto = new StateDTO("Tamilnadu", "TN", "India");
	  this.add(dto);

	  dto = new StateDTO("Andhra Pradesh", "AP", "India");
	  this.add(dto);

	  dto = new StateDTO("Karnataka", "KT", "India");
	  this.add(dto);

	  dto = new StateDTO("Uttar Pradesh", "UP", "India");
	  this.add(dto);

	  dto = new StateDTO("Rajasthan", "RJ", "India");
	  this.add(dto);

	  dto = new StateDTO("Punjab", "PU", "India");
	  this.add(dto);

	  dto = new StateDTO("Haryana", "HY", "India");
	  this.add(dto);

	  dto = new StateDTO("California", "CF", "USA");
	  this.add(dto);

	  dto = new StateDTO("Maharashtra", "MH", "India");
	  this.add(dto);

	  dto = new StateDTO("West Bengal", "WB", "India");
	  this.add(dto);

	  dto = new StateDTO("Bihar", "BH", "India");
	  this.add(dto);

	  dto = new StateDTO("Chattisgarh", "CH", "India");
	  this.add(dto);

	  dto = new StateDTO("Gujarat", "GU", "India");
	  this.add(dto);

	  dto = new StateDTO("Odisha", "OD", "India");
	  this.add(dto);

	  dto = new StateDTO("Kerala", "KR", "India");
	  this.add(dto);

	  dto = new StateDTO("Tripura", "TP", "India");
	  this.add(dto);

	  dto = new StateDTO("Nagaland", "NL", "India");
	  this.add(dto);
	  
	  dto = new StateDTO("Manipur", "MN", "India");
	  this.add(dto);

	  dto = new StateDTO("Assam", "AM", "India");
	  this.add(dto);

	}
   
      public List<StateDTO>  getStates(String patt) {
        List<StateDTO> ret = new ArrayList<StateDTO>();
         if(!patt.isEmpty()){		
          for(StateDTO dto : this){
           if(dto.getName().startsWith(patt)) {
               ret.add(dto);
	   }
	  }
         }
         else {
           ret.addAll(this);  
	 }
         java.util.Collections.sort(ret);
         return ret;
      }
	
}
