package com.htc.ext.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.htc.ext.domain.StateDTO;
import com.htc.ext.utils.StatesSet;

import java.io.PrintWriter;
import java.util.List;

import flexjson.JSONSerializer;
/**
 * Servlet implementation class StateSendServlet
 */
public class StateSendServlet extends HttpServlet {
	

	
	protected void doGet(HttpServletRequest request, 
			             HttpServletResponse response)
  	  throws ServletException, IOException {
	  process(request, response);  
	}

	
	protected void doPost(HttpServletRequest request, 
			              HttpServletResponse response) 
	  throws ServletException, IOException {
	  process(request, response);
	}

	protected void process(HttpServletRequest request, 
			               HttpServletResponse response)
        throws ServletException, IOException {
		String patt = request.getParameter("patt");
		StatesSet set = new StatesSet();
		List<StateDTO> list = set.getStates(patt);
		
		JSONSerializer serializer = new JSONSerializer();
		String content = serializer.exclude("*.class").serialize(list);
		PrintWriter out = response.getWriter();
		out.println(content);
		out.flush();
		
	}

	
}
