package com.htc.ext.domain;

import java.io.Serializable;
import java.sql.Timestamp;

public class CompanyShare implements Serializable {
    private  String  companyName;
    private  double  sharePrice;
    private  Timestamp timestamp;
    
	public CompanyShare() {	
      this.companyName = "";
	}


	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public double getSharePrice() {
		return sharePrice;
	}

	public void setSharePrice(double sharePrice) {
		this.sharePrice = sharePrice;
	}	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((companyName == null) ? 0 : companyName.hashCode());
		return result;
	}

	public CompanyShare(String companyName, 
			            double sharePrice,
			            Timestamp timestamp) {
		super();
		this.companyName = companyName;
		this.sharePrice = sharePrice;
		this.timestamp = timestamp;
	}

	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CompanyShare other = (CompanyShare) obj;
		if (companyName == null) {
			if (other.companyName != null)
				return false;
		} else if (!companyName.equals(other.companyName))
			return false;
		return true;
	}


}
