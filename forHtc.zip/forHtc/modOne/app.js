var hl= require('./cust_hello');
var gb = require('./cust_gb');
hl.hello();
gb.goodBye();