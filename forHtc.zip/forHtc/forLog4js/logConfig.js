var myLog = require("log4js");

myLog.configure({
appenders: {consAppender: {type:'console'},
            myAppender: {type: "file", filename: "htc.log"},
},categories: { default: {appenders: ['consAppender','myAppender'],level:'debug'}}
});
var logger = myLog.getLogger("myTrial");

logger.trace("This is Trace message");

logger.debug("This is debug message");
logger.info("This is info message");
logger.warn("This is wARNING message");
logger.error("This is Error message");
