function add(one,two){
  console.log(one+two);
}

function multiply(one,two){
  console.log(one*two);
}

function execute(functionName, one, two){
  functionName(one,two);
}

execute(add,6,8);
execute(multiply,6,8);