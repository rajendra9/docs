var os = require("os");

console.log("endianness:" + os.endianness());

console.log("Type:" + os.type());
console.log("Platform:" + os.platform());
console.log("TotalMem:" + os.totalmem());
console.log("cpus:" + os.cpus());
console.log("FreeMem:" + os.freemem());

//property
console.log("EOL:" + os.EOL + "kkkkk");



