var Set = require("collections/set");
var mySet = new Set(["aaa", 432.2, 10,{"name":"HTC"}]);
mySet.add("aaa"); 
console.log(mySet.has("aaa"));
console.log(mySet.toArray());
mySet.delete(10); 
console.log("After Delete");

console.log(mySet.toArray());

