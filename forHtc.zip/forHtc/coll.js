var colMap = require('collections/Map');

var colList = require('collections/List');

var list = new colList();
var map = new colMap();

list.push('aaaa','bbb','cccc','dddd');
console.log(list);
console.info(list.has('cccc'));
console.info(list.find('cccc'));

map.set(1,"one");
map.add("two",2);
map.set(3,"three");
map.add("four",4);

console.log(map.entries());
console.log(map.get(3));
console.log(map.toObject());
 


