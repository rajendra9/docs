var fs = require('fs');
var http = require('http');
var server = http.createServer(function(request,response){
  var newFile = fs.createWriteStream('myCopy.txt');
  request.pipe(newFile);
  request.on('end',function(){
   response.end('uploaded');
  });
});
server.on('listening',function(){
  console.log('server started');
});
server.listen(3000);