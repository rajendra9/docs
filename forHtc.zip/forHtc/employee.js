var EventEmitter = require('events').EventEmitter;
var util = require('util');
 
function Employee(name,job,salary){
  this.name = name;
  this.job = job;
  this.salary = salary;
  this.da = salary * 0.90;
  this.show= function(){
   console.log("Name:" + this.name +" job:" + this.job +
               " Salary:" + this.salary + " Da:" + this.da);
  }
}

util.inherits(Employee,EventEmitter);

Employee.prototype.promote = function(increment){
 this.salary = this.salary + increment;
 this.da = this.salary * 0.90;
 this.emit('updation','promoted');
}

var emp = new Employee('Santosh', 'Developer',23000.0);
emp.show();
emp.on('updation',function(arg){
 console.log(arg + ', update changes salary as well as DA');
 emp.show();
});

emp.promote(2500.0);