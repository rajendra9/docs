drop function if exists add_class_room(varchar(10),int,varchar(15),text[]);


create function add_class_room(in crs varchar(10), in crs_yr int,in teach varchar(15),in stuarr text[], out ret boolean) as $$
declare
  cnt integer;
begin

  select count(*)  into cnt from class_room where course=$1 and course_year=$2;
  if(cnt ==0) then
    insert into class_room( course,course_year,teacher,students) values
      ($1,$2,$2,$4);
    cnt := true;  
 
  end if;
end;
$$
LANGUAGE 'plpgsql';  
  