package exers;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

public class JdbcClassRoom {
  Connection conn;
 
  public JdbcClassRoom() {
	try {
	  InitialContext ctx = new InitialContext();
	  DataSource ds = 
        (DataSource)ctx.lookup("java:comp/env/jdbc/myPostgres");
	  conn = ds.getConnection();
	 }catch(Exception e) {
		  System.out.println(e.getMessage());
	  }
	 }
  }
  