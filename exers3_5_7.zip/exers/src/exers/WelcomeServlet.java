package exers;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import exers.utils.DBAuthenticator;


@WebServlet("/simpLogin")
@SuppressWarnings("serial")
public class WelcomeServlet extends HttpServlet {

    DBAuthenticator authenticator;
	@Override
	public void init() throws ServletException {
	   authenticator = new DBAuthenticator();
	}

	@Override
	public void destroy() {
		authenticator = null;
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			  throws ServletException, IOException {
	     doPost(request, response);
	}

	public String getToken(String email) {
		StringBuffer sb = new StringBuffer("?email=");
		try {
		email = URLEncoder.encode(email, "ISO_8859_1");
		}catch(Exception ex){
		  ex.printStackTrace();	
		}
		sb.append(email);
	    return sb.toString(); 
	}
	private String writeAnchor(String site, String email) {
	  StringBuffer sb = new StringBuffer("<a href='");
	  sb.append(site);
	  sb.append(this.getToken(email));
	  sb.append("'>");
	  sb.append(site);
	  sb.append("</a><br/>");
	  return sb.toString();		
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			  throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	    String uname = request.getParameter("username");
	    String pwd = request.getParameter("password");
	    boolean isValid = this.authenticator.validateUser(uname, pwd);
		if(isValid) {
		  String objType = request.getParameter("objType");
		  String email = request.getParameter("email");
		  if(objType.equalsIgnoreCase("books")) {
		   out.write(this.writeAnchor("amazon.html", email));
		   out.write(this.writeAnchor("wrox.html", email));
		   out.write(this.writeAnchor("manning.html", email));
		   out.flush();
		  }else if(objType.equalsIgnoreCase("flowers")) {
			out.write(this.writeAnchor("esotericFlowers.html", email));			   
		  }		  
		}
	}

}
