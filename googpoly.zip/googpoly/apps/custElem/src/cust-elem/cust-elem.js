import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/iron-input/iron-input.js';
import '@polymer/polymer/lib/elements/dom-repeat.js'
/**
 * @customElement
 * @polymer
 */
class CustElem extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
          margin-top: 20px;
          padding: 10px;
          font-weight: bold;

        }
      </style>
      <div align="center">
      <h2>Custom Element View page</h2>
      <p>you are working in [[company]]</p>
      <br/>
      <iron-input bind-value="{{company}}">
          <input value="{{company}}"/>
      </iron-input>
      <hr>
      <label>Departments:</label>
      
      <select name="dept">
       <option>&nbsp;&nbsp;</option>
        <template is="dom-repeat" items="{{departments}}">
             <option>{{item}}</option>
        </template>
      </select>
    </div>  
    `;
  }
  static get properties() {
    return {
      company: {
        type: String,
        value: 'HTC[Change This for 2-way]'
      }
    };
  }
  constructor(){
    super();
    this.departments = ["Sales","Purchase","Production","Finance","Shipping","HR"];
    }
}

window.customElements.define('cust-elem', CustElem);
