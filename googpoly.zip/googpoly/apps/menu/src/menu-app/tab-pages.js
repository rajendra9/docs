import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/paper-tabs/paper-tabs.js';
import '@polymer/paper-tabs/paper-tab.js';

/**
 * @customElement
 * @polymer
 */
class TabPages extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
        }
        .link { 
          @apply --layout-center center;
          @apply --layout-horizontal;
          border: 2px solid blue;
          font-size: 18px;
          background: #CCFFFF;
          padding: 10px;
          float: left;
          width: 80px;
          margin: 5px;
          height: 30px;
          font-weight: bold;
        }
        
      </style> 
      <paper-tabs selected="o">
       <paper-tab link>
        <a href="./my-viewOne.html" class="link"  tabIndex="-1">View One</a>
       </paper-tab> 
       <paper-tab link>
       <a href="./my-viewTwo.html" class="link"  tabIndex="-1">View Two</a>
      </paper-tab> 
      <paper-tab link>
      <a href="./my-viewThree.html" class="link"  tabIndex="-1">View Three</a>
     </paper-tab> 
     </paper-tabs>     
    `;
  }
  static get properties() {
    return {
      page: {
        type: String,
        value: ""
             
      }
    };
  }
  
  }

window.customElements.define('tab-pages', TabPages);
