import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/app-layout/app-header/app-header.js';
import '@polymer/app-layout/app-drawer/app-drawer.js';
import '@polymer/app-layout/app-toolbar/app-toolbar.js';
import '@polymer/paper-icon-button/paper-icon-button.js';
import '@polymer/iron-icons/iron-icons.js';


/**
 * @customElement
 * @polymer
 */
class MenuApp extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
          --app-primary-color: #4285f4;
          --app-secondary-color: black;
          --app-drawer-width: 300px;
        }
        iron-pages{
           margin: 0 20px;
        }
        iron-pages a{
          display: block;
          padding: 0 16px;
          text-decoration: none;
          line-height: 40px;
          color: var(--app-secondary-color);          
        }
       iron-pages a{
        color: black;
        font-weight: bold;          
        }
        app-header{
          color: #fff;
          background-color: var(--app-primary-color);
        }
        app-header paper-icon-button {
          --paper-icon-button-ink-color: white;
        }
      </style>
      
      
      <app-header reveals>
       <app-toolbar>
        <paper-icon-button icon="menu" onclick="drawer.toggle()"></paper-icon-button>
        <div main-title>My Menu</div>
        <paper-icon-button icon="delete"></paper-icon-button>
        <paper-icon-button icon="search"></paper-icon-button>
        <paper-icon-button icon="close"></paper-icon-button>
        <paper-progress  value="10" indeterminate bottom-item></paper-progress>
       </app-toolbar>
      </app-header>
               
      <iron-pages selected="0"> 
       <a  href="./my-viewone.html" >View One</a>
       <a  href="./my-viewTwo.html">View Two</a>
       <a  href="./my-viewThree.html">View Three</a>  
       </iron-pages>           
    `;
  }
  static get properties() {
    return {
      page: {
        type: String,
        value: '',
        reflectToAttribute: true
        
      }
    };
  }  
}
window.customElements.define('menu-app', MenuApp);
