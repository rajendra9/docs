import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/polymer/lib/elements/dom-repeat.js';

/**
 * @customElement
 * @polymer
 */
class UsePoly extends PolymerElement {
  static get template() {
    return html`
      <style>
      :host {
        display: block;       
        margin-top: 5px;
        padding: 5px;
      }   
      td{
          margin: 6px;
          padding: 6px;
      }  
      h2{
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
      }  
    </style>
    <div align="center">
    <h2>Showing A List of {{showList}} Json Data</h2>
    <table>  
       <tr><td>ProdId</td><td>ProdName</td><td>ProdCost</td></tr>
      <template is="dom-repeat" items="{{products}}">
       <tr>
        <td>{{item.prodId}}</td>
        <td>{{item.prodName}}</td>
        <td>{{item.prodCost}}</td>
       </tr>
      </template>
     </table>    
     </div>
    `;
  }
  static get properties() {
    return {
      showList: {
        type: String,
        value: 'List of Products'
      }
    };
  }
  constructor(){
    super();
     this.products = [
       {prodId: 200, prodName: 'AAAAA', prodCost: 234.5},
       {prodId: 300, prodName: 'BBBBB', prodCost: 443.5},
       {prodId: 400, prodName: 'CCCCC', prodCost: 454.5},
       {prodId: 500, prodName: 'DDDDD', prodCost: 534.5},
       {prodId: 600, prodName: 'EEEEE', prodCost: 434.5},         
     ];         
   }

}

window.customElements.define('use-poly', UsePoly);
