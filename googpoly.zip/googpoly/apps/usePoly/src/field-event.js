import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/iron-input/iron-input.js';
/**
 * @customElement
 * @polymer
 */
class FieldEvent extends PolymerElement {
  static get template() {
    return html`
      <style>
      :host {
        display: block;       
        margin-top: 5px;
        padding: 5px;
      }
      </style>
      <div align="center">
         <h1>Hello {{title}}</h1>
         <label>Name: &nbsp;</label>
         <iron-input  bind-value="{{name}}">
            <input is="iron-input" />
         </iron-input>
         <h3>You entered - [[name]]</h3>
         <label>Salary: &nbsp;</label>
         <iron-input  bind-value="{{salary}}">
            <input  placeholder="Salary here:"/>
         </iron-input>
         <h3>Property Change</h3>
         <p>{{changes}}</p>
       </div>        
    `;
  }
  static get properties() {
    return {
      title:{
        type: String,
        value: 'For Field Observable Events'
    },  
    name:{
        type: String,
        value: "HTC Global"
       },
       salary:{
          type: Number,
          observer: '_salChanged'
       }
    };    
  }
  _salChanged(newVal, oldVal){
    var msg = oldVal + " is Changed to " + newVal;
    console.log(msg);
    this.changes = msg; 
}

}

window.customElements.define('field-event', FieldEvent);
