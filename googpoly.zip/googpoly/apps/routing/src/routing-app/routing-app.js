import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/app-route/app-location.js';
import '@polymer/app-route/app-route.js';

/**
 * @customElement
 * @polymer
 */
class RoutingApp extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
        }
      </style>
      <app-location  route="{{route}}" ></app-location> 
      <app-route 
       route="{{route}}" 
        pattern="/:view"
        data="{{routeData}}"
        tail="{{subroute}}">
      </app-route>
      <app-route 
        route = "{{subroute}}" 
        pattern = "/:id"
        data = "{{subrouteData}}">
       </app-route>
   
      `;
  }
  static get properties() {
    return {
      routeData: {
        type: Object        
      },
      subroute:{
        type: Object
      }
    };
  }
}

window.customElements.define('routing-app', RoutingApp);
