import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/paper-toggle-button/paper-toggle-button.js';
/**
 * @customElement
 * @polymer
 */
class HideShow extends PolymerElement {
  static get template() {
    return html`
    <style>
     :host{
        display: block; 
        margin-top: 5px;    
        text-align:center;   
      } 
      .forHide{
        display: none;
      }
      .forShow{
         display: block;
      }
     paper-toggle-button{
       margin-left: 380px;
     }
     </style>
     <div align="center" >
       <h2 style="padding:18px;">Hiding and showing</h2> <br/>
       <paper-toggle-button checked="{{showFlag}}">show</paper-toggle-button>
       <br/>
       <section id="mySection" class="forHide">
         <h2>This display can be toggled</h2>
        </section>   
       </div> 
    `;
  }
  static get properties() {
    return {
      showFlag: {
        type: Boolean,
        value: false,
        observer: '_watchSwitch'
      }
    };
  }
  _watchSwitch(oldVal,newVal){
    if(newVal === true){
     const slot = this.shadowRoot.querySelector('#mySection');
     slot.className = 'forShow';
    console.log('shown');
    }
    else if(newVal === false){
      const slot = this.shadowRoot.querySelector('#mySection');
      slot.className = 'forHide';
     console.log('Hidden');
     }
  }
}

window.customElements.define('hide-show', HideShow);
