import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/paper-input/paper-input.js';
import '@polymer/paper-button/paper-button.js';
import '@polymer/paper-dialog/paper-dialog.js';

/**
 * @customElement
 * @polymer
 */
class ForDlg extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
        }
        paper-button{
          width: 120px;
          border: 2px solid blue;
        }
        paper-input{
          width: 150px;
          border: 2px solid blue;
        }  
        paper-dialog{
          width:  160px;
          border: 3px solid;
        }
        
      </style>
      <div align="center">
      <paper-input label="Name" 
      id="username" 
      allowed-pattern="[a-zA-Z]" 
      value={{username}} 
       
      error-message="User Name Required" required>
      </paper-input><br/><hr/>

      <paper-button raised 
       on-tap="validatedetails">Submit
       </paper-button>

        <div>
      <paper-dialog id="userdetails">
          <h2>User Information</h2>
           <p>[[username]]</p>

       <div class="buttons">
<!--This button is used to close the dialog-->
<paper-button dialog-dismiss 
style="color: #0B746E" on-tap="cleardata">
   CLOSE</paper-button>
         </div>
      </paper-dialog>
   </div>
   `;
  }
  static get properties() {
    return {
      username: {
        type: String
      }
    };
  }
 validatedetails(event) {
  
  if(  this.username == null || this.username.length == 0){
  
    this.username = "You should enter the username";
  
  }  else {
    this.username = "Welcome " +this.username+" to polymer";
  }
  this.$.userdetails.open();
}
}

window.customElements.define('for-dlg', ForDlg);
