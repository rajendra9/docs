import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/iron-icon/iron-icon.js';
import '@polymer/iron-icons/iron-icons.js';
import '@polymer/iron-form/iron-form.js';
import '@vaadin/vaadin-date-picker/vaadin-date-picker.js';
import '@vaadin/vaadin-button/vaadin-button.js';

/**
 * @customElement
 * @polymer
 */
class ShadDom extends PolymerElement {
  static get template() {
    return html`
   <style>
    :host{
      display: inline-block;       
     }  
     .localPara{
         background: cyan;
     }
      iron-icon {
         fill: rgba(0,0,0,0);
         stroke: currentcolor;
       } 
       :host([pressed]) iron-icon {
            fill: currentcolor;
        }
     </style>
      <div align="center">
       <iron-icon icon="[[toggleIcon]]">
       </iron-icon>
       <p>
          Content wont get default styles <br/>
          wont get style from Main Dom
       </p>
       <p class="localPara">
          Content coming from shadow Dom<br/>
          getting style from shadow style
       </p>        
      </div>
    `;
  }
  static get properties() {
    return {
      pressed:{
        type: Boolean,
        notify: true,
        reflectToAttribute: true,
        value: false
       },
       toggleIcon:{
           type: String
       }
    };
  }
  


}

window.customElements.define('shad-dom', ShadDom);
