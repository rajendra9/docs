import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/paper-input/paper-input.js';
import '@polymer/iron-ajax/iron-ajax.js';


/**
 * @customElement
 * @polymer
 */
class UseAjax extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
          margin:top: 5px;
        }
        paper-input{
          border: 3px solid blue;
          color: cyan;
          margin-bottom: 5px;
          width: 100px;
        }  
      </style>
      <div align='center'>
      <h2>Iron Ajax Demo</h2>
        <paper-input label='item Id' value='{{itemId}}' 
             on-blur='resolve'></paper-input><br/>
      <input  type='text'/>
      </div>
      <iron-ajax auto='' url='{{resolveUrl}}'
      id='xhr'
      handle-as='json'
      on-response='_handleResponse'>    
      </iron-ajax>
      <p>{{itemDetails}}</p>  
    </div>   
    `;
  }
  static get properties() {
    return {
      myUrl:{
        type: String,
        value: 'http://localhost:10080/restserv/rest/items/itemAsJson?itemId='
      },
      resolveUrl:{
        type: String,          
      },
      itemId: {
        type: Number,
        value: 100
      },
      itemDetails:{
        type: String
      }
    };
  }
  resolve(event){
    this.set('resolveUrl', this.myUrl + event.target.value);
  }

  _handleResponse(event){
    var resp = event.detail.response;
    this.itemDetails = JSON.stringify(resp);
  }

}

window.customElements.define('use-ajax', UseAjax);
