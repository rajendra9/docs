import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';

/**
 * @customElement
 * @polymer
 */
class WelcomeHtc extends PolymerElement {
  static get template() {
    return html` 
      <style>
        :host {
          display: block;
          color: blue;
        }
      </style>
      <h2>Hello [[welcome]]!</h2>
    `;
  }
  static get properties() {
    return {
      welcome: {
        type: String,
        value: 'Welcome to Htc Polymer Own Elements'
      }
    };
  }
}

window.customElements.define('welcome-htc', WelcomeHtc);
