import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/iron-jsonp-library/iron-jsonp-library.js';
import '@polymer/polymer/lib/elements/dom-if.js';

/**
 * @customElement
 * @polymer
 */
class MyJsonLib extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
        }
      </style>
     <div>
      <iron-jsonp-library 
      library-url="https://apis.google.com/js/platform.js?onload=%%callback%%" asynch defer 
       callbackName="_onLoadCallback"   notify-event="api-load"    
       library-loaded="{{loaded}}" >     
     </iron-jsonp-library>

    <template is="dom-if" if="{{loaded}}">
         <p class="success">The people json has been loaded</p>
    </template>
    
    <a href="#" on-click="renderWidget">Render the +1 button</a>
    <div id="widget-div"></div>    
    </div>
    `;
  }
  static get properties() {
    return {
     loaded: {
        type: Boolean,
        value: false        
      },
    };
  }
  renderWidget(e) {
    console.log('UUUUU');
    gapi.plusone.render("widget-div" );
  }
}

window.customElements.define('my-json-lib', MyJsonLib);
