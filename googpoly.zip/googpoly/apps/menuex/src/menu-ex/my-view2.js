import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';

/**
 * @customElement
 * @polymer
 */
class MyViewTwo  extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
        }
      </style>
      <h2>Hello [[name]]!</h2>
    `;
  }
  static get properties() {
    return {
      name: {
        type: String,
        value: 'Page Number-2'
      }
    };
  }
}

window.customElements.define('my-view2', MyViewTwo);