import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';

/**
 * @customElement
 * @polymer
 */
class MyViewOne  extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
        }
      </style>
      <h2>Hello [[name]]!</h2>
    `;
  }
  static get properties() {
    return {
      name: {
        type: String,
        value: 'Page Number-1'
      }
    };
  }
}

window.customElements.define('my-view1', MyViewOne);
