import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/paper-checkbox/paper-checkbox.js';
import '@polymer/paper-button/paper-button.js';
import '@polymer/paper-listbox/paper-listbox.js';
import '@polymer/paper-item/paper-item.js';
import '@polymer/polymer/lib/elements/dom-bind.js';
/**
 * @customElement
 * @polymer
 */
class MaterialElems extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
        }
        paper-listbox{
          margin-left: 450px;
        }
      </style>
      <h2>Material Elements</h2>     
      <dom-bind>
          <template is="dom-bind">
            <p>"[[prodName]]" is selected.</p>

            <paper-listbox attr-for-selected="prod-name" selected="{{prodName}}"
               fallback-selection="none">

              <paper-item prod-name="none">--choose--</paper-item>

              <paper-item prod-name="Car">Car</paper-item>

              <paper-item prod-name="Mobile">Mobile</paper-item>

              <paper-item prod-name="Computer">Computer</paper-item>

              <paper-item prod-name="Laptop">Laptop</paper-item>

            </paper-listbox>

          </template>

        </dom-bind>
        <paper-checkbox on-change="handleCheck"></paper-checkbox>
        <paper-button raised>
         <core-icon icon="favorite"></core-icon>
           My Button
        </paper-button>
        <p>{{checkStateMsg}}</p>
        
    `;
  }
  static get properties() {
    return {
      prodName: {
        type: String     
      },
      checkState: {
        type: Boolean     
      },
      checkStateMsg: {
        type: String     
      }
    };
  }
  handleCheck(event){
    this.checkState = !this.checkState;
    if(this.checkState) {
     this.checkStateMsg = 'I like Paper Elements';
    }
    else{
      this.checkStateMsg = '';
    }
  }
}

window.customElements.define('material-elems', MaterialElems);
