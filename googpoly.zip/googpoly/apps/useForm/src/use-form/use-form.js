import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/iron-form/iron-form.js';
import '@polymer/paper-input/paper-input.js';
import '@polymer/paper-button/paper-button.js';
import '@vaadin/vaadin-date-picker/vaadin-date-picker.js';

/**
 * @customElement
 * @polymer
 */
class UseForm extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
          margin: 8px;
        }
        paper-input{
          width: 110px;
          border: 2px solid;
        }
        td{
          margin: 5px;
          padding: 5px;
        }
      </style>
      <div align="center">
      <h2>Item Creation Form</h2>
      <iron-form>
      <form  method="post" id="itemForm"   
       action="http://localhost:10080/forPoly/insertItem.jsp" >
       <table><tr>
       <td><label>Item Number:</label></td><td><input  name="itemNum" type="text"/></td></tr>
       <tr><td><label>Item Name:</label></td><td><input  name="itemName" type="text"/></td> </tr>
    <tr><td><label>Item Cost:</label></td><td><input  name="itemCost" type="text"/></td></tr>
    <tr><td><label>Customer:</label></td><td><input  name="customer" type="text"/></td></tr> <br/>
    <tr><td><label>Date-of-manufacture</label></td>
    <td><input type="date" name="dom" required /></td></tr/>
    </table><br/><hr/>    
    <button  on-click="_submit">getItem</button>
    </form> 
    </iron-form>   
    </div>
    `;
  }
  static get properties() {
    return {
      itemNum: {
        type: String                
      }
      
    };
  }
  connectedCallback(){
    super.connectedCallback();
    const myForm = this.$.itemForm;
    myForm.addEventListener('iron-form-presubmit',function(event){
      event.preventDefault();
      console.log('here');
    });
  }
 
  _submit(){
    console.log("hhhhhhh");
    this.$['itemForm'].submit();
  }
}

window.customElements.define('use-form', UseForm);
