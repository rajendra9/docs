import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/paper-input/paper-input.js';
import '@polymer/paper-button/paper-button.js';
import '@vaadin/vaadin-grid/vaadin-grid.js';
import '@vaadin/vaadin-date-picker/vaadin-date-picker.js';
import '@polymer/iron-localstorage/iron-localstorage.js';
/**
 * @customElement
 * @polymer
 */
class SimpWeb extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host{
          display: block;
          margin-top: 5px;
        }
        section{
          text-align: center;
          display: block;
          width: 80%;
        }
        paper-input{
           width: 300PX; 
           border: 2px solid;          
        }
        vaadin-date-picker{
          width: 160px;          
        }
        paper-button{
          border: 2px solid;           
        }
      </style>
       <div align="center">
        <h2>Task Submission</h2>
        <section>
        <table><tr><td>
        <paper-input label="task"  value="{{work.task}}"></paper-input></td></tr>
        <tr><td><vaadin-date-picker label="due" value="{{work.due}}"></vaadin-date-picker></td></tr>
        <tr><td><paper-button raised on-tap="_addWork" > Add To Tasks </paper-button></td></tr>
        </table> 
        </section><hr/>
        <section>
        <vaadin-grid theme="row-dividers" id="myGrid" items="{{works}}">
        <vaadin-grid-column>
            <template class="header">
              <span>Task</span>
            </template> 
             <template>[[item.task]]</template>
          </vaadin-grid-column>
          <vaadin-grid-column >
            <template class="header">
              <span>Due-Date</span>
            </template>           
             <template>[[item.due]]</template>
          </vaadin-grid-column>
         </vaadin-grid>
        </section>
        <section>
        <iron-localstorage name="works" value="{{works}}" 
        on-iron-localstorage-load-empty="_initStore">
        </section>
        </div>
    `;
  }
  static get properties() {
    return {
      work: {
        type: Object,
        value: function(){  
          return {};      
        }  
      },
      works:{
        type: Array,
        value: function(){
          return [];
        }
      }
      
    };
   
  }
    _addWork(event){
    console.log('kkkkkk');
    this.push('works',this.work);
    console.log(this.works[0].task);  
    this.work = {};
  } 
 _initStore(event){
   console.log('store init');
   this.works = [];
 }
}

window.customElements.define('simp-web', SimpWeb);