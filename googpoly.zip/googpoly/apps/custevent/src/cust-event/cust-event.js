import {html, PolymerElement} from '@polymer/polymer/polymer-element.js';
import '@polymer/iron-input/iron-input.js';

/**
 * @customElement
 * @polymer
 */
class CustEvent extends PolymerElement {
  static get template() {
    return html`
      <style>
        :host {
          display: block;
          margin-top: 20px; 
        },
        button{
           width: 80px;
           border: 2px solid;
        }
      </style>
      <div align="center">       
      <label>Person Name:</label>  
      <iron-input bind-value="{{person}}">
            <input  placeholder="enter person"/>
        </iron-input><br/>
        <button on-click="showTopic">Show Topic</button>
      </div>
    `;
  }
  static get properties() {
    return {
      person: {
        type: String,
        value: ''
      },
      topic:{
        type: String
      },
      topics:{
          type: Map
      }
    };
  }
  constructor(){
    super();
    this.topics = new Map();
    this.topics.set("Sachin", "cricket");
    this.topics.set("Sindhu","Badminton");
    this.topics.set("Bachung","Football");                   
}
getTopic(){
    return this.topics.get(this.person);
}
showTopic(e){
       var result = this.person + '  interested topic is: ' + this.getTopic();
       console.log("fff" + result);
       this.dispatchEvent(new CustomEvent('kick',{detail: { topic: result }}));
}

}
window.customElements.define('cust-event', CustEvent);
