package com.htc.spring.boot.aop;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
 
@Aspect
public class AopForSampleService {
 
@Around("execution(* com.htc.spring.boot.services.SampleService.*(..))")
public Object doIntercept(ProceedingJoinPoint pjp)throws Throwable{
    System.out.println("Before doing service");
    Object[] params = pjp.getArgs();
    System.out.println(Arrays.toString(params));
    Object ret = pjp.proceed();
    System.out.println("After doing service - "+ret);
    return ret;
 }
    
}


