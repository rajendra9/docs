package com.htc.spring.boot;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.context.ApplicationContext;

import org.springframework.context.annotation.Bean;


import com.htc.spring.boot.services.SampleService;
import com.htc.spring.boot.aop.
AopForSampleService;


@SpringBootApplication
public class BootDemoApplication {

    public static void main(String[] args) {
 
     ApplicationContext ctx = SpringApplication.run(BootDemoApplication.class, args);

      System.out.println("****"+ctx);
      SampleService sample = (SampleService) ctx.getBean("sample");
     
      System.out.println("JJJ"+sample);
      System.out.println(sample.doWork("Swaminathan", "Tax-Calculation"));   
 
   }


   @Bean(name="sample")
   public SampleService createService(){

      return new SampleService();  
 
   }
 

  @Bean
   public AopForSampleService createAopService(){

      return new AopForSampleService();  

   }
 

}
