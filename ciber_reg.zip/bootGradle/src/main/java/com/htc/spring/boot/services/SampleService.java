package com.htc.spring.boot.services;

public class SampleService {
  
    public SampleService(){
      System.out.println("Welcome to service");
    }    

    public String doWork(String person,String work){
       StringBuilder sb = new StringBuilder();
       sb.append("Hello ");
       sb.append(person);
       sb.append(" We completed your work i.e ");
       sb.append(work);
       return sb.toString();
    }
}
