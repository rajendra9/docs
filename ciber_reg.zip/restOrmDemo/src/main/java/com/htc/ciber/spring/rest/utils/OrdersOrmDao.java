package com.htc.ciber.spring.rest.utils;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import org.hibernate.SessionFactory;

import com.htc.ciber.spring.rest.domain.OrderTo;


public interface OrdersOrmDao extends Serializable {
	
  public List<OrderTo>  getAllOrders();
  
  public boolean isOrderExists(String ordId);
  
  public Optional<OrderTo> getOrder(String orderId);
 
  public boolean saveOrder(OrderTo order);
  
  public boolean updateOrder(String ordId, String newCustomer, double newCost);

  public boolean deleteOrder(String ordId);
}
