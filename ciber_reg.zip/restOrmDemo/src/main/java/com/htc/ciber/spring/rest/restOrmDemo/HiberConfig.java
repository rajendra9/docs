package com.htc.ciber.spring.rest.restOrmDemo;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.htc.ciber.spring.rest.utils.OrdersOrmDao;
import com.htc.ciber.spring.rest.utils.OrdersOrmService;

@Configuration
@PropertySource("file:./jdbc.properties")
@EnableTransactionManagement
@ComponentScan({"com.htc.ciber.spring.rest.utils","com.htc.ciber.spring.rest.domain"})
public class HiberConfig {
	@Autowired
	Environment env;
	
	@Bean
    public DataSource dataSource() {
		DriverManagerDataSource ds =
             new DriverManagerDataSource(); 
		System.out.println("fired");
     String driverCl = env.getProperty("db.driver");
     ds.setDriverClassName(driverCl);
     ds.setUrl(env.getProperty("db.url"));
     System.out.println(env.getProperty("db.password"));
     ds.setUsername(env.getProperty("db.username"));
     ds.setPassword(env.getProperty("db.password"));
     System.out.println("***"+ds);
     return ds;
    }  	
    private Properties jpaProperties(){
	       Properties jpaProperties = new Properties();
	       jpaProperties.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
	       jpaProperties.put("hibernate.globally_quoted_identifiers","true");
	       jpaProperties.put("hibernate.cglib.use_reflection_optimizer","true");
	       jpaProperties.put("hibernate.format_sql","true");
	       jpaProperties.put("hibernate.show_sql","true");
	       return jpaProperties;
	}    
    @Bean
	public HibernateJpaVendorAdapter jpaVendorAdapter(){
	    HibernateJpaVendorAdapter jpaVendorAdapter =
	                        new HibernateJpaVendorAdapter();
	    jpaVendorAdapter.setDatabase(Database.MYSQL);
	    jpaVendorAdapter.setShowSql(true);
	    jpaVendorAdapter.setGenerateDdl(false);
	    return jpaVendorAdapter;
     }

    @Bean 
    public LocalContainerEntityManagerFactoryBean
                                 entityManagerFactory(){
        LocalContainerEntityManagerFactoryBean emFactoryBean =
                   new LocalContainerEntityManagerFactoryBean();
        emFactoryBean.setJpaVendorAdapter(jpaVendorAdapter());
        emFactoryBean.setPackagesToScan("com.htc.ciber.spring.rest.domain");              
        
        emFactoryBean.setPersistenceUnitName("default");         
        emFactoryBean.setDataSource(dataSource());
        emFactoryBean.setJpaProperties(jpaProperties());
        return emFactoryBean;
    }

    @Bean
    public JpaTransactionManager transactionManager() {
       JpaTransactionManager txManager = new JpaTransactionManager();
       txManager.setEntityManagerFactory(entityManagerFactory().getObject());  
       return txManager;
    }
  
    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
       return new PersistenceExceptionTranslationPostProcessor();
    }

	    
    @Bean(name = "ordersOrmService")
     public OrdersOrmDao orderOrmDao(){
      OrdersOrmDao ordersOrmDao = new OrdersOrmService();
      return ordersOrmDao;
    }
   


}
