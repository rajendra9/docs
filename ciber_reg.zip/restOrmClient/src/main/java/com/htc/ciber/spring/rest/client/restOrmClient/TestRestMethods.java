package com.htc.ciber.spring.rest.client.restOrmClient;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.web.client.RestTemplate;

import com.htc.ciber.spring.rest.domain.OrderTo;


public class TestRestMethods {

	public static final String REST_SERVICE_URI = "http://localhost:8020/crudOrder";
    
   
    @SuppressWarnings("unchecked")
    private  void listAllOrders(){
        System.out.println("Testing listAllOrders API-----------");
         
        RestTemplate restTemplate = new RestTemplate();
        List<LinkedHashMap<String, Object>> ordersLinkMap = restTemplate.getForObject(REST_SERVICE_URI+"/showAll/", List.class);
         
        if(ordersLinkMap!=null){
            for(LinkedHashMap<String, Object> map : ordersLinkMap){
                System.out.println("Order : id="+map.get("orderId")+", OrderDate="+map.get("orderDate")+", Customer="+map.get("customer")+", Cost="+map.get("cost"));;
            }
        }else{
            System.out.println("No Order exist----------");
        }
    }
     
    /* GET */
    private  void getOrder(){
        System.out.println("Testing getOrder API----------");
        RestTemplate restTemplate = new RestTemplate();
        OrderTo order = restTemplate.getForObject(REST_SERVICE_URI+"/getOrder/c1000", OrderTo.class);
        System.out.println(order);
    }
     
    /* POST */
    private  void createOrder() {
        System.out.println("Testing create OrderTO API----------");
        RestTemplate restTemplate = new RestTemplate();
        
        OrderTo newOrder = new OrderTo("c1900","2018-05-12","aaaa|bbbb", 2354.7, "M/s Kankan & Bros" );
        URI uri = restTemplate.postForLocation(REST_SERVICE_URI+"/addOrder/", newOrder, OrderTo.class);
        System.out.println("Location : "+uri.toASCIIString());
    }
 
    /* PUT */
    private void updateOrder() {
        System.out.println("Testing update Order API----------");
        RestTemplate restTemplate = new RestTemplate();
        
        OrderTo changed = new OrderTo("c1100", "2018-08-13", "piston3|bolt3|nut20", 11954.7, "M/s ChennaiKutty & Bros");
        restTemplate.put(REST_SERVICE_URI+"/changeOrder/c1100", changed);
        System.out.println(changed);
    }
 
    /* DELETE */
    private  void deleteOrder() {
        System.out.println("Testing delete Order API----------");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(REST_SERVICE_URI+"/delete/c1200");
    }
 
 
    
 
    public  void tesRest(){
        listAllOrders();
        getOrder();
        createOrder();
        listAllOrders();
        updateOrder();
        listAllOrders();
        deleteOrder();
        listAllOrders();
    }

}
