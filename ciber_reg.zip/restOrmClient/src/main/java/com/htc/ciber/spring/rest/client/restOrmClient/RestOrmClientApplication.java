package com.htc.ciber.spring.rest.client.restOrmClient;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class RestOrmClientApplication {

	@Bean
	public TestRestMethods getTester() {
		return new TestRestMethods();
	}

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(RestOrmClientApplication.class);
		TestRestMethods testRestMethods = ctx.getBean(TestRestMethods.class);
		testRestMethods.tesRest();
		ctx.close();

	}

}

