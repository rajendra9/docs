import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BlankComponent } from './blank/blank.component';
import { HostComponent } from './host/host.component';


const routes: Routes = [
  {path:'',component: BlankComponent},
  {path:':id/details', component: HostComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
