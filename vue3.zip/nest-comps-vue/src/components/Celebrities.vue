<template>
     <div id="celebrities">
      <ul>
        <li v-for="(celebrity,index) in celebrities" v-bind:key="index" v-on:click="celebrity.display = !celebrity.display">
          
          <span>{{celebrity.name}}</span>&nbsp;&nbsp;&nbsp;
          <span v-show="celebrity.display">{{celebrity.field}}</span>
          
        </li>  
      </ul>  

     </div>
</template>

<script>
 export default {
     data(){
         return {
           celebrities:[
             {name:'Sachin Tendulkar', field: 'Cricket', display: false},
             {name:'Sindhu', field: 'Shuttle', display: false},
             {name:'Baichung Bhutia', field: 'Football', display: false},
             {name:'Anna Hazare', field: 'Social Work', display: false},
             {name:'Bharat Chetri', field: 'Hockey', display: false},
             {name:'Ammer Khan', field: 'Bollywood', display: false}
             
           ]
         }
     }
 }


</script>

<style scoped>
 #celebrities{
   width: 100%;
   max-width: 1200px;
   margin: 40px auto;
   padding: 0 20px;
   box-sizing: border-box;
 }
 ul{
   display: flex;
   flex-wrap: wrap;
   list-style-type: none;
   padding: 0;
 }
 li{
   flex-grow: 1;
   flex-basis: 300px;
   text-align: center;
   padding: 30px;
   border: 1px solid #222;
   margin: 10px;
 }
</style>