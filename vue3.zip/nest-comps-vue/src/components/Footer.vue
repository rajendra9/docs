<template>
 <footer>
  <p>{{copyright}}</p>
 </footer>    
</template>

<script>
 export default {
     data(){
         return {
          copyright: 'Copyright 2018 Prasad, Chennai'
         }
     }
 }


</script>

<style scoped>
  footer{
   background: #222;
   padding: 6px;
  }
  p{
    color: lightblue;
    text-align: center;
  }
</style>