
new Vue({
    el: '#vue-refs-app',
    data:{  
        content:'hai',  
        name:'',
        favSports:''   
    },
    methods:{ 
        submitData: function(){
            this.name = this.$refs.name.value;
            this.favSports = this.$refs.favSports.value;
            this.content = this.$refs.divContent.innerHTML;
        }      
    },
    computed:{      
    }
});
