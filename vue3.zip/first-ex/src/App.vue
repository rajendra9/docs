<template>
  <div>
    <h1>{{title}}</h1>
    <Sports></Sports>
  </div>
</template>

<script>
import Sports from './components/sports.vue';

export default {
  components:{
  'Sports': Sports
},
 data(){
    return{ 
      title: 'This is the Vue Application'
  }
}

}
</script>

<style scoped>
 h1{
   color: blue;
   font-size: 24px;
   font-weight: bold;
 }
</style>
