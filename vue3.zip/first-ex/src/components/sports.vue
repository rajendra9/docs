<!-- component should only have one parent element -->
<template>
  <div>
     <h1> General Sports of Age</h1> 
  <ul>
      <li v-for='(sport,index) in sports' v-bind:key='index'>{{sport}}</li>
  </ul>
  </div>
</template>

<script>
export default{
    data(){
        return {
            sports: ['Cricket', 'Hockey', 'Tennis', 'Football','Shuttle']
        }
    }
}
</script>
<style scoped>
</style>