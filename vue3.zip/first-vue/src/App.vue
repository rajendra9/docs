<template>
  <div id="app">
    <h1>{{heading}}</h1>
    <sports></sports>
  </div>
</template>
<script>
import Sports from './components/sports.vue';
export default {
  components:{
    'sports': Sports
  },
  data(){
    return {
      heading: 'First Vue Cli3 Application'
    }
  }
}
</script>


<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  margin-left:200px;  
}
h1{
  color: purple;
}
</style>
