<template>
 <div id="sprt">
     <h1>Main Sports of this Age</h1>
     <ul>
         <li v-for="(sport, index) in sports" v-bind:key="index">{{sport}}</li>
     </ul>        
 </div>
</template>

<script>
export default{
 data(){
     return {
         sports: ['Cricket', 'Tennis', 'Shuttle', 'Hockey', 'Football', 'Kabbadi']
     }
 }

    
}
</script>

<style scoped>
h1{
    color: green;
}
#sprt{ 
 
  color: green;  
}
</style>