package wodomain



import grails.transaction.Transactional

class PersonController {



  static scope = "session"
 
   def authenticatorService

   def index() {
     redirect(action: 'login') 
   }

   def list(){
     def persons = Person.list()
     [persons : persons]
   }

   def login(){
   }

   def allow(){
     def un = params.username
     def pw = params.password
     def ret = authenticatorService.authenticate(un,pw)
     if(ret) {
       [result: "OK"]
     }
     else {
       [result: "NO"]
     }    
   }


   def show(){
     def person = Person.get(params.id)
     [person: person]
   }

   def create() {
     respond new Person(params)
   }

   @Transactional
   def save(Person person){
     if(person == null){
       transactionStatus.setRollbackOnly()
       notFound()
       return
     } 
     if(person.hasErrors()){
       transactionStatus.setRollbackOnly()
       respond person.errors, view: 'create'
       return
     }
     
     person.save flush:true
     flash.message = "person with id: "+person.id+" saved";
     redirect(action: 'create')    
  }
   
  @Transactional
   def update(){
     println "ddddd"
     def p = Person.get(params.pId)
     p.personName = params.pName
     println params
     

     p.dob = params.pDob

     p.address = params.pAddr

     p.income = Float.parseFloat(params.pInc)

     println p     
     if(p == null){
       transactionStatus.setRollbackOnly()
       notFound()
       return
     } 
     if(p.hasErrors()){
       transactionStatus.setRollbackOnly()
       respond person.errors, view: 'edit'
       return
     }
     
     p.save(insert:false, flush:true)
     flash.message = "person with id: "+p.id+" updated";
     redirect(action: 'list')    
  }

   @Transactional
   def delete(){
     def p = Person.get(params.id)
     if(p == null){
       transactionStatus.setRollbackOnly()
       notFound()
       return
     } 
     
     p.delete(flush:true)
     flash.message = "person with id: "+p.id+" deleted";
     redirect(action: 'list')    
  }
  def edit(){
   def person = Person.get(params.id)
   [person : person]
  }

  def doAjax(){
  }

  def simpAjax(){
    println "GGGGG"
    render "<h3>msg-Abracadabra<h3>"
  }




}
