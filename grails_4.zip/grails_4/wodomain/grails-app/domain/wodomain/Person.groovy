package wodomain



class Person {

  

   String personName
   String address
   Date dob
   float income

   def   scaffolding = true
   
   static mapping = {
      table "GR_PERSONS"
      version false
      id column: "PERSON_ID"
      id generator: "sequence", params:[sequence: "PERSONID_SEQ"]
   }    


   static constraints = {
     personName(nullable:false, maxSize:20)
     dob(nullable:false)
     income(min:10000F,scale:1) 
   }

   String toString(){
     id + ":" + personName + ":" + address+ ":" + dob + ":" + income
   }



}
