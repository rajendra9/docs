package wodomain



import grails.transaction.Transactional



@Transactional

class AuthenticatorService {

  
   def users = [:]
   
    AuthenticatorService(){
        users["madhavan"] = "maddi123"
        users["narayanan"] = "nari123"
        users["ketan"] = "ket123"  
    }
    
    def authenticate(un, pw) {
      if(users[un]){
        if(pw == users[un]){
          return  true
        }
       }
     return  false
    }

}
