package sprsec



class AdminController {

   
     
     def index() {
           render """<div style="text-align:center;font-size:18px;font-weight:bold;color:blue;">Welcome to Spring Security Core Pugin in Grails 3.1.0</div>"""
      }

}
