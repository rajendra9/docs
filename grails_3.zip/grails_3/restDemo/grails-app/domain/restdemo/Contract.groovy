package restdemo


import grails.rest.*

@Resource(uri="/contracts", readOnly=false, formats = ['json', 'xml'])

class Contract {

    String  contractName
    String  location
    int noWorkers
  
    
    static mapping = {
        table "GR_CONTRACTS"
        version  false
        id column: "CONTRACT_ID"
        id generator:"sequence",params:[sequence: "CONTRACTID_SEQ"] 
    }
    

     static constraints = {
        contractName(blank: false,maxSize: 35, minSize: 6)
        location(nullable: false)
        noWorkers(nullable: false, min:5) 
      }
   
     String toString(){
          id + ":" + contractName + ":" + location +":" + noWorkers 
      }


}
