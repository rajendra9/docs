drop table if exists react_persons;

create table react_persons(adhar_id varchar(14) primary key,
person_name  varchar(30),dob date,occupation varchar(30),income decimal(10,2));

insert into react_persons values('3243 2123 4532', 'Keshavan', '1994-09-12','State Govt Service', 36500.7);
insert into react_persons values('4356 5123 4875', 'Madhavan', '1994-04-30','Business',  42500.7);
insert into react_persons values('2123 6539 1709', 'Kalaiselvan','1995-11-06', 'Central Govt Service',  45600.7);
insert into react_persons values('2312 7687 3232', 'Muthu Kumar','1995-08-16', 'Gas Dealership',  125900.7);
insert into react_persons values('1324 6545 6565', 'Madivanan','1995-12-13', 'Central Govt Service',  43600.7);
insert into react_persons values('1812 7686 4487', 'Mrunalini', '1995-08-22','State Govt Service',  54760.7);
commit;

