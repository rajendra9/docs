package com.htc.jersey.utils;

import java.io.Serializable;

import javax.json.JsonArray;
import javax.json.JsonObject;

public interface ReactPersonDao extends Serializable {
  String PERSONS_SQL = "select adhar_id, person_name, dob, occupation, income from react_persons";  
  
  String PERSON_INSERT = "insert into react_persons(adhar_id, person_name, dob, occupation, income) values (?,?,?,?,?)";  
  
  String PERSON_UPDATE = "update react_persons set occupation=?, income=?  where adhar_id=?";
  
  String PERSON_DELETE = "delete from react_persons where adhar_id=?";
  
  
  public JsonArray getJsonPersons();
  
  public JsonObject savePerson(String id, String pName, String dobStr, String job, double income);

  public JsonObject updatePerson(String id, String newJob, double newIncome);

  public JsonObject removePerson(String id);

  
}
