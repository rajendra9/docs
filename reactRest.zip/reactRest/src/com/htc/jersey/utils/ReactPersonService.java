package com.htc.jersey.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

@SuppressWarnings("serial")
public class ReactPersonService implements ReactPersonDao {
   DataSource ds;
   
   public ReactPersonService() {
      try { 
	   Context ctx = new InitialContext();
	   ds = (DataSource)ctx.lookup("java:comp/env/jdbc/myPostgres");
	  }catch(NamingException ex) {
	   ex.printStackTrace();
      }
   }
    
    @Override
    public JsonArray getJsonPersons() {
       JsonArrayBuilder arrBuilder = Json.createArrayBuilder();
       JsonObjectBuilder objBuilder = null;
       JsonObject obj = null;
       Connection conn = null;
       try {
         conn = ds.getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(PERSONS_SQL);
         while(rs.next()) {
             objBuilder = Json.createObjectBuilder();
             objBuilder.add("adharId", rs.getString(1));
             objBuilder.add("personName", rs.getString(2));
             objBuilder.add("dob", rs.getDate(3).toString());             
             objBuilder.add("job", rs.getString(4));
             objBuilder.add("income", rs.getDouble(5));
             obj = objBuilder.build();
             arrBuilder.add(obj);
         }
       }catch(SQLException ex) {
           throw new RuntimeException(ex.getMessage());
       }
       finally {
           try {
             if(conn != null) {
                 conn.close();
             }
           }catch(Exception ex) {}
       }
       return arrBuilder.build();
    }

	@Override
	public JsonObject savePerson(String id, String pName, String dobStr, String job, double income) {
	   String msg = "problems in Inserting";		
	   JsonObject obj = null;
	   Connection conn = null;
       try {
         conn = ds.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(PERSON_INSERT);
         
         pstmt.setString(1, id);
         pstmt.setString(2, pName);
         java.sql.Date  dob = java.sql.Date.valueOf(dobStr);
         pstmt.setDate(3, dob);
         pstmt.setString(4,  job);
         pstmt.setDouble(5,  income);
         int rows = pstmt.executeUpdate();
         if(rows>0) {
        	msg  = "Person Successfully inserted";        	 
         }       
       }catch(SQLException ex) {
           throw new RuntimeException(ex.getMessage());
       }
       finally {
           try {
             if(conn != null) {
                 conn.close();
             }
           }catch(Exception ex) {}
       }
       JsonObjectBuilder objBuilder = Json.createObjectBuilder();
       objBuilder.add("msg", msg);             
       obj = objBuilder.build();
       return obj;
	}

	@Override
	public JsonObject updatePerson(String id, String newJob, double newIncome) {
	   String msg = "problems in Updating";		
	   JsonObject obj = null;
	   Connection conn = null;
	   try {
	     conn = ds.getConnection();
	     PreparedStatement pstmt = 
	     		 conn.prepareStatement(PERSON_UPDATE);
	        
	     pstmt.setString(1, newJob);
	     pstmt.setDouble(2, newIncome);
	     pstmt.setString(3, id);
	     int rows = pstmt.executeUpdate();
	     if(rows>0) {
	     	msg  = "Person Successfully Updated";        	 
	     }       
	    }catch(SQLException ex) {
	       throw new RuntimeException(ex.getMessage());
	    }
	    finally {
	      try {
	       if(conn != null) {
	          conn.close();
	       }
	      }catch(Exception ex) {}
	     }
	     JsonObjectBuilder objBuilder = Json.createObjectBuilder();
	     objBuilder.add("msg", msg);             
	     obj = objBuilder.build();
	     return obj;
	}

	@Override
	public JsonObject removePerson(String id) {
       String msg = "problems in Deleting";		
	   JsonObject obj = null;
	   Connection conn = null;
	   try {
	     conn = ds.getConnection();
	     PreparedStatement pstmt = 
	    		 conn.prepareStatement(PERSON_DELETE);
	     pstmt.setString(1, id);
	     int rows = pstmt.executeUpdate();
	     if(rows>0) {
	    	 msg  = "Person Deleted";        	 
	     }       
	    }catch(SQLException ex) {
	        throw new RuntimeException(ex.getMessage());
	    }
	    finally {
	      try {
	       if(conn != null) {
	          conn.close();
	       }
	      }catch(Exception ex) {}
	    }
	    JsonObjectBuilder objBuilder = Json.createObjectBuilder();
	    objBuilder.add("msg", msg);             
	    obj = objBuilder.build();
	    return obj;
	}
}
