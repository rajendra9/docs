package testing;

import wss2.SendAttachImplService;
import wss2.SendAttachImpl;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class SendAttachClient {
  
 public static void  main(String[]  args)
    throws Exception {
    
 
   SendAttachImplService service = 
                 new SendAttachImplService();
    
   
   SendAttachImpl attach = service.getSendAttachImplPort();
            
   byte[] fileBytes = attach.sendAttachments();
   byte[] picBytes = attach.sendPicture();

   try {
     BufferedOutputStream out = 
          new BufferedOutputStream(new FileOutputStream("attachs/condns.html"));
     out.write(fileBytes);
     out.flush();
     out = new BufferedOutputStream(new FileOutputStream("attachs/rose.gif"));
          out.write(picBytes);
     out.flush();
     out.close();
   }catch(IOException ioe) {
     ioe.printStackTrace();
    }
    System.out.println("attachments received");
 }   

}      