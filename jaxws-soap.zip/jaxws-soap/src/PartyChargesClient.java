package testing;

import wss.PartyChargesService;
import wss.PartyCharges;
import wss.GetDetailsResponse;
import wss.GetPartyArrangerResponse;
import wss.PartyArranger;
import java.net.URL;
import javax.xml.namespace.QName;
import java.util.concurrent.Future;
import javax.xml.ws.Response;
import javax.xml.ws.AsyncHandler;

public class PartyChargesClient {
  
 public static void  main(String[]  args)
    throws Exception {
    
   String pType = "birthday";
   double input = 2400000.0;     
 
   PartyChargesService service = 
                 new PartyChargesService();
    
   
    PartyCharges pCharge = service.getPartyChargesPort();
           
   Future  f = pCharge.getPartyArrangerAsync(pType, input,
    new AsyncHandler<GetPartyArrangerResponse>() {
     public void handleResponse(Response<GetPartyArrangerResponse> response) {
      try  {
       if(!response.isCancelled() && response.isDone()) {
        System.out.println("Async callback");
        GetPartyArrangerResponse resp = response.get();
        PartyArranger result = resp.getPartyOrganizer();
        System.out.println("Name:"+result.getArrangerName());
System.out.println("Participants:"+result.getParticipants());
System.out.println("Location:"+result.getLocation());
System.out.println("Per person Infra Cost:"   +result.getInfraCost());
System.out.println("Per Person Meals Cost:"+result.getFoodCost());


       }
      }catch(Exception ex) {
        ex.printStackTrace();
       }
      }
     });

   f = pCharge.getDetailsAsync(new AsyncHandler<GetDetailsResponse>(){
    public void handleResponse(Response<GetDetailsResponse> response){
      try {
       if(!response.isCancelled() && response.isDone()) {
        System.out.println("Async GetDetails callback");
        GetDetailsResponse resp = response.get();
        String result = resp.getDetails();
        System.out.println(result);
       }
      }catch(Exception ex){
        ex.printStackTrace();
       }
      }
     });
     
     Thread.sleep(3000);
  }

}      