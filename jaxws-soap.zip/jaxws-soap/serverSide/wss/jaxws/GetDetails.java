
package wss.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "getDetails", namespace = "http://wss/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getDetails", namespace = "http://wss/")
public class GetDetails {


}
