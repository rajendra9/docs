
import wss.WSDisplay;
import wss.WSDisplayService;

public class WSDisplayClient {
  
   public static void  main(String[]  args) {
     double   result = 0.0;
     double input = 865.6587;     
     try {
     
     WSDisplayService service = 
                    new WSDisplayService();
    
         if(service != null) {
            WSDisplay rounder = service.getWSDisplayPort();
            result = rounder.getRounded(input);
         }
         else{
              System.out.println("No Service");
          }
       }catch(Exception e) {
        e.printStackTrace();
      }
      System.out.println(input+" rounded value is:"+result);
  }

} 