package wss;

import javax.jws.WebService;
import javax.jws.WebMethod;

@WebService
public class WSDisplay {
   @WebMethod
   public  double getRounded(double val) {
     System.out.println("This Service is for Rounding Doubles");
     return Math.rint(val);
   }

} 
