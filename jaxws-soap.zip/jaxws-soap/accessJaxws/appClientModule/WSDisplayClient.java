
import wss.WSDisplayTwo;
import wss.WSDisplayTwoService;

public class WSDisplayClient {
  
   public static void  main(String[]  args) {
     double result = 0.0;
     double input = 13265.6587;     
     try {
     
     WSDisplayTwoService service = 
                    new WSDisplayTwoService();
    
         if(service != null) {
            WSDisplayTwo rounder = service.getWSDisplayTwoPort();
            result = rounder.rounding(input);
         }
         else{
              System.out.println("No Service");
          }
       }catch(Exception e) {
        e.printStackTrace();
      }
      System.out.println(input+" rounded value is:"+result);
  }

} 