
package wss;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the wss package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Rounding_QNAME = new QName("http://wss/", "rounding");
    private final static QName _RoundingResponse_QNAME = new QName("http://wss/", "roundingResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: wss
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Rounding }
     * 
     */
    public Rounding createRounding() {
        return new Rounding();
    }

    /**
     * Create an instance of {@link RoundingResponse }
     * 
     */
    public RoundingResponse createRoundingResponse() {
        return new RoundingResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Rounding }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wss/", name = "rounding")
    public JAXBElement<Rounding> createRounding(Rounding value) {
        return new JAXBElement<Rounding>(_Rounding_QNAME, Rounding.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RoundingResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://wss/", name = "roundingResponse")
    public JAXBElement<RoundingResponse> createRoundingResponse(RoundingResponse value) {
        return new JAXBElement<RoundingResponse>(_RoundingResponse_QNAME, RoundingResponse.class, null, value);
    }

}
