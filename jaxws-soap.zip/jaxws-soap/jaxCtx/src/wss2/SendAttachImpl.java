package wss2;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebParam;
import javax.xml.ws.soap.MTOM;
import javax.activation.DataHandler;
import java.io.File;

@MTOM
@WebService
public class SendAttachImpl {

   String name1 = "condns.html";
   String type1 = "text/html";
   
   String name2 = "rose.gif";  
   String type2 = "image/gif"; 

   @WebMethod
   public @WebResult(name="myHandler") DataHandler sendAttachments() {
     MyFileDataSource dataSource = 
              new MyFileDataSource(name1,type1);
     DataHandler handler = 
             new DataHandler(dataSource); 
     return handler;
   }
   
   @WebMethod
   public @WebResult(name="myHandler2") DataHandler sendPicture() {
     MyFileDataSource dataSource = 
              new MyFileDataSource(name2,type2);
     DataHandler handler = 
             new DataHandler(dataSource); 
     return handler;
   }
}