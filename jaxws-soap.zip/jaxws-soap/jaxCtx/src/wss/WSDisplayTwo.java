package wss;

import javax.jws.WebService;

import java.math.BigDecimal;
import java.math.MathContext;

import javax.jws.WebMethod;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Use;
import javax.jws.soap.SOAPBinding.Style;
import javax.jws.soap.SOAPBinding.ParameterStyle;

@WebService
@SOAPBinding(style=SOAPBinding.Style.DOCUMENT,
             use=SOAPBinding.Use.LITERAL,
             parameterStyle=SOAPBinding.ParameterStyle.WRAPPED)
public class WSDisplayTwo {

 @WebMethod(operationName="rounding")
 public  double getRounded(double val) {
  System.out.println("Rounding App web Service");
  BigDecimal bigDeci = BigDecimal.valueOf(val);
  return bigDeci.round(MathContext.DECIMAL32).doubleValue();
 }

}