package wss;

public enum PartyTypes {
    BIRTHDAY, MARRIAGE, ENGAGEMENT, PROMOTION;
}
