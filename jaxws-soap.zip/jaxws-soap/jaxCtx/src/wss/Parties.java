package wss;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Set;
import java.util.TreeMap;

public class Parties implements Serializable {
   
	EnumMap<PartyTypes, List<PartyArranger>> arrangers = 
			new  EnumMap<>(PartyTypes.class);
	PartyTypes[] existing = PartyTypes.values(); 
	String[] arrangerNames = {"M/s Sunny Decors", 
			              "M/s Star Glorifiers",
			              "M/s VineeT Behl Performers",
			              "M/s Easyway Celebrators"
	                     };
	
	{	   	
	   for(int i=0;i<existing.length;i++) {
		   List<PartyArranger> arrangerList = new ArrayList<>();
		   arrangers.put(existing[i], arrangerList);
	   }
	   initialize();
	}
	private void initialize() {
		
	  List<PartyArranger> curTypeList = arrangers.get(existing[0]);
	  curTypeList.add(new PartyArranger(arrangerNames[0], 300, 
			                    "Country Club, Begumpet", 50.0, 160.0));
	  
	  curTypeList.add(new PartyArranger(arrangerNames[1], 300, 
			                     "Nizam Club, Opp to Ravindra Bharathi", 65.0, 180.0));
	  
	  curTypeList.add(new PartyArranger(arrangerNames[2], 300, 
			     "Secunderabad Club, Secunderabad", 45.0, 175.0));
	  
	  curTypeList.add(new PartyArranger(arrangerNames[3], 300,
			              "Annapurna Hall, ASRaonagar", 53.0, 170.0));
	  
	  
	  curTypeList = arrangers.get(existing[1]);
	  curTypeList.add(new PartyArranger(arrangerNames[0], 600,
			                          "Country Club,Begumpet", 75.0, 240.0));
	  
	  curTypeList.add(new PartyArranger(arrangerNames[1], 600, 
			                 "Nizam Club, Opp to Ravindra Bharathi", 65.0, 230.0));
	  
	  curTypeList.add(new PartyArranger(arrangerNames[2], 600, 
			              "Secunderabad Club, Secunderabad", 62.0, 235.0));
	  
	  curTypeList.add(new PartyArranger(arrangerNames[3], 600,
                                "Annapurna Hall, ASRao Nagar", 55.0, 215.0));
	  
	  curTypeList = arrangers.get(existing[2]);
	  curTypeList.add(new PartyArranger(arrangerNames[0], 350, 
			                           "Country Club,Begumpet", 35.0, 130.0));
	  
	  curTypeList.add(new PartyArranger(arrangerNames[1], 350,
			                          "Nizam Club,Opp to Ravindra Bharathi", 40.0, 155.0));
	  
	  curTypeList.add(new PartyArranger(arrangerNames[2], 350, 
			                   "Secunderabad Club, Secunderabad", 35.0, 134.0));
	  
	  curTypeList.add(new PartyArranger(arrangerNames[3], 350, 
			                           "Annapurna Hall, ASRao Nagar", 30.0, 123.0));
	  
	  
	  curTypeList = arrangers.get(existing[3]);
	  curTypeList.add(new PartyArranger(arrangerNames[0], 250, 
			                            "Country Club, Begumpet", 35.0, 110.0));
	  
	  curTypeList.add(new PartyArranger(arrangerNames[1], 350, 
			                            "Nizam Club,Opp to Ravindra Bharathi", 40.0, 115.0));
	  
	  curTypeList.add(new PartyArranger(arrangerNames[2], 250,
			                       "Secunderabad Club,Secunderabad", 35.0, 120.0));
	  
	  curTypeList.add(new PartyArranger(arrangerNames[3], 250, 
			                    "Annapurna Hall, ASRao Nagar", 30.0, 110.0));  
	  
	}
	
	public NavigableMap<Double,PartyArranger>  sortableArrangerMap(PartyTypes partyType){
		NavigableMap<Double, PartyArranger> ret = new TreeMap<>();
		List<PartyArranger>   arrangerList = arrangers.get(partyType);
		
		for(PartyArranger arranger : arrangerList) {
			double key = arranger.getParticipants() * arranger.getInfraCost() * arranger.getFoodCost();
		    ret.put(key,  arranger);		    
		}
		return  ret;
	}
	
	public String showAll() {
		StringBuffer sb = new StringBuffer();
		Set<Map.Entry<PartyTypes,List<PartyArranger>>> entries = arrangers.entrySet();
		for(Map.Entry<PartyTypes,List<PartyArranger>> entry : entries) {
			sb.append("\nfor ");
			sb.append(entry.getKey());
			sb.append("-->\n" );
			for(PartyArranger arranger: entry.getValue()) {
				sb.append(arranger);
				sb.append(" , ");	
			}			
		}
		return sb.toString();
	}
	
}
