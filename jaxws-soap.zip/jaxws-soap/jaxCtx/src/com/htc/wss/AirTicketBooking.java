package com.htc.wss;

import javax.jws.WebMethod;
import javax.jws.WebService;

import com.htc.wss.domain.AirTicket;

@WebService
public class AirTicketBooking {

   @WebMethod
   public AirTicket bookTicket(String person,
                               String dot,
                               String from,
                               String to,
                               String travelClass,
                               double paidCharges){
       AirTicket ret = new AirTicket();
       AirTicket ticket = new AirTicket();
       AirTicketDAO dao = new AirTicketDAOImpl();
       ticket.setPerson(person);
       ticket.setSource(from);
       ticket.setTarget(to);
       ticket.setTravelDate(dot);
       ticket.setTicketClass(travelClass);
       ticket.setCharges(paidCharges);
       boolean boo = dao.saveAirTicket(ticket);
       if(boo){
           ret = ticket;
       }
       return ret;
   }
    
}
