package com.htc.micro.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GenerationType;
import javax.persistence.GeneratedValue;

@Entity
@Table(name="articles")
@SuppressWarnings("serial")
public class ArticleDto implements Serializable {
   
	private int articleId;
    private String title;
    private String category;
    
	public ArticleDto() {
		super();	
	}

	public ArticleDto(String title, String category) {
		super();
		this.title = title;
		this.category = category;
	}

	@Id
	@Column(name="article_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getArticleId() {
		return articleId;
	}

	public void setArticleId(int articleId) {
		this.articleId = articleId;
	}
    
	@Column
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Column
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + articleId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ArticleDto other = (ArticleDto) obj;
		if (articleId != other.articleId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ArticleDto [articleId=" + articleId + ", title=" + title + ", category=" + category + "]";
	}   
	
}
