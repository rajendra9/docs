import React from 'react';



const Home = () => {
   return(
       <div className='container'>
         <h4 className='center'>
             This is Home Page
         </h4>
         <p> This is Home Page for demonstrating  routes</p>     
       </div>
   )
}

export  default Home;