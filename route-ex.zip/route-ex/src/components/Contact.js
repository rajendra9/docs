import React from 'react';

const Contact = () => {
   return(
       <div className='container'>
         <h4 className='center'>
             This is Contacts Page
         </h4>
         <p> This is Contacts Page for demonstrating  routes</p>     
       </div>
   )
}

export  default Contact;