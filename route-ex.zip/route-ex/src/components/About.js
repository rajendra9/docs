import React from 'react';



const About = () => {
   return(
       <div className='container'>
         <h4 className='center'>
             This is About Page
         </h4>
         <p> This is About Page for demonstrating  routes</p>     
       </div>
   )
}

export  default About;