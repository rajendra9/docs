
package wss.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "getPartyArrangerResponse", namespace = "http://wss/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getPartyArrangerResponse", namespace = "http://wss/")
public class GetPartyArrangerResponse {

    @XmlElement(name = "partyOrganizer", namespace = "")
    private wss.PartyArranger partyOrganizer;

    /**
     * 
     * @return
     *     returns PartyArranger
     */
    public wss.PartyArranger getPartyOrganizer() {
        return this.partyOrganizer;
    }

    /**
     * 
     * @param partyOrganizer
     *     the value for the partyOrganizer property
     */
    public void setPartyOrganizer(wss.PartyArranger partyOrganizer) {
        this.partyOrganizer = partyOrganizer;
    }

}
