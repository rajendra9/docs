
package wss.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "getPartyArranger", namespace = "http://wss/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getPartyArranger", namespace = "http://wss/", propOrder = {
    "partyType",
    "payableAmount"
})
public class GetPartyArranger {

    @XmlElement(name = "partyType", namespace = "")
    private String partyType;
    @XmlElement(name = "payableAmount", namespace = "")
    private double payableAmount;

    /**
     * 
     * @return
     *     returns String
     */
    public String getPartyType() {
        return this.partyType;
    }

    /**
     * 
     * @param partyType
     *     the value for the partyType property
     */
    public void setPartyType(String partyType) {
        this.partyType = partyType;
    }

    /**
     * 
     * @return
     *     returns double
     */
    public double getPayableAmount() {
        return this.payableAmount;
    }

    /**
     * 
     * @param payableAmount
     *     the value for the payableAmount property
     */
    public void setPayableAmount(double payableAmount) {
        this.payableAmount = payableAmount;
    }

}
