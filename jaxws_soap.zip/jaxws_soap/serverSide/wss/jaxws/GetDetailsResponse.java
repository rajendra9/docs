
package wss.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "getDetailsResponse", namespace = "http://wss/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getDetailsResponse", namespace = "http://wss/")
public class GetDetailsResponse {

    @XmlElement(name = "details", namespace = "")
    private String details;

    /**
     * 
     * @return
     *     returns String
     */
    public String getDetails() {
        return this.details;
    }

    /**
     * 
     * @param details
     *     the value for the details property
     */
    public void setDetails(String details) {
        this.details = details;
    }

}
