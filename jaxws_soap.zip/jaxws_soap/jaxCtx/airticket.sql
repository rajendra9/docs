drop table if exists airtickets;

drop sequence if exists ticketid_seq;

create sequence ticketid_seq start with 100;

create table airtickets(ticket_id varchar(10) constraint airtickets_PK primary key,
person varchar(18),
travel_date  varchar(20),
from_place varchar(20),
to_place  varchar(20),
travel_class varchar(1)constraint airtickets_chk check (travel_class in ('E','B')),
charges decimal(10,2));



select * from  airtickets ;
