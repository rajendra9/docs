package com.htc.wss;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import com.htc.wss.domain.AirTicket;
import javax.persistence.Persistence;


public class AirTicketDAOImpl implements AirTicketDAO {
   EntityManager em;
   EntityTransaction trans;
    
   {
     EntityManagerFactory factory = 
                Persistence.createEntityManagerFactory("myDB");
     em = factory.createEntityManager();
   }
    
   private String getUniqueId(String targetPlace) {
     String ret = "";
     try {
       String sql = "select nextval('ticketid_seq')";
       Query qry = em.createNativeQuery(sql);
       Number num = (Number)qry.getSingleResult();
       int seqNum = num.intValue() + 1;
       char ch = targetPlace.charAt(0);
       ret = ret+ch+"-"+seqNum;
     }catch(Exception ex){
        ex.printStackTrace();
     }
     return ret; 
   }
   
   public boolean saveAirTicket(AirTicket airTicket) {
     boolean ret = false;
     try {
      trans = em.getTransaction();
      trans.begin();
      if(airTicket != null){
        String travelPlace = airTicket.getTarget();
        String ticketId = this.getUniqueId(travelPlace);
        airTicket.setTicketId(ticketId);
        em.persist(airTicket);
        ret = true;
        trans.commit();
      }
     }catch(Exception ex){
        trans.rollback();
        ex.printStackTrace();
     }
        return ret;
    }

}
