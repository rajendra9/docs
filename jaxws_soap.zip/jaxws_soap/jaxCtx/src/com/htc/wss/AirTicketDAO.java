package com.htc.wss;

import java.io.Serializable;

import com.htc.wss.domain.AirTicket;

public interface AirTicketDAO extends Serializable {
  public boolean saveAirTicket(AirTicket airTicket);
}
