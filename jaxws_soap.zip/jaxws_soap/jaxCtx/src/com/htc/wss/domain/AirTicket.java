package com.htc.wss.domain;

import java.io.Serializable;
import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

import java.time.LocalDate;

@Entity
@Table(name="AIRTICKETS")
public class AirTicket implements Serializable {
    private  String      ticketId;
    private  String      person;
    private  String      travelDate;
    private  String      source;
    private  String      target;
    private  String      ticketClass;
    private  double      charges;
    
    public AirTicket() {
        super();    
    }

    public AirTicket(String ticketId,
                     String person,
                     String travelDate,
                     String source,
                     String target,
                     String ticketClass,
                     double charges) {
        super();
        this.ticketId = ticketId;
        this.person = person;
        this.travelDate = travelDate;
        this.source = source;
        this.target = target;
        this.ticketClass = ticketClass;
        this.charges = charges;
    }
    
    @Id
    @Column(name="TICKET_ID")
    public String getTicketId() {
        return ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }

    @Column
    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }
    
    @Column(name="TRAVEL_DATE")
    public String getTravelDate() {
        return travelDate;
    }

    public void setTravelDate(String travelDate) {
        this.travelDate = travelDate;
    }

    @Column(name="FROM_PLACE")
    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    @Column(name="TO_PLACE")
    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }
    
    @Column(name="TRAVEL_CLASS")
    public String getTicketClass() {
        return ticketClass;
    }

    public void setTicketClass(String ticketClass) {
        this.ticketClass = ticketClass;
    }

    @Column
    public double getCharges() {
        return charges;
    }

    public void setCharges(double charges) {
        this.charges = charges;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((ticketId == null) ? 0 : ticketId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AirTicket other = (AirTicket) obj;
        if (ticketId == null) {
            if (other.ticketId != null)
                return false;
        } else if (!ticketId.equals(other.ticketId))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "AirTicket [ticketId=" + ticketId + ", person=" + person
                + ", travelDate=" + travelDate + ", source=" + source
                + ", target=" + target + ", ticketClass=" + ticketClass
                + ", charges=" + charges + "]";
    }    
    
}
