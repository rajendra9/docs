package wss;

import java.io.Serializable;
import java.util.Map;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService(name="PartyCharges") 
public class PartyCharges implements Serializable {
 
  Parties parties = new Parties();	
  
  @WebMethod
  public @WebResult(name="details") String getDetails() {
     return parties.showAll();
  }

  @WebMethod
  public @WebResult(name="partyOrganizer") PartyArranger
            getPartyArranger(@WebParam(name="partType") String partyType,
            		 @WebParam(name="payableAmount") double nearest) {
   PartyTypes partyTypes = PartyTypes.valueOf(partyType.toUpperCase());   
   NavigableMap<Double,PartyArranger> sortMap =
		  parties.sortableArrangerMap(partyTypes);
   Map.Entry<Double,PartyArranger> nearerEntry = sortMap.floorEntry(nearest);
   return nearerEntry.getValue();  
 }
}