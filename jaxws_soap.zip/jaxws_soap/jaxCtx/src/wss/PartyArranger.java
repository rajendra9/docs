package wss;

import java.io.Serializable;

public class PartyArranger implements Serializable  {   

   private   String   arrangerName;
   private   int      participants;
   private   String   location;
   private   double   infraCost; 
   private   double   foodCost;
    
  
   public PartyArranger() {
       super();        
   }

   public String getLocation() {
      return location;
   }

   public PartyArranger(String arrangerName, int participants, String location, double infraCost, double foodCost) {
	super();
	this.arrangerName = arrangerName;
	this.participants = participants;
	this.location = location;
	this.infraCost = infraCost;
	this.foodCost = foodCost;
}
public void setLocation(String location) {
       this.location = location;
   }

   public int getParticipants() {
      return participants;
   }

   public void setParticipants(int participants) {
      this.participants = participants;
   }

   public String getArrangerName() {
     	return arrangerName;
   }

   public void setArrangerName(String arrangerName) {
	   this.arrangerName = arrangerName;
   }

   public double getInfraCost() {
    	return infraCost;
   }

   public void setInfraCost(double infraCost) {
	   this.infraCost = infraCost;
   }

   public double getFoodCost() {
	    return foodCost;
   }

   public void setFoodCost(double foodCost) {
	   this.foodCost = foodCost;
   }

   @Override
   public int hashCode() {
	  final int prime = 31;
	  int result = 1;
	  result = prime * result + ((arrangerName == null) ? 0 : arrangerName.hashCode());
	  return result;
   }

   @Override
   public boolean equals(Object obj) {
	  if (this == obj)
		 return true;
	  if (obj == null)
		 return false;
	  if (getClass() != obj.getClass())
		  return false;
	  PartyArranger other = (PartyArranger) obj;
	  if (arrangerName == null) {
		  if (other.arrangerName != null)
			  return false;
	  } else if (!arrangerName.equals(other.arrangerName))
		  return false;
	  return true;
    }

    @Override
    public String toString() {
	     return "PartyArranger [arrangerName=" + arrangerName + ", participants=" + participants + ", location=" + location
			+ ", infraCost=" + infraCost + ", foodCost=" + foodCost + "]";
    }

   
     
}