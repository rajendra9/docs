package wss2;

import javax.activation.DataSource;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

public class MyFileDataSource implements DataSource {
  String name;
  String mimeType;

  public MyFileDataSource(){}
  

  public MyFileDataSource(String n,String type)  {
   name = n;
   mimeType = type;
  }
  
  public String getContentType() {
   return mimeType;
  }

  public InputStream getInputStream() throws IOException {
   InputStream ret = null;
   ClassLoader cLoader = this.getClass().getClassLoader();

   InputStream inputStream = cLoader.getResourceAsStream(name);

   ByteArrayOutputStream out = new ByteArrayOutputStream();
   int c = 0;
   while((c=inputStream.read()) != -1) {
    out.write(c);
   }
   byte[] bts = out.toByteArray();
   
   ret = new ByteArrayInputStream(bts);
   out.close();
   return ret;
  }

   public String getName() {
     return name;
   }
 
   public OutputStream getOutputStream() throws IOException  {
     return null;
   }
} 