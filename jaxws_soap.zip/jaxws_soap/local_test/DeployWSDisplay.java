import javax.xml.ws.Endpoint;

public class DeployWSDisplay {
   public  static void main(String[] args) {
    System.out.println("Starting WSDisplay Server");
    Endpoint.publish("http://localhost:8080/myws/wsdisplay",
                    new wss.WSDisplay());
   }

} 
