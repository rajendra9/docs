@javax.xml.bind.annotation.XmlSchema(namespace = "http://wss/")
package wss;
