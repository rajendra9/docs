package com.htc.jaxws.client;

import java.net.MalformedURLException;
import java.net.URL;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.jaxws.JaxWsPortProxyFactoryBean;

@Configuration
@ComponentScan
public class TestJaxwsServices {

	@Bean
	public JaxWsPortProxyFactoryBean getProxyFactory() {
		JaxWsPortProxyFactoryBean proxyBean = new JaxWsPortProxyFactoryBean();
		proxyBean.setServiceInterface(wss.WSDisplayTwo.class);
		try {
		proxyBean.setWsdlDocumentUrl(new URL("http://localhost:9091/htcws/services/wsdisplaytwo?WSDL"));
		}catch(MalformedURLException ex){
			ex.printStackTrace();
		}
		proxyBean.setNamespaceUri("http://wss/");
		proxyBean.setServiceName("rounding");
		proxyBean.setPortName("WSDisplayTwoPort");
		return proxyBean;
	}
	
}
