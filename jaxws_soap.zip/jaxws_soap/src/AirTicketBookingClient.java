package testing;

import com.htc.wss.AirTicketBookingService;
import com.htc.wss.AirTicketBooking;

import com.htc.wss.AirTicket;
import java.time.LocalDate; 
import java.time.format.DateTimeFormatter;

public class AirTicketBookingClient {
  
 public static void  main(String[]  args)
    throws Exception {
    
   double input = 3825.0;     
 
    AirTicketBookingService service = 
                 new AirTicketBookingService();
    
   
    AirTicketBooking booking = service.getAirTicketBookingPort();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");       
    LocalDate locDate = LocalDate.now();
    String travelDate = formatter.format(locDate);
    AirTicket airTicket = 
           booking.bookTicket("Samuel", travelDate, "Hyderabad", "Chennai", "E", 3400.5);
    StringBuffer sb = new StringBuffer();
    sb.append("Person-");
    sb.append(airTicket.getPerson());

    sb.append("TicketId-");
    sb.append(airTicket.getTicketId());

    sb.append("TravelDate-");
    sb.append(airTicket.getTravelDate());

    sb.append("Travelling From-");
    sb.append(airTicket.getSource());

    sb.append("Travelling To-");
    sb.append(airTicket.getTarget());
 
    sb.append("Travelling class-");
    sb.append(airTicket.getTicketClass());

    sb.append("Travelling Charges-");
    sb.append(airTicket.getCharges());
    System.out.println(sb.toString());






  }

}      