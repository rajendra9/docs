package wsclients;

import java.net.URL;

import javax.xml.namespace.QName;

import wss.WSDisplayTwo;
import wss.WSDisplayTwoService;

public class WSDisplayTwoBean {

public double invokeWSService(double input) {
 double result = 0.0;
 try {
   String urlStr = "http://localhost:9091/htcws/services/wsdisplaytwo?WSDL";
   String namespace = "http://wss/";

   URL url = new URL(urlStr);
   QName qn = new QName(namespace,"WSDisplayTwoService");

   WSDisplayTwoService service =
          new WSDisplayTwoService(url,qn);

   if(service != null) {
     WSDisplayTwo rounder = service.getWSDisplayTwoPort();
     result = rounder.rounding(input);
   }
   else {
    System.out.println("No Service");
   }
  }
  catch(Exception e){
   e.printStackTrace();
  }
  System.out.println(input+" rounded value is:"+result);
  return result;
 }

}