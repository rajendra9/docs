package logging;

import java.util.Collections;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.Arrays;

public class SortLogLevels {
    String[] levelStrings =
        {"CONFIG", "FINE", "INFO", "ALL",
         "FINER", "SEVERE", "FINEST", "WARNING" };
    int[] levelConstants = {Level.CONFIG.intValue(),
                           Level.FINE.intValue(),
                           Level.INFO.intValue(),
                           Level.ALL.intValue(),
                           Level.FINER.intValue(),
                           Level.SEVERE.intValue(),
                           Level.FINEST.intValue(),
                           Level.WARNING.intValue()                           
                          };
    public String getLevel(int levelInt){
      String ret = "";
      for(int i=0;i<levelConstants.length;i++){
       if(levelConstants[i] == levelInt){
         ret = levelStrings[i];
         break;
       }
      }
     return ret;
    }
    
    public void printSortLevels(){
     Integer[] levelIntegers = new Integer[levelConstants.length];
      for(int i=0;i<levelIntegers.length;i++){
          levelIntegers[i] = new Integer(levelConstants[i]); 
      }
      Comparator<Integer> rev = Collections.reverseOrder();
      Arrays.sort(levelIntegers, rev);
      for(Integer lev : levelIntegers){
        System.out.println(this.getLevel(lev.intValue()));  
      }
    }
    
    public static void main(String[] args) {
        SortLogLevels sLevels = new SortLogLevels();
        sLevels.printSortLevels();
    }

}
