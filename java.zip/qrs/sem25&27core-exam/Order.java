
package com.htc.javaee.exams;

import java.util.Date;
public class Order
{
      private int     prodId;
      private int     customerId;
      private int     orderId;
      private Date    orderDate;
      private double  discount;
      private int     qty;
      private double  totAmount;
      
      public Order()
      {
      }

      public Order(int orderId, Date orderDate, 
                   int prodId, int customerId,
                   int qty, double discount,
                   double totAmount)
      {
            super();
            this.orderId = orderId;
            this.orderDate = orderDate;
            this.prodId = prodId;
            this.customerId = customerId;
            this.qty = qty;
            this.discount = discount;
            this.totAmount = totAmount;
      }

      public int getProdId()
      {
            return this.prodId;
      }

      public void setProdId(int prodId)
      {
            this.prodId = prodId;
      }

      public int getCustomerId()
      {
            return this.customerId;
      }

      public void setCustomerId(int customerId)
      {
            this.customerId = customerId;
      }

      public int getOrderId()
      {
            return this.orderId;
      }

      public void setOrderId(int orderId)
      {
            this.orderId = orderId;
      }

      public Date getOrderDate()
      {
            return this.orderDate;
      }

      public void setOrderDate(Date orderDate)
      {
            this.orderDate = orderDate;
      }

      public double getDiscount()
      {
            return this.discount;
      }

      public void setDiscount(double discount)
      {
            this.discount = discount;
      }

      public int getQty()
      {
            return this.qty;
      }

      public void setQty(int qty)
      {
            this.qty = qty;
      }

      public double getTotAmount()
      {
            return this.totAmount;
      }

      public void setTotAmount(double totAmount)
      {
            this.totAmount = totAmount;
      }

      public int hashCode()
      {
            final int prime = 31;
            int result = 1;
            result = prime * result + this.orderId;
            return result;
      }

      public boolean equals(Object obj)
      {
            if (this == obj)
                  return true;
            if (obj == null)
                  return false;
            if (getClass() != obj.getClass())
                  return false;
            final Order other = (Order) obj;
            if (this.orderId != other.orderId)
                  return false;
            return true;
      }

      public String toString()
      {
       return "OrderId"+this.orderId+
              " OrderDate:"+this.orderDate+
              " productId:"+this.prodId+
              " customerId:"+this.customerId+
              " Qty:"+this.qty+
              " Discount:"+this.discount+
              " TotalAmount:"+this.totAmount;
      }
      
      

}

