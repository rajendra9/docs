
package com.htc.javaee.exams;


public class Customer
{
      public String toString()
      {
       return "Id:"+this.customerId+" Name:"+this.customerName+
              " customer Type:"+this.customerType;
      }

      private int    customerId;
      private String customerName;
      private String customerType;

      public Customer()
      {
      }

      public Customer(int customerId, String customerName, String customerType)
      {
            super();
            this.customerId = customerId;
            this.customerName = customerName;
            this.customerType = customerType;
      }

      public int getCustomerId()
      {
            return this.customerId;
      }

      public void setCustomerId(int customerId)
      {
            this.customerId = customerId;
      }

      public String getCustomerName()
      {
            return this.customerName;
      }

      public void setCustomerName(String customerName)
      {
            this.customerName = customerName;
      }

      public String getCustomerType()
      {
            return this.customerType;
      }

      public void setCustomerType(String customerType)
      {
            this.customerType = customerType;
      }

      public int hashCode()
      {
            final int prime = 31;
            int result = 1;
            result = prime * result + this.customerId;
            return result;
      }

      public boolean equals(Object obj)
      {
            if (this == obj)
                  return true;
            if (obj == null)
                  return false;
            if (getClass() != obj.getClass())
                  return false;
            final Customer other = (Customer) obj;
            if (this.customerId != other.customerId)
                  return false;
            return true;
      }

}

