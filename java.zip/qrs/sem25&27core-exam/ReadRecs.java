
package com.htc.javaee.exams;
import java.io.DataOutputStream;
import java.io.File;
import java.io.RandomAccessFile;
import java.io.IOException;
import java.io.FileOutputStream;

public class ReadRecs
{
  int     slno;
  int     orderNo;
  int     orderDate;
  int     custId;
  int     prodId;
  int     qty;
  double  amt;

  RandomAccessFile raf;
  
   public static final int RECORD_SIZE = 32;
   public static final String FNAME = "orders.dat";
   
   public void ReadRecord(int customerId)
    throws IOException
    {
     File f = new File(FNAME);
     long len = f.length();
     int noRecs = (int)(len/RECORD_SIZE);
     
     System.out.println("There are "+noRecs+" in this file");
     
     raf = new RandomAccessFile(FNAME,"r");
     raf.seek(0);
     DataOutputStream errOut =
           new DataOutputStream(new FileOutputStream("recErr.dat"));
     DataOutputStream custOut =
           new DataOutputStream(new FileOutputStream("customer"+customerId+".dat"));
     
    
     for(int i=0;i<noRecs;i++)
     {      
      slno = raf.readInt();
      orderNo = raf.readInt();
      orderDate = raf.readInt();
      custId = raf.readInt();
      prodId = raf.readInt();
      qty = raf.readInt();
      amt = raf.readDouble();
      if(  (slno==0)
         ||(orderNo==0)
         ||(orderDate==0)
         ||(custId==0)
         ||(prodId==0)
         ||(qty==0)
         ||(amt==0))
      {
         errOut.writeInt(slno);
         errOut.writeInt(orderNo);
         errOut.writeInt(orderDate);
         errOut.writeInt(custId);
         errOut.writeInt(prodId);
         errOut.writeInt(qty);
         errOut.writeDouble(amt);        
      }
      else if (custId==customerId)
      {
            custOut.writeInt(slno);
            custOut.writeInt(orderNo);
            custOut.writeInt(orderDate);
            custOut.writeInt(custId);
            custOut.writeInt(prodId);
            custOut.writeInt(qty);
            custOut.writeDouble(amt);    
      }
      else
      {
        System.out.print("Sl-No:"+slno);
        System.out.print(" Order-No:"+orderNo);
        System.out.print(" Order-Date:"+orderDate);
        System.out.print(" Customer-Id:"+custId);
        System.out.print(" Product-Id:"+prodId);
        System.out.print(" Qty:"+qty);
        System.out.println(" Amount:"+amt);
      }
     }
     
      raf.close();
   }
   
   public static void main(String[] args)
    throws IOException
  {
    ReadRecs recs = new ReadRecs();
    recs.ReadRecord(1100);
  }  
    
    
    
 }



