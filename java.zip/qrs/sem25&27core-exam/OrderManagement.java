
package com.htc.javaee.exams;

import java.util.Date;
import java.util.Scanner;
import java.util.ArrayList;
import java.text.SimpleDateFormat;


public class OrderManagement
{
      ArrayList<Product> products;
      ArrayList<Customer> customers;
      ArrayList<Discount> discounts;
      
      public OrderManagement()
      {
       products = new ArrayList<Product>();
       customers = new ArrayList<Customer>();
       discounts = new ArrayList<Discount>();
       try
       {
        populateLists();
       }
       catch(Exception e)
       {
         e.printStackTrace();    
       }
      
       
      }
      private void populateLists()throws Exception
      {
        customers.add(new Customer(1000,"ABC","oneTime"));
        customers.add(new Customer(1100,"DEF","regular"));
        customers.add(new Customer(1200,"GHI","regular"));
        
        products.add(new Product(100,"Lux",21.5,1000));
        products.add(new Product(200,"Cinthol",23.5,1100));
        products.add(new Product(300,"Dove",32.5,1200));
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        discounts.add(new Discount(10,sdf.parse("12-09-2007"),
                    sdf.parse("9-12-2007"),1000,10.0));
        discounts.add(new Discount(20,sdf.parse("11-08-2007"),
                    sdf.parse("22-11-2007"),1100,15.0));
        discounts.add(new Discount(30,sdf.parse("12-08-2007"),
                    sdf.parse("12-12-2007"),1200,15.0));

        
      }
      public double getDiscountCost(int custId,int prodId)
      {
        System.out.println(custId+"::"+prodId);     
        double ret = 0.0;
        String cuType = "";    
        double cost = 0.0;
        for(Customer cu : customers)
        {
              if(cu.getCustomerId()==custId)
              {
                    cuType = cu.getCustomerType();
                    break;
              }
        }
        System.out.println("Cust-Type:"+cuType);
        for(Product pr : products)   
        {            
         if(pr.getProdId()==prodId)
         {
               cost = pr.getCost();
               break;
         }         
        }
        System.out.println("prod cost:"+cost);
        if(cuType.equalsIgnoreCase("onetime"))
        {      
          ret = cost*0.10;
        }
        else if(cuType.equalsIgnoreCase("regular"))
        {
          ret = cost*0.15;      
        }
        return (cost-ret);
      }
      public void printOrderCost(int prodId,
                                 int customerId,
                                 int qty)
      {
         double dis = getDiscountCost(customerId,prodId);
         System.out.println("Total Ordered cost"+(qty*dis));   
      }
      
      public static void main(String[] args)
      throws Exception
      {
       Scanner scan = new Scanner(System.in);
       System.out.println("Enter customer Id:");
       int custId = Integer.parseInt(scan.nextLine());
       
       System.out.println("Enter product Id:");
       int prodId = Integer.parseInt(scan.nextLine());
       
       System.out.println("Enter Quantity:");
       int qty = Integer.parseInt(scan.nextLine());
       
       OrderManagement om = new OrderManagement(); 
       om.printOrderCost(prodId,custId,qty);
      }

}

