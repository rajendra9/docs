
package com.htc.javaee.exams;
import java.io.File;
import java.io.RandomAccessFile;
import java.io.IOException;

public class CreateRecs
{ 

  RandomAccessFile raf;
  
   public static final int RECORD_SIZE = 32;
   public static final String FNAME = "orders.dat";
   
   public void writeRecord(int sno,int ordNo,
                           int ordDt,int custId,
                           int prdId,int qty,
                           double amt)
    throws IOException{
     File f = new File(FNAME);
     long len = f.length();
     
     raf = new RandomAccessFile(FNAME,"rw");
     raf.seek(len);
     raf.writeInt(sno);
     raf.writeInt(ordNo);
     raf.writeInt(ordDt);
     raf.writeInt(custId);
     raf.writeInt(prdId);
     raf.writeInt(qty);
     raf.writeDouble(amt);
     raf.close();
   }
   public void writeRecords(int[] sno,int[] ordNo,
               int[] ordDt,int[] custId,
               int[] prdId,int[] qty,
               double[] amt)
    throws IOException
  {
         
    File f = new File(FNAME);
    long len = f.length();

    raf = new RandomAccessFile(FNAME,"rw");
    raf.seek(len);
    for(int i=0;i<sno.length;i++)
    {      
      raf.writeInt(sno[i]);
      raf.writeInt(ordNo[i]);
      raf.writeInt(ordDt[i]);
      raf.writeInt(custId[i]);
      raf.writeInt(prdId[i]);
      raf.writeInt(qty[i]);
      raf.writeDouble(amt[i]);
    }  
      raf.close();
}
  public static void main(String[] args)
  throws IOException
  {
    CreateRecs recs = new CreateRecs();
    int[] slnos = {1,2,3,4,5};
    int[] ordNos = {10001,10002,10003,10004,10005};
    int[] ordDts = {10,12,14,16,0};
    int[] custIds = {1000,1100,1200,1300,1400};
    int[] prdNos = {100,200,300,400,500};
    int[] qtys = {15,35,40,23,20};
    double[] amts = {320.50,720.40,820.30,715.5,0.0};
    recs.writeRecords(slnos, ordNos, ordDts, custIds, prdNos, qtys, amts);
  }  
    
    
    
 }



