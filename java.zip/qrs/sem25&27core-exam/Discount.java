
package com.htc.javaee.exams;

import java.util.Date;

public class Discount
{
      
      public String toString()
      {
       return "Id:"+this.discountId+" FromDate:"+this.fromDate+
              " ToDate:"+this.toDate+" customerId:"+this.customerId+
              " Discount:"+this.discount;
      }
      private  int     discountId;
      private  Date    fromDate;
      private  Date    toDate;
      private  int     customerId;
      private  double  discount;
      
      public Discount(int discountId, Date fromDate, Date toDate,
                  int customerId, double discount)
      {
            super();
            this.discountId = discountId;
            this.fromDate = fromDate;
            this.toDate = toDate;
            this.customerId = customerId;
            this.discount = discount;
      }

      public Discount()
      {
      }

      public int getDiscountId()
      {
            return this.discountId;
      }

      public void setDiscountId(int discountId)
      {
            this.discountId = discountId;
      }

      public Date getFromDate()
      {
            return this.fromDate;
      }

      public void setFromDate(Date fromDate)
      {
            this.fromDate = fromDate;
      }

      public Date getToDate()
      {
            return this.toDate;
      }

      public void setToDate(Date toDate)
      {
            this.toDate = toDate;
      }

      public int getCustomerId()
      {
            return this.customerId;
      }

      public void setCustomerId(int customerId)
      {
            this.customerId = customerId;
      }

      public double getDiscount()
      {
            return this.discount;
      }

      public void setDiscount(double discount)
      {
            this.discount = discount;
      }

      public int hashCode()
      {
            final int prime = 31;
            int result = 1;
            result = prime * result + this.discountId;
            return result;
      }

      public boolean equals(Object obj)
      {
            if (this == obj)
                  return true;
            if (obj == null)
                  return false;
            if (getClass() != obj.getClass())
                  return false;
            final Discount other = (Discount) obj;
            if (this.discountId != other.discountId)
                  return false;
            return true;
      }

}

