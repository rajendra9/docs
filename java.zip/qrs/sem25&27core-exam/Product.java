
package com.htc.javaee.exams;
 

public class Product
{
      private int     prodId;
      private String  prodDesc;
      private double  cost;
      private int     customerId;
      
      public Product(int prodId, String prodDesc, double cost, int customerId)
      {
            super();
            this.prodId = prodId;
            this.prodDesc = prodDesc;
            this.cost = cost;
            this.customerId = customerId;
      }

      public Product()
      {
      }

      public int getProdId()
      {
            return this.prodId;
      }

      public void setProdId(int prodId)
      {
            this.prodId = prodId;
      }

      public String getProdDesc()
      {
            return this.prodDesc;
      }

      public void setProdDesc(String prodDesc)
      {
            this.prodDesc = prodDesc;
      }

      public double getCost()
      {
            return this.cost;
      }

      public void setCost(double cost)
      {
            this.cost = cost;
      }

      public int getCustomerId()
      {
            return this.customerId;
      }

      public void setCustomerId(int customerId)
      {
            this.customerId = customerId;
      }

      public int hashCode()
      {
            final int prime = 31;
            int result = 1;
            result = prime * result + this.prodId;
            return result;
      }

      public boolean equals(Object obj)
      {
            if (this == obj)
                  return true;
            if (obj == null)
                  return false;
            if (getClass() != obj.getClass())
                  return false;
            final Product other = (Product) obj;
            if (this.prodId != other.prodId)
                  return false;
            return true;
      }

      public String toString()
      {
        return "Id:"+this.prodId+" Desc:"+this.prodDesc+
               " Cost:"+this.cost+" customerId:"+this.customerId;
      }

}

