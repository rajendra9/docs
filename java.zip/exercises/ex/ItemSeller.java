package stuexercises;

public class ItemSeller {
   String[][] itemCosts;
   
   
   {
	   itemCosts = new String[][] {
			   {"Engine","75000.5"},
			   {"Chassis","45000.0"},
			   {"Bonnet","12500.5"},
			   {"Seats", "2500.5"},
			   {"Doors","2550.5"},
			   {"Dickey","4500.5"},
			   {"Electricals","8500.5"},
			   {"Metal-Cover","1250.5"},
			   {"Mother-Board","8500.5"},
			   {"Hard-Disc","2500.5"},
			   {"RAM","1800.5"},
			   {"Processor","5600.5"},
			   {"CompElectricals","3500.5"}
			  };   
   }
   
   public double getCost(String partName) {
	   double ret = 0.0;
	   for(String[] item : itemCosts) {
		   if(item[0].equalsIgnoreCase(partName)) {
			   ret = Double.parseDouble(item[1]);
			   break;
		   }
	   }
	   return ret;
   }
   
}
