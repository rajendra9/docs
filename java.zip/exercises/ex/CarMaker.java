package stuexercises;

public class CarMaker extends EnggDevelopment {

	public static final String PROD_NAME = "car";
	  String[] parts = null;
	public void makePrototype(String product) {
	  if(product.equalsIgnoreCase(PROD_NAME)) {
		  String subParts = "";
		  String[][] prods = this.getProducts();
		  for(String[] prod : prods) {
			  if(prod[0].equalsIgnoreCase(PROD_NAME)) {
				  subParts = prod[1];
				  break;
			  }
		  }
		  parts = subParts.split("['|']");
		  System.out.println("Order of assembly is:");
		  int count = 0;
		  for(String p : parts){
			  System.out.println(++count+"-->"+p);
		  }
		  
	  }
	  else {
		  System.out.println("We are not making this product");
	  }
	}

	@Override
	public double estimateCost(String product) {
		ItemSeller seller = this.getSeller();
		double total = 0.0;
		for(String  p : parts ){
			total += seller.getCost(p);
		}
		return total;
	}
	
	public static void main(String[] args) {
		EnggDevelopment engg = new CarMaker();
		engg.makePrototype(PROD_NAME);
		System.out.println("Cost involved :"+engg.estimateCost(PROD_NAME));
	}

}
