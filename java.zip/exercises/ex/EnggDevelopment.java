package stuexercises;

import java.util.Map;
import java.util.List;
import java.util.HashMap;

public abstract class EnggDevelopment {
	private String[][] products;
	private ItemSeller seller;
	{
       products = new String[][] {{"Car","Engine|Chasis|Bonnet|Seats|Doors|Dickey|Electricals"},
				{"Computer","Metal-Cover|Mother-Board|Hard-Disc|RAM|Processor|CompElectricals"}
			};     	
       seller = new ItemSeller();
	}

	public String[][] getProducts() {
		return products;
	}
	public void setProducts(String[][] products) {
		this.products = products;
	}
	public ItemSeller getSeller() {
		return seller;
	}
	public void setSeller(ItemSeller seller) {
		this.seller = seller;
	}
	public abstract void makePrototype(String product);
    public abstract double estimateCost(String product);
}
