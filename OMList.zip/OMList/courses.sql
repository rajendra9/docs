drop table if exists student_Master;

drop table if exists course_master;


create table course_master(course_id integer primary key,
        course_name varchar(20));

create table student_master(student_id integer primary key,student_name varchar(20),address varchar(20),idx integer,course_id integer references course_master(course_id));


insert into course_master values(100,'J2EE');

insert into course_master values(200,'.NET');

insert into  course_master values(300,'Oracle');


commit;
