select * from  course_master;

select * from  student_master;






