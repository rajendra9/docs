package testing;

import com.jee.jpa.JPACourseDAO;
import com.jee.jpa.domain.CourseDto;
import com.jee.jpa.domain.StudentDto;



public class HiberTest {

 public static void main(String[] args) {
   JPACourseDAO dao = new JPACourseDAO();
   dao.createCourse(new CourseDto(400,"OOAD"));

   StudentDto studentVO1 = new StudentDto(10,"MuthuKumar");
   StudentDto studentVO2 = new StudentDto(20,"sanat kumar");
   StudentDto studentVO3 = new StudentDto(30,"Swaroop");
   StudentDto studentVO4 = new StudentDto(40,"Prabhakar");
   StudentDto studentVO5 = new StudentDto(50,"Sandeep");
   StudentDto studentVO6 = new StudentDto(60,"Prakash");

   studentVO1.setAddress("Tambaram");
   studentVO2.setAddress("ChintadriPet");
   studentVO3.setAddress("ChromePet");
   studentVO4.setAddress("Chitlapakkam");
   studentVO5.setAddress("Kalpakkam");
   studentVO6.setAddress("TondiarPet");

   dao.createStudent(studentVO1);
   dao.createStudent(studentVO2);
   dao.createStudent(studentVO3);
   dao.createStudent(studentVO4);    
   dao.createStudent(studentVO5);
   dao.createStudent(studentVO6);    

   dao.addStudent(100,10);
   dao.addStudent(100,30);
   dao.addStudent(100,60);
   dao.addStudent(200,20);
   dao.addStudent(200,40);
   dao.addStudent(100,50);

   System.out.println(dao.getCourseDetails(100)); 
   dao.closeEM();
  }

} 
