package com.jee.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jee.jpa.domain.CourseDto;
import com.jee.jpa.domain.StudentDto;


public class JPACourseDAO {

	EntityManager em;
	EntityTransaction trans;
	
	public JPACourseDAO() {
        EntityManagerFactory factory = 
		      Persistence.createEntityManagerFactory("myDb");
	  em = factory.createEntityManager();
	}

	
	public boolean createCourse(CourseDto course) {
	   boolean  ret = false; 
	   trans = em.getTransaction();
	   trans.begin();
	   try {
	     em.persist(course);
	     ret = true;
	     trans.commit();
	   }catch(Exception e){		   
	     e.printStackTrace();
	     trans.rollback();
	   }
	   return ret;
	}


	public boolean createStudent(StudentDto student){
	   boolean  ret = false; 
           trans = em.getTransaction();
           trans.begin();
	   try {
	     em.persist(student);
	     ret = true;
	     trans.commit();
	   }catch(Exception e){		   
	     e.printStackTrace();
	     trans.rollback();
	   }
	   return ret;
	}

	public  boolean  addStudent(int courseId, int existingStudentId) {
	  boolean  ret = false; 
          trans = em.getTransaction();
	  trans.begin();
	  try {
	    CourseDto course = 
                 em.getReference(CourseDto.class,
	    	 new Integer(courseId));
	    StudentDto student = 
                  em.getReference(StudentDto.class,                                                         new Integer(existingStudentId));
	    List<StudentDto> students = course.getStudents();
	    if(!students.contains(student)) {
	      students.add(student);
	      em.merge(course);
		  ret = true;
		}    
        trans.commit();
	  }catch(Exception e){
          e.printStackTrace();
		  trans.rollback();
	  }
	  return ret;
	}
	
		
	public  String  getCourseDetails(int courseId) {
	   StringBuilder sb = new StringBuilder(); 
	   trans = em.getTransaction();
	   trans.begin();
	   try {
	    CourseDto course = 
             em.getReference(CourseDto.class,
		             new Integer(courseId));
	     List<StudentDto> students = course.getStudents();
	     sb.append("\n"+course.toString()+"\r\n");
	     if(students.size()>0) { 
                sb.append("\nstudents are:\n");
     
             for(StudentDto stu : students) {
               sb.append(stu.toString()+"\n");
             }
            } 
            sb.append("\n");
            trans.commit();
	   }catch(Exception e){
	      e.printStackTrace();
	      trans.rollback();
	   }
	   return sb.toString();
	}
 
	public void closeEM() {
	  em.close();
	}

}