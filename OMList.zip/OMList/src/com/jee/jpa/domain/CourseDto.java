package com.jee.jpa.domain;

import java.util.List;
import java.util.ArrayList;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.JoinColumn;


@Entity
@Table(name="course_master")
@SuppressWarnings("serial")
public class CourseDto implements java.io.Serializable {
  private  int              courseId;
  private  String           courseName;
  private  List<StudentDto>  students;
  
  {
   students = new ArrayList<StudentDto>();
  } 
  
  public CourseDto()  {
   
  }
  
  public CourseDto(int courseId, String courseName){
	super();
	this.courseId = courseId;
	this.courseName = courseName;
  }

  @Id
  @Column(name="COURSE_ID")
  public int getCourseId() {
	return courseId;
  }


  public void setCourseId(int courseId) {
	this.courseId = courseId;
  }

  @Column(name="COURSE_NAME") 
  public String getCourseName() {
	return courseName;
  }

  public void setCourseName(String courseName) {
	this.courseName = courseName;
  }

  @OneToMany
  @JoinColumn(name="COURSE_ID")
  @OrderColumn(name="IDX")
  public List<StudentDto> getStudents() {
	return students;
  }

  public void setStudents(List<StudentDto> students) {
	this.students = students;
  }

  public String addStudent(StudentDto student) {
   String ret = "existing";
   if(!getStudents().contains(student)) {
    getStudents().add(student);
    ret = "added";
   }
   return ret;
  }

  public String toString() {
     StringBuffer sb = new StringBuffer();
     sb.append("Id:"+courseId+" Name:"+courseName);
     return sb.toString();
  }


  public int hashCode() {
    final int PRIME = 31;
    int result = 1;
    result = PRIME * result + courseId;
    return result;
  }

  public boolean equals(Object obj) {
    if (this == obj)
        return true;
    if (obj == null)
        return false;
    if (getClass() != obj.getClass())
        return false;
    final CourseDto other = (CourseDto) obj;
    if (courseId != other.courseId)
        return false;
    return true;
  }

}