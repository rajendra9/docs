package com.jee.jpa.domain;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
@Table(name="student_master")
@SuppressWarnings("serial")
public class StudentDto implements 
   Comparable<StudentDto> ,java.io.Serializable  {

  private  int     stuId;
  private  String  stuName;
  private  String  address;
  
  public StudentDto(){}
  
  public StudentDto(int stuId, String stuName) {
	super();	
	this.stuId = stuId;
	this.stuName = stuName;
  }
  
  @Column
  public String getAddress() {
	return address;
  }
  
  public void setAddress(String address) {
	this.address = address;
  }
  
  @Id
  @Column(name="STUDENT_ID")
  public int getStuId() {
	return stuId;
  }

  public void setStuId(int stuId){
	this.stuId = stuId;
  }

  @Column(name="STUDENT_NAME")
  public String getStuName() {
	return stuName;
  }

  public void setStuName(String stuName) {
	this.stuName = stuName;
  }

  public int compareTo(StudentDto arg0){
      return this.stuId-arg0.stuId;
  }

  public String toString() {
	StringBuffer sb = new StringBuffer();
	sb.append("Id:"+stuId+" Name:"+stuName);
	sb.append(" address:"+address.trim());
	return sb.toString();
  }

  @Override
  public int hashCode() {
    final int PRIME = 31;
    int result = 1;
    result = PRIME * result + stuId;
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
        return true;
    if (obj == null)
        return false;
    if (getClass() != obj.getClass())
        return false;
    final StudentDto other = (StudentDto) obj;
    if (stuId != other.stuId)
        return false;
    return true;
  }
  
}