import React, { PureComponent } from 'react';

import './App.css';

const SampTemp =(props) => {
  console.log("Render SampTemp");
  return (<div>{props.goals}</div>)
}


class App extends PureComponent {  //Component
  state = {
    goals: 0
  }
  componentDidMount(){
    setInterval(() => {
      this.setState(()=>{
        return { goals: Math.round(Math.random()) }
      })
    }, 2000);
  }
  /*shouldComponentUpdate(nextProp, nextState){
    console.log('nextProp', nextProp);
    console.log('nextState', nextState);
    return (this.state.goals === nextState.goals ? false : true);
    
  } */
  render() {
    console.log("Render App");
    return (
      <div className="App">
         <SampTemp goals={this.state.goals} />      
      </div>
    );
  }
}

export default App;
