import React, { Component } from 'react';
import logo from './logo.svg';
import Employees from './jsons/employees.json';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <table className="tbl">
          <tbody>
           {
             Employees.map(function(emp,index){
              return( <tr><td>{emp.userId}</td><td>{emp.employeeCode}</td><td>{emp.preferredFullName}</td>
              <td>{emp.jobTitleName}</td><td>{emp.preferredFullName}</td>
              <td>{emp.region}</td><td>{emp.phoneNumber}</td>
              <td>{emp.emailAddress}</td></tr>)
             })
           }

          </tbody>
        </table>
      </div>
    );
  }
}

export default App;
