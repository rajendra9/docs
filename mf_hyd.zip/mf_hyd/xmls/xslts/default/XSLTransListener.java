

import javax.xml.transform.ErrorListener;
import javax.xml.transform.TransformerException;

public class XSLTransListener implements ErrorListener {

    @Override
    public void error(TransformerException te) throws TransformerException {
       String msg = te.getMessageAndLocation();
       System.out.println(msg);       
    }

    @Override
    public void fatalError(TransformerException te)
            throws TransformerException {
       String msg = te.getMessageAndLocation();
       System.out.println(msg);
    }

    @Override
    public void warning(TransformerException te) throws TransformerException {
      String msg = te.getMessageAndLocation();
      System.out.println(msg);
    }

}