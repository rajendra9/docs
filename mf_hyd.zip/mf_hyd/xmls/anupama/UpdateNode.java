package doubts;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import myxmls.DocParser;
import myxmls.ParsedDocSaver;

public class UpdateNode  {

 public static void main(String[] args)
  throws Exception {

  DocParser dParser = new DocParser();
  Document document = dParser.getParseSchemaDocument("cities.xml");

  String ns = document.getNamespaceURI();
  Node rootNode = document.getDocumentElement();
  NodeList nodeList = document.getElementsByTagName("city");
  Node chNode = null;
  outer:
   for(int i=0;i<nodeList.getLength();i++) {
    Node cityNode = nodeList.item(i);     
    NodeList cityChildren = cityNode.getChildNodes();
    int len = cityChildren.getLength();
    for(int j=0;j<len;j++) {
     chNode = cityChildren.item(j);
     if(chNode == null) {
      continue;
     }
     if(!(chNode.getFirstChild() instanceof org.w3c.dom.Text)) {
      continue;
     }
        
     String data = chNode.getFirstChild().getNodeValue();       
     if(!data.equals("New Delhi")) {
       continue;
     }
     Node populationNode = chNode.getNextSibling().getNextSibling();
     populationNode.setTextContent(""+14000000); 		 
     break outer;
    }
   }
   ParsedDocSaver docSaver = new ParsedDocSaver();
   String fPath = "file:///C:/xmls/cities_new.xml";
   boolean boo = docSaver.saveDoc(document, fPath); 
   if(boo) {
      System.out.println("document saved");
  }
    
    	 
 }

}