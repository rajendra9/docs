package testing;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;

import mysamp.AddressTy;
import mysamp.ObjectFactory;
import mysamp.StudentType;
import mysamp.StudentsType;
import newsamp.ProdTy;
import newsamp.ProdsTy;

public class JaxbCreateStudents {

   ObjectFactory obf = new ObjectFactory();	
	
   private AddressTy formAddress(String houseNum, String street, String area, String city, Integer pincode) {
	   AddressTy address = obf.createAddressTy();
	   address.setHouseNo(houseNum);
	   address.setStreet(street);
	   address.setArea(area);
	   address.setCity(city);
	   address.setPincode(pincode);
	   return address;
   }
	
   private StudentType createAndPopulate(String stuId, String stuName,
		                       String course, String college, String[] subjects) {
     StudentType baseStudent = obf.createStudentType();
     baseStudent.setStuId(stuId);
     baseStudent.setStuName(stuName);
     baseStudent.setCollege(college);
     baseStudent.setCourse(course);
     StudentType.Subjects subs = obf.createStudentTypeSubjects();
     List<String> subsList = subs.getSubject();
     Arrays.stream(subjects).forEach((e)-> subsList.add(e));
     baseStudent.setSubjects(subs);
     return baseStudent;
   }
	
	
   private JAXBElement<StudentsType> createStudents() {
	   StudentsType ret = obf.createStudentsType(); 
	   String[] subsOne = {"English", "Telugu", "Mathematics","Physics","Chemistry","Computers","Sociology"};
	   AddressTy addressOne = this.formAddress("5/43", "Venkateswara Colony", "Saroor Nagar", "Hyderabad", 500032); 
       StudentType s1 = this.createAndPopulate("C100", "Santosh", "B.Sc", "St Joseph College", subsOne );
       s1.setAddress(addressOne);
       ret.getStudents().add(s1);
       
       String[] subsTwo = {"English", "Telugu", "Biology","Zoology","Chemistry","Computers","Sociology"};
	   AddressTy addressTwo = this.formAddress("101A", "New Bank Colony", "Santosh Nagar", "Hyderabad", 500012); 
       StudentType s2 = this.createAndPopulate("C110", "Meghanadh", "B.Sc", "Swamy Vivekananda College", subsTwo );
       s2.setAddress(addressTwo);
       ret.getStudents().add(s2);
       
       String[] subsThree = {"English", "Telugu", "Commerce","Company Law","Accounts","Computers","Sociology"};
	   AddressTy addressThree = this.formAddress("43/65 A", "opp to PostOffice", "Malakpet", "Hyderabad", 500035); 
       StudentType s3 = this.createAndPopulate("C120", "Swaroopa", "B.Com", "Budding Giants College", subsThree );
       s2.setAddress(addressThree);
       ret.getStudents().add(s3);
     
       return obf.createStudents(ret);   
   }
   
   public static void main(String[] args) throws Exception {
 
	JaxbCreateStudents jaxbCreateStudents = new JaxbCreateStudents();	   
    
	  JAXBContext jxb = JAXBContext.newInstance("mysamp");
      Marshaller marshaller = jxb.createMarshaller();
      PrintWriter out = new PrintWriter("students_new.xml"); 
      JAXBElement<StudentsType> newStudents = jaxbCreateStudents.createStudents();
    
      marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
                  Boolean.TRUE);
      marshaller.marshal(newStudents,out);
      marshaller.marshal(newStudents,System.out);
      out.close();
  }

}