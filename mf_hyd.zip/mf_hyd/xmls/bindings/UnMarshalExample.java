package books;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import mySamp.Book;
import mySamp.BookStoreType;
import mySamp.BookStoreType.BookList;
import mySamp.ObjectFactory;

public class UnMarshalExample {

	public static void main(String[] args) throws JAXBException,IOException {
		
		
	JAXBContext jxb = JAXBContext.newInstance("mySamp");
	Unmarshaller um = jxb.createUnmarshaller();
	
	JAXBElement<BookStoreType> bst =
    (JAXBElement<BookStoreType>)um.unmarshal(new File("bookstore-jaxb.xml"));
	
	BookStoreType bookStore = bst.getValue();
		
	ObjectFactory factory  = new ObjectFactory();
	BookStoreType.BookList books = bookStore.getBookList(); 
	
	 
	Book b1 = factory.createBook(); 
	b1.setAuthor("James Rolling");
	b1.setIsbn("978-0060555");
	b1.setTitle("harry poter");
	b1.setPublisher("Mc graw hill");
	List<Book> bookList = books.getBook();
	bookList.add(b1);
	
	bookStore.setBookList(books);	
	
	JAXBElement<BookStoreType>  jaxbElement = factory.createBookStore(bookStore);	
	
	Marshaller marsh = jxb.createMarshaller();
	marsh.setProperty(marsh.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	PrintWriter out = new PrintWriter("newfile.xml");
	marsh.marshal(jaxbElement, out);
	marsh.marshal(jaxbElement, System.out);
	out.close();
	 	  
	
	
				
	}
	
}


	

