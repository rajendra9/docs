package myxmls;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlAccessType;

@XmlRootElement(name="Students" )
@XmlType(name="StudentsType",propOrder={"students"})
@XmlAccessorType(value=XmlAccessType.PUBLIC_MEMBER)
public class ForStudents {

    
   private ForStudent[] students;
    
    

    
   public ForStudent[]  getStudents() {
     return students;
   }
   
   @XmlElement(name="students" , required=true)
   public  void setStudents(ForStudent[] newStudents) {
     students = newStudents;
   }


}