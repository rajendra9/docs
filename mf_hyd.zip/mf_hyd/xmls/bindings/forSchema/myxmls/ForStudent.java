package myxmls;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlAccessType;


@XmlType(name="StudentType",propOrder={"stuName", "course","college","address","subjects"})
@XmlAccessorType(value=XmlAccessType.PUBLIC_MEMBER)
public class ForStudent {

    private String stuId;
    private String stuName;
    private String course;
    private String college;

    private String[]  subjects = new String[6];
    
    private Address address;
    
    private String description;
    
    public String getDescription() {
        return description;
    }

    @XmlTransient
    public void setDescription(String description)  {
        this.description = description;
    }

    public ForStudent(){}

    public ForStudent(String stuId,
                         String stuName,
                         String course) {
        super();
        this.stuId = stuId;
        this.stuName = stuName;
        this.course = course;
    }
    
   public String[]  getSubjects() {
     return subjects;
   }
   
   @XmlElementWrapper(name="subjects",nillable=false)
   @XmlElement(name="subject" , required=true)
   public  void setSubjects(String[] newSubjects) {
     subjects = newSubjects;
   }

    public String getStuId() {
        return stuId;
    }

    @XmlID
    @XmlAttribute(required=true)
    public void setStuId(String stuId) {
        this.stuId = stuId;
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public String getCourse() {
        return course;
    }

  
    public void setCourse(String course) {
        this.course = course;
    }  

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + stuId.hashCode();
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final ForStudent other = (ForStudent) obj;
        if (!stuId.equals(other.stuId))
            return false;
        return true;
    }
    
    public String getCollege() {
        return college;
    }
    
    @XmlElement(required=true)
    public void setCollege(String college) {
        this.college = college;
    }

    public Address getAddress() {
        return address;
    }
    
    @XmlElement(name="address", type=Address.class,nillable=false)  
    public void setAddress(Address address)  {
        this.address = address;
    }
    
    @Override
    public String toString()  {
      return ToStringCreator.toStringInLine(this);  
    } 

}