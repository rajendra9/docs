package bind;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Marshaller;
import newsamp.ObjectFactory;
import newsamp.ProdsTy;
import newsamp.ProdTy;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.math.BigInteger;
import javax.xml.namespace.QName;

public class NewJaxbDemo {

 public static void main(String[] args)
  throws Exception {
 
  JAXBContext jxb = JAXBContext.newInstance("newsamp");
  Unmarshaller um = jxb.createUnmarshaller();
  JAXBElement<ProdsTy> prds =
    (JAXBElement<ProdsTy>)um.unmarshal(new File("newproducts.xml"));

  ProdsTy prods = prds.getValue();

  ObjectFactory obf = new ObjectFactory(); 
    
  ProdTy prod = obf.createProdTy();
  prod.setQty(new BigInteger("20"));
  prod.setBrand("LG");
  prod.setName("TV");
  prod.setId(new BigInteger("210"));
    
  java.util.List<ProdTy> lt = prods.getProduct();
  lt.add(prod);

  JAXBElement<ProdsTy> newPrds = obf.createProducts(prods); 
         
  Marshaller msh = jxb.createMarshaller(); 

  msh.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
                  Boolean.TRUE);
  PrintWriter out = 
      new PrintWriter(new FileWriter("newProducts_new.xml"));
  msh.marshal(newPrds,out);
  msh.marshal(newPrds,System.out);
  out.close();
 }

}