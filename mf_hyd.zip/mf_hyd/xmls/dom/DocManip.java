package dom;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.util.Scanner;

public class DocManip  {

  static Document doc;

 public static void main(String[] args)throws Exception {
  Scanner scan = new Scanner(System.in);
  System.out.println("enter file to changed");  
  String filename = scan.nextLine();
  
  System.out.println("is it schema based enter 'true/false'");  
  boolean isSchema = Boolean.parseBoolean(scan.nextLine());
    
  System.out.println("enter parent id of element");  
  String idStr = scan.nextLine();

  System.out.println("enter child element name for change");  
  String oldElt = scan.nextLine();

  System.out.println("enter new element name");  
  String newElt = scan.nextLine();

  System.out.println("enter new element value");  
  String newValue = scan.nextLine();

  System.out.println("enter target file");  
  String newFile = scan.nextLine();

  if(!isSchema) {
   doc = new DocParser().getParseDocument(filename);   
  }
  else {
   doc = new DocParser().getParseSchemaDocument(filename);   
  }

  Node root = doc.getDocumentElement();
  System.out.println("\nBefore Change\n");

  printNodes(root);

  changeNode(idStr,oldElt,newElt,newValue); 
 
  System.out.println("\nAfter Change\n");

  printNodes(root);
     
  doc.normalizeDocument();    
  ParsedDocSaver docSaver = new ParsedDocSaver();
  boolean boo = 
    docSaver.saveDoc(doc,"file:///C:/xmls/"+newFile); 
  if(boo) {
   System.out.println("\n Tree Saved"); 
  }      
 }
  public static void printNodes(Node rt){    
 
   NodeList nl = rt.getChildNodes();
   int len = nl.getLength();
   for(int i=0;i<len;i++) {
    Node nd = nl.item(i); 
    if(nd.hasChildNodes()){
     System.out.println(nd.getNodeName());    
     NodeList nl2 = nd.getChildNodes();
   
     for(int j=0;j<nl2.getLength();j++) {
      Node nd2 = nl2.item(j);
      if(nd2.getNodeType() != Node.TEXT_NODE){
       System.out.print(nd2.getNodeName()+":"); 
       System.out.println(nd2.getTextContent());
      }
     }
    }
   }
  }
 
  public static void changeNode(String id, String elt, 
                                String newelt, String newtext)
   throws Exception {
   Node node = doc.getElementById(id);
   NodeList nl = node.getChildNodes();
   int len = nl.getLength();  
         
   for(int i = 0;i<len;i++) {
    Node nd = nl.item(i);     
      
   if(nd.getNodeType() == Node.ELEMENT_NODE) {
    if(!nd.getNodeName().equalsIgnoreCase(elt)) {
     continue;
    }
    changing(nd,newelt,newtext);
    break; 
   }
  }
 }
  public static void changing(Node nd, String newelt, String newtext) {
  
   String ns = doc.getNamespaceURI();
   Node news = doc.createElementNS(ns, newelt);
   Node newscontent = doc.createTextNode(newtext);
   news.appendChild(newscontent);
   Node parent = nd.getParentNode();
   parent.replaceChild(news,nd);
  }

}
/*use personal.xml,students.xml as document
  java DocManip personal.xml a30 location area TNagar
  or
  java students.xml d300 college prof-college SRMEngineering  
 */