package dom;
import org.w3c.dom.Document;

public class DocParse {
 
 static String filename = "";  
    
 public static void main(String args[])
  throws Exception {
  
  if(args.length != 2){
    System.err.println("usage 'java DocParse <filename> <isSchema>'");
     System.exit(1);
  }   
  try {
   Document document = null;
   boolean isSchema = Boolean.parseBoolean(args[1]);
   if(!isSchema) {  
    document = new DocParser().getParseDocument(args[0]);
   }
   else {
    document = new DocParser().getParseSchemaDocument(args[0]);
   }
   System.err.println(args[0]+" is parsed.");
  }
  catch(Exception e) {
   System.err.println(args[0]+" could not be parsed");
   e.printStackTrace();
  }
 }

}