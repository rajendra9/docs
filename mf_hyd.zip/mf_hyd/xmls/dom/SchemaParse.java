package dom;

import java.io.File;
import java.io.IOException;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Schema;
import javax.xml.validation.Validator;
import javax.xml.transform.stream.StreamSource;

public class SchemaParse {
 
  public static void main(String[] args)
    throws Exception {
   if(args.length != 2) {
    System.err.println("usage 'java SchemaParse <xsdfile> <xmlfile> '");
     System.exit(1);
   }   
    String language = javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI;
    SchemaFactory scf = SchemaFactory.newInstance(language);
   
    StreamSource source = new StreamSource(new File(args[0]));
    Schema schema = scf.newSchema(source); 
   
    Validator validator = schema.newValidator();
    MyDefHandler eh = new MyDefHandler();
    validator.setErrorHandler(eh);
    validator.validate(new StreamSource(new File(args[1])));
    System.err.println(args[1]+" parsed & validated");
   }

}