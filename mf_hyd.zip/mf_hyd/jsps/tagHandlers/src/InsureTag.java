package prajsp;

import java.io.IOException;
import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class InsureTag extends SimpleTagSupport {
 
 private int assured;
 private int term;
   
 public int getAssured() {
  return assured;
 }

 public void setAssured(int ass) {
  assured = ass;
 }
  
 public int getTerm() {
  return term;
 }
 
 public void setTerm(int te) {
  term = te;
 }   
  
 public double getPremium(int amount, int period) {
  double offset = 0.0;
  if(period == 30) {
   offset = 0.98;
  }
  else if(period == 25) {
   offset = 1.02;
  }
  else if(period == 20) {
   offset = 1.06;
  }
  else if(period == 15) {
   offset = 1.10;
  }
  else if(period == 10) {
   offset = 1.14;
  }
  double addamount = amount*offset;
  double ret = Math.rint(addamount/period);
  return ret;
 }

 public double getBonus(int amount, int period) {
  double crate = 0.0;
  if(period == 30) {
   crate = 45.00;
  }
  else if(period == 25) {
   crate = 40.50;
  }
  else if(period == 20) {
   crate = 38.00;
  }
  else if(period == 15) {
   crate = 34.00;
  }
  else if(period == 10) {
   crate = 32.50;
  }
  return  (((amount/1000)*crate)*period);
 }
        
 public void doTag()throws JspException {
  double premium;
  double bonus;
  try {
   JspContext  jtx = getJspContext();
   JspWriter out = jtx.getOut();
   
 
   premium = getPremium(assured,term);
   bonus = getBonus(assured,term);
 
   out.write("<hr><font color = 'red' " +
            " size = '+3'> Premium to " +
            " be paid is <u>" + 
            premium + ".</u><br/><br/>");

   out.write("At Current Rates The Expected " +
             "Bonus is <u>" + bonus + ".</u>"+
             " </font><br/><br/>");
   out.write("<font  color = 'green'>" +
            "Note:Both the above calculations," +
            "Annual payment is the" +
            " Basis,please .</font>");
  }
  catch(IOException e) {
   throw new  JspException("Fatal Error:ric tag "+
              " could not write to jsp out");
  }        
 }

}