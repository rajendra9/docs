package prajsp;

import java.io.Serializable;

public class ShopItem implements Serializable {
   private long itemId;
   private String itemName;
   private double itemCost;
   private int qty;
   
   public ShopItem() {
    super();
   }

   public ShopItem(long itemId, 
                   String itemName, 
                   double itemCost, 
                   int qty) {
     super();
     this.itemId = itemId;
     this.itemName = itemName;
     this.itemCost = itemCost;
     this.qty = qty;
   }

   public long getItemId() {
      return itemId;
   }

   public void setItemId(long itemId) {
      this.itemId = itemId;
   }

   public String getItemName() {
      return itemName;
   }

   public void setItemName(String itemName) {
      this.itemName = itemName;
   }

   public double getItemCost() {
      return itemCost;
   }

   @Override
   public String toString() {
       return "ShopItem [itemId=" + itemId + ", itemName=" + itemName + ", itemCost=" + itemCost + ", qty=" + qty + "]";
   }

   public void setItemCost(double itemCost) {
       this.itemCost = itemCost;
   }

   public int getQty() {
      return qty;
   }
 
   public void setQty(int qty) {
      this.qty = qty;
   }

   @Override
   public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + (int) (itemId ^ (itemId >>> 32));
      return result;
   }

   @Override
   public boolean equals(Object obj) {
       if (this == obj)
          return true;
       if (obj == null)
          return false;
       if (getClass() != obj.getClass())
           return false;
       ShopItem other = (ShopItem) obj;
       if (itemId != other.itemId)
          return false;
        return true;
   }
   
   
   
   
   
   
   
}
