package prajsp;

import java.util.Map;
import java.util.HashMap;

public class MyBean implements java.io.Serializable
 {
  private String myName;
  private String course;
  private Map<String,String> map;

  public MyBean()
  {
    myName="sunder";
    map=new HashMap<String,String>();
    map.put("1","Bhaskar");
    map.put("two","Hemalatha");
    map.put("three","Jolly Sahoo");
    map.put("four","Krishnamurthy");
  }

  public void setMap(Map<String,String> newMap)
  {
    map=newMap;
  }
 
  public Map getMap()
  {
    return map;
  }

  public void setMyName(String str)
  {
    myName=str;
  }

  public String getCourse()
  {
    return course;
  }

  public void setCourse(String str)
  {
   course=str;
  }

  public String getMyName()
  {
    return myName;
  }

  public String upper(String str)
  {
    return str.toUpperCase();
  }
}
