package prajsp;

import java.io.IOException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.JspTagException;

public class MenuItemTag extends TagSupport  {

 private String name;

 public void setName(String newName) {
  name = newName;
 }
   
 public int doStartTag() throws JspTagException {
   MenuTag menu = (MenuTag)this.getParent(); 
   menu.addNavigator(name);
   return SKIP_BODY;
 }


}