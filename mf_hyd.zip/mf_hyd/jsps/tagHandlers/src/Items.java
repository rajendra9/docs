package prajsp;
import java.util.*;
public class Items extends ArrayList<String>
 {
  public Items()
   {
    super();
    for(int i=0;i<10;i++)
     add(new String("INDIA is-"+i));
    }
} 
    