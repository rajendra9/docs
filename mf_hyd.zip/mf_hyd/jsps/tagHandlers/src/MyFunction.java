package prajsp;

public class MyFunction {

 public static double getPower(int x, int y) {
  return (int)Math.round(Math.pow(x,y));    
 }

}