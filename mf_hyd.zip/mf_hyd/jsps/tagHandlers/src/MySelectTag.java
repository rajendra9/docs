package prajsp;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.annotation.Resource;
import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import javax.sql.DataSource;

public class MySelectTag extends SimpleTagSupport {
 
 @Resource(name="jdbc/myPostgres", type=javax.sql.DataSource.class)
  DataSource ds;
   
  
 public void doTag()throws JspException {
  Connection conn = null;
  StringWriter strOut = new StringWriter();
  try {
   JspContext  jtx = getJspContext();
   JspWriter out = jtx.getOut();
   
   JspFragment sqlStrFrag = this.getJspBody();
   sqlStrFrag.invoke(strOut);
   
   String sqlStr = strOut.toString();
   conn = ds.getConnection();
   Statement stmt = conn.createStatement();
   ResultSet rs = stmt.executeQuery(sqlStr);
   ResultSetMetaData rsmd = rs.getMetaData();
   int colCnt = rsmd.getColumnCount();
   while(rs.next()) {
	  for(int i=0;i<colCnt;i++) {
		  out.println(rs.getString(i+1)+"&nbsp;&nbsp;");
	  }
	  out.println("<br/>");
   }
   out.flush();
   }catch(SQLException | IOException sqe) {
	   sqe.printStackTrace();
   }
 
  }

}