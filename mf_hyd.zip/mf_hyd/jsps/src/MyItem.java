package prajsp;


public  class MyItem extends GenItem {
 String   itemName;
        
 public MyItem(int id, String n){
  super(id);
  this.itemName = n;
 }

 public MyItem(){}
        
 public String getItemName(){
  return itemName;
 }

 public void setItemName(String n) {
  itemName = n;
 }

 @Override
  public String toString() {
   return itemId+"::"+itemName;
  }
        
}