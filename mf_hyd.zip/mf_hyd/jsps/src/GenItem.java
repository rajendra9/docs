package prajsp;

import java.io.Serializable;

public abstract class GenItem implements Serializable {
  int   itemId;
        
  public GenItem(int id) {
   super();
   this.itemId = id;
  }

  public GenItem(){}
        
  public int getItemId() {
   return itemId;
  }

  public void setItemId(int n) {
   itemId = n;
  }

  @Override
  public int hashCode(){
   final int PRIME = 31;
   int result = 1;
   result = PRIME * result + itemId;
   return result;
  }

  @Override
  public boolean equals(Object obj) {
   if (this == obj)
    return true;
   if (obj == null)
    return false;
   if (getClass() != obj.getClass())
    return false;
   final GenItem other = (GenItem) obj;
   if (itemId != other.itemId)
    return false;
   return true;
  }

  @Override
  public String toString() {
   return ""+this.itemId;
  }
        
}