var mongoose = require('mongoose');
var productSchema = new mongoose.Schema({
  prod_name: String,
  prod_type: String,
  prod_cost: Number,
  updated_at: { type: Date, default: Date.now},
});
module.exports = mongoose.model('Product', productSchema);