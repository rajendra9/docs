<template>
 <header>
     <h2 v-on:click="changeTitle">{{title}}</h2>
     
 </header>
</template>

<script>
 import { bus }  from '../main';
export default{
   props: {     
   title: {
      type: String      
   } 
 },
    data(){
        return{
          
        }
    },
     methods:{
       changeTitle: function() {
          this.title = 'High Caloried People';
          bus.$emit('goodTitle','High Caloried People');
       }    
 }

}

</script>
<style scoped>
header{
    background: lightblue;
    padding: 8px;
}
h2{
    color: #222;
    text-align: center;
}
</style>