<template>
  <div id="app">   
    <my-header v-bind:title="title" ></my-header> 
     <celebs v-bind:celebs="celebrities"  ></celebs>     
    <my-footer v-bind:title="title" ></my-footer>
  </div>
</template>

<script>
import MyHeader from './components/myHeader.vue';
import Celebs from './components/celebs.vue';
import MyFooter from './components/myFooter.vue';
export default {
 
  components: {
    'my-header': MyHeader,
    'celebs' : Celebs,
    'my-footer': MyFooter
  },
  data(){
    return{
           celebrities:[
             {name:'Sachin Tendulkar', field: 'Cricket', display: false},
             {name:'Sindhu', field: 'Shuttle', display: false},
             {name:'Baichung Bhutia', field: 'Football', display: false},
             {name:'Anna Hazare', field: 'Social Work', display: false},
             {name:'Bharat Chetri', field: 'Hockey', display: false},
             {name:'Ammer Khan', field: 'Bollywood', display: false}             
           ],
           title: 'Golden Celebrities'

    }
  },
  methods:   {
  followUpGoodTitle: function(changedTitle) {
    this.title = changedTitle;
  }
}

}
</script>

<style scoped>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;  
  margin-top: 60px;
}
</style>
