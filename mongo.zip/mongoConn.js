var mongoClient = require('mongodb').MongoClient;

var url ='mongodb://localhost:27017/samp';

mongoClient.connect(url, { useNewUrlParser:true }, function(err,db){
    if(err){
        console.log('error in getting connection');
    }
    else {
        console.log('connection established');
        db.close();
    }
});