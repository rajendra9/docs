db.createUser(
    {
       user: "scott",
       pwd: "tiger",
         roles: [
          { role:  "genUser" ,db: "samp"}
        ]
    }  
) 
        