db.createRole(
    {
        role: "genUser",
       privileges: [
               { resource: { db: "samp", collection: ""}, actions: ["find", "insert", "update", "remove"]}
       ],
        roles: [
          { role:  "readWrite", db: "samp" }
        ]
    },
  {w: "majority", wtimeout: 10000}
) 
        