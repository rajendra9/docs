db.updateUser("scott",
  {
   roles : [
        { role: "readWrite",  db:"test" },
         { role: "readWrite",  db:"samp" }       
  ],
  pwd: "tiger"
 }
)