db.world.find({BirthRate: {$gt:20.0}},{Country:1,Continent:1,Capital:1,_id:0}).forEach(printjson);
