var mongoClient = require('mongodb').MongoClient;

var url ='mongodb://localhost:27017/samp';

mongoClient.connect(url,{useNewUrlParser:true}, function(err,db){
    if(err){
        console.log('error in getting connection');
    }
    else {
       var dbo = db.db('samp');
       var rows = dbo.collection('persons').find().toArray(function(err,rec){
        if(err){
            console.log('error in getting results');
        } 
        else{
            //var result = rec.ssn +'-' + rec.name + '-' + rec.salary + '-' +rec.mobile;
            console.log(JSON.stringify(rec));            
        }
        db.close();
       });  
    }
});