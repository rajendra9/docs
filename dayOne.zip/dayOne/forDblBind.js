new Vue({
    el: '#vue-dbl-bnd-app',
    data:{
        name:'',
        age:'' 
    },
    methods:{
      
    }
})