new Vue({
    el: '#vue-evt-app',
    data:{
        commuFunds: 2000,
        donation: 0,
        spending: 0   
    },
    methods:{
       addDonationToFunds: function(){
           console.log('donation');
           this.commuFunds = this.commuFunds+parseInt(this.donation);
          
       },
       spendMoney: function(amt){
           console.log('expenses');
           this.commuFunds = this.commuFunds-parseInt(this.spending);                 
       }
       
    }
})