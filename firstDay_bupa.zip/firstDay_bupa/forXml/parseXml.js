var fs = require("fs");
var parse = require("xml-parser");
var inspect = require("util").inspect;

var file = './data/AttrDept.xml';
var xmlContent = fs.readFileSync(file,'UTF-8');
var obj = parse(xmlContent);
console.log(inspect(obj, {colors: true, depth: Infinity}));  