module.exports=
MyRect=function(wd,ht){
        this.width = parseInt(wd);
        this.height = parseInt(ht);
       MyRect.prototype.area=function(){
        return (this.height*this.width)
       };
       MyRect.prototype.show=function() {
        console.log("width is:"+this.width+" height:"+this.height);
       };
       MyRect.compare = function(rectA,rectB) {
        var area1 = rectA.area();
        var area2 = rectB.area();
        console.log(area1 + "::" + area2);
        if(area1>area2) {
         return  1;
        }
        else if(area1<area2) {
         return -1;
        }
        else {
         return 0;
        }
       };
      };
