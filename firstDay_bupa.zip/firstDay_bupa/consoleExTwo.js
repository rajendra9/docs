var emp = {id:200, name:'sudarshan',salary:40000.0};
var str = 'Tambaram';
console.log('This is a number-%d,This is a String-%s,This is an Object',63, str,emp);
console.log(emp.name+' '+emp.salary);
