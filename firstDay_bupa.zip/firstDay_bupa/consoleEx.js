var assert = require("assert");

console.time("Iteration")

for(var i=0;i<200;i++){
  process.stdout.write(i+' ');
}

console.log();

console.timeEnd('Iteration');

//shows stack trace methods
console.trace('loop ended');

var ag = process.argv[2];
var x = parseInt(ag,10);
console.log(x);

assert.ok(x<5,"x is not proper");
