function async(obj){
  obj();
}
var interval = 100;

setInterval(function(){
  async(function(){
    console.log('Async is done');
  });
 },interval);
console.log('How are you');