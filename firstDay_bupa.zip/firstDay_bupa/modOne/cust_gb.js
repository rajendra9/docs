exports.goodBye=function(){
 console.log('Good Bye');
}