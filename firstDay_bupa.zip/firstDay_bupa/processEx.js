loopData = [];
console.log('working directory-'+process.cwd());


process.on('exit', function(){
 console.log('program is exiting');
});

// this function will fire after a loop operation
process.nextTick(function(){
 console.log('Data:'+loopData);
}); 

for(var i=0;i<10;i++){
 loopData.push('HTC-'+i);
} 


console.log('time-'+process.uptime());

