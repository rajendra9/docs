var jFile = require("jsonfile");


var file = './data/pers.json';
var newFile = './data/newPers.json';
var rec = {"adharId":"1212 1764 9879",
     "name": "Vadivelan",
     "occupation": "State Govt Service",
     "monthlyIncome":41760.5};
var finalData = [] ;
var readData ;
 jFile.readFile(file,function(err,obj){
  if(!err){
   var data = JSON.parse(JSON.stringify(obj));   
   console.log(data.length);
   for(var i=0;i<data.length;i++){
    finalData.push(data[i]);
    }
   console.log(finalData); 
   finalData.push(rec);
   jFile.writeFile(file,finalData, function(err){
    if(err){
      console.log("error in writing");
    }
    console.log("writing good");    
  });
  }

 }); 
 
 