package com.htc.javafx;
	
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;


public class MySampMain extends Application {
	@Override
	public void start(Stage stage) {
	  try{	
		AnchorPane root = 
			(AnchorPane)FXMLLoader.load(this.getClass().getResource("mySamp.fxml"));
	    Scene scene = new Scene(root,300,300);
	    stage.setScene(scene);
	    stage.setTitle("Sample Application");
	    stage.show();
	  }catch(IOException ioe){
		  ioe.printStackTrace();
	  }
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
