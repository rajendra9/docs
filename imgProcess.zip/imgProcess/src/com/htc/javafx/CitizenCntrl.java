package com.htc.javafx;

import com.htc.javafx.utils.CitizenDTO;
import com.htc.javafx.utils.CitizensDAO;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class CitizenCntrl {

   @FXML //fx:id=citizenTbl
   TableView<CitizenDTO>  citizenTbl;

   @FXML  //fx:id=adharIdCol
   TableColumn<CitizenDTO,String>  adharIdCol;

   @FXML  //fx:id=regNameCol
   TableColumn<CitizenDTO,String>  regNameCol;

   @FXML  //fx:id=jobCol
   TableColumn<CitizenDTO,String>  jobCol;

   @FXML  //fx:id=dobCol
   TableColumn<CitizenDTO,String>  dobCol;

   @FXML  //fx:id=incomeCol
   TableColumn<CitizenDTO,Double>  incomeCol;

   @FXML  //fx:id=pincodeCol
   TableColumn<CitizenDTO,Integer>  pincodeCol;


   @FXML //fx:id=show
   Button show;

   CitizensDAO citizensDao;
   double tableWidth;
   @FXML
   public void initialize(){
      citizensDao = new CitizensDAO();

      show.setOnAction(new EventHandler<ActionEvent>(){
         public void handle(ActionEvent evt){
           ObservableList<CitizenDTO> list = citizensDao.getCitizens();
           FXCollections.sort(list);
           SortedList<CitizenDTO> sortedList = new SortedList<>(list);
           citizenTbl.setItems(sortedList);
           sortedList.comparatorProperty().bind(citizenTbl.comparatorProperty());
           tableWidth = citizenTbl.getWidth();

           System.out.println(tableWidth);

           adharIdCol = new TableColumn<CitizenDTO,String>("Adhar Id");
           adharIdCol.setCellValueFactory(new PropertyValueFactory("adharId"));
           adharIdCol.setPrefWidth(tableWidth/6);

           regNameCol = new TableColumn<CitizenDTO,String>("Reg Name");
           regNameCol.setCellValueFactory(new PropertyValueFactory("regName"));
           regNameCol.setPrefWidth(tableWidth/6);

           jobCol = new TableColumn<CitizenDTO,String>("Job");
           jobCol.setCellValueFactory(new PropertyValueFactory("job"));
           jobCol.setPrefWidth(tableWidth/6);


           dobCol = new TableColumn<CitizenDTO,String>("Dob");
           dobCol.setCellValueFactory(new PropertyValueFactory("dob"));
           dobCol.setPrefWidth(tableWidth/6);

           incomeCol = new TableColumn<CitizenDTO,Double>("Income");
           incomeCol.setCellValueFactory(new PropertyValueFactory("income"));
           incomeCol.setPrefWidth(tableWidth/6);


           pincodeCol = new TableColumn<CitizenDTO,Integer>("Pincode");
           pincodeCol.setCellValueFactory(new PropertyValueFactory("pincode"));
           pincodeCol.setPrefWidth(tableWidth/6);

           citizenTbl.getColumns().setAll(adharIdCol,regNameCol,jobCol,dobCol,incomeCol,pincodeCol);
           //citizenTbl.requestFocus();
         }

      });
   }
}
