package com.htc.javafx.utils;

import java.io.Serializable;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableListBase;

public class CitizensDAO implements Serializable {
    ObservableList<CitizenDTO> citizens;
    
    {
      citizens = FXCollections.observableArrayList();
      CitizenDTO dto = new CitizenDTO("C2311","Manishankar","BusinessMan","12-04-1987",45000.0,600023);
      citizens.add(dto);
      dto = new CitizenDTO("C5432","Mridula","SGovt Service","10-06-1988",38000.0,600032);
      citizens.add(dto);
      dto = new CitizenDTO("C5477","Manishankar","CGovt Service","21-03-1989",29000.0,600020);
      citizens.add(dto);
      dto = new CitizenDTO("C1321","Girija","Pvt Service","15-08-1989",34000.0,600023);
      citizens.add(dto);
      dto = new CitizenDTO("C9856","Sankar","SGovt Service","28-02-1985",23000.0,600017);
      citizens.add(dto);
      dto = new CitizenDTO("C6546","MuraliKrishna","CGovt Service","22-07-1987",21000.0,600019);
      citizens.add(dto);
      dto = new CitizenDTO("C8767","Vinod kumar","BusinessMan","18-06-1988",45000.0,600047);
      citizens.add(dto);
      dto = new CitizenDTO("C3385","Daruwala","SGovt Service","19-07-1989",42000.0,600016);
      citizens.add(dto);
      dto = new CitizenDTO("C4449","Christino","CGovt Service","22-07-1987",31000.0,600024);
      citizens.add(dto);
      dto = new CitizenDTO("C6363","Syed Basha","Pvt Service","18-03-1988",39000.0,600041);
      citizens.add(dto);
      dto = new CitizenDTO("C2232","Sivaram","Pvt Service","19-02-1987",61000.0,600046);
      citizens.add(dto);            
    }

    public ObservableList<CitizenDTO> getCitizens() {
        return citizens;
    }

    public void setCitizens(ObservableList<CitizenDTO> citizens) {
        this.citizens = citizens;
    }
    

}
