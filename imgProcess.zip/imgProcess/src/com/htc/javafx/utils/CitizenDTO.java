package com.htc.javafx.utils;

import java.io.Serializable;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class CitizenDTO implements Serializable,Comparable<CitizenDTO> {
    private  StringProperty   adharId;
    private  StringProperty   regName;
    private  StringProperty   job;
    private  StringProperty   dob;
    private  IntegerProperty  pincode;
    private  DoubleProperty   income;
    
       
    @Override
    public int compareTo(CitizenDTO other) {
       return this.getAdharId().compareTo(other.getAdharId());
    }
    
    public StringProperty  adharIdProperty(){
       if(adharId==null){
         adharId = new SimpleStringProperty(this,"adharId");  
       }
       return adharId;
    }
    public StringProperty  regNameProperty(){
        if(regName==null){
          regName = new SimpleStringProperty(this,"regName");  
        }
        return regName;
    }
    
    public StringProperty  jobProperty(){
        if(job==null){
          job = new SimpleStringProperty(this,"job");  
        }
        return job;
    }
    public StringProperty  dobProperty(){
        if(dob==null){
          dob = new SimpleStringProperty(this,"dob");  
        }
        return dob;
    }
    public IntegerProperty  pincodeProperty(){
        if(pincode==null){
          pincode = new SimpleIntegerProperty(this,"pincode");  
        }
        return pincode;
    }
    public DoubleProperty incomeProperty(){
        if(income==null){
            income = new SimpleDoubleProperty(this,"income");  
          }
         return income; 
    }
    
    
    public String getAdharId() {
        return adharIdProperty().get();
    }


    public void setAdharId(String newVal) {
        adharIdProperty().set(newVal);
    }
    
    public String getRegName() {
        return regNameProperty().get();
    }


    public void setRegName(String newVal) {
        regNameProperty().set(newVal);
    }


    public String getJob() {
        return jobProperty().get();
    }


    public void setJob(String newVal) {
        jobProperty().set(newVal);
    }


    public String getDob() {
        return dobProperty().get();
    }


    public void setDob(String newVal) {
        dobProperty().set(newVal);
    }

    public int getPincode() {
      return this.pincodeProperty().get();
    }


    public void setPincode(int newVal) {
        this.pincodeProperty().set(newVal);
    }


    public double getIncome() {
        return incomeProperty().get();
    }


    public void setIncome(double newVal) {
        this.incomeProperty().set(newVal);
    }   
    
    public CitizenDTO() {
       
    }
    
    public CitizenDTO(String adharId,
                      String regName,
                      String job,
                      String dob,
                      double income,
                      int pincode){
       this.setAdharId(adharId);
       this.setDob(dob);
       this.setIncome(income);
       this.setRegName(regName);
       this.setPincode(pincode);
       this.setJob(job);
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((adharId == null) ? 0 : adharId.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CitizenDTO other = (CitizenDTO) obj;
        if (adharId == null) {
            if (other.adharId != null)
                return false;
        } else if (!adharId.equals(other.adharId))
            return false;
        return true;
    }
    @Override
    public String toString() {
       StringBuilder sb = new StringBuilder();
       sb.append("AdharId-"+this.getAdharId());
       sb.append(" RegName-"+this.getRegName());
       sb.append(" Job-"+this.getJob());
       sb.append(" Dob-"+this.getDob());
       sb.append(" Income-"+this.getIncome());
       sb.append(" Pincode-"+this.getPincode());
       return sb.toString();        
    }
    
    

}
