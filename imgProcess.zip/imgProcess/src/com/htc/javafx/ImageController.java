package com.htc.javafx;


import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;


public class ImageController {

    @FXML
    private ImageView srcImg;

    @FXML
    private ImageView targetImg;

    @FXML
    private Button changeBtn;

    @FXML
    void initialize(){
        changeBtn.setOnAction((e)->{
            Image src = srcImg.getImage();
            PixelReader piReader = src.getPixelReader();
            int ht = (int)src.getHeight();
            int wd = (int)src.getWidth();
            WritableImage dest  = new WritableImage(wd, ht);
            PixelWriter piWriter = dest.getPixelWriter();
            for(int i=0;i<ht;i++){
                for(int j=0;j<wd;j++){
                  Color colr = piReader.getColor(j,i);
                  piWriter.setColor(i, j, colr.brighter());
                }
            }
            targetImg.setImage(dest);
            });
    }

}
