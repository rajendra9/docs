package com.htc.javafx;

import java.io.IOException;
import java.net.URL;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;

import javafx.scene.layout.BorderPane;


public class ImageChangeMain extends Application {
    @Override
    public void start(Stage stage) {
      try{
            BorderPane root =
                    (BorderPane)FXMLLoader.load(this.getClass().getResource("imgChange.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Image Change Application");
        stage.show();
      }catch(IOException ioe){
              ioe.printStackTrace();
      }
    }

    public static void main(String[] args) {
            launch(args);
    }
}
