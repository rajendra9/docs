package com.htc.javafx;

import javafx.animation.FadeTransition;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.util.Duration;


public class AnimCntrl {
    
   @FXML //fx:id=mall
   ImageView  mall;
   
   @FXML //fx:id=animate
   Button animate;
   
   
   @FXML
   public void initialize(){
       
      animate.setOnAction(new EventHandler<ActionEvent>(){
         public void handle(ActionEvent evt){
           FadeTransition transition = new FadeTransition(Duration.millis(3000),mall);
           transition.setFromValue(1.0);
           transition.setToValue(0.1);
           transition.setCycleCount(Timeline.INDEFINITE);
           transition.setAutoReverse(true);
           transition.play();
         }
          
      }); 
   }
}
