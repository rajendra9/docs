const app = new Vue({
  el: '#showif-app',
  data:{
    isCorrect: true,
    isWrong: false   
  },
  methods:{
    change: function(){
      this.isCorrect = false;
      this.isWrong = true;
    }
   
  }
});
