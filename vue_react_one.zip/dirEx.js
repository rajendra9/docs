const app = new Vue({
  el: '#dir-app',
  data:{
    isCorrect: false,
    hello: 'Hello World',
    keka: 'This is Directive',
    noKeka: 'This is No directive'
  },
  methods:{
    show: function(){
      this.hello= 'Happy Event';
      this.isCorrect = true;
    },
   
  }
});
