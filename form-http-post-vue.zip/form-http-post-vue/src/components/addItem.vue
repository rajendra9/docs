<template>
  <div id="add-item">
    <h2>Create a new Item</h2>
    <form>
        <table>
          <tr>
            <td>Enter Item Id:</td>
            <td><input type="text" v-model.lazy="item.item_id" /></td>
          </tr>
          <tr>
            <td>Enter Item Name:</td>
            <td><input type="text" v-model.lazy="item.item_name" /></td>
          </tr>
          <tr>
            <td>Select Item Type:</td>
            <td><select class="mySelect" v-model.lazy="item.item_type">
                <option>---choose---</option>
                <option v-for="(itType,index) in itemTypes" v-bind:key="index">{{itType}}</option>
                </select>  
            </td>    
          </tr>    
          <tr>
            <td>Enter Item Cost:</td>
            <td><input type="text" v-model.lazy="item.item_cost" /></td>
          </tr>
       
          </table>
          
          <div id="radios">
            <label> Choose Customer Name:</label>
             <ul >
               <li  v-for="(cust,index) in knownCustomers" v-bind:key="index">
                 <input type="radio" name="customer" v-bind:value="cust"  v-model="item.customer" />
                 <label>{{cust}}</label>
               </li>               
             </ul>  
          </div>
         <div class="buttons"><button v-on:click.prevent="saveItem">Save Item</button></div>         
    </form> 
    <div v-if="submitted">
        {{restResult}}
    </div>     
    <div id="preview">
        <h3> Item Preview</h3>
        <p> Item-Id: {{item.item_id}}</p>
        <p> Item-Name: {{item.item_name}} </p>
        <p> Item-Cost: {{item.item_cost}} </p>
        <p> Item-Type: {{item.item_type}} </p>        
        <p> Customer: {{item.customer}} </p>

    </div>
    
  </div>
</template>

<script>

export default {
  data(){
      return{
         item: {
             item_id:'',
             item_name:'',
             item_cost:0.0,
             item_type:'',
             customer:''
         },
         submitted: false,
         restResult:'',
         knownCustomers: ['M/s Sampath Electronics', 'M/s PanneerDas Dresses', 'M/s Sameer Decors', 'M/s Kumaran Sales'],
         itemTypes: ['Electronics', 'Furniture', 'Cosmetics', 'Dressware', 'Footware']
      }
  },
  methods:{
      saveItem: function(){
          this.$http.post('http://localhost:9090/vuerest/rest/items/saveItem',this.item)
                    .then(function(data){
                        this.submitted = true;
                        this.restResult=data.bodyText;
                    });
      }
   }
}
</script>

<style scoped>
#add-item *{
    box-sizing: border-box;
}
#add-item{
    margin: 15px auto;
    max-width: 550px;
}
label{
    display: block;
    margin: 20px 0 10px;
}
input[type="text"] {
    display: block;
    width: 100%;
    padding: 8px;
}
#preview{
    padding: 10px 20px;
    border: 1px dotted #ccc;
    margin: 30px 0;
}
h3{
    margin-top: 10px;
}
#radios label{
    margin: 0;
}
#radios ul{
    margin-top:1px;
    margin: 0;
    list-style-type: none;
}   
#radios ul li{
    margin: 0px; 
}  
#radios ul li input{
    margin: 0; 
}  

#radios ul li label{
    margin: 2px;
    display: inline-block;
    padding: 2px;
}
button{
    margin-top: 2px;
    width: 110px;
    height: 40px;
    border: 2px solid;
    text-align: center;
}
.buttons{
    margin-left: 100px;
    margin-top: 5px;
}
.mySelect{
    width: 175px;
    height: 40px;
}
</style>
