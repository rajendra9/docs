import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MatButtonModule, MatDatepickerModule, MatInputModule, MatNativeDateModule, MatFormFieldModule, MatCheckboxModule, MatListModule, MatCardModule } from '@angular/material';
import { AppComponent } from './app.component';
import { AssignmentsComponent } from './assignments/assignments.component';
import { SubmittedDirective } from './shared/submitted.directive';
import {BrowserAnimationsModule}  from '@angular/platform-browser/animations';
import { FormsModule }    from '@angular/forms';
import { AssignmentDetailComponent } from './assignments/assignment-detail/assignment-detail.component';
import { AddAssignmentComponent } from './assignments/add-assignment/add-assignment.component';

@NgModule({
  declarations: [
    AppComponent,
    AssignmentsComponent,
    SubmittedDirective,
    AssignmentDetailComponent,
    AddAssignmentComponent
    
  ],
  imports: [
    BrowserModule, FormsModule, MatDatepickerModule, MatNativeDateModule, MatCheckboxModule, MatButtonModule, MatInputModule, MatCardModule, MatFormFieldModule, MatListModule, BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
