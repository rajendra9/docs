import { Component, OnInit } from '@angular/core';
import { Assignment }  from './assignment';

@Component({
  selector: 'app-assignments',
  templateUrl: './assignments.component.html',
  styleUrls: ['./assignments.component.css']
})
export class AssignmentsComponent implements OnInit {
  title:string = "My Assignments Application";
 
  enabled :boolean = false;
  formVisible: boolean = false;
  selectedAssignment: Assignment;

  assignments: Assignment[] = [{
    name: 'First',
    due_date: new Date('2019-02-04'),
    submitted: true
  },
{
  name: 'Second',
  due_date: new Date('2019-03-02'),
  submitted: false
},
{
  name: 'Third',
  due_date: new Date('2019-03-05'),
  submitted: false
} ];
  constructor() { }

  ngOnInit() {
    setTimeout(()=>{
      this.enabled = true;
    }, 2000);
  }
 
  setSelected(assignment : Assignment){
    this.selectedAssignment = assignment;
  }

  onAddBtnClick(){
    this.formVisible = true;
    this.selectedAssignment = null;
  }

  onNewAssignment(event: Assignment){
   this.assignments.push(event);
   this.formVisible = false;
  }
}
