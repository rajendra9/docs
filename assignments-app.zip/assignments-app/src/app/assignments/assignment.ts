export class Assignment {
    name: string;
    due_date: Date;
    submitted?:boolean;
}