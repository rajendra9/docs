drop table if exists springemps;

create table springemps as
 select empno as emp_id,ename as emp_name,job,coalesce(comm,0) as emp_comm,
 sal as emp_sal,deptno as dept_id from emp;
 
alter table springemps add constraint sampemps4_PK primary key(emp_id);

alter table springemps alter column job  type varchar(16);

alter table springemps alter column emp_sal type decimal(9,2);

alter table springemps alter column emp_comm set default 0.0;

delete from springemps
where dept_id is null;

 
