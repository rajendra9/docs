package testing;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import trans.ItemTransDao;


public class TestItemTransDao {
 
  
  public static void main(String[] args) {
   try {   
	   AnnotationConfigApplicationContext factory =
        new AnnotationConfigApplicationContext(trans.ItemJdbcConfig.class);
        
    ItemTransDao dao = 
           (ItemTransDao)factory.getBean("itemTransDao"); 
    String ret = dao.createItemAndOrder(101, "Pin20", 201.5, 1000, 10, 101, "M/s Star Auto Traders");
    System.out.println(ret);
    
    ret = dao.createItemAndOrder(111, "Bush80", 102.5, 1010, 20, 111, "M/s Vinay Auto Stores");
    System.out.println(ret);
    
    dao.showDetails();
    ret = dao.createItemAndOrder(121, "Rings", 452.5, 1020, 20, 141, "M/s Bhasha Traders");
    System.out.println(ret);
    
    dao.showDetails(); 
    factory.close();
   }
   catch(Exception e) {
         e.printStackTrace();
   }
 } 

}