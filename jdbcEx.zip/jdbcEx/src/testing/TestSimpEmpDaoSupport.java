package testing;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.List;

import sprjdbc.SpringEmp;
import sprjdbc.SpringEmpDao;



public class TestSimpEmpDaoSupport {
 
  
  public static void main(String[] args) {
   try {   
	   AnnotationConfigApplicationContext factory =
        new AnnotationConfigApplicationContext(sprjdbc.SpringEmpJdbcConfig.class);
        
    SpringEmpDao dao = 
           (SpringEmpDao)factory.getBean(sprjdbc.SpringEmpDaoSupport.class); 
    SpringEmp emp = new SpringEmp(2224, "Sandesh", "SALESMAN", 24010.5, 30);
    emp.setEmpComm(120.0);
    boolean boo = dao.addEmp(emp);
    System.out.println("New Employee with 2224 empid is inserted:" + boo);
    System.out.println("\nSearching");
    System.out.println(dao.findEmployee(7654));
    System.out.println("\nQuerying for All Employees");
    List<SpringEmp> empList = dao.getAll();
    empList.forEach(System.out::println);
    boolean isUpdated = dao.updateEmpSalary(7900, 1250.0);
    System.out.println("\n" + isUpdated + "\n");
    empList = dao.getAll();
    empList.forEach(System.out::println);
    
    System.out.println("\nExecuting a procedure ");
    dao.performCall(7654);
    factory.close();
   }
   catch(Exception e) {
         e.printStackTrace();
   }
 } 

}