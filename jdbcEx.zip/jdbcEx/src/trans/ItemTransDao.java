package trans;

import java.io.Serializable;


public interface ItemTransDao extends Serializable {
	
	String SQL_ALL = "select order_id, order_date,item_name,customer,"+
            " order_qty * item_cost as total_cost from item_trans natural join item_master";
    
	String ITEM_MASTER_ROW_CREATE = "insert into item_master values(?,?,?)";
    
	String ITEM_TRANS_ROW_CREATE = "insert into item_trans values(?,?,?,?,?)";
    
	public String createItemAndOrder(int itemId, String itemName, double cost, int orderId, int orderQty,int transItemId, String customer);
    
	public void showDetails();
    
}
    
