package sprjdbc;

import java.util.List;

public interface SpringEmpDao {

 public void performCall(int eno);
 
 public boolean updateEmpSalary(int empId, double newSalary);
 
 public boolean addEmp(SpringEmp emp);
 
 public SpringEmp findEmployee(int eno);
 
 public List<SpringEmp> getAll();
 
 
}

