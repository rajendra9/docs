package sprjdbc;


public class SpringEmp {
 
 private int empId;
 private String empName;
 private String job;
 private double empSal;
 private double empComm;
 private int deptId;
  
 public String getJob(){
  return this.job;
 }
 
 public void setJob(String job){
  this.job = job;
 } 

 public int hashCode(){
  final int prime = 31;
  int result = 1;
  result = prime * result + this.empId;
  return result;
 }
 
 public boolean equals(Object obj){
  if (this == obj)
   return true;
  if (obj == null)
   return false;
  if (getClass() != obj.getClass())
   return false;
  SpringEmp other = (SpringEmp) obj;
  if (this.empId != other.empId)
   return false;
  return true;
 }
 
  public int getEmpId(){
  return this.empId;
 }
 
 public void setEmpId(int empId){
  this.empId = empId;
 }
 
 public String getEmpName(){
  return this.empName;
 }
 
 public void setEmpName(String empName){
  this.empName = empName;
 }
 
 public SpringEmp() {
 }
 
 public int getDeptId(){
  return this.deptId;
 }
 
 public void setDeptId(int deptId){
  this.deptId = deptId;
 }

 public SpringEmp(int empId, String empName, String job,
                  double empSal, int deptId) {
   super();
   this.empId = empId;
   this.empName = empName;
   this.job = job;
   this.empSal = empSal;
   this.deptId = deptId;
 }

 public double getEmpComm() {
	return empComm;
 }

 public void setEmpComm(double empComm) {
	this.empComm = empComm;
 } 

 public double getEmpSal(){
     return this.empSal;
 }

 
 public void setEmpSal(double empSal){
   this.empSal = empSal;
 }

 @Override
 public String toString() {
     return "SampEmp4 [empId=" + empId + ", empName=" + empName + ", job=" + job + ", empSal=" + empSal + ", empComm="
			+ empComm + ", deptId=" + deptId + "]";
 }

 

}