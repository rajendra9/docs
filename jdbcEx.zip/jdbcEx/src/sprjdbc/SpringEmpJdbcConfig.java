package sprjdbc;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@PropertySource("file:./jdbc.properties")
@Configuration
@ComponentScan
public class SpringEmpJdbcConfig  {
 
	@Autowired
	Environment env;
	
	@Bean(name="dataSource")
    public DataSource dataSource() {
     DriverManagerDataSource ds =
             new DriverManagerDataSource();   
     String driverCl = env.getProperty("db.driver");
     ds.setDriverClassName(driverCl);
     ds.setUrl(env.getProperty("db.url"));
     //System.out.println(env.getProperty("db.password"));
     ds.setUsername(env.getProperty("db.username"));
     ds.setPassword(env.getProperty("db.password"));
     System.out.println("***"+ds);
     return ds;
    }  	
	
    

 
 
 
}