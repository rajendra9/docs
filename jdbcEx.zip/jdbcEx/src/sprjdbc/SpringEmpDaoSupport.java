package sprjdbc;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Component;

@Component
public class SpringEmpDaoSupport implements SpringEmpDao {
  private static final String SQL_ALL = 
	  "select emp_id, emp_name, job, emp_sal, emp_comm, dept_id from springemps";
	
  
  DataSource dataSource;
  
  @Autowired(required=true)
  public void setDataSource(DataSource ds) {
	this.dataSource = ds;  
  }
  
  JdbcTemplate jdbcTemplate;
  
  @Autowired(required=true)
  public void setJdbcTemplate(DataSource ds) {
	 this.jdbcTemplate = new JdbcTemplate(dataSource);
  }
  
 public boolean addEmp(SpringEmp emp){
  SimpleJdbcInsert insert =  new SimpleJdbcInsert(dataSource);
  int result = insert.withTableName("springemps")
     .usingColumns("emp_id","emp_name","job","emp_sal","emp_comm", "dept_id")
    .execute(new BeanPropertySqlParameterSource(emp));
  System.out.println("insert is:"+result);
  return true;
 }
 
 public SpringEmp findEmployee(int eno){
   String objSql = "select emp_id,emp_name,job,emp_sal, emp_comm,"+
                  " dept_id from springemps "+
                  " where emp_id=?";
   Object[] params = {new Integer(eno)};
   Map<String,Object> rowMap = this.jdbcTemplate.queryForMap(objSql, params); 
   SpringEmp ret = this.mapRowToObject(rowMap);	  
   return ret; 
 }
 
 private SpringEmp mapRowToObject(Map<String,Object> rowMap) {
	 SpringEmp ret = new SpringEmp();
	 ret.setEmpId((Integer)rowMap.get("emp_id"));
	 ret.setEmpName((String)rowMap.get("emp_name")); 
     ret.setJob((String)rowMap.get("job"));	    
     ret.setEmpSal(((BigDecimal)rowMap.get("emp_sal")).doubleValue());
     ret.setEmpComm(((BigDecimal)rowMap.get("emp_comm")).doubleValue());	
     ret.setDeptId((Integer)rowMap.get("dept_id"));   	
	 return ret;	
 }

 public boolean updateEmpSalary(int empId, double newSalary) {
     String sqlStr = "update springemps set  emp_sal = ? where emp_id=?";
     
     int rows = this.jdbcTemplate.update(sqlStr, new Double(newSalary), new Integer(empId));
     
     if(rows == 1) {
  	   return true;
     }
     return false;
  }    

 
 
 public List<SpringEmp> getAll(){
   List<SpringEmp> ret = new ArrayList<>();
   List<Map<String, Object>> rowMapList = 
		     this.jdbcTemplate.queryForList(SQL_ALL);     
   System.out.println(rowMapList); 
   for(Map<String,Object> rowMap : rowMapList) {
    	 SpringEmp obj = this.mapRowToObject(rowMap);
    	 ret.add(obj);
     }
     return ret;
 }
 	 
 
 
 public void performCall(int eno) {
  SimpleJdbcCall call = 
      new SimpleJdbcCall(dataSource);
  call = call.withProcedureName("sendpaydtls");
  call.declareParameters(new SqlParameter("eno",Types.INTEGER));
  call.declareParameters(new SqlOutParameter("salary",Types.NUMERIC));
  call.declareParameters(new SqlOutParameter("commission",Types.NUMERIC));
  Map<String,Object> params =
     new HashMap<String,Object>();
  params.put("ENO", eno);
  Map<String,Object> results = 
       call.execute(params);
  System.out.println("Salary:"+results.get("salary"));
  System.out.println("Commission:"+results.get("commission"));
 }

}