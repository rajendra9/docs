drop function if exists sendpaydtls(in eno integer,out salary decimal(10,2), out commission decimal(10,2));

create function sendpaydtls(in eno integer,out salary decimal(10,2), out commission decimal(10,2)) as $$
declare
       x integer;      
begin
      select count(1) into x from springemps 
       where emp_id=$1;
      if(x=0) then
       salary:=0;
       commission:=0; 
      else
        select emp_sal*12,coalesce(emp_comm,0)*12 into salary,commission from springemps 
         where emp_id=$1;
      end if;
    return ;
end;
$$ LANGUAGE plpgsql;
