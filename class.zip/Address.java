package Lambdas;

import java.io.Serializable;

public class Address implements Serializable {
  private  String  houseNum;
  private  String  street;
  private  String  area;
  private  String  city;
  private  String  state;
  private  String  pincode;
  
  public Address() {
	super();	
  }

  public Address(String houseNum, 
		       String street, 
		       String area, 
		       String city,
		       String state, 
		       String pincode) {
	 super();
	 this.houseNum = houseNum;
	 this.street = street;
	 this.area = area;
	 this.city = city;
	 this.state = state;
	 this.pincode = pincode;
  }

  public String getHouseNum() {
	 return houseNum;
  }

  public void setHouseNum(String houseNum) {
	 this.houseNum = houseNum;
  }

  public String getStreet() {
	  return street;
  }

  public void setStreet(String street) {
	this.street = street;
  }

  public String getArea() {
	 return area;
  }

  public void setArea(String area) {
	 this.area = area;
  }

  public String getCity() {
	 return city;
  }

  public void setCity(String city) {
	 this.city = city;
  }

  public String getState() {
	 return state;
  }

  public void setState(String state) {
	 this.state = state;
  }

  public String getPincode() {
	 return pincode;
  }

  public void setPincode(String pincode) {
	 this.pincode = pincode;
  }

   @Override
   public int hashCode() {
	 final int prime = 31;
	 int result = 1;
	 result = prime * result + ((houseNum == null) ? 0 : houseNum.hashCode());
	 result = prime * result + ((state == null) ? 0 : state.hashCode());
	 return result;
   }

   @Override
   public boolean equals(Object obj) {
	 if (this == obj)
		 return true;
	 if (obj == null)
		 return false;
	 if (getClass() != obj.getClass())
	     return false;
	 Address other = (Address) obj;
	 if (houseNum == null) {
	     if (other.houseNum != null)
			return false;
	 } else if (!houseNum.equals(other.houseNum))
		return false;
	 if (state == null) {
	   if (other.state != null)
			return false;
	 } else if (!state.equals(other.state))
	 	return false;
	  return true;
   }

   @Override
   public String toString() {
     	return "[houseNum=" + houseNum + ", street=" + street + ", area="
	           + area + ", city=" + city + ", state=" + state + ", pincode="
			   + pincode + "]";
   }
  
  
}
