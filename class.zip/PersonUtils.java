package Lambdas;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PersonUtils implements Serializable {
   List<Person>  persons;
   
  {
   persons = new ArrayList<>();
   Address address = 
	  new Address("34A", "Green Park Road", "Anna Nagar","Chennai", "Tamilnadu", "600001");
   Person person = new Person("SamyNathan", "Civil Contractor", address, 9854362254L);
   persons.add(person);
   
   address =     
   new Address("21/32S", "church Road", "Besant Nagar","Chennai", "Tamilnadu", "600012");
   person = new Person("Sethu Madhavan", "Architect", address, 9480160214L);
   persons.add(person);
   
   address =
   new Address("D213", "TVS stores Road", "Guindy","Chennai", "Tamilnadu", "600006");
   person = new Person("Nachiappan", "Excise Officer", address, 9498726254L);
   persons.add(person);
   
   address =
    new Address("4561D", "Pachiamman Kovil Street", "Tambaram","Chennai", "Tamilnadu", "600014");
   person = new Person("PalaniSamy", "Income Tax Officer", address, 9874324454L);
   persons.add(person);
   
   address =
    new Address("21/34AA", "Kopperundevi Road", "Chromepet","Chennai", "Tamilnadu", "600044");
   person = new Person("Alazhanathan", "sub PostMaster", address, 98204622054L);
   persons.add(person);
   
   address =
   new Address("202A", "tangirala Park Road", "Besant Road","Vijayawada", "Andhra Pradesh", "520002");
   person = new Person("V.Subba Rao", "Jt Collector", address, 94565116875L);
   persons.add(person);
   
   address =
	new Address("211", "Near Sivan Koil", "Mada Street,Mylapore","Chennai", "Tamilnadu", "600004"); 
   person = new Person("S.Narayana Iyer", "Dist Judge",  address, 98765876875L);
   persons.add(person);   
   
   address =     
		   new Address("21/32S", "church Road", "Anna Nagar","Chennai", "Tamilnadu", "600007");
   person = new Person("Sethu Madhavan", "Team Leader", address, 9230180224L);
   persons.add(person);
  
  }

  public List<Person> getPersons() {
	return persons;
  }

  public void setPersons(List<Person> persons) {
	this.persons = persons;
  } 

  
  
}
