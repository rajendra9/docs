package Lambdas;

import java.io.Serializable;

public class Person implements Serializable {
    private  String  name;
    private  String  occupation;
    private  Address address;
    private  long    phoneNum;
    
	public Person() {
		super();
	}

	public Person(String name, String occupation, Address address, long phoneNum) {
		super();
		this.name = name;
		this.occupation = occupation;
		this.address = address;
		this.phoneNum = phoneNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public long getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(long phoneNum) {
		this.phoneNum = phoneNum;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (phoneNum ^ (phoneNum >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		if (phoneNum != other.phoneNum)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "[name=" + name + ", occupation=" + occupation
				+ ", address=" + address + ", phoneNum=" + phoneNum + "]";
	}
	

	
}
