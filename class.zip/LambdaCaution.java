package Lambdas;

public class LambdaCaution {
	
	public void meth1(String ... args) {
	/*	for(var i=0;i<args.length;i++) {
			new Thread(()-> System.out.println(args[i])).start();
		}
	*/
	}

	public void meth2(String ... args) {
	   for(String arg: args) {
			new Thread(()-> System.out.println(arg)).start();
	   }		
	}
	
	public static void main(String[] args) {
		LambdaCaution lambdaCaution = new LambdaCaution();
		lambdaCaution.meth2("Sriram", "Kesavan", "Kishan Mathur", "Abdullah");
	}

}
