package day7;

import java.util.LinkedHashMap;

/*the ordering mode - true for access-order,
 *  false for insertion-order
*/

public class LinkedMapDemo {

 public static void main(String[] args) {
   LinkedHashMap<String, Double> map = 
             new LinkedHashMap<String, Double>(20,0.80F,true);
    map.put("One", 543.2);
    map.put("Two", 553.2);
    map.put("Three", 563.2);
    map.put("Four", 573.2);
    map.put("Three", 666.2);
     
    System.out.println(map); 
    LinkedHashMap<String, Double> map2 = 
           new LinkedHashMap<String, Double>(20,0.80F,false);
     map2.put("One", 543.2);
     map2.put("Two", 553.2);
     map2.put("Three", 563.2);
     map2.put("Four", 573.2);
     map2.put("Three", 666.2);
     
     System.out.println(map2); 

	}

}
