package Lambdas;

import java.util.List;
import java.util.stream.Collectors;

import static java.util.Comparator.*;

import java.util.Collections;

public class PersonsCompare {

	
	public static void main(String[] args) {
		List<Person> persons = new PersonUtils().getPersons();
		Collections.sort(persons, comparing(Person::getName).thenComparing(Person::getPhoneNum));
	    persons.forEach(System.out::println);
	}

}
