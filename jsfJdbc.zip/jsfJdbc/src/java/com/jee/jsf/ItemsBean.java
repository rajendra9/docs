package com.jee.jsf;


import com.jee.jsf.utils.ItemDao;
import com.jee.jsf.utils.JdbcItemTO;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;
import com.jee.jsf.utils.JdbcItemManipulator;
import java.util.ArrayList;
import java.util.List;

@Named("itemBean")
@SessionScoped
public class ItemsBean implements java.io.Serializable {
     
    ItemDao dao = new JdbcItemManipulator();        
   
    JdbcItemTO  jdbcItem = new JdbcItemTO();
   
    int itemId;
    
    String resultMsg;

    List<JdbcItemTO> items = new ArrayList<>();

    public List<JdbcItemTO> getItems() {
        return items;
    }

    public void setItems(List<JdbcItemTO> items) {
        this.items = items;
    }
    
    public JdbcItemTO getJdbcItem() {
        return jdbcItem;
    }

    public int getItemId() {
        return itemId;
    }

    public String getResultMsg() {
        return resultMsg;
    }

    public void setJdbcItem(JdbcItemTO jdbcItem) {
        this.jdbcItem = jdbcItem;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }
    
    public String insertItem(){
        boolean result = this.dao.addJdbcItemTO(jdbcItem);
        if(result){
            this.setResultMsg(" JdbcItemTO with id:" + jdbcItem.getItemId() + 
                    " has been saved successfully ");
            this.jdbcItem = new JdbcItemTO();
            return "success";
        }
        return "failure";
    }
    
    public String listItems(){
        System.out.println("listing");
        List<JdbcItemTO> fetched = dao.getAllJdbcItems();
        System.out.println("&&&&&" + fetched);
        if(fetched.size()>0){
            this.setItems(fetched);
            return "listing";
        }
        return "failure";
    }
    
    public String searchItem(){
        
        JdbcItemTO result = this.dao.searchJdbcItemTO(this.itemId);
        
        if(result != null){
            this.setResultMsg("Searched Details:" + result.toString());
            this.itemId = 0;
            return "success";
        }
        return "failure";
    }
    public String updateItem(){
      boolean result = 
         this.dao.updateJdbcItemTO(jdbcItem.getItemId(), jdbcItem.getItemCost());
      if(result){
            this.setResultMsg(" JdbcItemTO with id:" + jdbcItem.getItemId() + 
                    " has been updated successfully ");
            this.jdbcItem = new JdbcItemTO();
            return "success";
        }
        return "failure";
    }
    public String deleteItem(){
        boolean result = this.dao.deleteJdbcItemTO(itemId);
        if(result){
            this.setResultMsg(" JdbcItemTO with id:" + itemId + 
                    " has been deleted successfully ");
            this.itemId = 0;
            return "success";
        }
        return "failure";
    }
}
