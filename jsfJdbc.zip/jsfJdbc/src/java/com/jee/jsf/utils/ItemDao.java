package com.jee.jsf.utils;

import java.sql.Connection;
import java.util.List;

public interface ItemDao {

    boolean addJdbcItemTO(JdbcItemTO item);

    boolean updateJdbcItemTO(int itemId, double newCost);

    boolean deleteJdbcItemTO(int itemId);

    JdbcItemTO searchJdbcItemTO(int itemId);

    List<JdbcItemTO> getAllJdbcItems();
    
   
}