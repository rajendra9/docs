package com.jee.jsf.utils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JdbcItemManipulator implements ItemDao {
    public static final String URL = "jdbc:postgresql://localhost:5432/samp";
    public static final String USERNAME = "postgres";
    public static final String PASSWORD = "mother";
      
    public Connection getConnection() {
       Connection conn = null;
        try {
         Class.forName("org.postgresql.Driver");
         conn = DriverManager.getConnection(URL,USERNAME, PASSWORD);
      }catch(ClassNotFoundException | SQLException ex) {
         ex.printStackTrace();
      } 
      return conn;
    }  
 
    public void closeConn(Connection conn) {
      try {
        conn.close();
      }catch(SQLException sqle) {
            sqle.printStackTrace();
      }
    }  
    
    @Override
    public boolean addJdbcItemTO(JdbcItemTO item) {
        Connection conn = null;
        boolean ret = false;
        String sql = "insert into jdbcitems values(?,?,?)";
        try {
         conn = this.getConnection();
         PreparedStatement pstmt = 
                 conn.prepareStatement(sql);
         pstmt.setInt(1,item.getItemId());
         pstmt.setString(2,item.getItemName());
         pstmt.setDouble(3, item.getItemCost());
         int recs = pstmt.executeUpdate();
         if(recs>0) {
             ret = true;
         }
       }catch(Exception e){
        e.printStackTrace();
       }
       finally {
           this.closeConn(conn); 
       }
       return ret;
     }
    
    
    @Override
    public boolean updateJdbcItemTO(int itemId, double newCost) {
        Connection conn = null;
        boolean ret = false;
        String sql = "update jdbcitems set item_cost=? "+
                      " where item_id= ?";
        try {
         conn = this.getConnection();
         PreparedStatement pstmt = 
                 conn.prepareStatement(sql);
          pstmt.setDouble(1, newCost );
          pstmt.setInt(2, itemId);
          int recs = pstmt.executeUpdate();
          if(recs>0) {
             ret = true;
          }
        }catch(Exception e){
          e.printStackTrace();
        }
        finally {
            this.closeConn(conn); 
        }
        return ret;
    }
    
    @Override
    public boolean deleteJdbcItemTO(int itemId) {
        boolean ret = false;
        Connection conn = null;
        String sql = "delete from jdbcitems where item_id= ?";
        try {
         conn = this.getConnection();
         PreparedStatement pstmt = 
                 conn.prepareStatement(sql);
         pstmt.setInt(1, itemId);
         int recs = pstmt.executeUpdate();
         if(recs>0) {
            ret = true;
         }
        }catch(Exception e){
          e.printStackTrace();
        }
        finally {
            this.closeConn(conn); 
        }
        return ret;
     }
        
    @Override
    public JdbcItemTO searchJdbcItemTO(int itemId) {
        JdbcItemTO ret = new JdbcItemTO();
        Connection conn = null;
        String sql = "select item_name,item_cost "+
                     " from jdbcitems where item_id= ?";
        try {
         conn = this.getConnection();
         PreparedStatement pstmt = 
                 conn.prepareStatement(sql);
         pstmt.setInt(1, itemId);
         ResultSet result = pstmt.executeQuery();
         if(result.next()) {
            ret.setItemId(itemId);
            ret.setItemName(result.getString(1));
            ret.setItemCost(result.getDouble(2));
         }
        }catch(Exception e){
          e.printStackTrace();
        }
        finally {
            this.closeConn(conn); 
        }
        return ret;
     }
       
    @Override
    public List<JdbcItemTO> getAllJdbcItems() {
        List<JdbcItemTO> ret = new ArrayList<JdbcItemTO>();
        JdbcItemTO item = null;
        Connection conn = null;
        String sql = "select item_id, item_name,item_cost "+
                     " from jdbcitems ";
        try {
         conn = this.getConnection();
         Statement stmt = 
                 conn.createStatement();
         ResultSet result = stmt.executeQuery(sql);
         while(result.next()) {
            item = new JdbcItemTO();
            item.setItemId(result.getInt(1));
            item.setItemName(result.getString(2));
            item.setItemCost(result.getDouble(3));
            ret.add(item); 
         }
        }catch(Exception e){
          e.printStackTrace();
        }
        finally {
            this.closeConn(conn); 
        }
        return ret;
     }
}