package com.htc.data;

import java.net.InetAddress;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.cassandra.config.AbstractCassandraConfiguration;
import org.springframework.data.cassandra.core.CassandraTemplate;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Session;

@Configuration
@EnableCassandraRepositories(basePackages="com.htc.data.domain")
public class SprCassConfig extends AbstractCassandraConfiguration {

	public static final String KEY_SPACE = "my_hr";
	
	@Override
	public  String getKeyspaceName() {
		return KEY_SPACE;
	}
	
    @Bean 
	public CassandraTemplate createSession() {
      Cluster cluster =  Cluster.builder().addContactPoints("127.0.0.1").build();   
    
      Session session = cluster.connect(KEY_SPACE);
      System.out.println("&&&&" + session);
      return new CassandraTemplate(session);
    }
    
	@Bean(name="cassService")
	public SprCassService  getSpringCassandraService() {
		return  new SprCassService();
	}


}
