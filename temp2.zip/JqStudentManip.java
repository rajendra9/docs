package myjqs.utils;

import java.io.Serializable;

import javax.json.JsonObject;

public interface JqStudentManip extends Serializable {
	
  public JsonObject  searchStudent(String stuId);
  public JsonObject saveStudent(String id, String name, String course, String naticveCity,int age);
  public void close();

}
