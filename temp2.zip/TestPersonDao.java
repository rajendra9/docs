package testing;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.htc.data.SprCassService;

public class TestPersonDao {

	public static void main(String[] args) {
	  try {   
		AnnotationConfigApplicationContext factory =
		      new AnnotationConfigApplicationContext(com.htc.data.SprCassConfig.class);
        SprCassService cassService = (SprCassService)factory.getBean("cassService");        
    	System.out.println(cassService);
    	System.out.println(cassService.findById(100).get()); 
    	cassService.close();
    	factory.close();
	    }catch(Exception ex) {
    	  ex.printStackTrace();	
    	}
	}
	
}
