package myjqs.utils;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="jqstudents")
public class JqStudentTo implements Serializable {
   
   private  String  stuId;
   private  String  stuName;
   private  String  course;
   private  String  nativeCity;
   private  int     age;
   
   public JqStudentTo() {
	super();
   }

   public JqStudentTo(String stuId, String stuName, String course, String nativeCity, int age) {
	  super();
	  this.stuId = stuId;
	  this.stuName = stuName;
	  this.course = course;
	  this.nativeCity = nativeCity;
	  this.age = age;
   }

   @Override
   public int hashCode() {
	 final int prime = 31;
	 int result = 1;
	 result = prime * result + ((stuId == null) ? 0 : stuId.hashCode());
	 return result;
   }

   @Override
   public boolean equals(Object obj) {
	  if (this == obj)
	     return true;
	  if (obj == null)
	     return false;
	  if (getClass() != obj.getClass())
		 return false;
	  JqStudentTo other = (JqStudentTo) obj;
	   if(stuId == null) {
	      if (other.stuId != null)
			return false;
	    }else if (!stuId.equals(other.stuId))
		  return false;
	    return true;
    }

   @Id
   @Column(name="stu_id")
   public String getStuId() {
	  return stuId;
   }

   public void setStuId(String stuId) {
	  this.stuId = stuId;
   }

   @Column(name="stu_name")
   public String getStuName() {
	   return stuName;
   }

   public void setStuName(String stuName) {
	   this.stuName = stuName;
   }

   @Column
   public String getCourse() {
	  return course;
   }

   public void setCourse(String course) {
	   this.course = course;
   }
   @Column(name="native_city")
   public String getNativeCity() {
	   return nativeCity;
   }

   public void setNativeCity(String nativeCity) {
	   this.nativeCity = nativeCity;
   }

   @Column
   public int getAge() {
	   return age;
   }

   public void setAge(int age) {
      this.age = age;
   }

   @Override
   public String toString() {
	  return "JqStudentTo [stuId=" + stuId + ", stuName=" + stuName + ", course=" + course + ", nativeCity=" + nativeCity
			+ ", age=" + age + "]";
   }  
   
}
