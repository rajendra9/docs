package day10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FileWriting {

	public static void main(String[] args)throws IOException {
		String sep = File.separator;
		File dir = new File("C:" + sep + "htc");
		if(!dir.exists()) {
			dir.mkdir();
		}
		File newFile = new File(dir, "sample.dat");
		if(!newFile.exists()) {
			newFile.createNewFile();
		}
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Content to be Saved");
		String content = scan.nextLine();
		byte[] bts = content.getBytes();
		FileOutputStream fout = new FileOutputStream(newFile);
		
		fout.write(bts);
        fout.close();
        
        FileInputStream fin = new FileInputStream(newFile);
        int c = 0;
        char ch = '\u0000';
       
        while((c = fin.read())!= -1) {
          ch = (char)c;
          System.out.print(ch +" ");
	    }
        fin.close();
	}

}
