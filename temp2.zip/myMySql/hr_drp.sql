DROP VIEW if exists emp_detls;

ALTER TABLE departments  drop  foreign key dept_mgr_fk;

ALTER TABLE departments
drop foreign key  dept_loc_fk;

ALTER TABLE employees
drop foreign key     emp_dept_fk;

ALTER TABLE employees
drop foreign key     emp_job_fk ;

ALTER TABLE employees
drop foreign key     emp_manager_fk;


ALTER TABLE job_history
drop FOREIGN KEY     jh_jb_fk;

ALTER TABLE job_history
drop    FOREIGN KEY  jh_emp_fk;

ALTER TABLE job_history
drop FOREIGN KEY     jh_dept_fk;

ALTER TABLE locations
drop FOREIGN KEY loc_c_id_fk;


ALTER TABLE countries
drop  FOREIGN KEY countr_reg_fk;
 
drop table if exists employees cascade;
drop table if exists job_history cascade;


drop table if exists countries cascade; 
drop table if exists regions cascade ;
drop table if exists locations cascade;
drop table if exists jobs cascade;
drop table if exists departments cascade;
