drop table if exists comm_services;

create table comm_services (service_id  varchar(20) primary key,
service_name  varchar(30),
done_date date,
doneBy varchar(30) ,
group_or_single  char(1), 
amount_charged decimal(10,3),
constraint  comm_chk1  check  (group_or_single in ('s','S','G','g')) 
);

DELIMITER $$
drop function if exists calc_service_tax;

create function calc_service_tax(service_id varchar(10)) 
returns decimal(11,3) reads SQL DATA
BEGIN
  DECLARE  ret  decimal(11,3);
  IF (service_id = 'bk_home_est_1100') THEN  
       set ret = 0.06;
  ELSEIF(service_id = 'cour_1200') THEN  
       set ret = 0.05;
  ELSEIF(service_id like  'bldg_const%' ) THEN  
       set ret = 0.095;
  ELSEIF(service_id  like  'tour_oper%' )  THEN
       set ret = 0.14;
  ELSE 
       set ret = 0.05;
  END IF;
  return ret;
end $$

DELIMITER ;
drop trigger if exists add_service_tax;

create trigger add_service_tax before insert on comm_services
for each row set NEW.amount_charged = (NEW.amount_charged+(NEW.amount_charged*(calc_service_tax(NEW.service_id))));

insert into comm_services values ('cour_1200', 'courier_400km',  '2015-02-26', 'Professional couriers', 'G', 13500.5);

insert into comm_services values ('bk_home_est_1100',  'Home Estimate',  '2015-03-28' ,'Mr.Panduranga Mohan',  'S',  6500.5);

insert into comm_services values ('bldg_const_1300', 'Builders''Plan preparation', '2015-03-30', 'M/s Chetan Architects', 'g', 155000.5);                                  
commit;

select * from comm_services;
