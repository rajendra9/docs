DELIMITER $$

create procedure get_emp_details(in eno integer,out en varchar(20),out jb varchar(20),out sa  float,out dn int)
DETERMINISTIC
begin
 declare cnt int default 0;
 select count(*) into cnt from emp where empno=eno;
 if(cnt>0) then
  select ename,job,sal,deptno into en,jb,sa,dn from emp where empno=eno;
 end if;
end$$
DELIMITER ;