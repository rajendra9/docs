DELIMITER |
CREATE  PROCEDURE simpProc(IN birdId INT,OUT output VARCHAR(20))
BEGIN
  DECLARE xx INT default 0;
  SELECT count(*) into xx from birds
  where bird_id = birdId;
  if(xx>0) then
   SELECT bird_name into output from birds
   where bird_id = birdId;
  end if;    
END;
|

