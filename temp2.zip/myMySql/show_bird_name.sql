DELIMITER $$
CREATE FUNCTION  show_bird_name(id integer) 
RETURNS  varchar(20) DETERMINISTIC
BEGIN
 DECLARE cnt INT default 0;
 DECLARE bname varchar(20); 
 select count(*)  into cnt from birds where bird_id=id;
 if(cnt>0) then
   select bird_name  into bname  from birds where bird_id=id;
 end if;
 return bname;  
END $$
DELIMITER ;
 
   
  