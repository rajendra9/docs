import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import com.mysql.jdbc.JDBC4CallableStatement;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
public class MultiResults {

    public static void main(String[] args) throws Exception{
        
       /* MysqlDataSource ds = new MysqlDataSource();
        ds.setPassword("prasad");
        ds.setUser("dtrprasad");
        ds.setServerName("localhost");
        ds.setDatabaseName("samp");
        ds.setPortNumber(3306); */
        
        Connection con = new MyDataSource("mysql").getConnection();
        CallableStatement cstmt = con.prepareCall("{call multi_stmts(?)}");
        cstmt.setInt(1, 20);
        boolean isExecuted = cstmt.execute();
        if(isExecuted){
          ResultSet rs = cstmt.getResultSet();
          while(rs.next()){
            System.out.print(rs.getString(1)+" ");
            System.out.println(rs.getString(2));            
          }
        }
        if(cstmt.getMoreResults()){
          ResultSet rs = cstmt.getResultSet();
          while(rs.next()){
            System.out.print(rs.getString(1)+" ");
            System.out.println(rs.getString(2));            
          }  
        }
        con.close();
    }

}
