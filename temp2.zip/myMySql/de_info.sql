DELIMITER  $$

drop procedure if exists dept_info; 

create procedure dept_info(in deptId integer,out tot_sal decimal(12,2),
out max_sal decimal(8,2),out min_sal decimal(12,2),out avg_sal decimal(10,2))
BEGIN
 DECLARE  xx integer;
  select count(*) into xx from dept where deptno=deptid;
  if(xx=1) then
    select sum(sal),max(sal),min(sal),avg(sal) into tot_sal,max_sal,min_sal,avg_sal from         emp where deptno=deptid;
  end if;
END $$

DELIMITER  ;

call dept_info(20,@totsal,@maxsal,@minsal,@avgsal);
select @totsal,@maxsal,@minsal,@avgsal; 