drop table if exists spr4emps;

create table spr4emps as
select employee_id emp_id,
concat(concat(first_name,' '),last_name) emp_name,
job_title  job,
hire_date hdate,
salary,
department_name as dept_name from
employees e, jobs j, departments d
where e.department_id = d.department_id and
e.job_id = j.job_id;