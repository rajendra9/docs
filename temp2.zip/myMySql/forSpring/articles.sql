DROP TABLE IF  EXISTS articles;

CREATE TABLE IF NOT EXISTS articles (
  article_id  serial primary key,
  title varchar(60) NOT NULL,
  category varchar(40) NOT NULL
  
); 
-- Dumping data for table concretepage.articles: ~3 rows (approximately)
INSERT INTO articles (title, category) VALUES
	( 'Java Concurrency', 'Java'),
	( 'Hibernate HQL ', 'Hibernate'),
	('Spring MVC with Hibernate', 'Spring'); 

