drop table soapsales;
create table soapsales(sale_id varchar(20) primary key,sale_date date,
soap_name varchar(15),soap_cost decimal(5,2),qty int not null);

insert into soapsales(sale_id, sale_date,soap_name ,soap_cost ,qty) values 
(1021, '2015-03-21','Lux', 32.5, 4),
(1022, '2015-03-23','Marvel', 35.5, 3),
(1023, '2015-03-24','Dove', 41.3, 4);

commit;
DELIMITER $$

drop function if exists getCollectedTax;

create function getCollectedTax(saleid VARCHAR(15))
returns DECIMAL(8,2) reads SQL  DATA

BEGIN

   DECLARE tot_tax DECIMAL(8,2);
  
   DECLARE continue handler for not found set  tot_tax = 0.0;
  
   select (soap_cost *qty*0.5) into tot_tax  from soapsales 
   where sale_id = saleid;
   return tot_tax;

END $$
 
DELIMITER ;  

select getCollectedTax(1021);
select getCollectedTax(1022);
select getCollectedTax(1023);
 