import java.sql.SQLException;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.Types;
import com.htc.javaee.utils.MyDataSource;
import java.util.Scanner;

public class JdbcProcDemo {

 public static void main(String[] args) 
  throws SQLException,ClassNotFoundException {
  Scanner scan = new Scanner(System.in);
 
  String dbSrc = "",tbl = "";
  MyDataSource ds = null;
  try { 
   ds = new MyDataSource("mysql");  

   Connection conn = ds.getConnection();
   
   CallableStatement cstmt = conn.prepareCall("{call simpProc(?,?)}");
   System.out.println("enter an existing bird_id");

   int birdId = Integer.parseInt(scan.nextLine());

   cstmt.setInt(1,birdId);
   cstmt.registerOutParameter(2,Types.VARCHAR);

   cstmt.executeUpdate();     

   System.out.println(cstmt.getString(2));
        
   conn.close();
  }
  catch(Exception e) {
      e.printStackTrace();
  }
 }

}