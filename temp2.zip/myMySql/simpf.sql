delimiter //
CREATE FUNCTION simpf(num INTEGER) RETURNS double  
 LANGUAGE SQL 
 DETERMINISTIC
BEGIN
  DECLARE 
    myNum double;
    IF(num > 100) THEN
     SET myNum = pow(num,3);
    ELSE
     SET myNum = pow(num,4);
    END IF;
   return myNum;
END //