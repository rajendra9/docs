drop table if exists persons;

create table persons(adharid varchar(10) primary key,person_name varchar(20),location varchar(15),income float8);

insert into persons values('s100','Satish','New Delhi',550000.5);

insert into persons values('s200','Raghu','Chennai',450000.5);

insert into persons values('s300','Gopal','Madurai',480000.5);

insert into persons(adharid,person_name,location,income) values
('s400','Kiran','Puducherry',520000.5),
('s500','Deepa','Mettur',525000.5),
('s600','Sivaranjani','Thoothukudi',530000.5);



