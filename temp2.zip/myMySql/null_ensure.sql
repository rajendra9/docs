DELIMITER $$
CREATE TRIGGER avoid_empty_id
    BEFORE INSERT ON mycheck
        FOR EACH ROW
        BEGIN
        IF new.id = 0 THEN 
          SET new.id  = NULL; 
        END IF;
END $$

DELIMITER ;