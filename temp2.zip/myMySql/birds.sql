drop table if exists birds;

create table birds(bird_id int primary key, bird_name  varchar(20),doi date);

insert into birds values(100,'Eagle','1150-01-21');

insert into birds values(200,'Parrot','1040-03-31');

insert into birds values(400,'Koil','1180-05-20');

insert into birds values(300,'Peacock','1290-08-15');

commit;