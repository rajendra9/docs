delimiter //
create procedure multi_stmts(IN dno int)
DETERMINISTIC
BEGIN
   select empno,ename,job,sal,deptno  from emp
   where deptno=dno;
 
   select dname,loc  from dept
   where deptno=dno;

   select grade,losal,hisal  from salgrade;

END //
 