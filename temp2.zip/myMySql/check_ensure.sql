drop table if exists mycheck;
create table mycheck(id int, name varchar(3));

drop procedure if exists check_name;
drop trigger if exists check_name_insert;

DELIMITER $$

create procedure check_name(in na varchar(3))
DETERMINISTIC
BEGIN
        IF na  not  in ('aaa','bbb','ccc') THEN 
          SIGNAL SQLSTATE  '02001'
          SET message_text = 'given name value is not allowed';
        END IF;
end $$
  


CREATE TRIGGER  check_name_insert
   BEFORE INSERT  ON mycheck
        FOR EACH ROW
  BEGIN
    if new.id=0 then
      set new.id = null;
    end if;
    call check_name(new.name);
END $$

CREATE TRIGGER  check_name_update
   BEFORE UPDATE  ON mycheck
        FOR EACH ROW
  BEGIN
    if new.id=0 then
      set new.id = null;
    end if;
    call check_name(new.name);
END $$


DELIMITER ;