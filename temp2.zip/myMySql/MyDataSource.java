package com.htc.javaee.utils;

import java.util.Properties;
import java.io.FileReader;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

public class MyDataSource {
 
 String dbType; 
 public MyDataSource(String dType) {
  dbType = dType;
 }
 
 public Connection getConnection() 
  throws SQLException,ClassNotFoundException,IOException {
  String fileName = "";
  if(dbType.equalsIgnoreCase("oracle")){
   fileName = "orasource";
  }
  else if(dbType.equalsIgnoreCase("mysql")) {
    fileName = "mysqlsource";
  } 
  try {
   FileReader reader =
        new FileReader(fileName + ".properties");

   Properties props = new Properties();
   props.load(reader);
   String driv = props.getProperty("jdbc.driver");
   String url = props.getProperty("jdbc.url");
   String user = props.getProperty("jdbc.username");
   String password = props.getProperty("jdbc.password");
        
   Class.forName(driv);
   Connection conn = 
        DriverManager.getConnection(url, user, password);
   return conn;
  }catch(Exception ex){
    ex.printStackTrace();
    throw ex;
  } 

}

/* ensure orasource.properties,mysqlsource.properties
 * are there in same directory,
 * and in another command line run derbynt.bat & startderby.bat
 */ 