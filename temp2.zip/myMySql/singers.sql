DROP TABLE IF EXISTS SINGER;

CREATE TABLE SINGER (
ID INT NOT NULL AUTO_INCREMENT,
FIRST_NAME VARCHAR(60) NOT NULL, 
LAST_NAME VARCHAR(40) NOT NULL,
BIRTH_DATE DATE,
DESCRIPTION VARCHAR(2000),
 PHOTO BLOB, 
 VERSION INT NOT NULL DEFAULT 0,
 UNIQUE UQ_SINGER_1 (FIRST_NAME, LAST_NAME),
 PRIMARY KEY (ID)
);
insert into singer(first_name, last_name, birth_date) values ('John', 'Mayer', '1977-10-16');
insert into singer( first_name, last_name, birth_date) values ('Eric', 'Clapton', '1945-03-30');
insert into singer (first_name, last_name, birth_date )values ('John', 'Butler', '1975-04-01');
insert into singer (first_name, last_name, birth_date) values ('B.B.', 'King', '1925-09-16');
insert into singer (first_name, last_name, birth_date) values ('Jimi', 'Hendrix', '1942-11-27');
insert into singer (first_name, last_name, birth_date) values ('Jimmy', 'Page', '1944-01-09');
insert into singer (first_name, last_name, birth_date) values ('Eddie', 'Van Halen',
'1955-01-26');
insert into singer (first_name, last_name, birth_date) values ('Saul Slash', 'Hudson',
'1965-07-23');
insert into singer (first_name, last_name, birth_date) values ('Stevie', 'Ray Vaughan',
'1954-10-03');
insert into singer (first_name, last_name, birth_date) values ('David', 'Gilmour',
'1946-03-06');
insert into singer (first_name, last_name, birth_date) values ('Kirk', 'Hammett', '1992-11-18');
insert into singer (first_name, last_name, birth_date) values ('Angus', 'Young', '1955-03-31');
insert into singer (first_name, last_name, birth_date) values ('Dimebag', 'Darrell',
'1966-08-20');
insert into singer (first_name, last_name, birth_date) values ('Carlos', 'Santana',
'1947-07-20');