package myjqs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import myjqs.utils.JqStudentManip;
import myjqs.utils.JqStudentService;


@WebServlet("/jqstudent")
public class JqStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 112343L;
  
    JqStudentManip stuManip;	
	
	
	@Override
	public void destroy() {
		super.destroy();
		this.stuManip = null;
	}


	@Override
	public void init() throws ServletException {
		super.init();
		this.stuManip = new JqStudentService();
	}


	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   PrintWriter out = response.getWriter();
	   response.setContentType("application/json");
	   String stuNum = request.getParameter("id");
	   System.out.println(stuNum);
	   JsonObject jsonObj = this.stuManip.searchStudent(stuNum);
	   System.out.println(jsonObj.toString());
	   out.println(jsonObj.toString());
	   out.flush();
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
	    response.setContentType("application/json");
	    
	    BufferedReader in = request.getReader();
	    String line = in.readLine();
		System.out.println("HHH"+line); 
		String[] tokens = line.split("[&]");    
	    String stuIdStr="", name="",course ="",city="",ageStr="";
	    stuIdStr = tokens[0].substring(tokens[0].indexOf("=")+1);
	    name = tokens[1].substring(tokens[1].indexOf("=")+1);
		course = tokens[2].substring(tokens[2].indexOf("=")+1);
	    city = tokens[3].substring(tokens[3].indexOf("=")+1);
		ageStr = tokens[4].substring(tokens[4].indexOf("=")+1);
		int age = Integer.parseInt(ageStr);
		JsonObject obj =
	    	this.stuManip.saveStudent(stuIdStr,name,course,city,age);
	    if(obj.get("msg") != null) {
		   out.println(obj.toString());
		}
	    out.close();	
	}

}
