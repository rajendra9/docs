package myjqs.utils;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JqStudentService implements JqStudentManip {
   
	EntityManagerFactory factory;
	EntityManager em;
	EntityTransaction trans;
	
	{
		factory = Persistence.createEntityManagerFactory("myDB");
		em = factory.createEntityManager();		
	}
	
	@Override
	public JsonObject searchStudent(String stuId) {
		JqStudentTo student = new JqStudentTo();
		trans = em.getTransaction();
		trans.begin();
		try {
		  student = em.getReference(JqStudentTo.class, stuId);	
		  trans.commit();			
		  if(student != null) {
			  return this.getJson(student);
		  }
		}catch(EntityNotFoundException ex) {
		  System.out.println(ex);
		  trans.rollback();
		}		
		return this.getJson(student);
	}

	@Override
	public void close() {
	  if(factory != null) {
		 factory.close(); 
	  }
		
	}

	@Override
	public JsonObject saveStudent(String id, String name, String course, String nativeCity, int age) {
		String msg = "Not Saved";
		trans = em.getTransaction();
		trans.begin();
		try {
		  em.persist(new JqStudentTo(id, name, course, nativeCity, age));	
		  trans.commit();			
		  msg = "Student with id:"+id +" is Saved";
		}catch(Exception ex) {
		  ex.printStackTrace();
		  trans.rollback();
		}		
		return this.getJson(msg);

	}
	
	private JsonObject getJson(JqStudentTo student) {
		String result = "";
		JsonObjectBuilder objBuilder = 
				Json.createObjectBuilder();
	if(student.getStuId()!=null) {
		result = "stuId:" + student.getStuId();
	    result += " stuName:"+ student.getStuName();
	    result += " course:" + student.getCourse();
	    result += " nativeCity:" + student.getNativeCity();
	    result += " age" + student.getAge();
      }
	   else {
		  result = " Go ahead student does not exist";
	   }
	    objBuilder.add("msg",result);
		return objBuilder.build();
	 }
	
	private JsonObject getJson(String msg) {
		JsonObjectBuilder objBuilder = 
				Json.createObjectBuilder();
		objBuilder.add("msg", msg);
		return objBuilder.build();
	}
	

}
