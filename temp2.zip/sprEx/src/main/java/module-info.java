module  com.htc.spring.webflux{
   requires reactor.core;
   requires spring.beans;
   requires spring.boot;
   requires spring.boot.autoconfigure;
   requires spring.web;
   requires spring.webflux;
   requires spring.context;
   exports com.htc.spring.webflux;
}




