package  com.htc.spring.webflux;

import org.springframework.stereotype.Component;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import  reactor.core.publisher.Mono;

@Component
public class  WelcomeHandler {

   public Mono<ServerResponse>  welcome(ServerRequest request){
   
    return ServerResponse.ok().contentType(MediaType.TEXT_PLAIN)
                     .body(BodyInserters.fromObject("Welcome To Spring WebFlux")); 

   }

    public Mono<ServerResponse>  welcomePerson(ServerRequest request){
   
      String message = "<div style='color:blue;font-size:18px;font-weight:bold'>Hi HTC Developer See Webflux</div>";
    return ServerResponse.ok().contentType(MediaType.TEXT_HTML)
                     .body(BodyInserters.fromObject(message)); 

   }


}