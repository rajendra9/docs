package day10;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteArrayDemo {

 public static void main(String[] args)throws IOException {
   
   File f = new File("ajanta.txt");	 
   int len = (int)f.length();
   byte[] bytes = new byte[len];
   
   FileInputStream fin = new FileInputStream("ajanta.txt");
   fin.read(bytes);
   ByteArrayOutputStream bout = new ByteArrayOutputStream(len + 20);
   
   FileOutputStream fout = new FileOutputStream("new_ajanta.txt");
   ByteArrayInputStream bin =
        new ByteArrayInputStream(bytes);
   int splCharCnt = -1;
   int c = 0;
   char ch = '\u0000';
  
   while((c = bin.read())!= -1) {
     ch = (char)c;
   if(ch == '$' || ch == '#' || ch == '*' || ch =='%' || ch == '&' || ch == '@') {
     ++splCharCnt;
     continue;
   }
   bout.write(c);;
  }
  byte[] filtered = bout.toByteArray();
  System.out.println(new String(filtered));
  System.out.println("special Characters are :"+ splCharCnt);
  
  bout.writeTo(fout);
  fout.close();
  bout.close();
  bin.close();
   
 }

}      