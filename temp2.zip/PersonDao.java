package com.htc.data;
import java.util.List;

import org.springframework.data.cassandra.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.htc.data.domain.PersonDto;

public interface PersonDao extends CrudRepository<PersonDto, Integer>{

	public PersonDto searchPerson(int id);
	
	public List<PersonDto> findAll();
	
	public void close();

}
