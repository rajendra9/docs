package testing;

import java.util.Optional;

import com.htc.ogm.ProjectService;
import com.htc.ogm.domain.Project;

public class HiberOgmTest {

	public static void main(String[] args) {
		ProjectService prjService = new ProjectService();
		Project metro = new Project("metro14", "Chennai-Metro", "Chennai Guindy", "14600crs");
		metro.setIncurredCost("20000crs");
		boolean ret = prjService.saveProject(metro);
		System.out.println("Project Saved is:"+ret);
		metro = new Project("metro16", "Cochi-Metro", "Cochin", "2577crs");
		metro.setIncurredCost("2700crs");
		ret = prjService.saveProject(metro);
		System.out.println("Project Saved is:"+ret);
		
		Optional<Project> opt = prjService.searchProject("metro14");
		if(opt.isPresent()) {
			System.out.println(opt.get());
		}
		prjService.close();
	}

}
