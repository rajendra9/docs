package com.htc.ogm.domain;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@SuppressWarnings("serial")
@Entity
public class Project implements Serializable {

	
	private String projectId;
	private String projectName;
	private String location;
	private String estimatedCost;
	private String incurredCost;
	
	public Project() {
		super();	
	}

	public Project(String projectId, String projectName, String location, String estimatedCost) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
		this.location = location;
		this.estimatedCost = estimatedCost;
	}

	public Project(String projectId) {
		super();
		this.projectId = projectId;
	}
    
	@Id
    @Column
	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	@Column
	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	@Column
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Column
	public String getEstimatedCost() {
		return estimatedCost;
	}

	public void setEstimatedCost(String estimatedCost) {
		this.estimatedCost = estimatedCost;
	}

	@Column
	public String getIncurredCost() {
		return incurredCost;
	}

	public void setIncurredCost(String incurredCost) {
		this.incurredCost = incurredCost;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((projectId == null) ? 0 : projectId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Project other = (Project) obj;
		if (projectId == null) {
			if (other.projectId != null)
				return false;
		} else if (!projectId.equals(other.projectId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", projectName=" + projectName + ", location=" + location
				+ ", estimatedCost=" + estimatedCost + ", incurredCost=" + incurredCost + "]";
	}
	
}
