package com.htc.ogm;

import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.htc.ogm.domain.Project;


public class ProjectService {

	static EntityManagerFactory  factory;
	static EntityManager em;
	
	static{
	  factory = Persistence.createEntityManagerFactory("myOgm");
	  
	}
	
	public EntityManager getEntityManager() {
		return factory.createEntityManager();		
	}
	
	public void close() {
		if(factory != null) {
			factory.close();
		}
	}
   
	public boolean saveProject(Project project) {
	   EntityManager em = this.getEntityManager();
	   EntityTransaction trans = em.getTransaction();
	   trans.begin();
	   try {
		  em.persist(project);
		  trans.commit();
		  return true;
	   }catch(Exception ex) {
		   ex.printStackTrace();
		   trans.rollback();
	   }
	   em.close();
	   return false;	   
	}
	public Optional<Project> searchProject(String id) {
	   Optional<Project> ret = Optional.empty();
       EntityManager em = this.getEntityManager();
	   EntityTransaction trans = em.getTransaction();
	   trans.begin();
		   try {
			 Project searched =  em.getReference(com.htc.ogm.domain.Project.class, id);
	         ret = Optional.of(searched);
			 trans.commit();			 
		   }catch(Exception ex) {
			   ex.printStackTrace();
			   trans.rollback();
		   }
		   return ret;	   
		}
	
}
