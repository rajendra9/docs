new Vue({
    el: '#vue-evt-app',
    data:{
        commuFunds: 2000,
        donation: 0,
        spending: 0,
        mousePositions:'X:0 and Y:0'   
    },
    methods:{
       addDonationToFunds: function(){
            this.commuFunds = this.commuFunds + parseInt(this.donation);
          
       },
       addBulkDonation: function(val){
           this.commuFunds = this.commuFunds + parseInt(val);
       },
       spendMoney: function(){
           this.commuFunds = this.commuFunds - parseInt(this.spending);                 
       },
       showMousePos: function(event){
           this.mousePositions = "Mouse at X:" + event.offsetX + ", Y: " + event.offsetY;
       }
       
    }
})