new Vue({
    el: '#vue-compu-app',
    data:{
        age: 20,
        a: 0,
        b: 0   
    },
    methods:{
      /* addAToAge: function(){
           console.log('a add');
           return this.age + this.a;
          
       },
       addBToAge: function(amt){
           console.log('b add');
           return this.age + this.b;                 
       }
      you have to remove braces in html file to avoid firing both methods*/ 
    },
    computed:{
        addAToAge: function(){
            console.log('a add');
            return this.age + this.a;
           
        },
        addBToAge: function(amt){
            console.log('b add');
            return this.age + this.b;                 
        }  
    }
})