var one = new Vue({
    el: '#vue-multi-one',
    data:{
        title: 'Vue App One'
    },
    methods:{
       
    },
    computed:{
      greet: function(){
          return 'Hello From Vue App One';
      }   
    }
});
var two = new Vue({
    el: '#vue-multi-two',
    data:{
      title: 'Vue App Two'
    },
    methods:{
        changeTitleInOne: function(){
            one.title = 'This is a Changed Title';
        }   
    },
    computed:{
        greet: function(){
            return 'Hello From Vue App Two';
        },
        

    }
})

two.title = 'Changed from outside, its possible'