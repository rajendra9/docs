Vue.component('greeting',{
    template:'<h3>Hello {{name}} please listen, I am a Reusable Component<br/><button v-on:click="changeName">change Name</button></h3>',
    data: function() {
        return   {
            name: 'Prasad'
        }     
    },
    methods:{
        changeName: function(){
            this.name = 'Sarveswar'
        }
    }
});

new Vue({
    el: '#vue-multi-one',
    data:{       
    },
    methods:{       
    },
    computed:{      
    }
});
new Vue({
    el: '#vue-multi-two',
    data:{      
    },
    methods:{
    },
    computed:{
    }
})

