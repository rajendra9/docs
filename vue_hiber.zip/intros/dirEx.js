const app = new Vue({
  el: '#app',
  data:{
    isCorrect: true,
    hello: "Hello World",
    keka: 'This is Directive'
  },
  methods:{
    show: function(){
      this.hello= 'Happy Event'
    },
    display: function(){
      return 'Learn Vuejs Smarter Way'
    }
  }
});
