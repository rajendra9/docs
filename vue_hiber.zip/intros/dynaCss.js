new Vue({
    el: '#vue-dyna-css-app',
    data:{
       isCricket: false,
       isFamous: false
    },
    methods:{
      
    },
    computed:{
        compClasses: function(){
            return{
                isCricket: this.isCricket,
                isFamous: this.isFamous
            }
        }
    }
})