drop table if exists personalhobbies;

drop table if exists person;

create table person(adhar_id varchar(12) primary key,
person_name varchar(20),profession varchar(20),
income  decimal(9,2),address varchar(30));

create table personalhobbies(hobby_id integer constraint hobbies_PK primary key,
hobby_name varchar(20),
hours_time integer,guidance varchar(1),
location varchar(20),
annual_spent  decimal(8,2),adhar_id varchar(12) references person);

insert into person values('CH00000876','ThanigaVel','Business',
600750.5,'ChromePet');

insert into person values('CH00000656','Kumaraswamy','Developer',
360750.5,'Tambaram');

insert into person values('CH00001126','Madivanan','ST-Govt-Service',
45750.5,'Tambaram');

insert into person values('CH00001214','MuthuVel','CG-Govt-Service',
54750.5,'Guindy');

insert into person values('CH00001414','Thandony','Private-Service',
36550.5,'ChromePet');

insert into person values('CH00000456','Satyam','Business',
51276.5,'TNagar');

insert into personalhobbies values(10,'Playing-Cards',1,'N','Tambaram',
10000.0,'CH00000456');

insert into personalhobbies values(20,'Social-Service',1,'Y','ChromePet',
5000.0,'CH00000456');

insert into personalhobbies values(30,'Book-Reading',2,'N','British-Library',
1050.0,'CH00001126');

insert into personalhobbies values(40,'Movies',1,'N','Home-TV',
300.0,'CH00001126');

insert into personalhobbies values(50,'Table-Tennis',1,'Y','Chennai-Club',
1500.0,'CH00000876');

insert into personalhobbies values(60,'Photography',0.5,'N','News-Ageny',
1200.0,'CH00000876');

insert into personalhobbies values(70,'Movies',2,'N','Home-TV',
500.0,'CH00001214');

insert into personalhobbies values(80,'Lawn-Tennis',1,'N','Rovers-Club',
1250.0,'CH00001214');

insert into personalhobbies values(90,'Book-Reading',1,'N','Chennai-Library',
250.0,'CH00001414');

insert into personalhobbies values(100,'Outings',1,'N','Chennai',
600.0,'CH00001414');

insert into personalhobbies values(110,'Tourism',1,'N','Chennai',
5000.0,null);


commit;