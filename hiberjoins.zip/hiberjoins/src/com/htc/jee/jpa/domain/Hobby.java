package com.htc.jee.jpa.domain;

import java.io.Serializable;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.JoinColumn;

@Entity
@Table(name="PERSONALHOBBIES")
public class Hobby implements Serializable {

    @Id
    @Column(name="HOBBY_NAME")
    private String hobbyName;

    @Column(name="ANNUAL_SPENT")
    private double annualSpent;

    private String guidance;

    @Column(name="HOURS_TIME")
    private double spentTime;

    private String location;
    //bi-directional many-to-one association to Person
    @ManyToOne
    @JoinColumn(name="ADHAR_ID")
    private Person person;
 
    public Hobby() {
    }

    public String getHobbyName() {
       return this.hobbyName;
    }

    public void setHobbyName(String hobbyName) {
       this.hobbyName = hobbyName;
    }

    public double getAnnualSpent() {
	return this.annualSpent;
    }

    public void setAnnualSpent(double annualSpent) {
       this.annualSpent = annualSpent;
    }

    public String getGuidance() {
       return this.guidance;
    }

    public void setGuidance(String guidance) {
      this.guidance = guidance;
    }

    public double getSpentTime() {
      return this.spentTime;
    }

    public void setSpentTime(double hoursTime) {
      this.spentTime = hoursTime;
    }

    public String getLocation() {
       return this.location;
    }

    public void setLocation(String location) {
	this.location = location;
    }

    public Person getPerson() {
	return this.person;
    }

    public void setPerson(Person person) {
	this.person = person;
    }

	
    @Override
    public int hashCode() {
     final int prime = 31;
      int result = 1;
      result = prime * result
              + ((hobbyName == null) ? 0 : hobbyName.hashCode());
      result = prime * result + ((person == null) ? 0 : person.hashCode());
      return result;
    }

    @Override
    public boolean equals(Object obj) {
       if (this == obj)
         return true;
       if (obj == null)
         return false;
       if (getClass() != obj.getClass())
          return false;
        Hobby other = (Hobby) obj;
       if (hobbyName == null) {
         if (other.hobbyName != null)
           return false;
       } else if (!hobbyName.equals(other.hobbyName))
          return false;
       if (person == null) {
	if (other.person != null)
	  return false;
       } else if (!person.equals(other.person))
          return false;
       return true;
   }

   @Override
   public String toString() {
    return "Hobby [hobbyName=" + hobbyName +
                   ",annualSpent=" + annualSpent +
		   ", guidance=" + guidance + 
                   ", hoursTime=" + spentTime + 
                   ", location=" + location + 
                   ", person=" + person + "]";
	}
	
	
	
}