package com.htc.grails



class MallSale {

 

     String mallItemNum
     int qty
     float moneyPaid
     Date saleDt 
    

     static constraints = {
      }
    
    static mapping = {
        table "MALLSALES"
        version false   
        id column: "MALL_SALE_ID"
        id generator: "sequence", params: [sequence: "mallsaleid_seq"]      
        mallItemNum column: "MALL_ITEM_NUM"
     }
   
    String toString(){
       return id + ":" +mallItemNum + ":" + saleDt + ":" + qty + ":" + moneyPaid
    }



}
