package com.htc.grails

import grails.transaction.Transactional

@Transactional
class FruitService {

     def fruits = []


   FruitService(){
     fruits << new Fruit(fruitName: "Apple", fruitType: "Lal Ambri", area: "Jammu & Kashmir", country: "India")
     fruits << new Fruit(fruitName: "Apple", fruitType: "Braeburn", area: "Nelson", country: "NewZealand")
     fruits << new Fruit(fruitName: "Apple", fruitType: "Cortland", area: "New York", country: "USA")
     fruits << new Fruit(fruitName: "Apple", fruitType: "Fuji", area: "Morioka", country: "Japan")
    fruits <<  new Fruit(fruitName: "Apple", fruitType: "Red June", area: "Simla", country: "India")
   }

    def  getFruits() {
      fruits
    }
}
