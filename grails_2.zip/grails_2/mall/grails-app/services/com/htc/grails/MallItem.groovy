package com.htc.grails

class MallItem {

   String mallItemId;
   String brand
   int size
   double cost


    @Override
    public String toString() {
        return "MallItem{" +
                "brand='" + brand + '\'' +
                ", size=" + size +
                ", cost=" + cost +
                '}';
    }


}
