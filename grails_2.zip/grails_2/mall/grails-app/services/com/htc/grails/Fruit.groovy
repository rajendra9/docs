package com.htc.grails



class Fruit {

   String fruitName
   String fruitType
   String area
   String country 
   


    @Override
    public String toString() {
        return "Fruit{" + "name=" + fruitName + ", fruitType=" + fruitType + ", area=" +   
        area + ", country=" + country + "}" 
    }


}
