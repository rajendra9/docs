package com.htc.grails

import grails.transaction.Transactional

@Transactional
class MallSaleService {

def categories = [:]


  MallSaleService(){
   def shirts = [
    new MallItem(mallItemId: "ph21090", brand: "Arrow", size :42, cost: 894.5),
    new MallItem(mallItemId: "ph21085", brand: "Bare", size :40, cost: 765.5),
    new MallItem(mallItemId: "ph21092", brand: "Vivaldi" ,size :44, cost: 543.5),
    new MallItem(mallItemId: "ph21043", brand: "Hero" ,size :42, cost: 465.5)
   ]
 
  def trousers = [
      new MallItem(mallItemId: "ph23065", brand: "Arrow" ,size :36, cost: 1121.5),
      new MallItem(mallItemId: "ph23081", brand: "Bare" ,size :38, cost: 985.5),
      new MallItem(mallItemId: "ph23076", brand: "Vivaldi", size :34, cost: 783.5),
      new MallItem(mallItemId: "ph23021", brand: "Lee" ,size :42, cost: 1225.5)
   ]

    categories["shirts"] = shirts
    categories["trousers"] = trousers
  }

    def  getCategoryTypes(fabType) {
      def cat = categories.find { it.key == fabType }
      if (cat) {
         def mallItems = cat.value
         return mallItems 
        }
        retun "na"
    }
    def getCategories() {
        return categories.keySet()
    }
    
    def save(MallSale sale){
      println "kkk"+sale
      if(sale == null || sale.hasErrors()){
        transactionStatus.setRollbackOnly()
      }
      sale.save(flush: true)
    }

}
