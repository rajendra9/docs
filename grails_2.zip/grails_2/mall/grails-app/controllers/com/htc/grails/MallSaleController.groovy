package com.htc.grails



class MallSaleController {

 

    static scaffold = MallSale
    def catCnt = 0
    def mallSaleService 
   
    def showTypes(){
    }
     
    def  transact(){
         def selectQtyStr = ""
        for(int count = 0;count<catCnt;count++){
             selectQtyStr = params."qty_${count}" 
             if(!selectQtyStr) {
                   continue
             }
            else {
                 def selectQty = Integer.parseInt(selectQtyStr)
                 def itemIdStr = params."mallItemId_${count}"
                 println "gggg"+itemIdStr
                 def itemCostStr = params."cost_${count}"
                 float money = selectQty * Float.parseFloat(itemCostStr)
                 def saleDate = new Date()
                 MallSale sale = new MallSale()
                 sale.mallItemNum = itemIdStr
                 sale.saleDt = saleDate
                 sale.qty = selectQty
                 sale.moneyPaid = money 
                 mallSaleService.save(sale)          
              }
            }
            [message: "Selected Mall Items Saved"]  
          } 

         def details(){
             def cate = params.cate
             def categories =   (ArrayList)mallSaleService.getCategoryTypes(cate)
             catCnt = categories.size()
             [cates : categories] 
         }

        def index() {
             def mainTypes = mallSaleService.getCategories()
             redirect (action: "showTypes",params:[types: mainTypes])
        }


}
