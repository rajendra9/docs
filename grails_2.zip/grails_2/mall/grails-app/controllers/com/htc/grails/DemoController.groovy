package com.htc.grails



class DemoController {

   
 
  def fruitService
  def   location = "Tambaram"
   def index() {    
      flash.message = "Some Basic Concepts"
      session.fruit = "Pineapple"
      session.fruits = fruitService.fruits
      redirect action: "welcome" 
    }

   def welcome(){
        def myFruits = fruitService.fruits
        println myFruits
        [location: location, frts: myFruits] 
   }



}
