package monggorm

class PersonController {
     def index() { 
       flash.message = "Welcome to MongoDB-GORM"
       redirect(action: "input")
     }

    def input(){
    }
     
   
   
    def savePers(){
      def adhId = params.adh_id
      def person_name = params.p_name
      def sal = Float.parseFloat(params.sal)

      def per = new Person()
      per.adharId = adhId
      per.name = person_name
      per.salary = sal
      per.save(failOnError: true, flush: true)
      flash.msg = "Person saved successfully"      
      respond(action:  "input")
     }



}
