package monggorm

import org.bson.types.ObjectId

class Person {

   ObjectId id
   String adharId 
   String name
   float salary 
   static mapWith = "mongo" 
   
   static mapping = {
     collection "samp.persons"
     database "samp" 
     version false
   }

 
}
