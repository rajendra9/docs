package jaspex

class Employee {
    String empName
    String job
    Date hiredate
    String deptName
    float  salary

   static mapping = {
        table "GREMPLOYEES"
        version false
        id column: "EMPID"
        id generator: "sequence",params : [sequence: "GREMPID_SEQ"]
   }

   static constraints = {
        empName (nullable: false)
        deptName (nullable: false)
   }
}
