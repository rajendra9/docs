package jaspex



import java.util.Collection;
import ar.com.fdvs.dj.core.DynamicJasperHelper;
import ar.com.fdvs.dj.core.layout.ClassicLayoutManager;
import ar.com.fdvs.dj.domain.DynamicReport;
import ar.com.fdvs.dj.domain.builders.FastReportBuilder;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.view.JasperViewer;
import grails.transaction.Transactional

class EmployeeController {

  

    @Transactional
    def index() { 
     FastReportBuilder fastReportBuilder = 
                         new FastReportBuilder();
     DynamicReport rpt = fastReportBuilder.addColumn("Emp-Id","id",Long.class.getName(),8) 
     .addColumn("Emp-Name","empName",String.class.getName(), 20)
     .addColumn("Job","job",String.class.getName(),15)
     .addColumn("HireDate","hiredate",java.sql.Timestamp.class.getName(),22)
     .addColumn("salary","salary",Float.class.getName(),10)
     .addColumn("Dept-Name","deptName",String.class.getName(),8)
     .setTitle("Dynamic Jasper Report")
     .setSubtitle("Employee Information")
     .setPrintBackgroundOnOddRows(true)
     .setLeftMargin(5)
     .setRightMargin(5)
     .setTopMargin(5)
     .setColumnSpace(5)
     .setUseFullPageWidth(true).build();
   
      def emps = Employee.list()
      
      JRDataSource ds = new JRBeanCollectionDataSource(emps); 
      JasperPrint jp = DynamicJasperHelper.generateJasperPrint(rpt,
                new ClassicLayoutManager(),ds);
       byte[] pdfAsBytes = JasperExportManager.exportReportToPdf(jp);
       response.contentType = "application/pdf"
       response.contentLength = pdfAsBytes.length
       response.setHeader("Content-disposition",
                          "inline; filename=\"Report.pdf\"");
       response.outputStream << pdfAsBytes
    }



}
