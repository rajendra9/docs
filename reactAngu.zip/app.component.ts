import { Component } from '@angular/core';
import {FormBuilder, FormGroup, Validators }  from '@angular/forms';

@Component({
  selector: 'ng-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  personForm: FormGroup;
  personId:string = '';
  name: string = '';
  phone: string = '';
  personMail: string = '';
  income: number = 0.0;
  
  posting: any;
  formSubmitted:boolean = false;
  constructor(fb: FormBuilder){
    this.personForm = fb.group({
      personId: [null, Validators.required],
      name: [null,[Validators.required,Validators.minLength(6)]],
      phone: [null, Validators.required],
      personMail: [null,[Validators.required,Validators.email]],
      income: [null,[Validators.required,Validators.min(1800)]]
    });
  }
  get f(){
    return this.personForm.controls;
  }
  savePerson(posting){
    this.formSubmitted = true;
    alert(JSON.stringify(posting));
  }

}
