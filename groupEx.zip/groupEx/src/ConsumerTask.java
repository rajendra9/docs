package com.htc.kafka.consumers;

import kafka.consumer.ConsumerIterator;
import kafka.consumer.KafkaStream;
import kafka.message.MessageAndMetadata;

public class ConsumerTask implements Runnable{
    private KafkaStream<byte[],byte[]> stream;
    private int threadNum;
    
    public ConsumerTask(KafkaStream<byte[], byte[]> stream, int threadNum) {
        super();
        this.stream = stream;
        this.threadNum = threadNum;
    }
    
   public void run() {
       ConsumerIterator<byte[], byte[]> consIterator = stream.iterator();
       while(consIterator.hasNext()) {
          MessageAndMetadata<byte[],byte[]> obj = consIterator.next();
          byte[] key = obj.key();
          byte[] value = obj.message();            
          System.out.println("Thread-" + this.threadNum + " received mesage is-" + new String(key)+"::"+ new String(value)); 
       }
       System.out.println("shutting down Thread-" + this.threadNum);
   }
}
