package com.htc.kafka.consumers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import kafka.consumer.ConsumerConfig;
import kafka.consumer.KafkaStream;
import kafka.javaapi.consumer.ConsumerConnector;

public class MultiConsumerDemo {
   private final ConsumerConnector consumer;
   final String topic;
   ExecutorService executor;
   
   public MultiConsumerDemo(String zkConnect, String groupId, String topicName) {
      consumer = kafka.consumer.Consumer.createJavaConsumerConnector(this.createConsumerConfig(zkConnect,groupId));
      this.topic = topicName;    
   }  
   
   private ConsumerConfig createConsumerConfig(String zkConnect, String groupId) {
       Properties props = new Properties();
       props.put("zookeeper.connect", zkConnect);
       props.put("group.id", groupId);
       props.put("zookeeper.session.timeout.ms", "3000");
       props.put("zookeeper.sync.time.ms", "400");
       props.put("auto.commit.interval.ms", "1000");
       return new ConsumerConfig(props);
   }

   public void shutdown() {
       if(consumer != null) {
          consumer.shutdown(); 
       }
       if(executor != null) {
           executor.shutdown();
       }
       try {
        if(!executor.awaitTermination(5000, TimeUnit.MILLISECONDS)) {
         System.out.println("Timedout waiting for consuer Threads to shutdown. exiting uncleanly");   
        }
       }catch(InterruptedException ex) {
           System.out.println("Interrupted during shutdown, exiting uncleanly");  
       }       
   }
   
   public void run(int numThreads) {
     Map<String, Integer> topicCountMap = new HashMap<>();
     topicCountMap.put(topic, numThreads);
     Map<String, List<KafkaStream<byte[], byte[]>>> consumerMap =
             consumer.createMessageStreams(topicCountMap);
     List<KafkaStream<byte[], byte[]>> streams = consumerMap.get(topic);
     executor = Executors.newFixedThreadPool(numThreads);
     int threadNum = 0;
     for(final KafkaStream<byte[],byte[]> stream : streams) {
         executor.execute(new ConsumerTask(stream, threadNum));
         threadNum += 1;
     }       
     
   }

   public static void main(String ... args) {
       String zkAddress = "localhost:5000";
       String groupName = "samp";
       int numThreads = 2;
       String topicName= "simpTopic";
       try {
           MultiConsumerDemo multiConsumerDemo =
                   new MultiConsumerDemo(zkAddress, groupName, topicName);
           multiConsumerDemo.run(numThreads);
           
           try {
               Thread.currentThread().sleep(10000);
           }catch(InterruptedException ex) {
               System.out.println("Main thread is interrupted");
           }
           multiConsumerDemo.shutdown();
       }catch(Exception ex) {
           ex.printStackTrace();
       }
   }
   
}
