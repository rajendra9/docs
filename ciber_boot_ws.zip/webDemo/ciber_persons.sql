
drop table if exists ciber_persons;

create table ciber_persons(adhar_id varchar(15) primary key,
first_name  varchar(15), last_name varchar(15),
address varchar(50),income numeric(10,2));

insert into ciber_persons values('5432','Sudheer', 'Kumar','Tambaram, Chennai', 126000.0);

insert into ciber_persons values('4332','Janani', 'Rajan','Madurai, Chennai', 145000.0);

insert into ciber_persons values('6123','Muthu', 'Kumar','Tirunelveli, Chennai', 167000.0);

insert into ciber_persons values('7654','Sethu', 'Madhavan','Moosapet,Hyderabad', 141000.0);

insert into ciber_persons values('2543','Kesava', 'Rao,'Besant Road, Vijayawada', 206000.0);
