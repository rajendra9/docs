package com.htc.ciber.spring.webDemo.utils;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import com.htc.ciber.spring.webDemo.domain.PersonTo;

public interface PersonDao extends Serializable {
   
	public boolean savePerson(PersonTo person);
	public boolean updatePersonAddress(String adharId, String newAddress);
	public boolean updatePersonIncome(String adharId, double newIncome);
	public boolean removePerson(String adharId);
	public List<PersonTo> getPersons();
	public Optional<PersonTo> searchPerson(String adharId);
	
	
}
