package com.htc.ciber.spring.webDemo;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.htc.ciber.spring.webDemo.utils.PersonDao;
import com.htc.ciber.spring.webDemo.utils.PersonService;

@PropertySource("file:./jdbc.properties")
@SpringBootApplication
@ComponentScan({"com.htc.ciber.spring.webDemo","com.htc.ciber.spring.webdemo.utils",})
public class WebDemoApplication {
	
	@Autowired
	Environment env;
	
	@Bean
    public DataSource dataSource() {
		DriverManagerDataSource ds =
             new DriverManagerDataSource(); 
		System.out.println("fired");
     String driverCl = env.getProperty("db.driver");
     ds.setDriverClassName(driverCl);
     ds.setUrl(env.getProperty("db.url"));
     System.out.println(env.getProperty("db.password"));
     ds.setUsername(env.getProperty("db.username"));
     ds.setPassword(env.getProperty("db.password"));
     System.out.println("***"+ds);
     return ds;
    }  	
	
	@Bean
	public PersonDao personService() {
		PersonService personService = new PersonService();
		personService.setDataSource(dataSource());
		return personService;
	}
	public static void main(String[] args) {
		SpringApplication.run(WebDemoApplication.class, args);
	}

}

