package com.htc.ciber.spring.rest.domain;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="ciber_orders")
@NamedQuery(name="all.orders", query=" select ord from OrderDto ord")
@NamedQuery(name="order.byId", query=" select ord from OrderDto ord where ord.orderId=:oid")
public class OrderDto implements Serializable {
 private  String         orderId;
 private  LocalDate   orderDate;
 private  String      items;
 private  double      cost;
 private  String      customer;

 
 public OrderDto(String orderId) {
  super();
  this.orderId = orderId;  
 }

 public OrderDto(){}

 @Column
 public double getCost() {
   return cost;
 }

 public void setCost(double cost) {
   this.cost = cost;
 }

 @Column                                                                          public String getCustomer() {
    return customer;
 }

 public void setCustomer(String customer) {
    this.customer = customer;
 }

 @Column(name="order_date")
 public LocalDate getOrderDate(){
    return orderDate;
 }

 public void setOrderDate(LocalDate orderDate) {
    this.orderDate = orderDate;
 }

 @Id
 @Column(name="order_id")
 public String getOrderId() {
    return orderId;
 }

 public void setOrderId(String orderId) {
    this.orderId = orderId;
 }

 @Override
 public String toString(){        
  String ret = "\r\n Order-Id:"+this.orderId+
               "\r\n Ordered-Date:"+this.orderDate;
  ret = ret+"\r\n Cost:"+this.cost+
       "\r\n Customer:"+this.customer;        
  return ret;
 }

  public String getItems() {
	return items;
  }

  public void setItems(String items) {
	 this.items = items;
  }

  @Override
  public int hashCode() {
	 final int prime = 31;
	 int result = 1;
	 result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
	 return result;
  }

  @Override
  public boolean equals(Object obj) {
     if (this == obj)
	 	return true;
	 if (obj == null)
	  	return false;
	 if (getClass() != obj.getClass())
	 	return false;
	 OrderDto other = (OrderDto) obj;
	 if (orderId == null) {
	 	if (other.orderId != null)
			return false;
	 } else if (!orderId.equals(other.orderId))
	    return false;
	 return true;
   }
  

}