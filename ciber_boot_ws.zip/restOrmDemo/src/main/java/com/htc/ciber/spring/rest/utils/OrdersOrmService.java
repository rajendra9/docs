package com.htc.ciber.spring.rest.utils;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.transaction.annotation.Transactional;

import com.htc.ciber.spring.rest.domain.OrderDto;
import com.htc.ciber.spring.rest.domain.OrderTo;

@Transactional
@SuppressWarnings("serial")
public class OrdersOrmService implements OrdersOrmDao  {
	
   @PersistenceContext
    EntityManager em;


    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
   
   
   public boolean isOrderExists(String ordId) {
	 String qryStr = "select  count(*) from OrderDto ord where ord.orderId=:oid";  
	 TypedQuery<Long> qry = em.createQuery(qryStr, java.lang.Long.class); 
     qry.setParameter("oid", ordId);
     Long rows = qry.getSingleResult();  
	 if(rows>0) {	 
		 return false;
	 }
	 else {
		return true; 
	 }  
   }
   
   public OrderDto translateAsDto(OrderTo order) {
	   OrderDto orderEntity = new OrderDto();
	   orderEntity.setCost(order.getCost());
	   orderEntity.setCustomer(order.getCustomer());
	   orderEntity.setItems(order.getItems());
	   orderEntity.setOrderId(order.getOrderId());
	   LocalDate dt = LocalDate.parse(order.getOrderDate(), formatter);
	   orderEntity.setOrderDate(dt);
	   return  orderEntity;    
   }
   
   public OrderTo translateAsTo(OrderDto orderEntity) {
	   OrderTo order = new OrderTo();
	   order.setCost(orderEntity.getCost());
	   order.setCustomer(orderEntity.getCustomer());
	   order.setItems(orderEntity.getItems());
	   order.setOrderId(orderEntity.getOrderId());
	   LocalDate dt = orderEntity.getOrderDate();
	   String dtStr = formatter.format(dt);
	   order.setOrderDate(dtStr);
	   return  order;    
   }
   
   public OrdersOrmService() {
       super();        
   }   
   
   
   @Override
   public List<OrderTo> getAllOrders() {
	  List<OrderTo> ret = new ArrayList<>(); 
	  TypedQuery<OrderDto> qry = 
			  em.createNamedQuery("all.orders", OrderDto.class);
      List<OrderDto> dtoList = qry.getResultList();
  	  for(OrderDto orderEntity : dtoList ) {
        ret.add(this.translateAsTo(orderEntity));
      }
      return ret; 
   }

   @Override
   public Optional<OrderTo> getOrder(String ordId) {
	  Optional<OrderTo> ret = Optional.empty(); 
	  try {
	   TypedQuery<OrderDto> qry = 
				  em.createNamedQuery("order.byId", OrderDto.class);
	   qry.setParameter("oid", ordId); 
	   OrderDto orderEntity = qry.getSingleResult();
       OrderTo order = this.translateAsTo(orderEntity);
	   ret = Optional.of(order);
	  }
	  catch(Exception ex) {
		  ex.printStackTrace();   
	  }
      return ret;			   
   }

   

   @Override
   public boolean saveOrder(OrderTo order) {
	   boolean  ret = false;
	   OrderDto orderEntity = this.translateAsDto(order);
	   try{   
	     em.persist(orderEntity);
	     ret = true;	    
	    }catch(Exception e){
	      e.printStackTrace();	      
	    }
	    return ret;
	 }



   @Override
   public boolean updateOrder(String ordId, String newCustomer, double newCost) {
	   boolean ret = false;        
       try {
        OrderDto searched = em.getReference(OrderDto.class, ordId);
        searched.setCustomer(newCustomer);
        searched.setCost(newCost);
        em.merge(searched);
        ret = true;
       }catch(Exception ex){
         ex.printStackTrace();  
       }
       return ret;
   }
   @Override
   public boolean deleteOrder(String ordId) {
	   boolean ret = false;        
       try {
    	 OrderDto searched = em.getReference(OrderDto.class, ordId);
         em.remove(searched);
        ret = true;
       }catch(Exception ex){
         ex.printStackTrace();  
       }
       return ret;
	 
   }  
   
}