drop table if exists expenseslog;

drop table if exists  expenses;



create table expenseslog(userid varchar(25),pword varchar(20),
rolename  varchar(1) constraint log_ck check (rolename in ('M','R')),
constraint log_pk primary key(userid,pword));


create table expenses(trans_id integer constraint exps_PK primary key,
empid integer,
ename  varchar(25),boss varchar(25),do_sub  date,amt_sub decimal(8,2),
do_san date,amt_san decimal(8,2)); 

insert into expenseslog values('scott','tiger','M');

insert into expenseslog values('mohinder','amarnath','M');

insert into expenseslog values('dtrprasad','prasad','R');

insert into expenseslog values('satish','satish','R');

insert into expenses values(1,100,'satish','scott','2018-12-03',3100,null,null);

insert into expenses values(2,200,'Manish','scott','2018-12-01',4300,null,null);


select *  from expenseslog;
commit;
