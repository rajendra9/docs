select count(*) from expenseslog  where userid='dtrprasad' and pword='prasad' and rolename='R'; 

select * from expenseslog;

select  *  from  expenses;