drop table if exists services;


drop sequence services_idservices_seq;

create sequence services_idservices_seq start with 1000;



create table services(trans_id integer
primary key default nextval('services_idservices_seq'),
service_name  varchar(20) not null,pay_date date,
charges float); 

select *  from services;