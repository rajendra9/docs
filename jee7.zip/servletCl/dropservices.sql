drop table  services;

