drop table if exists validusers;

create table validusers(username varchar(25),password varchar(25),
constraint valid_PK primary key(username, password));

insert into validusers values('santosh', 'sant123');
insert into validusers values('ramesh', 'rame123');
insert into validusers values('gambhir', 'gamb123');
insert into validusers values('nirupama', 'niru123');
insert into validusers values('vasanth', 'vasa123');



