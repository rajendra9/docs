package labex;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class ServProductService implements ServProdDao {

	DataSource ds;
	PreparedStatement pstmt;
	ResultSet rs;
	Connection conn;
	{
		Context ctx = new InitialContext();
		//ENC
		ds = (DataSource)ctx.lookup("java:comp/env/jdbc/myPostgres");
	}
	
	public ServProductService()throws NamingException{
		System.out.println("DataSource " + ds);
	}
	
	@Override
	public boolean saveProduct(ServProductDto dto) {
		try {
		   conn = ds.getConnection();
		   pstmt = conn.prepareStatement(INSERT_SQL);
		   pstmt.setInt(1, dto.getProdId());
		   pstmt.setString(2, dto.getProdName());
		   pstmt.setDouble(3, dto.getProdCost());
		   pstmt.setString(4, dto.getDealer());
		   int rows = pstmt.executeUpdate();
		   if(rows>0) {
			   return true;
		   }
		}catch(SQLException ex) {
			ex.printStackTrace();
		}		
		return false;
	}

	@Override
	public Optional<ServProductDto> searchProduct(int id) {
		Optional<ServProductDto> ret = Optional.ofNullable(new ServProductDto());
		ServProductDto dto = new ServProductDto();
		try {
		   conn = ds.getConnection();
		   pstmt = conn.prepareStatement(FIND_SQL);
		   pstmt.setInt(1, id);
		   rs  = pstmt.executeQuery();
		   rs.next();
		   dto.setProdId(id);
		   dto.setProdName(rs.getString(1));
		   dto.setProdCost(rs.getBigDecimal(2).doubleValue());
		   dto.setDealer(rs.getString(3));
		   ret = Optional.of(dto);		   
		}catch(SQLException ex) {
			ex.printStackTrace();
		}		
	    return ret;
	}

	@Override
	public List<ServProductDto> listAll() {
		List<ServProductDto> ret = new ArrayList<>();
		ServProductDto dto = null;
		try {
		   conn = ds.getConnection();
		   pstmt = conn.prepareStatement(FIND_ALL);
		   rs  = pstmt.executeQuery();
		   while(rs.next()) {
			  dto = new ServProductDto();
			  dto.setProdId(rs.getInt(1));
			  dto.setProdName(rs.getString(2));
			  dto.setProdCost(rs.getBigDecimal(3).doubleValue());
			  dto.setDealer(rs.getString(4));
	          ret.add(dto);
		   }
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return ret;
	}

	@Override
	public void closeConn() {
		try {
		   if(conn != null) {
			   conn.close();
		   }
		}catch(Exception ex) {
		  ex.printStackTrace();	
		}		
	}

}
