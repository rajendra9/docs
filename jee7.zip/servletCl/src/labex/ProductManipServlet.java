package labex;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Optional;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/prodManip")
public class ProductManipServlet extends HttpServlet {
    ServProdDao dao;

	@Override
	public void destroy() {
		super.destroy();
		dao.closeConn();
		dao = null;
	}




	@Override
	public void init() throws ServletException {
		super.init();
		try {
		 dao = new ServProductService();
	   }catch(NamingException ne) {
		   ne.printStackTrace();
	   }
	}

	private void listProds(PrintWriter out, List<ServProductDto> list) {
		StringBuffer sb = new StringBuffer("<table><tr><td>Prod Id</td><td>Prod Name</td><td>Prod Cost</td><td>Dealer</td></tr>");
		list.forEach((pr) -> sb.append("<tr><td>"+pr.getProdId()+"</td><td>"+pr.getProdName()+"</td><td>"+pr.getProdCost()+"</td><td>"+pr.getDealer()+"</td></tr>"));
	    sb.append("</table>");
	    out.println(sb.toString());		
	}
	
	
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   response.setContentType("text/html");
	   PrintWriter out = response.getWriter();
	   String action = request.getParameter("act");
	   if(action.equalsIgnoreCase("list")) {
		   List<ServProductDto> list = dao.listAll();
		   this.listProds(out, list);
		   out.flush();
	   }
	   else if(action.equalsIgnoreCase("insert")) {
		   String prodNoStr = request.getParameter("prodId");
		   int prodNo = Integer.parseInt(prodNoStr);
		   String prodName = request.getParameter("prodName");
		   String prodCostStr = request.getParameter("prodCost");
		   double prodCost = Double.parseDouble(prodCostStr);
		   String dealer = request.getParameter("dealer");
	       ServProductDto dto = new ServProductDto(prodNo, prodName, prodCost, dealer);
	       boolean  ret = dao.saveProduct(dto);
	       if(ret) {
	    	   out.println(dto.toString()+ " is Safely Saved");
	       }
	       else {
	    	   out.println("problems in Safely Saved");	    	   
	       }
	       out.flush();
		   
	   } 
	   else if(action.equalsIgnoreCase("search")) {
		   String prodNoStr = request.getParameter("prodId");
		   int prodNo = Integer.parseInt(prodNoStr);
	       Optional<ServProductDto> dtoOpt = dao.searchProduct(prodNo);
	       if(dtoOpt.isPresent()) {
	    	   out.println("Searched Object is:" + dtoOpt.get().toString());
	       }else {
	    	   out.println("problems in Searching");	    	   
	       }
	       out.flush(); 
	       }	   
	}		

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
