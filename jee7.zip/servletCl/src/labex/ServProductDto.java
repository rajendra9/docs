package labex;

import java.io.Serializable;

public class ServProductDto implements Serializable {
   
	private int prodId;
	private String prodName;
	private double prodCost;
	private String dealer;
	
	public ServProductDto(int prodId, String prodName, double prodCost, String dealer) {
		super();
		this.prodId = prodId;
		this.prodName = prodName;
		this.prodCost = prodCost;
		this.dealer = dealer;
	}

	public ServProductDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public double getProdCost() {
		return prodCost;
	}

	public void setProdCost(double prodCost) {
		this.prodCost = prodCost;
	}

	public String getDealer() {
		return dealer;
	}

	public void setDealer(String dealer) {
		this.dealer = dealer;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + prodId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ServProductDto other = (ServProductDto) obj;
		if (prodId != other.prodId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ServProductDto [prodId=" + prodId + ", prodName=" + prodName + ", prodCost=" + prodCost + ", dealer="
				+ dealer + "]";
	}
	
	
	
	
	
	
	
}
