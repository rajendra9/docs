package labex;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;



public interface ServProdDao extends Serializable {
     
	public boolean saveProduct(ServProductDto  dto);
	public Optional<ServProductDto> searchProduct(int id);
	public List<ServProductDto> listAll();
	public void closeConn(); 
	String INSERT_SQL="insert into serv_prods values(?, ?, ?, ?)";
	
	String FIND_SQL="select prod_name,prod_cost,dealer from serv_prods where prod_id = ?";
	
	String FIND_ALL="select prod_id,prod_name,prod_cost,dealer from serv_prods"; 
	
     
}
