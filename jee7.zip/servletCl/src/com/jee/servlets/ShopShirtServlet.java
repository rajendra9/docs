package com.jee.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import  com.jee.utils.Dresses;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns={"/shop1"})
@SuppressWarnings("serial")
public class ShopShirtServlet extends HttpServlet {
   Dresses dresses;
   
   protected void doGet(HttpServletRequest request,
                        HttpServletResponse response)
	 throws ServletException, IOException {
 	doPost(request, response);
   }

   @Override
    public void init() throws ServletException {
	dresses = new Dresses();
    }

    @Override
    public void destroy() {
      dresses = null;
    }
    
    protected void doPost(HttpServletRequest request, 
	                  HttpServletResponse response) 
       throws ServletException, IOException {
       HttpSession session = request.getSession(true);
       String shirt = request.getParameter("shirt");
       Double cost = dresses.getCost(shirt);
       session.setAttribute(shirt, cost);
       response.sendRedirect("jeans.html");
    }

}
