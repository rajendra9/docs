package com.jee.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns={"/sendErr"})
@SuppressWarnings("serial")
public class SendErrServlet extends HttpServlet {
   
    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
      throws ServletException, IOException  {

        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) 
    throws ServletException, IOException   {
        /* if <error-page> is written then that will be displayed 
           else given string is printed */

        response.sendError(490, "message is MyError");
    }

}
