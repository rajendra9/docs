package com.jee.servlets;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jee.utils.TransportRequestWrapper;

import javax.servlet.RequestDispatcher;

@WebServlet(urlPatterns={"/transport"})
@SuppressWarnings("serial")
public class TransportServlet extends HttpServlet {
  
 public String getDealer(String type, double amount) {
   String dealer = "";
   if(type.equals("CA")) {
    if(amount<=450000) {
      dealer = "M/s TVS Motors";
    }
    else {
     dealer = "M/s Pioneer Motors";
    }
   }
   else {
    if(amount<=65000) {
     dealer = "M/s Jai Auto Dealers";
    }
    else {
     dealer = "M/s Star Automobiles";
    }
   }
   return dealer;
  }

 public void doGet(HttpServletRequest req,
                   HttpServletResponse res)
  throws ServletException,IOException {
  double funds = 0.0; 
  String trans = req.getParameter("transType");
  String fundsStr = req.getParameter("funds");
 
  if(fundsStr != null) {
   funds = Double.parseDouble(fundsStr);
  }

  String dealer = getDealer(trans,funds);

  req.setAttribute("Dealer",dealer);

  TransportRequestWrapper wrapper 
     = new TransportRequestWrapper(req);
 
  if(trans.equalsIgnoreCase("CA")) {

   RequestDispatcher  rd  = 
   this.getServletContext().getRequestDispatcher("/cars");
   
   rd.forward(wrapper,res);  
  }
  else if(trans.equalsIgnoreCase("MC")) {

   RequestDispatcher  rd  = this.getServletContext().
           getRequestDispatcher("/motorCycles");
   rd.forward(wrapper,res);  
  }
 }

}