package com.jee.servlets;
import  java.io.IOException;
import  javax.servlet.Filter;
import  javax.servlet.ServletRequest;
import  javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import  javax.servlet.FilterConfig;
import  javax.servlet.FilterChain;
import  javax.servlet.ServletException;

@WebFilter(filterName="filtOne")
public class MyFilter1 implements Filter {
 
 FilterConfig fconfig = null;
 
 public void init(FilterConfig conf)throws ServletException  {
  fconfig = conf;   
 }
   
 public void destroy() {
  fconfig = null;
 }
  
 public void doFilter(ServletRequest req, 
           ServletResponse res,FilterChain fc)
  throws ServletException, IOException {
   System.out.println("Before - MyFilter1");
 
   fc.doFilter(req,res);

   System.out.println("After - MyFilter1");

 }

}