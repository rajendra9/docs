package com.jee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.jee.utils.MediBillsResolver;

@WebServlet(urlPatterns={"/applyCookie"})
@SuppressWarnings("serial")
public class MedicalCookieServlet extends HttpServlet {
   MediBillsResolver resolver;
   
   @Override
   public void destroy() {
     resolver = null;
   }

   @Override
   public void init() throws ServletException {
     resolver = new MediBillsResolver();
   }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     doPost(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     response.setContentType("text/html");
     PrintWriter out = response.getWriter();   
     int empNo = 0;
     double bills = 0.0;
     String empNoStr = request.getParameter("empNo");
     String billsStr = request.getParameter("mediBills");
     if(empNoStr != null){
       empNo = Integer.parseInt(empNoStr);    
     }
     if(billsStr != null){
         bills = Double.parseDouble(billsStr);    
     }
     String reply = resolver.sanctionReimbursement(empNo, bills);
     reply = URLEncoder.encode(reply, "ISO-8859-1");
     if(!reply.equalsIgnoreCase("Employee no is not correct")){
      Cookie ck = new Cookie("mediResult",reply);
      int life = 2*24*60*60;
      ck.setMaxAge(life);
      ck.setPath("/servCl/statusReply");
      ck.setHttpOnly(true);
      response.addCookie(ck);
      out.println("<center><u>Submitted</u></center>");
     }
     else {
       out.println("<center><u>Employee no is not correct</u></center>");   
     }
     out.close();
   }
}
