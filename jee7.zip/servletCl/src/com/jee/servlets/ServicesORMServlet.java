package com.jee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.jee.utils.ServicesOrmDelegate;

@WebServlet(urlPatterns={"/servicesOrm"})
@SuppressWarnings("serial")
public class ServicesORMServlet extends HttpServlet {
   
    ServicesOrmDelegate delegate;
    
   
   @Override
    public void destroy() {
       delegate.close();
       delegate = null;
    }

    @Override
    public void init() throws ServletException {
        delegate = new ServicesOrmDelegate();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       PrintWriter out = response.getWriter();
       response.setContentType("text/html");
       String serviceName = request.getParameter("service");
       String payCharges = request.getParameter("servCharges");
       double payableCharges = Double.parseDouble(payCharges);
     
       boolean ret = delegate.addService(serviceName, payableCharges);
       out.println("<div align='center'>");
       if(ret){
         out.println("payment of "+serviceName+"'s Service Charge paid through ORM <br/>");
       }
       else {
           out.println("problems in saving  " + serviceName); 
       }
       out.println("</div>");   
       out.close();
   }
}