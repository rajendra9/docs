package com.jee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.jee.utils.OrderVO;
import com.jee.utils.OrdersMap;
import java.io.ObjectOutputStream;

@WebServlet(urlPatterns={"/objServlet"})
@SuppressWarnings("serial")
public class ObjectSentServlet 
  extends javax.servlet.http.HttpServlet {
	
	
 public void doGet(HttpServletRequest request,
                   HttpServletResponse response)
  throws ServletException, IOException {
 
  String orderStr = request.getParameter("ordId");
  try {
   if(orderStr != null) {
    int id = Integer.parseInt(orderStr);
    OrdersMap map = new OrdersMap();
    OrderVO order = map.getOrder(id);
    if(order==null) {
     order = new OrderVO(0,null,"id given not there",0.0);
    }
    response.setContentType(
     "application/x-java-serialized-object");

    ObjectOutputStream out =
      new ObjectOutputStream(response.getOutputStream());

    out.writeObject(order);
    out.flush();
    out.close();
   }
   else {
    PrintWriter out = response.getWriter();
    out.println("Order id should be given");
    out.close();
   }
  }   
  catch(Exception e) {
   PrintWriter out = response.getWriter();
   out.println("Order id is not correct");
   out.close();  
  }
 } 	
	
  public void doPost(HttpServletRequest request,
                         HttpServletResponse response)
    throws ServletException, IOException {
	   doGet(request,response);
  }
  	  	    
}