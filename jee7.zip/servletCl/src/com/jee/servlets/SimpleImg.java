package com.jee.servlets;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletContext;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns={"/img"})
@SuppressWarnings("serial")
public class SimpleImg extends HttpServlet {

 public void doGet(HttpServletRequest req, 
                   HttpServletResponse res)
  throws IOException,ServletException {

  res.setContentType("image/jpeg");
  
  ServletContext stx = this.getServletContext(); 
  File f = new File(stx.getRealPath("/images/smallbabies.jpeg"));
  int flen = (int)f.length();
 
  FileInputStream fin = new FileInputStream(f);
  byte buf[] = new byte[flen];
  res.setContentLength(flen);

  fin.read(buf);
  res.getOutputStream().write(buf);
  fin.close();
  res.getOutputStream().close();    
 }

}