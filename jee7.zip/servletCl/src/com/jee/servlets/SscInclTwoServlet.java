package com.jee.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns={"/ssc2"})
@SuppressWarnings("serial")
public class SscInclTwoServlet extends HttpServlet {

 public void doGet(HttpServletRequest req,
                   HttpServletResponse res)
   throws ServletException,IOException {

  int qty = Integer.parseInt(req.getParameter("qty"));
  Double itPrice  = (Double)req.getAttribute("itCost");
   
  double price = itPrice.doubleValue();
  double transCharge = 0.0;
  String deliveryMode = "";  

  if(qty<5) {
   transCharge = 25.50;
   deliveryMode = "Courier-HandDelivery";
  } 
  else if(qty>5 && qty<25) {
   transCharge = 50.50;
   deliveryMode = "Person-HandDelivery";
  }
  else if(qty>25 && qty<100) {
   transCharge = 105.50;
   deliveryMode = "Van-GoodsDelivery";
  }
  else {
   transCharge = 150.50;
   deliveryMode = "Lorry-GoodsDelivery";
  }

  res.setContentType("text/html");
  PrintWriter out = res.getWriter();
  
  out.println("<b><font color = 'blue' size = '+2'>" +
             " Total cost is: " + (qty*price) + "<br>");
   
  out.println("Transport charges  of qty '" + qty + 
               "' are:" + transCharge + "<br>");

   out.println(" Delivery is by " + deliveryMode + 
            ". <br>Happy shopping.<br><br></Font>");
   
  }

 }