package com.jee.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jee.utils.Authenticator;

import java.net.URLEncoder;

@WebServlet(urlPatterns={"/urlRe"})
@SuppressWarnings("serial")
public class UrlRewriteServlet extends HttpServlet {
   Authenticator authenticator;
   
   public String getUrlAppender(String un, String pw){
       StringBuilder sb = new StringBuilder();
       try {
       un = URLEncoder.encode(un, "ISO-8859-1");
       sb.append("username=" + un + "&");
       pw = URLEncoder.encode(pw, "ISO-8859-1");
       sb.append("password=" + pw);
       }catch(Exception ex){
           ex.printStackTrace();
       }
       return sb.toString();
   }

   @Override
   public void destroy() {
       authenticator= null;
   }

   @Override
    public void init() throws ServletException {
       authenticator = new Authenticator();
    }

    protected void doGet(HttpServletRequest request, 
                        HttpServletResponse response) 
         throws ServletException, IOException {
	doPost(request, response);
   }

   protected void doPost(HttpServletRequest request, 
                         HttpServletResponse response) 
       throws ServletException, IOException {
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
    
      String un = request.getParameter("username");
      String pw = request.getParameter("password");
      
      boolean isValid = authenticator.validateUser(un, pw);
      if(isValid){
        
        String token = this.getUrlAppender(un, pw);
        out.println("<div align=center>Welcome !to Url Rewriting <br>");
        out.println("<b>Click these Anchors to" + 
                      " Go to other Sites</b><br>");
        String url1 = "http://localhost:10080/servCl/oneServ?";
        out.println("<a href='" + url1 + token + "'>One-Servlet</a><br/>");

        HttpSession session = request.getSession();
        System.out.println(session);
        String normUrl=response.encodeURL("/servCl/normUrl.html");    
        out.println("<a href='"+ normUrl+"' >Norm Page</a></div>");
      }
      else {
       response.sendRedirect("urlRewrite.html");  
      }
      out.close();
       
   }

}
