package com.jee.servlets;

import  java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jee.utils.DBAuthenticator;

@WebFilter(filterName="loginFilter")
public class LoginFilter implements Filter  {
  FilterConfig fconfig = null;
  DBAuthenticator authenticator;
  
  public LoginFilter()  {
    System.out.println("LoginFilter contacted.\n");
  }
 
  public void init(FilterConfig conf)throws ServletException  {
     fconfig = conf;   
     authenticator = new DBAuthenticator();
  } 
   public void destroy() {
     fconfig = null;
     authenticator = null;
   }
   
  public void doFilter(ServletRequest req,
                       ServletResponse res,
                       FilterChain fc)
          throws ServletException,IOException  {
     HttpServletRequest hReq = (HttpServletRequest)req;
     HttpServletResponse hRes = (HttpServletResponse)res; 
     String user = (String)hReq.getParameter("username");   
     String pwd = (String)hReq.getParameter("password");   
     System.out.println(user + "::" + pwd);
     boolean valid = authenticator.validateUser(user, pwd);
     if(!valid) {
        System.out.println("authentication Failed");  
         hRes.sendRedirect("http://localhost:8080/servCl/filterLogin.html");
         return;
     }
     fc.doFilter(req,res); 
     authenticator.recordVisit(user);     
   }

 }