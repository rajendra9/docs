package com.jee.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;

@WebServlet(urlPatterns={"/ssc1"})
@SuppressWarnings("serial")
public class SscInclOneServlet extends HttpServlet {

 public void doGet(HttpServletRequest req,
                  HttpServletResponse res)
  throws ServletException, IOException {
   res.setContentType("text/html");
   PrintWriter out  =  res.getWriter();

   out.println("<center><h1>"+
           "Programmatic SSCommunication</h1>");
   out.println("<h2>WholeSale Cosmetics Market</h2>");

   String itName = req.getParameter("itemName");  
   double cost = 0.0;

   if(itName.equals("ponds")) {
      cost  =  25.60;
   }
   else if(itName.equals("denim")) {
      cost  =  54.50;
   }
   else if(itName.equals("lakme")) {
      cost  =  68.80;
   }
   
   out.println("<br>This Item requested is<b>" + 
              "<font size  =  '+2' color  =  'red'> " + 
              itName + "<br><br>");

   out.println("<b>Price of it per piece  is:" + cost + 
               "</font></b><br><br>");

   out.flush();

   //pass the request on to fill in the next part

   RequestDispatcher rd  =  
     this.getServletContext().getRequestDispatcher("/ssc2");

   req.setAttribute("itCost", new Double(cost));
   rd.include(req, res);

   out.println("If Not received within"+
               " 24 hrs Contact us.</center>");
   
   out.close();
  }

}
