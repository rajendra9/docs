package com.jee.servlets;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns={"/motorCycles"})
@SuppressWarnings("serial")
public class MotorCyclesServlet extends HttpServlet  {

 public void doGet(HttpServletRequest req,
                    HttpServletResponse res)
  throws ServletException,IOException {

   res.setContentType("text/html");
   PrintWriter out  =  res.getWriter();
   String   fundVal = req.getParameter("funds");
   double funds = 0.0;

   if(fundVal != null) {
     funds = Double.parseDouble(fundVal);
   }

   String dlr = (String)req.getAttribute("Dealer");   

   String disStr =  req.getParameter("discount");
   double dis = Double.parseDouble(disStr);

   if(funds<65000) {
    out.println("<center><b><font color  =  'blue' " + 
                 "size  =  '+2'>");
    out.println("<u>Types Present</u><br><br><br>");
    out.println("Bajaj-Classic--> 55,000.00<br><br>");
    out.println("Bajaj-Star-> 56,000.00<br><br>");
    out.println("Honda-Passion--> 64,000.00<br><br>");
    out.println("TVS-Star--> 51,000.00<br><br>");
    out.println("</font><font color='red'>");
    out.println("Contact "+dlr+" for details</font>"); 
   }
   else {
    out.println("<center><b><font color='blue'"+
                 "size='+2'>");
    out.println("<u>Types Present</u><br><br><br>");
    out.println("Bajaj-Pulsar--> 75,000.00<br><br>");
    out.println("Honda-DTS--> 76,000.00<br><br>");
    out.println("Escorts--> 83,000.00<br><br>");
    out.println("TVS-apache--> 1,00,000.00<br><br><br>");
    out.println("</font><font color='red'>");
    out.println("Contact "+dlr+" for details</font>"); 
   }

   if(dis>0.0) {
    out.println("<br><br>Discount at this time is:" +
                 dis * 100 + "%<br>");
    }
 
    out.close();
   }

 }
