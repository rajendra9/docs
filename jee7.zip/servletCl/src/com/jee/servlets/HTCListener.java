package com.jee.servlets;

import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.jee.utils.HTCInfo;
import javax.servlet.ServletContextEvent;
import java.util.HashMap;

@WebListener
public  final class HTCListener 
  implements HTCInfo,ServletContextListener {
   
 public HashMap<String,String> map;
 
 public HTCListener()  {
  System.out.println("HTCListener is initialized");
  map = new  HashMap<String,String>();
  String info = HTC_CO+"<br>"+HTC_ADDRESS;

  map.put("info", info);

  map.put("user1", "ashok");
  map.put("user2", "rajesh");
  map.put("user3", "samy"); 
 }
      
 public void contextInitialized(ServletContextEvent evt) { 
  evt.getServletContext().setAttribute(EFIN_USERS,map);
 }
   
 public void contextDestroyed(ServletContextEvent evt) {
  evt.getServletContext().removeAttribute(EFIN_USERS);
  map = null;
 } 
  
}