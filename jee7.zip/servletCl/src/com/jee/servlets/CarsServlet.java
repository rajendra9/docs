package com.jee.servlets;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns={"/cars"})
@SuppressWarnings("serial")
public class CarsServlet extends HttpServlet {

 public void doGet(HttpServletRequest req,
                   HttpServletResponse res)
  throws ServletException, IOException {

  res.setContentType("text/html");
  PrintWriter out  =  res.getWriter();
  String   fundVal = req.getParameter("funds");
  double funds = 0.0;

  if(fundVal != null) {
   funds = Double.parseDouble(fundVal);
  }

  String dlr = (String)req.getAttribute("Dealer");
  String disStr =  req.getParameter("discount");
  double dis = Double.parseDouble(disStr);
     
  if(funds<=450000) {
   out.println("<center><b><font color  =  'blue' " + 
               "size  =  '+2'>");
   out.println("<u>Types Present</u><br><br><br>");
   out.println("Maruthi-Alto-->2,40,000.00<br><br>");
   out.println("Maruthi-Zen-->3,55,000.00<br><br>");
   out.println("Huyndai-Contra-->2,80,000.00<br><br>");
   out.println("Premier-Padmini-->3,24,000.00<br><br>");
   out.println("</font><font color='red'>");
   out.println("Contact " + dlr + " for details"); 
  }
  else {
   out.println("<center><b><font color  =  'blue' " + 
               "size  =  '+2'>");
   out.println("<u>Types Present</u><br><br><br>");
    out.println("Honda-->6,20,000.00<br><br>");
    out.println("BMW-->8,65,000.00<br><br>");
    out.println("Maruthi-Deluxe-->6,56,000.00<br><br>");
    out.println("Premier-Renault-->6,32,000.00<br><br><br>");

    out.println("</font><font color='red'>");
    out.println("Contact " + dlr + " for details</font>"); 
  }
  if(dis>0.0) {
    out.println("<br><br>Discount at this time is:" + 
                 dis*100 + "%<br>");
  }
  out.close();
 }
    
}