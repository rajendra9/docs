package com.jee.servlets;
import  java.io.IOException;

import  javax.servlet.Filter;
import  javax.servlet.FilterChain;
import  javax.servlet.ServletException;
import  javax.servlet.ServletRequest;
import  javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import  javax.servlet.FilterConfig;

@WebFilter(filterName="filtThree")
public class MyFilter3 implements Filter {

 FilterConfig fconfig = null;
 
 public void init(FilterConfig conf)throws ServletException {
  fconfig = conf;   
 }
   
 public void destroy() {
  fconfig = null;
 }
  
 public void doFilter(ServletRequest req,
            ServletResponse res, FilterChain fc)
  throws ServletException, IOException  {
 
  System.out.println("Before - MyFilter3");
 
  fc.doFilter(req,res);
 
  System.out.println("After  -  MyFilter3");

 }

}