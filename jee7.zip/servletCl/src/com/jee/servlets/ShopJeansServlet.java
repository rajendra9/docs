package com.jee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.jee.utils.Dresses;

@WebServlet(urlPatterns={"/shop2"})
@SuppressWarnings("serial")
public class ShopJeansServlet extends HttpServlet {
   Dresses dresses;
	
   protected void doGet(HttpServletRequest request,
                        HttpServletResponse response)
       throws ServletException, IOException {
  	doPost(request, response);
   }

   @Override
   public void init() throws ServletException {
     dresses = new Dresses();
   }

   @Override
   public void destroy() {
     super.destroy();
     dresses = null;
   }

   protected void doPost(HttpServletRequest request, 
                         HttpServletResponse response) 
	  throws ServletException, IOException {
      HttpSession session = request.getSession(false);
      String jeans = request.getParameter("jeans");
      Double cost = dresses.getCost(jeans);
	   
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
      Enumeration<String> attrs = session.getAttributeNames();
      double total = cost;
      out.println("<center><h2>Dress Purchases</h2>");
      while(attrs.hasMoreElements()) {
         String shirtName = attrs.nextElement();
         double shirtCost = (Double)session.getAttribute(shirtName);
	 total += shirtCost;
	 out.println("<br/>Selected Shirt : "+shirtName+"<br/>");
      }
      out.println("Selected Jeans : "+jeans+"<br/>");
      out.println("Total cost is : "+total+"</center>");
    }

}
