package com.jee.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.jee.utils.Authenticator;

@WebServlet(urlPatterns={"/hiddenSess"})
@SuppressWarnings("serial")
public class HiddenSessServlet extends HttpServlet {
   Authenticator authenticator;
	   
   public String getHiddenForm(String site, String un, String pw){
     StringBuilder sb = 
       new StringBuilder("<form action='"+site+"' method='post'>");
     sb.append("<input type='hidden' name='username' value='"+un+"'>");
     sb.append("<input type='hidden' name='password' value='"+pw+"'>");
     sb.append("<input type='submit' value='Go to "+site+"'></form>");	       
     return sb.toString();
   }

   @Override
   public void destroy() {
     authenticator= null;
   }

   @Override
   public void init() throws ServletException {
     authenticator = new Authenticator();
   }

   protected void doGet(HttpServletRequest request, 
                        HttpServletResponse response) 
        throws ServletException, IOException {
    doPost(request, response);
   }

   protected void doPost(HttpServletRequest request, 
                         HttpServletResponse response) 
    throws ServletException, IOException {
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    
    String un = request.getParameter("username");
    String pw = request.getParameter("password");
      
    boolean isValid = authenticator.validateUser(un, pw);
    if(isValid){
      out.println("<div align=center><h2>you can choose among following sites</h2>");
      String result = this.getHiddenForm("fashionWare", un, pw);
      out.println(result+"<br/><br/>");
      result = this.getHiddenForm("footwear", un, pw);
      out.println(result+"</div>");
    }else {
      response.sendRedirect("hidInput.html");  
    }
    out.close();
   }

}
