package com.jee.servlets;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns={"/sample"})
@SuppressWarnings("serial")
public class SampleServlet extends HttpServlet {

 public void doGet(HttpServletRequest req,
                   HttpServletResponse res)
  throws ServletException,IOException  {
 
  res.setContentType("text/html");
  PrintWriter out = res.getWriter();
 
  String name = req.getParameter("name");
 
  out.println("<b>hello ! "+name+" </b><br>");
  out.println("<b>Welcome to Servlet Programming</b><br>");

  out.println("<i>Mark this date i.e:"+new Date().toString()+"</i>");
  out.close();
 }

}