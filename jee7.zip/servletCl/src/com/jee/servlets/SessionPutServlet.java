package com.jee.servlets;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns={"/sess"})
@SuppressWarnings("serial")
public class SessionPutServlet extends HttpServlet {

 public void doGet(HttpServletRequest req,
                   HttpServletResponse res) throws
   IOException, ServletException {
  HttpSession ses = req.getSession(true);
    
  PrintWriter out = res.getWriter();
  res.setContentType("text/html");
  int max = ses.getMaxInactiveInterval();
  out.println("<center>SESSION MAXIMUM INTERVAL IS::" + max + "<br>");
  ses.setMaxInactiveInterval(2*60*60);
  out.println("NOW SESSION MAXIMUM INTERVAL IS::" +  
               ses.getMaxInactiveInterval() + "<br>");

  out.println("SESSION NEW IS::" + ses.isNew() + "<br>");

  Double incr = (Double)ses.getAttribute("PEARS");
  double temp;
  Double ss;
  if(incr !=  null) {
    temp = incr.doubleValue();
    out.println("<i> LAST NOTED 'PEARS' VALUE IS :::" +
                temp + "</i><br>");
    ss = new Double(5.00+temp);
  }
  else {
   ss =  new Double(35.0);
  }   
  ses.setAttribute("PEARS",ss);
  out.println("<b> THE NEW 'PEARS' VALUE IS :::" + 
               ss + "</b></center>");
  out.close();
  }

}   