package com.jee.servlets;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns={"/fils"})
@SuppressWarnings("serial")
public class MyFilterServlet extends HttpServlet {

 public void doGet(HttpServletRequest req,
                   HttpServletResponse res)
  throws ServletException,IOException {

  res.setContentType("text/html");
  PrintWriter out = res.getWriter();
  
  out.println("<div align=center>");
  out.println("<b>hello! This is for "+
               " demonstrating Filters</b><br>");
  out.println("<b>See Server Startup window</b><br>");

  out.println("<i>Mark this date i.e:"+
                new Date().toString()+"</i>");
  out.println("</div>");
  out.close();
 }

}