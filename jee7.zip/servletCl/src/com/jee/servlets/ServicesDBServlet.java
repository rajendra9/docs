package com.jee.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.annotation.Resource;
import java.sql.Date;
import java.time.LocalDateTime;
import java.time.temporal.ChronoField;

@WebServlet(urlPatterns={"/servicesDB"})
@SuppressWarnings("serial")
public class ServicesDBServlet extends HttpServlet {
    
    @Resource(name="jdbc/myPostgres",type=javax.sql.DataSource.class)
    DataSource ds;
    
    static final  String SQL = 
   "insert into services(service_name,pay_date,charges) values(?,?,?)";   
    
    @Override
    public void destroy() {
      ds = null;
    }  
    
    public void init(){
     if(ds != null) {
        System.out.println("DataSource injected");
     }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      PrintWriter out = response.getWriter();
      response.setContentType("text/html");
      String serviceName = request.getParameter("service");
      String payCharges = request.getParameter("servCharges");
      double payableCharges = Double.parseDouble(payCharges);
      LocalDateTime locDt = LocalDateTime.now();
      
      Date dtVal = 
        new Date(locDt.getLong(ChronoField.MILLI_OF_SECOND));
      int rows = 0;
      try {
        Connection conn = ds.getConnection();
        PreparedStatement pstmt = conn.prepareStatement(SQL);
        pstmt.setString(1,serviceName);
        pstmt.setDate(2,dtVal);
        pstmt.setDouble(3,payableCharges);
        rows = pstmt.executeUpdate();
      }catch(SQLException sqEx){
          sqEx.printStackTrace();
      }
      
      out.println("<center>");
      if(rows>0){
          out.println("payment of "+serviceName+"'s Service Charge paid<br/>");  
      }else {
          out.println("problem in payment<br/>");   
      }
      out.close();
    }
}
