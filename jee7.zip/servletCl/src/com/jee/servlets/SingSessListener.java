package com.jee.servlets;

import java.util.Iterator;

import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import javax.servlet.ServletContext;
import javax.servlet.annotation.WebListener;

@WebListener
public class SingSessListener implements HttpSessionListener {

    public SingSessListener() {
    }

    public void sessionCreated(HttpSessionEvent arg0) {
        HttpSession sess = arg0.getSession();
        String id = sess.getId();
        System.out.println(id + " session is created");    
    }

    public void sessionDestroyed(HttpSessionEvent arg0) {
       HttpSession sess = arg0.getSession();
       String id = sess.getId();
       
       ServletContext ctx = sess.getServletContext(); 
       Map<String,String> sessions 
          = (Map<String,String>)ctx.getAttribute("sessions");
       System.out.println("before:"+sessions);
       if(sessions != null){
        if(sessions.containsValue(id)) {
         Iterator<Map.Entry<String,String>> iter
              = sessions.entrySet().iterator();
          while(iter.hasNext()) {
            Map.Entry<String,String> entry = iter.next();
            if(entry.getValue().equalsIgnoreCase(id)){
               iter.remove();
               break;
            }
          }
        }
        System.out.println("after:"+sessions);
      }
    }
	
}
