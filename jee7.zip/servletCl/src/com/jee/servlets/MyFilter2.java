package com.jee.servlets;
import  java.io.IOException;
import  javax.servlet.Filter;
import  javax.servlet.ServletRequest;
import  javax.servlet.FilterChain;
import  javax.servlet.ServletException;
import  javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import  javax.servlet.FilterConfig;

@WebFilter(filterName="filtTwo")
public class MyFilter2 implements Filter {

 FilterConfig fconfig = null;
 
 public void init(FilterConfig conf)throws ServletException {
  fconfig = conf;   
 }
   
 public void destroy() {
  fconfig = null;
 }
  
 public void doFilter(ServletRequest req,
            ServletResponse res, FilterChain fc)
  throws ServletException, IOException {
 
  System.out.println("Before - MyFilter2");
 
  fc.doFilter(req,res);
 
  System.out.println("After - MyFilter2");

 }

}