package com.jee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.servlet.annotation.MultipartConfig;

@WebServlet("/upload")
@MultipartConfig(location="/files")
/* you have to create folder 'files' like in this case
 * Workspace/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/work/Catalina/localhost/servCl
 * and check existence of them after program
 */
@SuppressWarnings("serial")
public class SimpUploadServlet extends HttpServlet {

   public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     doPost(request, response);	
   }

   public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
      Collection<Part> parts = request.getParts();
      for(Part part : parts){
	String fileName = part.getSubmittedFileName();
	System.out.println("**"+fileName);
	part.write(fileName);
      }
      out.println("<h3 align='center'>Files uploaded</h3>");
      out.close();
   }

}
