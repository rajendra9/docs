package com.jee.servlets;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebFilter(urlPatterns={"/singleSess"})
public class SingSessFilter implements Filter {
    FilterConfig filCfg;
    ServletContext ctx;
    ConcurrentMap<String,String> allowed;
    public void destroy() {
		// TODO Auto-generated method stub
    }

    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
       HttpServletRequest request = (HttpServletRequest)req;
       HttpServletResponse response = (HttpServletResponse)res;
        String username = request.getParameter("username");
        String pwd = request.getParameter("password");
        boolean valid = this.authenticate(username, pwd);
        if(valid) {
        HttpSession session = request.getSession();
        String sid = session.getId();
        Map<String,String> curUsers = (Map<String,String>)ctx.getAttribute("sessions"); 
        if(curUsers == null) {
            curUsers = new HashMap<>();
            curUsers.put(username, sid);
            ctx.setAttribute("sessions",curUsers);              
        }
        else {
          if(curUsers.containsKey(username)){
             response.sendRedirect("noSess.html");
          }
          else{
             curUsers.put(username,sid); 
          }          
        }
       }
       chain.doFilter(request, response);
    }
    private boolean authenticate(String un, String pw){
        boolean ret = false;
        if(allowed.containsKey(un)){
           String pwd = allowed.get(un);
           if(pwd.equalsIgnoreCase(pw)){
               ret = true;
           }
        }
        return ret;
    }
    public void init(FilterConfig fConfig) throws ServletException {
      this.filCfg = fConfig;
      ctx = filCfg.getServletContext();
      allowed = new ConcurrentHashMap<String, String>();
      allowed.put("saravanan","saravanan");
      allowed.put("subbarao","subbarao");
      allowed.put("madhavan","madhavan");
      allowed.put("manasa","manasa");
      allowed.put("rakesh","rakesh");     
    }

}
