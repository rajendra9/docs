package com.jee.servlets;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns={"/nf"})
@SuppressWarnings("serial")
public class NFormatServlet extends HttpServlet {

 public void doGet(HttpServletRequest req, 
                   HttpServletResponse res)
  throws ServletException,IOException {

  int input = 0;
  res.setContentType("text/html");
  PrintWriter out=res.getWriter();  
  try {
   input = Integer.parseInt(req.getParameter("val"));
  }
  catch(NumberFormatException e) {
   System.out.println("Wrong Input");
   throw e;
  }
  out.println("<center><b>Input is</b>" + input + "<br>");
  out.println("<b>Power to 5 is :</b>" + Math.pow(input,5) + "<br></center>");

  out.close();
 }
}