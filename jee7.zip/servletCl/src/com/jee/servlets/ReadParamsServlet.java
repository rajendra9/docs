package com.jee.servlets;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Enumeration;
import java.util.Map;
import java.util.Arrays;

@WebServlet(urlPatterns={"/readParams"})
@SuppressWarnings("serial")
public class ReadParamsServlet extends HttpServlet {

    private String checkBrowser(String str) {
      System.out.println("%%%%"+str); 
      String ret = "";
      if(str.indexOf("IE")>-1) {
        ret = "Browser is Microsoft IE";
      }
      else if(str.indexOf("Firefox")>-1) { 
        ret = "Browser is Mozilla Firefox";
      }
      else if(str.indexOf("Chrome")>-1) { 
          ret = "Browser is Google Chrome";
      }
      return ret;
    }
    
    public void pr(PrintWriter ot, String str) {
        ot.println(str + "<br><br>");
    }
    protected void doGet(HttpServletRequest request, 
                        HttpServletResponse response) 
                         throws ServletException, IOException {
      readParams(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       readParams(request, response);
   }

   private void  readParams(HttpServletRequest request, 
                            HttpServletResponse response) 
        throws ServletException, IOException {
        PrintWriter out = response.getWriter();
	response.setContentType("text/html");
	pr(out ,"<div align=center>");
	Map<String,String[]>  params =
	      request.getParameterMap();
        if(params != null) {
	    if(params.size()>0) {
             for(Map.Entry<String,String[]> entry : params.entrySet()) {
              pr(out, "parameter name is:" + entry.getKey());
	      String[] vals = entry.getValue();
	      pr(out, "<br/>parameter value/s:");
              if(vals.length>1) {
	          pr(out, Arrays.toString(vals));
	          pr(out, "<br/>");
	      }
	      else {
                pr(out, vals[0]);
                pr(out, "<br/>");
	      }
	}
      }
  }
        pr(out, "<span style='text-decoration:underline;'>HttpServletRequest methods</span>"); 
        pr(out, "SERVER ::"+request.getLocalName());
        pr(out, "-" + request.getLocalAddr());
        pr(out, "Receiving Port" + request.getLocalPort());
        pr(out, "Port:-->" + request.getServerPort());

        pr(out, "CLIENT ::" + request.getRemoteHost());
        pr(out, "-" + request.getRemoteAddr());
        pr(out, "Client-Port::" + request.getRemotePort());

        pr(out, "Query String:" + request.getQueryString());     
        pr(out, "Request-Url :" + request.getRequestURL().toString());
        pr(out, "Path Info:" + request.getPathInfo());//*
        pr(out, "Translated Path:" + request.getPathTranslated());//*

        pr(out, "Secure:" + request.isSecure());
        pr(out, "Client User:" + request.getRemoteUser()); //*
        pr(out, "Server User:" + request.getUserPrincipal()); //*
        pr(out, System.getProperty("user.name"));
           
        pr(out, "<br><u>ServletContext methods</u><br>");

        ServletContext stx = this.getServletContext();
        pr(out, "Real Path:" + stx.getRealPath("diffParams.html"));
        pr(out, "Mime Type:" + stx.getMimeType("diffParams.html"));
        pr(out, "Server Info:" + stx.getServerInfo());

       String uaStr = request.getHeader("user-agent");
       out.println(">>>>>>"+checkBrowser(uaStr));
       pr(out,"<br>Headers<br>"); 
       Enumeration<String> eHeaders = request.getHeaderNames();
       if(eHeaders != null) {
        String hName = eHeaders.nextElement(); 
        String hValue = request.getHeader(hName);         
        pr(out, hName + " ::" + hValue);
       }  
       String abbVal = this.getServletContext().getInitParameter("ABB");
       pr(out,"ABB share price:"+abbVal);
       String accVal = this.getServletContext().getInitParameter("ACC");
       pr(out,"ACC share price:"+accVal);
       pr(out, "</center>");
    out.close();
   }
}
