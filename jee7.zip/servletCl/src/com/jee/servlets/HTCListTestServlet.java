package com.jee.servlets;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns={"/listTest"})
@SuppressWarnings("serial")
public class HTCListTestServlet extends HttpServlet {

  public void doGet(HttpServletRequest req,
                    HttpServletResponse res)
   throws IOException, ServletException  {
  
  ServletContext stx = this.getServletContext();
  HashMap<String,String> map = 
    (HashMap<String,String>)stx.getAttribute(com.jee.utils.HTCInfo.EFIN_USERS);

  String usr = req.getParameter("user");
  String pwd = req.getParameter("password");
  res.setContentType("text/html");
  PrintWriter out = res.getWriter();
   
  try {
   String p1 = (String)map.get(usr);
   
   if(p1 == null) {
    System.out.println("user-"+usr+" is not existing");
    System.out.println("User is not authenticated");
    RequestDispatcher rd  = req.getRequestDispatcher("HTCForm.html");  
    rd.forward(req,res);
   }
   else if(p1.equalsIgnoreCase(pwd)) { 
    String info = (String)map.get("info");
    out.println("<center><br><h3 style='color:blue;'>"+info+"<br>");
    out.println("User is authenticated</h3></center>");
   }
  }
  catch(Exception e){}
 }

}