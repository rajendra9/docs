package com.jee.servlets;

import  java.io.IOException;
import java.time.LocalDate;

import  javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import  javax.servlet.http.HttpServlet;
import  javax.servlet.http.HttpServletRequest;
import  javax.servlet.http.HttpServletResponse;

@WebServlet("/filtLogin")
@SuppressWarnings("serial")
public class FilterLoginServlet  extends HttpServlet  {
   public void doPost(HttpServletRequest req,
                     HttpServletResponse res)
         throws IOException,ServletException
   {       
       LocalDate locDate = LocalDate.now();
       int year = locDate.getYear();
	   res.getWriter().println("<div align='center' style='color:blue;font-size:20px;font-weight:bold;'>Wish you all Happy Rainy season " + year + "</div>");
       res.getWriter().close();    
   }

 }
    