package com.jee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.jee.utils.ServicesDelegate;

@WebServlet(urlPatterns={"/services"},
initParams = {
   @WebInitParam(name="servicePayCounter", value="Guindy")     
},loadOnStartup=1)
@SuppressWarnings("serial")
public class ServicesServlet extends HttpServlet {
   ServicesDelegate delegate ;
    
   @Override
   public void destroy() {
     delegate = null;
   }

   @Override
   public void init() throws ServletException {
     System.out.println("Services Servlet"); 
     delegate = new ServicesDelegate(); 
   }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     doPost(request, response);
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     PrintWriter out = response.getWriter();
     response.setContentType("text/html");
     String serviceName = request.getParameter("service");
     String payCharges = request.getParameter("servCharges");
     double payableCharges = Double.parseDouble(payCharges);
     boolean boo = delegate.addService(serviceName, payableCharges);
     out.println("<div align=center>");
     out.println("<h2>Services Payment Center</h2>");
     
     if(boo){
       out.println("payment of " + serviceName + "'s Service Charge paid<br/>");  
     }else {
       out.println("problem in payment<br/>");   
     }
     ServletConfig config = this.getServletConfig();
     String location = config.getInitParameter("servicePayCounter");
     out.println("Payment location is :" + location + "<br/>");
      
     ServletContext ctx = this.getServletContext();
     String db = ctx.getInitParameter("serviceDB");
     out.println("Service Stores DB is :" + db + "</div>");
     out.close();
    }
	
}
