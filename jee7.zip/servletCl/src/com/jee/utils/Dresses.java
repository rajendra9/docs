package com.jee.utils;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class Dresses implements java.io.Serializable {
    ConcurrentMap<String,Double> dressCosts ; 
    
    {
      dressCosts = new ConcurrentHashMap<String,Double>();
      dressCosts.put("Lee", 1250.5);
      dressCosts.put("Denim", 980.5);
      dressCosts.put("Vivaldi", 350.5);
      dressCosts.put("Arrow", 470.5);       
    }
	
    public Double getCost(String brand) {
	Double ret = 0.0;
	if(dressCosts.containsKey(brand)) {
          ret = dressCosts.get(brand);
	}
	return ret;
    }

}
