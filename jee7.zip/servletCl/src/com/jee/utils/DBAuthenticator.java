package com.jee.utils;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBAuthenticator implements java.io.Serializable {
  DataSource ds;
  private String sqlQry = "select count(1) from validusers "
  		+ "where username = ? and password = ?";
  private String insertSql = "insert into authTable"
  		+ " values(current_date, ?)";
 
  public DBAuthenticator() {
	try{ 
      Context ctx = new InitialContext();
      ds = (DataSource)ctx.lookup("java:comp/env/jdbc/myPostgres");  
    }catch(NamingException ne){
    	throw new RuntimeException(ne.getMessage());
    }
  }
  public  boolean  validateUser(String username, String password){
	  boolean ret = false;
	  Connection conn = null;
	  try{
	    conn = ds.getConnection();
	    PreparedStatement pstmt = conn.prepareStatement(sqlQry);
	    pstmt.setString(1,  username);
	    pstmt.setString(2, password);
        ResultSet rs = pstmt.executeQuery();
        if(rs.next()){
        	int cnt = rs.getInt(1);
        	ret = (cnt>0) ? true : false;
        }
	  }catch(SQLException sqe){
		  throw new RuntimeException(sqe.getMessage());
      }finally{
    	  try { conn.close(); }catch(Exception ex){};
      }
    return ret;
  }
  
  public boolean recordVisit(String username) {
	  Connection conn = null;
	  try{  
	    conn = ds.getConnection();
	    PreparedStatement  pstmt = conn.prepareStatement(insertSql);
	    pstmt.setString(1,username);
	    int rows = pstmt.executeUpdate();
        if(rows > 0) {
        	System.out.println("user entry audited");
        	return true;
        }
     }catch(SQLException sqe){
		  throw new RuntimeException(sqe.getMessage());
     }finally{
   	    try { conn.close(); }catch(Exception ex){};
     }
	 return false;  
  }
  
}