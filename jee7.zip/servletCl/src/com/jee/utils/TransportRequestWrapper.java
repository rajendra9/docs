package com.jee.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.util.GregorianCalendar;
import java.util.Calendar;
import java.util.Map;

public  class  TransportRequestWrapper  
      extends HttpServletRequestWrapper {

  HttpServletRequest request;

  public TransportRequestWrapper(HttpServletRequest req) {
    super(req);
    this.request = req;
  }
  
  public String getParameter(String name) {
   String ret = "";
   GregorianCalendar gc = new GregorianCalendar();
   int mon = gc.get(Calendar.MONTH);
   
   if(name.equals("discount")) {
    if((mon >= 3) && (mon < 10)) {
      ret = "" + new Double(0.15);
    }
    else{
      ret = "0.05";
    } 
   }
   else {
     ret = request.getParameter(name);  
   }
   
   return ret;   
 }

  public Map<String,String[]> getParameterMap() {
    Map<String,String[]> map = super.getParameterMap();
    map.put("discount",
            new String[]{getParameter("discount")});   
    return map;
  }

  public String[] getParmeterValues(String param) {
   String[] ret = new String[1];
   ret[0] = getParameter(param);
   return ret;
  }

}