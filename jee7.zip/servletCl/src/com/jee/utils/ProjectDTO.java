package com.jee.utils;

import java.io.Serializable;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

public class ProjectDTO implements Serializable,HttpSessionBindingListener {
  
   private String projectId;
   private String projectName;
   private String location;
   private double estimatedCost;
   private double currentSpentCost;
   
   DataSource ds;
   Connection conn;
   
   private void lookup(){
     try{
       Context ctx = new InitialContext();
       ds = (DataSource)ctx.lookup("java:comp/env/jdbc/myPostgres");
       conn = ds.getConnection();
     }catch(NamingException | SQLException ex){
         ex.printStackTrace();
     }
   }
   
   private void populate() {
     String id = this.projectId;
     String sql = 
       "select proj_name, location, est_cost_lakhs, cur_spent_lakhs "+
       " from genprojects where proj_id=?";
     try {
       PreparedStatement pstmt = conn.prepareStatement(sql);
       pstmt.setString(1,id);
       ResultSet rs = pstmt.executeQuery();
       if(rs.next()){
         this.projectName = rs.getString(1);
         this.location = rs.getString(2);
         this.estimatedCost = rs.getDouble(3);
         this.currentSpentCost = rs.getDouble(4);
       }
     }catch(SQLException ex){
         ex.printStackTrace();
     }finally{
        try{
           if(conn != null) { conn.close(); } 
        }catch(SQLException sq){}
     }
   }
   public ProjectDTO() {
    super();
    lookup();
   }

   public ProjectDTO(String projectId) {
     super();
     this.projectId = projectId;
     lookup();
   }

   public String getProjectId() {
     return projectId;
   }
 
   public void setProjectId(String projectId) {
     this.projectId = projectId;
   }

   public String getProjectName() {
     return projectName;
   }

   public void setProjectName(String projectName) {
      this.projectName = projectName;
   }

   public String getLocation() {
     return location;
   }

   public void setLocation(String location) {
      this.location = location;
   }

   public double getEstimatedCost() {
      return estimatedCost;
   }

   public void setEstimatedCost(double estimatedCost) {
      this.estimatedCost = estimatedCost;
   }

   public double getCurrentSpentCost() {
      return currentSpentCost;
   }

   public void setCurrentSpentCost(double currentSpentCost) {
      this.currentSpentCost = currentSpentCost;
   }

   @Override
   public int hashCode() {
     final int prime = 31;
     int result = 1;
     result = prime * result + ((projectId == null) ? 0 : projectId.hashCode());
     return result;
   }

   @Override
   public boolean equals(Object obj) {
     if (this == obj)
         return true;
     if (obj == null)
         return false;
     if (getClass() != obj.getClass())
         return false;
     ProjectDTO other = (ProjectDTO) obj;
     if (projectId == null) {
         if (other.projectId != null)
             return false;
     } else if (!projectId.equals(other.projectId))
         return false;
     return true;
    }

    @Override
    public String toString() {
       return "ProjectDTO [projectId=" + projectId + ", projectName="
            + projectName + ", location=" + location + ", estimatedCost="
            + estimatedCost + ", currentSpentCost=" + currentSpentCost + "]";
    }

    @Override
    public void valueBound(HttpSessionBindingEvent arg0) {
        this.populate();
        
    }

    @Override
    public void valueUnbound(HttpSessionBindingEvent arg0) {
        this.projectId ="";
        this.projectName="";
        this.location = "";
        this.estimatedCost = 0.0;
        this.currentSpentCost = 0.0;
        
    }
   
    
   
   
   
   
   
   
}
