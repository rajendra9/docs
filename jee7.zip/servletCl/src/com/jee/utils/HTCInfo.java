package com.jee.utils;

public interface HTCInfo {

  String HTC_CO = "M/s HTC Global Solutions Ltd";
  String HTC_ADDRESS = " MEPZ Tambaram Chennai-600045";
  String EFIN_USERS = "efin";

}
 