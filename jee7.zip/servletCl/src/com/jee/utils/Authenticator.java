package com.jee.utils;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class Authenticator implements java.io.Serializable {
  ConcurrentMap<String,String> users;
  
  public Authenticator() {
    users = new ConcurrentHashMap<String, String>();
    users.put("AAAA","1111");
    users.put("BBBB","2222");
    users.put("CCCC","3333");
    users.put("DDDD","4444");    
  }

  public  boolean  validateUser(String username, String password){
    System.out.println(username+"....."+password);
    boolean ret = false;
    if(users.containsKey(username)) {
      String pword = users.get(username);
      if(pword.equals(password)){
          ret = true;
      }
    }
    return ret;
  }
  
}
