package com.jee.utils;

import java.io.Serializable;
import java.util.Date;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentHashMap;

public class ServicesDelegate implements Serializable {
    
   ConcurrentMap<ServiceEntry, Double>  services;

   public ServicesDelegate() {
     super();
     services = new ConcurrentHashMap<>();
   }
      
   public boolean addService(String serviceName, double charges){
       boolean ret = false;
       ServiceEntry entry = new ServiceEntry(serviceName,new Date());
       if(!services.containsKey(entry)) {
           services.put(entry, charges);
           ret = true;
       }
       System.out.println("**"+services+"**");
       return ret;
   }
}
