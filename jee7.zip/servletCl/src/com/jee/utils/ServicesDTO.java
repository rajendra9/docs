package com.jee.utils;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.time.LocalDate;

@Entity
@Table(name="SERVICES")
public class ServicesDTO implements Serializable {
    
    private  int       transId;	
    private  String     serviceName;
    private  LocalDate  payDate;
    private  double     serviceCharges;
	
    public ServicesDTO() {		
    }  
    
    public ServicesDTO(String serviceName, LocalDate payDate, double serviceCharges) {
        super();
        this.serviceName = serviceName;
        this.payDate = payDate;
        this.serviceCharges = serviceCharges;
    }
    
    @Id
    @SequenceGenerator(name="services_idservices_seq",
    sequenceName="services_idservices_seq",
    allocationSize=1)
   @GeneratedValue(strategy = GenerationType.SEQUENCE,
        generator="services_idservices_seq")
   @Column(name="TRANS_ID")
    public int getTransId() {
        return transId;
    }

    public void setTransId(int transId) {
        this.transId = transId;
    }
    @Column(name="PAY_DATE")
    public LocalDate getPayDate() {
        return payDate;
    }
    public void setPayDate(LocalDate payDate) {
        this.payDate = payDate;
    }

    @Column(name="SERVICE_NAME")
    public String getServiceName() {
	return serviceName;
    }

    public void setServiceName(String serviceName) {
	this.serviceName = serviceName;
    }

    @Column(name="CHARGES")
    public double getServiceCharges() {
	return serviceCharges;
    }

    public void setServiceCharges(double serviceCharges) {
	this.serviceCharges = serviceCharges;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (transId ^ (transId >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ServicesDTO other = (ServicesDTO) obj;
        if (transId != other.transId)
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "ServicesDTO [transId=" + transId + ", serviceName=" + serviceName + ", payDate=" + payDate
                + ", serviceCharges=" + serviceCharges + "]";
    }   

}
