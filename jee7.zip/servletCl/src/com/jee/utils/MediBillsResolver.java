package com.jee.utils;

import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentHashMap;

public class MediBillsResolver implements java.io.Serializable {
    
    //key is empId, value id eligible/existing amount
    private ConcurrentMap<Integer,Double> allowedBills;
    
    {
     allowedBills = new ConcurrentHashMap<Integer,Double>();    
     allowedBills.put(1111, 6800.5);
     allowedBills.put(2222, 7510.5);
     allowedBills.put(3333, 8420.5);
     allowedBills.put(4444, 4940.5);
     allowedBills.put(5555, 4985.0);
   }
    
   public String sanctionReimbursement(int empId, 
                                         double submitted){
     StringBuilder ret = new StringBuilder();
     if(allowedBills.containsKey(empId)) {
       double existing = allowedBills.get(empId);
       if(existing>=submitted){
         ret.append("Reimbursment being paid");
         allowedBills.put(empId, (existing-submitted));
       }
       else {
        ret.append("Not sufficient amount available ");
        ret.append("<br/>only "+existing+" available");
       }      
      }
     else {
         ret.append("<span style='text-decoration:underline;'>Employee no is not correct</span>");  
     }
     return ret.toString();
    }
}
