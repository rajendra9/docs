package com.jee.utils;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class ServicesOrmDelegate implements Serializable {
    EntityManager em ;
    EntityTransaction trans;
    EntityManagerFactory emf;
    
    {
      emf = Persistence.createEntityManagerFactory("myDB");
      em = emf.createEntityManager();
      System.out.println("***"+em);
    }
          
   public boolean addService(String serviceName, double charges){
     ServicesDTO dto = new ServicesDTO(serviceName, LocalDate.now(),charges);
     trans = em.getTransaction();
     trans.begin();
     try{
       em.persist(dto);
       trans.commit();
       return true;
     }catch(Exception ex){
       ex.printStackTrace();
       trans.rollback();
       return false;
     }
   }    
   public void close(){
       emf.close();
   }
}
