drop table if exists authtable;

create table authtable(logdate date,username varchar(30));

select *  from authtable;

delete from authtable;