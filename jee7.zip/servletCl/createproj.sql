drop table genprojects;

create table genprojects(proj_id  varchar(20) primary key,
proj_name  varchar(20),location varchar(20),est_cost_lakhs float,cur_spent_lakhs float);

insert into genprojects values('C100','Metro-Rail','Chennai',86500.0,76500.0);
insert into genprojects values('C120','Airport','Chennai',265000.0,245500.0);
insert into genprojects values('H100','Metro-Rail','Hyderabad',82500.0,43500.0);
insert into genprojects values('B100','Metro-Rail','Bangalore',80500.0,63500.0);
insert into genprojects values('K100','Metro-Rail','Cochin',50500.0,13500.0);
commit;
