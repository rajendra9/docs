drop table if exists serv_prods;

create  table serv_prods(prod_id integer  primary key,
prod_name  varchar(30),prod_cost decimal(8,2),dealer varchar(40));