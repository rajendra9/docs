var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');

var app = express();
var logger = function(request, response, next){
  console.log('Logging.....');
  next();
}
app.use(logger);
// view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

app.use(express.static(path.join(__dirname,'public')));
/*var person ={
    name: 'Santosh',
    age: 30
}
var people = [
    {
        name: 'Santosh',
        age: 30
    },
    {
        name: 'Raveena',
        age: 24
    },{
        name: 'Lekhak',
        age: 28
    }  
]*/
app.get('/', function(request, response){
    // response.json(person);
    // response.json(people);
    //response.send('Hello world');
    response.render('index',{
        title: 'Hello Customers'
    });
});
app.listen(5000, function(){
    console.log('Server Started at 5000');
})