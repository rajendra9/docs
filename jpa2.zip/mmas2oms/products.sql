drop table  mm_products cascade constraints;

drop  table mm_dealers cascade constraints;

drop  table mm_dealer_product cascade constraints ;

create table mm_dealer_product(dealer_product_id number, product_id number,
dealer_id number ,
ship_date date,
constraint dp_PK primary key(dealer_product_id));

create table mm_products(prod_id number constraint MM_PRODS_PK primary key,
pname varchar2(20),
cost number(8,2)); 

create table mm_dealers(dealer_id number constraint MM_DEALS_PK primary key,
dname varchar2(20),
address varchar2(30), 
turnover number(8,2));

alter table mm_dealer_product add constraint MM_DP_FK1 foreign key(dealer_id) references mm_dealers(dealer_id);

alter table mm_dealer_product add constraint MM_DP_FK2 foreign key(product_id) references mm_products(prod_id);

commit;


