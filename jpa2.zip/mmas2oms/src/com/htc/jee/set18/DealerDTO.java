package com.htc.jee.set18;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

import java.util.HashSet;
import java.util.Set;


@Entity
@Table(name="TWO_OM_DEALERS")
@NamedQuery(name="DealerDTO.findAll", query="SELECT d FROM DealerDTO d")
public class DealerDTO implements Serializable {
   
    private int dealerId;
    private String address;
    private String dealerName;
    private double turnover;
    private Set<DealerProduct> dealerProduct = new HashSet<>();

    public DealerDTO() {
    } 
    
    public DealerDTO(int dealerId, 
                     String dealerName,
                     double turnover,
                     String address) {
        super();
        this.dealerId = dealerId;
        this.dealerName = dealerName;
        this.turnover = turnover;
        this.address = address;
    }

    @Id
    @Column(name="DEALER_ID")
    public int getDealerId() {
       return this.dealerId;
    }

    public void setDealerId(int dealerId) {
       this.dealerId = dealerId;
    }

    @Column
    public String getAddress() {
       return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Column(name="DNAME")
    public String getDealerName() {
       return this.dealerName;
    }

    public void setDealerName(String dname) {
      this.dealerName = dname;
    }

    @Column
    public double getTurnover() {
      return this.turnover;
    }

    public void setTurnover(double turnover) {
      this.turnover = turnover;
    }

    @OneToMany(mappedBy="dealer")
    public Set<DealerProduct> getDealerProduct() {
       return this.dealerProduct;
    } 
    
    
    public void setDealerProduct(Set<DealerProduct> dealerProduct) {
        this.dealerProduct = dealerProduct;
    }

    public void addDealerProduct(DealerProduct dealerProduct){
        this.getDealerProduct().add(dealerProduct);
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + dealerId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        DealerDTO other = (DealerDTO) obj;
        if (dealerId != other.dealerId)
            return false;
        return true;
    }

    @Override
    public String toString() {
     StringBuilder sb = new StringBuilder();
     sb.append("Dealer-Id:"+dealerId+
               " Name:"+dealerName+
               " Address:"+address+
               " TurnOver:"+turnover);
     return sb.toString();
    }

}