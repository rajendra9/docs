package com.htc.jee.set18;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Column;
import java.time.LocalDate;

@Entity
@Table(name="TWO_OM_DEALER_PRODUCT")
public class DealerProduct implements java.io.Serializable {

    private int  dealerProductId;
    private ProductDTO product = new ProductDTO();
    private DealerDTO  dealer = new DealerDTO();
    private LocalDate shipDate = LocalDate.now();
   
    
    @Id
    @Column(name="DEALER_PRODUCT_ID")
    public int getDealerProductId() {
        return dealerProductId;
    }



    public void setDealerProductId(int dealerProductId) {
        this.dealerProductId = dealerProductId;
    }


    @ManyToOne
    @JoinColumn(name="PRODUCT_ID")
    public ProductDTO getProduct() {
        return product;
    }

    public void setProduct(ProductDTO product) {
        this.product = product;
    }

    @ManyToOne
    @JoinColumn(name="DEALER_ID")
    public DealerDTO getDealer() {
        return dealer;
    }

    public void setDealer(DealerDTO dealer) {
        this.dealer = dealer;
    }
    
    @Column(name="SHIP_DATE")
    public LocalDate getShipDate() {
        return shipDate;
    }

    public void setShipDate(LocalDate shipDate) {
        this.shipDate = shipDate;
    }

    public DealerProduct(int dealerProductId, LocalDate shipDate) {
        super();
        this.dealerProductId = dealerProductId;
        this.shipDate = shipDate;
    }

    public DealerProduct() {
        // TODO Auto-generated constructor stub
    }

}
