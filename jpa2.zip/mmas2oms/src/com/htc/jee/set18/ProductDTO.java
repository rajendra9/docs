package com.htc.jee.set18;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import java.util.HashSet;
import java.util.Set;


@Entity
@Table(name="TWO_OM_PRODUCTS")
@NamedQuery(name="ProductDTO.findAll", query="SELECT p FROM ProductDTO p")
public class ProductDTO implements Serializable {

    private int prodId;
    private double cost;
    private String prodName;
    private Set<DealerProduct> dealerProduct = new HashSet<>();

    public ProductDTO() {
    }    
    
    public ProductDTO(int prodId, String prodName, double cost) {
        super();
        this.prodId = prodId;
        this.cost = cost;
        this.prodName = prodName;
    }    
    
    public void setDealerProduct(Set<DealerProduct> dealerProduct) {
        this.dealerProduct = dealerProduct;
    }

    @Id
    @Column(name="PROD_ID")
    public int getProdId() {
      return this.prodId;
    }

    public void setProdId(int prodId) {
      this.prodId = prodId;
    }

    @Column
    public double getCost() {
      return this.cost;
    }

    public void setCost(double cost) {
      this.cost = cost;
    }

    @Column(name="PNAME")
    public String getProdName() {
       return this.prodName;
    }

    public void setProdName(String pname) {
      this.prodName = pname;
    }


     @OneToMany(mappedBy="product")
     public Set<DealerProduct> getDealerProduct() {
        return this.dealerProduct;
     }     
     
     public void addDealerProduct(DealerProduct dealerProduct){
         this.getDealerProduct().add(dealerProduct);
     }
     
     @Override
     public String toString()  {
      StringBuilder sb = new StringBuilder();
      sb.append("Prod-Id:" + prodId + " Name: " + prodName + " Cost:" + cost);
      return sb.toString();
     }     
     
     @Override
     public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + prodId;
        return result;
     }
     
     @Override
     public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ProductDTO other = (ProductDTO) obj;
        if (prodId != other.prodId)
            return false;
        return true;
      }
 
     
}