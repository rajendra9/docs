package com.htc.jee.set18;

import java.io.Serializable;
import java.time.LocalDate;

public interface HibSalesDAO extends Serializable {
  public  void  close();
  public  boolean saveDealer(DealerDTO dealer);
  public  boolean saveProduct(ProductDTO product);
  public boolean saveDealerProduct(int dealerProdId, int dealerId, int prodId, LocalDate shippingDate);
  
  
}
