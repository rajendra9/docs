package com.htc.jee.set18;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.List;

public class TestHibSales {

    
    public static void main(String[] args) {
        HibSalesDAO hibSalesDao = new HibSalesService();
        LocalDate sDate = LocalDate.of(2015, Month.DECEMBER, 23);
        DealerDTO dealer = 
                new DealerDTO(1010, "M/s Martandam & Bros", 230000.5, "Tambaram,Chennai");
        boolean boo = hibSalesDao.saveDealer(dealer);
        System.out.println("Dealer dealer saved is:"+boo);
        
        ProductDTO product = new ProductDTO(10, "Lux", 19.50);   
        boo = hibSalesDao.saveProduct(product);
        System.out.println("product  saved is:"+boo);
        product = new ProductDTO(20, "Pears", 25.80);
        boo = hibSalesDao.saveProduct(product);
        System.out.println("product saved is:"+boo);
        
        boo = hibSalesDao.saveDealerProduct(10000, 1010, 10, sDate);
        System.out.println("DealerProduct saved is " + boo);
        sDate = LocalDate.of(2015, Month.DECEMBER, 22);
        boo = hibSalesDao.saveDealerProduct(10010, 1010, 20, sDate);
        System.out.println("DealerProduct saved is " + boo);        
        hibSalesDao.close();
    }

}
