package com.htc.jee.set18;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import java.util.Optional;

public class HibSalesService implements HibSalesDAO {
   
    static SessionFactory sessFactory;
    static {
        sessFactory = HibernateBoot.getFactory(); 
    }
    
    public Session getSession() {
        return sessFactory.openSession();
    }           
    
    @Override
    public boolean saveDealer(DealerDTO dealer) {
       boolean ret = false;       
       Session session = this.getSession();
       Transaction trans = session.beginTransaction();
       try{
           Serializable id = session.save(dealer);
           if(id != null){
             ret = true;
             trans.commit();   
           }
        }catch(Exception ex){
            ex.printStackTrace();
            trans.rollback();
        }
        session.close();
        return ret;      
    }

    @Override
    public boolean saveProduct(ProductDTO product) {
        boolean ret = false;       
        Session session = this.getSession();
        Transaction trans = session.beginTransaction();
        try{
            Serializable id = session.save(product);
            if(id != null){
              ret = true;
              trans.commit();   
            }
         }catch(Exception ex){
             ex.printStackTrace();
             trans.rollback();
         }
         session.close();
         return ret;      
    }

    @Override
    public boolean saveDealerProduct(int dealerProdId, int dealerId, int prodId, LocalDate shippingDate) {
        boolean ret = false;       
        Session session = this.getSession();
        Transaction trans = session.beginTransaction();
        try{
          DealerDTO dealer = session.get(DealerDTO.class, new Integer(dealerId));
          ProductDTO product = session.get(ProductDTO.class, new Integer(prodId));
          DealerProduct  dealerProduct = new DealerProduct(dealerProdId,shippingDate);
          dealerProduct.setDealer(dealer);
          dealerProduct.setProduct(product);
          Serializable id = session.save(dealerProduct);
          dealer.addDealerProduct(dealerProduct);
          product.addDealerProduct(dealerProduct);
          session.update(dealer);
          session.update(product);;
          if(id != null){
              ret = true;
              trans.commit();   
          }
         }catch(Exception ex){
             ex.printStackTrace();
             trans.rollback();
         }
         session.close();
         return ret;      
        
        
    }   
    
    @Override
    public void close() {
      sessFactory.close();       
    } 
    

}
