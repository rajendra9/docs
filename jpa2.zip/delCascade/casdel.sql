drop table if exists compu_items;


drop table if exists compu_stores;

create  table compu_stores(store_id integer primary key, store_name  varchar(25),
store_loc varchar(30), approx_investment_cost_lacs decimal);

create  table compu_items(item_id integer primary key, item_name  varchar(25),
item_cost decimal, store_id integer references compu_stores(store_id));

insert into compu_stores values(1001, 'LineStores','Bay-11',12.5);
insert into compu_stores values(1002, 'Raw Material Stores','Bay-15',22.5);
insert into compu_stores values(1003, 'SubAsslyStores','Bay-09',5.5);


insert into compu_items values(101, 'itemA', 53.5, 1002);
insert into compu_items values(102, 'itemB', 23.5, 1002);
insert into compu_items values(103, 'itemC', 24.5, 1001);
insert into compu_items values(104, 'itemD', 120.5, 1001);

commit;

select *  from compu_stores;
select *  from compu_items;
