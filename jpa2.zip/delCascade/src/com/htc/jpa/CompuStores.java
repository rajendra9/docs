package com.htc.jpa;
/*
 * tore_id integer, store_name  varchar(25),
store_loc varchar(30),  decimal
 */

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import javax.persistence.CascadeType;

@Entity
@Table(name="compu_stores")
public class CompuStores implements Serializable {

	private   int     storeId;
	private   String  storeName;
	private   String  storeLocation;
	private   double  approxInvestment;
	
    private Set<CompuItem>  items = new HashSet<>();

	public CompuStores() {
		super();
	}

	public CompuStores(int storeId, String storeName, String storeLocation, double approxInvestment) {
		super();
		this.storeId = storeId;
		this.storeName = storeName;
		this.storeLocation = storeLocation;
		this.approxInvestment = approxInvestment;
	}

	@Id
	@Column(name="store_id")
	public int getStoreId() {
		return storeId;
	}

	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}

	@Column(name="store_name")
	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	@Column(name="store_loc")
	public String getStoreLocation() {
		return storeLocation;
	}

	public void setStoreLocation(String storeLocation) {
		this.storeLocation = storeLocation;
	}

	@Column(name="approx_investment_cost_lacs")
	public double getApproxInvestment() {
		return approxInvestment;
	}

	public void setApproxInvestment(double approxInvestment) {
		this.approxInvestment = approxInvestment;
	}
	
	@OneToMany(mappedBy="store",
	cascade = {CascadeType.PERSIST, CascadeType.REMOVE})
	public Set<CompuItem> getItems() {
		return items;
	}

	public void setItems(Set<CompuItem> items) {
		this.items = items;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + storeId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CompuStores other = (CompuStores) obj;
		if (storeId != other.storeId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CompuStores [storeId=" + storeId + ", storeName=" + storeName + ", storeLocation=" + storeLocation
				+ ", approxInvestment=" + approxInvestment + ", items=" + items + "]";
	}
    
    
	

}
