package com.htc.jpa;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class CascadeTesting implements CascadeDeleteTest {

	EntityManagerFactory emf;
	EntityManager em;
	EntityTransaction trans;
	
	{
		emf = Persistence.createEntityManagerFactory("myDB");
		em = emf.createEntityManager();
	}
	
	@Override
	public void closeEF() {
	  if(emf != null) {
		  emf.close();
		  emf = null;
	  }
	}

	@Override
	public CompuStores searchStoreById(int storeId) {
	   CompuStores stores = new CompuStores();
	   trans = em.getTransaction();
	   trans.begin();
	   String qryStr = "select st from CompuStores st where st.storeId=:sid";
	   try {
		 TypedQuery<CompuStores> qry = em.createQuery(qryStr, CompuStores.class);   
	     qry.setParameter("sid", new Integer(storeId));
	     stores = qry.getSingleResult();
	     trans.commit();
	   }catch(Exception ex) {
		  ex.printStackTrace();
		  trans.rollback();
	   }	   
	   return stores;
	}

	@Override
	public CompuItem searchItemById(int itemId) {
		CompuItem storeItem = new CompuItem();
		   trans = em.getTransaction();
		   trans.begin();
		   String qryStr = "select it from CompuItem it where it.itemId =:itId";
		   try {
			 TypedQuery<CompuItem> qry = em.createQuery(qryStr, CompuItem.class);   
		     qry.setParameter("sid", new Integer(itemId));
		     storeItem = qry.getSingleResult();
		     trans.commit();
		   }catch(Exception ex) {
			  ex.printStackTrace();
			  trans.rollback();
		   }	   
		   return storeItem;		
	}

	@Override
	public boolean deleteStore(int storeId) {
	   boolean ret = false;
	   CompuStores stores = new CompuStores();
	   trans = em.getTransaction();
	   trans.begin();
	   String qryStr = "select st from CompuStores st where st.storeId=:sid";
	   try {
		 TypedQuery<CompuStores> qry = em.createQuery(qryStr, CompuStores.class);   
	     qry.setParameter("sid", new Integer(storeId));
	     stores = qry.getSingleResult();
	     em.remove(stores);
	     ret = true;
	     trans.commit();
	   }catch(Exception ex) {
		  ex.printStackTrace();
		  trans.rollback();
	   } 
	   return ret;
	}

	@Override
	public boolean addStoreWithItems(CompuStores newStore, Collection<CompuItem> newStoreItems) {
		boolean ret = false;
		trans = em.getTransaction();
		trans.begin();
		Set<CompuItem> storeItems = new HashSet<>();
		for(CompuItem item : newStoreItems) {
			item.setStore(newStore);
		}
		storeItems.addAll(newStoreItems);
		try {
		  newStore.setItems(storeItems);
		  em.persist(newStore);
		  ret = true;
		  trans.commit();
		}catch(Exception ex) {
			ex.printStackTrace();
			trans.rollback();
		}
		return ret;
	}
}
