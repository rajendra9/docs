package com.htc.jpa;

import java.io.Serializable;
import java.util.Collection;

public interface CascadeDeleteTest extends Serializable {

	public void closeEF();
	public CompuStores searchStoreById(int storeId);
	public CompuItem searchItemById(int itemId);
	public boolean deleteStore(int storeId);
	public boolean addStoreWithItems(CompuStores newStore,Collection<CompuItem> newStoreItems);
	
	
}
