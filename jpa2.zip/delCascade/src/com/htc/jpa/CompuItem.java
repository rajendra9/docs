package com.htc.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="compu_items")
public class CompuItem implements Serializable {

	private  int  itemId;
	private  String  itemName;
    private  double  itemCost;
    
    private CompuStores store;
    
	public CompuItem() {
		super();		
	}

	public CompuItem(int itemId, String itemName, double itemCost) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemCost = itemCost;
	}

	@ManyToOne
	@JoinColumn(name="store_id")
	public CompuStores getStore() {
		return store;
	}

	public void setStore(CompuStores store) {
		this.store = store;
	}

	@Id
	@Column(name="item_id")
	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	@Column(name="item_name")
	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	@Column(name="item_cost")
	public double getItemCost() {
		return itemCost;
	}

	public void setItemCost(double itemCost) {
		this.itemCost = itemCost;
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + itemId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CompuItem other = (CompuItem) obj;
		if (itemId != other.itemId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CompuItem [itemId=" + itemId + ", itemName=" + itemName + ", itemCost=" + itemCost + "]";
	}

    
}
