package testing;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import com.htc.jpa.CascadeTesting;
import com.htc.jpa.CompuItem;
import com.htc.jpa.CompuStores;

public class CascadeTestingClient {
    
		
	public static void main(String[] args) {
		CascadeTesting cascade = new CascadeTesting();
		
		boolean ret = cascade.deleteStore(1001);
		System.out.println("Delete successful-" + ret);
		CompuStores newStore = new CompuStores(1004, "VendorStores", "Bay-22", 2.1);
		
		Collection<CompuItem> newStoreItems = new ArrayList<>();
		newStoreItems.add(new CompuItem(112, "ItemX", 48.9));
		newStoreItems.add(new CompuItem(116, "ItemZ", 56.5));
		
		ret = cascade.addStoreWithItems(newStore, newStoreItems);
		
		System.out.println("Cascade save-" + ret);
		cascade.closeEF();
	}

}
