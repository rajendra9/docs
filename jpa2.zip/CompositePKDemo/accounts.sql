drop table if exists bank_accounts;

create table bank_accounts(acc_id  varchar(20),
acc_name  varchar(30),
acc_type varchar(1) constraint acc_chk check (acc_type in ('S','C','R','F','O')),
balance decimal(8,2),
constraint acc_PK primary key(acc_id,acc_type));

