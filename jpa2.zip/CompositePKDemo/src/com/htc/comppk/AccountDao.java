package com.htc.comppk;

import java.io.Serializable;
import java.util.Optional;

public interface AccountDao extends Serializable {
	
   public Optional<AccountDTO>  searchAccount(AccountPK pk);
   public boolean  saveAccount(String id, String name, String accTy, double bal);
   public void close();

}
