package com.htc.comppk;

import java.io.Serializable;

@SuppressWarnings("serial")
public class AccountPK implements Serializable {
     private String accId;
     private String accType;
     
	 public String getAccId() {
		return accId;
	 }

	public AccountPK(String accId, String accType) {
		super();
		this.accId = accId;
		this.accType = accType;
	}

	public void setAccId(String accId) {
		this.accId = accId;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public AccountPK() {
		super();
	 }
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accId == null) ? 0 : accId.hashCode());
		result = prime * result + ((accType == null) ? 0 : accType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountPK other = (AccountPK) obj;
		if (accId == null) {
			if (other.accId != null)
				return false;
		} else if (!accId.equals(other.accId))
			return false;
		if (accType == null) {
			if (other.accType != null)
				return false;
		} else if (!accType.equals(other.accType))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AccountPK [accId=" + accId + ", accType=" + accType + "]";
	}
	
}
