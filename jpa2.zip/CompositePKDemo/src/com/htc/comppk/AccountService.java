package com.htc.comppk;

import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class AccountService implements AccountDao {

	EntityManagerFactory factory;
	EntityManager em;
	EntityTransaction trans;
	
	{
		factory = Persistence.createEntityManagerFactory("myPostgres");
		em = factory.createEntityManager();
	}
	
	@Override
	public void close() {
		if(factory != null) {
			factory.close();
		}		
	}

	public AccountService() {
    }
	@Override
	public Optional<AccountDTO> searchAccount(AccountPK pk) {
	    Optional<AccountDTO> ret = Optional.empty();
		trans = em.getTransaction();
	    trans.begin();
	    try {
		  TypedQuery<AccountDTO> qry = em.createNamedQuery("searchByPK",AccountDTO.class);
		  qry.setParameter("id", pk.getAccId());
		  qry.setParameter("aty", pk.getAccType());
		  AccountDTO retAcc = qry.getSingleResult();
		  ret = Optional.of(retAcc);
		  trans.commit();
	    }catch(Exception ex) {
		   ex.printStackTrace();
		   trans.rollback();
	    }
	    return ret;
    }

	@Override
	public boolean saveAccount(String id, String name, String accTy, double bal) {
		boolean ret = false;
		trans = em.getTransaction();
	    trans.begin();
	    try {
	      AccountDTO dto = new AccountDTO(id, name, accTy, bal);
	      em.persist(dto);
	      trans.commit();
	      ret = true;
	    }catch(Exception ex) {
	       ex.printStackTrace();
		   trans.rollback();		    	
	    }
		return false;
	}

}
