package com.htc.comppk;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="bank_accounts")
@IdClass(com.htc.comppk.AccountPK.class)
@NamedQuery(name="searchByPK",query="select ato from AccountDTO as ato where ato.accId=:id and ato.accType=:aty")
public class AccountDTO implements Serializable {
    private  String  accId;
    private  String  accName;
    private  String  accType;
    private  double  balance;
    
    public AccountDTO() {		
	}

	public AccountDTO(String accId, String accName, String accType, double balance) {
		super();
		this.accId = accId;
		this.accName = accName;
		this.accType = accType;
		this.balance = balance;
	}

	@Id
	@Column(name="acc_id")
	public String getAccId() {
		return accId;
	}

	public void setAccId(String accId) {
		this.accId = accId;
	}
	
	@Column(name="acc_name")
	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	@Id
	@Column(name="acc_type")
	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}
	
    @Column
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accId == null) ? 0 : accId.hashCode());
		result = prime * result + ((accType == null) ? 0 : accType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountDTO other = (AccountDTO) obj;
		if (accId == null) {
			if (other.accId != null)
				return false;
		} else if (!accId.equals(other.accId))
			return false;
		if (accType == null) {
			if (other.accType != null)
				return false;
		} else if (!accType.equals(other.accType))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AccountDTO [accId=" + accId + ", accName=" + accName + ", accType=" + accType + ", balance=" + balance
				+ "]";
	}	

}
