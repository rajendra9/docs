package testing;

import java.util.Optional;

import com.htc.comppk.AccountDTO;
import com.htc.comppk.AccountDao;
import com.htc.comppk.AccountPK;
import com.htc.comppk.AccountService;

public class TestAccountDao {

	public static void pr(String s) {
		System.out.println(s);
	}
	public static void main(String[] args) {
	  AccountDao dao = new AccountService();
	  boolean ret = dao.saveAccount("s12321", "GuruPrakash", "S", 20000.0);
	  
	  pr(""+ret);
	  
	  ret = dao.saveAccount("s12324", "John Viswas", "C", 32900.0);
	  pr("" + ret);
	  
	  ret = dao.saveAccount("s12324", "John Nishanth", "S", 4300.0);
	  pr("" + ret);
	  
	  Optional<AccountDTO> opt = dao.searchAccount(new AccountPK("s12324","S")) ;
	  
	  pr(opt.get().toString());
	   
	  
	  dao.close();

	}

}
