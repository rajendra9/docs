drop table if exists proctable;

create table proctable(proc_id  integer primary key,
proc_name  varchar(20),proc_cost decimal(7,2), customer varchar(30));

insert into proctable values(1000,'AAAA',54.5,'M/s Velavan Bros');

insert into proctable values(1010,'BBBB',84.5,'M/s Murugan Bros');

insert into proctable values(1020,'CCCC',73.5,'M/s Sachin Bros');

insert into proctable values(1030,'DDDD',44.5,'M/s Dhanush Bros');
insert into proctable values(1040,'EEEE',54.5,'M/s Sarala Enterprises');

insert into proctable values(1050,'FFFF',46.7,'M/s Panneer Das');
insert into proctable values(1060,'GGGG',72.5,'M/s Velavan Bros');

insert into proctable values(1070,'HHHH',84.5,'M/s Vetrivel');
insert into proctable values(1080,'IIII',85.0,'M/s Sachin Bros');

insert into proctable values(1090,'JJJJ',43.5,'M/s Murugan Bros');

insert into proctable values(1100,'KKKK',39.5,'M/s Sachin Bros');

insert into proctable values(1110,'LLLL',91.5,'M/s Murugan Bros');

insert into proctable values(1120,'MMMM',81.5,'M/s Kumaran Co');

insert into proctable values(1130,'NNNN',75.5,'M/s Kumaran Co');

commit;