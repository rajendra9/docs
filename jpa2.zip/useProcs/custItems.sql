drop function if exists customerItemInfo(in cust varchar(30),out items_cnt integer, out items_cost decimal(10,2));

create function customerItemInfo(in cust varchar(30),out items_cnt integer, out items_cost decimal(10,2)) as $$
declare
       cnt integer; 
     
begin
      select count(1) into cnt from proctable
       where customer = $1;
      if(cnt=0) then
       items_cnt := 0;
       items_cost := 0; 
      else
        select count(1) , sum(proc_cost)  into items_cnt, items_cost from proctable
         where customer = $1;
      end if;
    return ;
end;
$$ LANGUAGE plpgsql;
