package com.htc.jpa;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.FlushModeType;
import javax.persistence.ParameterMode;
import javax.persistence.Persistence;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Expression;

import org.hibernate.CacheMode;

@SuppressWarnings("serial")
public class ProcDTOService implements ProcDAO {    

    EntityManagerFactory factory;
    EntityManager em;
    EntityTransaction trans;    
    
    public ProcDTOService() {
      System.out.println("Starting");  
      factory = Persistence.createEntityManagerFactory("myOra");
      em = factory.createEntityManager();
      em.setFlushMode(FlushModeType.COMMIT);
    }

    @Override
    public boolean addItem(ProcDTO dto) {
      boolean ret = false;
      trans = em.getTransaction();
      try {
        trans.begin();
        em.persist(dto);
        trans.commit();
        ret = true;
      }catch(Exception ex){
        trans.rollback();
        ex.printStackTrace();
      }
      return ret;
    }    

    @Override
    public List<ProcDTO> getCustomerItems(String customer) {
        List<ProcDTO> ret = new ArrayList<>();
        CriteriaBuilder cBuilder = null;             
        try{
          cBuilder = em.getCriteriaBuilder();
          CriteriaQuery<ProcDTO> cQuery = cBuilder.createQuery(ProcDTO.class); 
          Root<ProcDTO> dtoRoot = cQuery.from(ProcDTO.class);
          Expression<String> exp = dtoRoot.get("customer");
          Predicate  custCondn = cBuilder.equal(exp, customer);   
          cQuery = cQuery.select(dtoRoot);
          cQuery = cQuery.where(custCondn);
          TypedQuery<ProcDTO> typedQuery = em.createQuery(cQuery);
          ret = typedQuery.getResultList();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return ret; 
    }

    @Override
    public int retUpdateCostRows(String customer, double addPercentage) {
      int ret = 0;
        trans = em.getTransaction();
      trans.begin();
      CriteriaBuilder cBuilder = null;
      Root<ProcDTO> root = null;      
      try{
        cBuilder = em.getCriteriaBuilder();
        CriteriaUpdate<ProcDTO> cUpdater =
                   cBuilder.createCriteriaUpdate(ProcDTO.class);
        root = cUpdater.from(ProcDTO.class);
        Expression<String> exp = root.get("customer");
        Predicate  custCondn = cBuilder.equal(exp, customer);      
        cUpdater = cUpdater.where(custCondn); 
        Path<Number> path = root.get("procCost");
        Expression<Number> hike = cBuilder.quot(path, addPercentage);
        Expression<Number> newCost = cBuilder.sum(path, hike);
        cUpdater = cUpdater.set(path, newCost);
        ret = em.createQuery(cUpdater).executeUpdate();
        trans.commit();
      }
      catch(Exception e){
         e.printStackTrace();
         trans.rollback();
      }      
       return ret;
    }

    @Override
    public int getDeleteItemsCount(String customer) {
       trans = em.getTransaction();
       int ret = 0;
       try{ 
        trans.begin();
        CriteriaBuilder cBuilder = em.getCriteriaBuilder();
        CriteriaDelete<ProcDTO> cDeleter =
                     cBuilder.createCriteriaDelete(ProcDTO.class);
        Root<ProcDTO> root = cDeleter.from(ProcDTO.class);
        Expression<String> exp = root.get("customer");
        Predicate  custCondn = cBuilder.equal(exp, customer);      
        cDeleter = cDeleter.where(custCondn); 
        ret = em.createQuery(cDeleter).executeUpdate();
        trans.commit();
       }catch(Exception ex){
           ex.printStackTrace();
           trans.rollback();
       }
       return ret;
        
    }

    @Override
    public String getItemInfoByCustomer(String customer) {
       StringBuilder sb = new StringBuilder();
       StoredProcedureQuery spQuery = em.createStoredProcedureQuery("customerItemInfo");
       spQuery.registerStoredProcedureParameter("customer", String.class, ParameterMode.IN);
       spQuery.registerStoredProcedureParameter("items_cnt", Integer.class, ParameterMode.OUT);
       spQuery.registerStoredProcedureParameter("items_cost", java.math.BigDecimal.class, ParameterMode.OUT);
       spQuery.setParameter("customer", customer);
       spQuery.execute();
       Integer cnt = (Integer)spQuery.getOutputParameterValue("items_cnt");
       BigDecimal totCost = (BigDecimal)spQuery.getOutputParameterValue("items_cost");
       sb.append(customer +"'s supplied items data");
       sb.append("\nTypes of Item's count is:" + cnt);
       sb.append("\nTotal Item's cost is:" + totCost);
       return sb.toString();
    }
    
    
    
    @Override
    public void showAllItems() {
      trans = em.getTransaction();
      trans.begin();      
      String qryStr = "select p from ProcDTO p";
      TypedQuery<ProcDTO> qry =
              em.createQuery(qryStr, ProcDTO.class);      
      qry.setHint("org.hibernate.cacheMode", CacheMode.IGNORE);
      List<ProcDTO> list = qry.getResultList();
      for(ProcDTO dto : list){
          //if not this you will get from cache
          em.refresh(dto);
          System.out.println(dto);
          System.out.println();
      }
      trans.commit();
    }

    @Override
    public void closeEM() {
      if(factory != null){
          em.close();
          factory.close();         
      }

    }

}
