package com.htc.jpa;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
@Table(name="proctable")
public class ProcDTO implements Serializable {
   
    private  int     procId;
    private  String  procName;
    private  double  procCost;
    private  String  customer;
    
    public ProcDTO() {
        
    }

    public ProcDTO(int procId, 
                   String procName, 
                   double procCost, 
                   String customer) {
        super();
        this.procId = procId;
        this.procName = procName;
        this.procCost = procCost;
        this.customer = customer;
    }
    @Id
    @Column(name="PROC_ID")
    public int getProcId() {
        return procId;
    }

    public void setProcId(int procId) {
        this.procId = procId;
    }

    @Column(name="PROC_NAME")
    public String getProcName() {
        return procName;
    }

    public void setProcName(String procName) {
        this.procName = procName;
    }
    @Column(name="PROC_COST")
    public double getProcCost() {
        return procCost;
    }

    public void setProcCost(double procCost) {
        this.procCost = procCost;
    }

    @Column
    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + procId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ProcDTO other = (ProcDTO) obj;
        if (procId != other.procId)
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "ProcDTO [procId=" + procId + ", procName=" + procName
                + ", procCost=" + procCost + ", customer=" + customer + "]";
    }    

}
