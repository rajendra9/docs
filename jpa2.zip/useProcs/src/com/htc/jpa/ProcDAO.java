package com.htc.jpa;

import java.io.Serializable;
import java.util.List;

public interface ProcDAO extends Serializable {
    
    public boolean addItem(ProcDTO dto);
    
    public int retUpdateCostRows(String customer, double addPercent);
    
    public int getDeleteItemsCount(String customer);
    
    public List<ProcDTO> getCustomerItems(String customer); 
    
    public String getItemInfoByCustomer(String customer);
    
    public void  showAllItems();
    
    public void closeEM();
    
    
}
