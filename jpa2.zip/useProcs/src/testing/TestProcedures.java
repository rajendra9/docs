package testing;


import java.time.LocalDate;
import java.time.Month;
import java.util.List;

import com.htc.jpa.ProcDAO;
import com.htc.jpa.ProcDTO;
import com.htc.jpa.ProcDTOService;



public class TestProcedures {

    public static void main(String[] args) {
        ProcDAO dao = new ProcDTOService();
        List<ProcDTO> sachinItems = dao.getCustomerItems("M/s Sachin Bros");   
        sachinItems.forEach(System.out::println);
        
        String sachinData = dao.getItemInfoByCustomer("M/s Sachin Bros");
        System.out.println("Before update:" + sachinData);
        
        int changed = dao.retUpdateCostRows("M/s Sachin Bros", 5.0);
        System.out.println("updated:" + changed + " rows");
  
                
        ProcDTO dto = new ProcDTO(1200, "GHGH", 54.3, "M/s Velavan Bros");
        System.out.println("new ProcDTO saved is:" + dao.addItem(dto));
     
        dao.showAllItems();
        changed = dao.getDeleteItemsCount("M/s Dhanush Bros");
        System.out.println("deleted:" + changed + " rows");
              
        
        dao.closeEM();
    }

}
