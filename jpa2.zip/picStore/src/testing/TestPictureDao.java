package testing;

import com.htc.jpa2.PictureDao;
import com.htc.jpa2.PictureService;

public class TestPictureDao {

    public TestPictureDao() {
        // TODO Auto-generated constructor stub
    }

    public static void main(String[] args) {
        PictureDao picDao = new PictureService();
        String path = "banana.gif";
        boolean ret = picDao.savePicture(path);
        System.out.println("Picture saved is: " + ret); 
        
        String loc = picDao.readPicture(1);
        System.out.println("Db Downloaded file is :"+loc);
        		
        picDao.close();
    }

}
