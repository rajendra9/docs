package com.htc.jpa2.domain;

import java.io.Serializable;
import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="pic_stores")
@SuppressWarnings("serial")
public class PictureDTO implements Serializable {
  
   private int picId;
   private String picName;
   private Blob picture;
   
   public PictureDTO(int picId, String picName) {
	 super();
	 this.picId = picId;
	 this.picName = picName;
    }

    public PictureDTO() {
	    super();	
    }

    @Id
    @Column(name="pic_id")
    @GeneratedValue(generator="picGenerator")
    @GenericGenerator(name="picGenerator",strategy="increment")
	public int getPicId() {
		return picId;
	}

	public void setPicId(int picId) {
		this.picId = picId;
	}
    @Column(name="pic_name")
	public String getPicName() {
		return picName;
	}

	public void setPicName(String picName) {
		this.picName = picName;
	}
    
	@Lob
	 public Blob getPicture() {
		return picture;
	}

	public void setPicture(Blob picture) {
		this.picture = picture;
	}
    
    
   
   
   
   
  
}
