package com.htc.jpa2;

import java.io.Serializable;

public interface PictureDao extends Serializable {
   public boolean savePicture(String path);
   public String readPicture(int picId);
   public void close();
}
