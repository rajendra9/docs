package com.htc.jpa2;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.htc.jpa2.domain.PictureDTO;

public class PictureService implements PictureDao {
   static SessionFactory sessionFactory;
	
   static {
	   sessionFactory = HibernateBoot.getFactory(); 
   }
   
   public Session getSession() {
		return sessionFactory.openSession();
   }
	  
	@Override
    public void close() {
	  sessionFactory.close(); 
    }


	@Override
	public boolean savePicture(String path) {
	  boolean ret = false;	
	  Session session = this.getSession();
	  Transaction trans = session.beginTransaction();
	  try { 
		InputStream inStream = this.getClass().getResourceAsStream(path); 
		BufferedInputStream in = new BufferedInputStream(inStream);
		List<Byte> byteList = new ArrayList<>();
		int c = 0;
		while((c=in.read())!= -1) {
		   byteList.add((byte)c);	
		}
		Byte[] data = byteList.toArray(new Byte[] {0});
		byte[] picBytes = new byte[data.length];
		for(int i=0;i<data.length;i++) {
			picBytes[i] = data[i].byteValue();
		}
		PictureDTO picDto = new PictureDTO();
		picDto.setPicName(path);
		Blob picture = Hibernate.getLobCreator(session).createBlob(picBytes);
		picDto.setPicture(picture);
		session.save(picDto);
		ret = true;
		trans.commit();
	   }catch(IOException ioe) {
		   ioe.printStackTrace();
		   trans.rollback();
	   }
	   return ret;
	}

	@Override
	public String readPicture(int picId) {
		String sep = File.separator;
		String ret = "C:" + sep + "temp" + sep ;
		Session session = this.getSession();
		Transaction trans = session.beginTransaction();
		try {
	      PictureDTO dto = session.get(com.htc.jpa2.domain.PictureDTO.class, new Integer(picId));		  
		  String picName = dto.getPicName();
		  ret = ret + picName;
		  Blob blob = dto.getPicture();
		  int len = (int)blob.length();
		  byte[] picBytes = blob.getBytes(1, len);
		  BufferedOutputStream out = 
				  new BufferedOutputStream(new FileOutputStream(ret));
		  out.write(picBytes);;
		  out.close();
		  trans.commit();
		}catch(Exception ex) {
			ex.printStackTrace();
			trans.rollback();
		}
		return ret;
	}

}
