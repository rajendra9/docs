drop table if exists pic_stores;

create table pic_stores(pic_id integer primary key,
pic_name varchar(30),picture oid);

select *  from pic_stores;