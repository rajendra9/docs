package testing;

import java.time.LocalDate;
import java.time.Month;

import com.htc.jpa.OrderDao;
import com.htc.jpa.OrderDaoImpl;
import com.htc.jpa.OrderItem;
import com.htc.jpa.PurOrder;

public class TestOrphans {

    public static void main(String[] args) {
        OrderDao dao = new OrderDaoImpl();
 
        LocalDate locDate = LocalDate.of(2016, Month.MARCH, 15);
        PurOrder order = new PurOrder(100, locDate, "M/s Avanti Enterprises");
        System.out.println("Order saved is:" + dao.saveOrder(order));
        locDate = LocalDate.of(2016, Month.MARCH, 20);
        order = new PurOrder(110, locDate, "M/s Kaushal & Bros");
        System.out.println("Order saved is:" + dao.saveOrder(order));
        locDate = LocalDate.of(2016, Month.MARCH, 25);
        order = new PurOrder(120, locDate, "M/s Murugan Sales");
        System.out.println("Order saved is:" + dao.saveOrder(order));
    
        OrderItem ordItem = new OrderItem(1000, "Item-A", 325.5, 12);
        System.out.println("OrderItem saved is:" + dao.saveItem(ordItem, 100));
        ordItem = new OrderItem(1010, "Item-B", 405.5, 16);
        System.out.println("OrderItem saved is:" + dao.saveItem(ordItem, 100));
        ordItem = new OrderItem(1020, "Item-C", 395.5, 20);
        System.out.println("OrderItem saved is:" + dao.saveItem(ordItem, 100));
        ordItem = new OrderItem(1030, "Item-D", 295.5, 22);
        System.out.println("OrderItem saved is:" + dao.saveItem(ordItem, 100));
        
        ordItem = new OrderItem(1040, "Item-E", 345.5, 16);
        System.out.println("OrderItem saved is:" + dao.saveItem(ordItem, 110));
        ordItem = new OrderItem(1050, "Item-C", 395.5, 14);
        System.out.println("OrderItem saved is:" + dao.saveItem(ordItem, 110));
        ordItem = new OrderItem(1060, "Item-D", 297.5, 24);
        System.out.println("OrderItem saved is:" + dao.saveItem(ordItem, 120));
        dao.displayItems();
        dao.removeOrder(120);
        System.out.println("--------------------------------------");
        System.out.println("After removal");
        dao.displayItems();
        dao.close();
    }

}
