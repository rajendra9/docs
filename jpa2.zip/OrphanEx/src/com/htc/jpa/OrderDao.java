package com.htc.jpa;

import java.io.Serializable;

public interface OrderDao extends Serializable {
  public boolean  saveOrder(PurOrder order);
  public boolean  saveItem(OrderItem item);  
  public boolean  saveItem(OrderItem item, int orderId);
  public boolean  removeOrder(int orderId);
  public boolean  removeOrderItem(int orderId,int transId);
  public void displayItems();
  public void close();
}
