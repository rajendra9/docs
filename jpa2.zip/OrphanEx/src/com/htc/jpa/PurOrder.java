package com.htc.jpa;

import java.io.Serializable;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.OneToMany;
import javax.persistence.JoinColumn;

@Entity
@Table(name="PO_ORDERS")
public class PurOrder implements Serializable {
     
    private  int    orderId;
    private  LocalDate   orderDate;
    private  String customer;    
    private  Set<OrderItem>  orderItems = new HashSet<>();
    
    public PurOrder(int orderId, LocalDate orderDate, String customer) {
        super();
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.customer = customer;
    }   
    
    public PurOrder() {
        // TODO Auto-generated constructor stub
    }
    
    @OneToMany(orphanRemoval=true)
    @JoinColumn(name="ORDER_ID")
    public Set<OrderItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(Set<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

    @Id
    @Column(name="ORDER_ID")
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    @Column(name="ORDER_DATE")    
    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }
    
    @Column
    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    @Override
    public String toString() {
        return "PurOrder [orderId=" + orderId + ", orderDate=" + orderDate + ", customer=" + customer + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + orderId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PurOrder other = (PurOrder) obj;
        if (orderId != other.orderId)
            return false;
        return true;
    }
    
    
    

}
