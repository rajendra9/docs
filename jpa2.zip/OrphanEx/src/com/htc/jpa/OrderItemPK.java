package com.htc.jpa;

import java.io.Serializable;

@SuppressWarnings("serial")
public class OrderItemPK implements Serializable {
    private int itemId;
    private int orderId;
    
    public OrderItemPK(int itemId, int orderId) {
        super();
        this.itemId = itemId;
        this.orderId = orderId;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + itemId;
        result = prime * result + orderId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OrderItemPK other = (OrderItemPK) obj;
        if (itemId != other.itemId)
            return false;
        if (orderId != other.orderId)
            return false;
        return true;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public OrderItemPK() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public String toString() {
        return "OrderItemPK [itemId=" + itemId + ", orderId=" + orderId + "]";
    }

}
