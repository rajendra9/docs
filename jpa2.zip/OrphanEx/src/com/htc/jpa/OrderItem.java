package com.htc.jpa;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Column;

@Entity
@SuppressWarnings("serial")
@Table(name="ORDER_ITEMS")
@NamedQuery(name="allItems",query="select o from OrderItem o")
public class OrderItem implements Serializable {
    private  int    transId;
    private  String itemName;
    private  int    itemQty;
    private  double itemCost;   
   
    public OrderItem() {
        // TODO Auto-generated constructor stub
    }
    
    public OrderItem(int transId, String itemName, double itemCost, int itemQty) {
        super();
        this.transId = transId;
        this.itemName = itemName;
        this.itemCost = itemCost;
        this.itemQty = itemQty;
    }
    
    @Id
    @Column(name="TRANS_ID")
    public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	

    @Column(name="ITEM_NAME")
    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    @Column(name="ITEM_QTY")
    public int getItemQty() {
        return itemQty;
    }

    public void setItemQty(int itemQty) {
        this.itemQty = itemQty;
    }
    @Column(name="ITEM_COST")    
    public double getItemCost() {
        return itemCost;
    }

    public void setItemCost(double itemCost) {
        this.itemCost = itemCost;
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + transId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderItem other = (OrderItem) obj;
		if (transId != other.transId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "OrderItem [transId=" + transId + ", itemName=" + itemName + ", itemQty=" + itemQty + ", itemCost="
				+ itemCost + "]";
	} 
    

}
