package com.htc.jpa;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

@SuppressWarnings("serial")
public class OrderDaoImpl implements OrderDao {
    
    EntityManager em;
    EntityTransaction trans;
    EntityManagerFactory emf;
    
    {
      emf  = Persistence.createEntityManagerFactory("myMySql");
      em = emf.createEntityManager();
    }

    public OrderDaoImpl() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public boolean saveOrder(PurOrder order) {
        boolean ret = false;
        trans = em.getTransaction();
        trans.begin();
        try{
          em.persist(order);
          trans.commit();
          ret = true;
        }catch(Exception e){
          e.printStackTrace();
          trans.rollback();  
        }
        return ret;
    }

    @Override
    public boolean saveItem(OrderItem item) {
        boolean ret = false;
        trans = em.getTransaction();
        trans.begin();
        try{
          em.persist(item);
          trans.commit();
          ret = true;
        }catch(Exception e){
          e.printStackTrace();
          trans.rollback();  
        }
        return ret;
    }
    

    @Override
    public boolean saveItem(OrderItem item, int orderId) {
        boolean ret = false;
        trans = em.getTransaction();
        trans.begin();
        PurOrder order = null;
        try{         
          order = em.getReference(PurOrder.class, new Integer(orderId));
          order.getOrderItems().add(item);
          em.persist(item);
          order = em.merge(order);
          trans.commit();
          ret = true;
        }catch(Exception e){
          e.printStackTrace();
          trans.rollback();  
        }
        return ret;
    }
    

    @Override
    public boolean removeOrder(int orderId) {
        boolean ret = false;
        trans = em.getTransaction();
        trans.begin();
        PurOrder order = null;
        try{
          order = em.getReference(PurOrder.class, new Integer(orderId));
          em.remove(order);
          trans.commit();
          ret = true;
        }catch(Exception e){
          e.printStackTrace();
          trans.rollback();  
        }
        return ret;
    }
    

    @Override
    public boolean removeOrderItem(int orderId, int transId) {
        boolean ret = false;
        trans = em.getTransaction();
        trans.begin();
        PurOrder order = null;
        try{
          order = em.getReference(PurOrder.class, new Integer(orderId));
          //forDelete = em.getReference(OrderItem.class,new OrderItemPK(itId,orderId));
          Set<OrderItem> items = order.getOrderItems();
          Iterator<OrderItem> iter = items.iterator();
          OrderItem ordItem = null;
          while(iter.hasNext()){
              ordItem = iter.next();
              if(ordItem.getTransId()==transId){
                  iter.remove();
                  break;
              }
          }
          //em.remove(ordItem);
          em.merge(order); 
          trans.commit();
          ret = true;
        }catch(Exception e){
          e.printStackTrace();
          trans.rollback();  
        }
        return ret;    
    
    }

    @Override
    public void displayItems() {
       trans = em.getTransaction();
       trans.begin();
       try{ 
         TypedQuery<OrderItem> itemQry = 
                 em.createNamedQuery("allItems",OrderItem.class);
         List<OrderItem> itemList = itemQry.getResultList();
         itemList.forEach(System.out::println);
         trans.commit();
       }catch(Exception e){
           e.printStackTrace();
           trans.rollback();
       }
    }

    @Override
    public void close() {
        emf.close();        
    }

}
