drop table if exists order_items;

drop table if exists po_orders;

create table po_orders(order_id integer primary key,
order_date date,customer varchar(35));


create table order_items(trans_id integer primary key, 
item_name varchar(35) not null, item_cost float,item_qty integer,
order_id integer,
constraint foreign key(order_id) references po_orders(order_id));

delete  from order_items;
delete  from po_orders;

commit;

