package com.htc.jee.jpa;


import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.google.common.base.MoreObjects;

@Entity
@Table(name="CACHE_EMPS")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@NamedQuery(name="findAll",query="select e from EmpHiber e")
public class EmpHiber implements Serializable {
    private int empId;
    private String empName;
    private String job;
    private String deptName;
    private double salary;
    private String location;
    private LocalDate hiredate;
    
    public LocalDate getHiredate() {
        return hiredate;
    }

    public void setHiredate(LocalDate hiredate) {
        this.hiredate = hiredate;
    }

    public EmpHiber() {
        super();      
    }

    public EmpHiber(int empId, String empName, String job, LocalDate dt,double salary, String loc,  String deptName) {
        super();
        this.empId = empId;
        this.empName = empName;
        this.job = job;
        this.hiredate = dt;
        this.salary = salary;
        this.location = loc;
        this.deptName = deptName;
    }

    @Override
    public String toString() {
      return  MoreObjects.toStringHelper(this)
       .add("EmpId:", this.empId)
       .add(" EmpName:",this.empName)
       .add(" Job:",this.job)
       .add(" Salary:",this.salary)
       .add(" Hiredate:",this.hiredate)
       .add(" Location:", location)
       .add(" DeptName:",this.deptName)
       .omitNullValues()
       .toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + empId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        EmpHiber other = (EmpHiber) obj;
        if (empId != other.empId)
            return false;
        return true;
    }
    @Id
    @Column
    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }
    @Column
    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    @Column
    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }
    @Column
    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }
    
    @Column
    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}    
    
}
