package com.htc.jee.jpa;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

import org.hibernate.query.Query;
import org.hibernate.CacheMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class EmpDaoImpl implements EmpDao {

    static SessionFactory sessFactory;
    static {
        sessFactory = HibernateBoot.getFactory(); 
        System.out.println("####"+sessFactory);
    }
    
    public Session getSession() {
        return sessFactory.openSession();
    }           
    
    @Override
    public void getEmps() {
        Session session  = this.getSession();

        List<EmpHiber> ret = new ArrayList<>();
        
        Query qry = session.getNamedQuery("findAll");
        qry.setCacheable(true);
        qry.setCacheMode(CacheMode.NORMAL);
        qry.setCacheRegion("Hiber_Employees");
        EmpHiber emp = null;
        Stream<EmpHiber> stream = qry.stream();
        Iterator<EmpHiber> iter = stream.iterator();
        while(iter.hasNext()){
            emp = iter.next();
            ret.add(emp);
        }
        ret.forEach(System.out::println);          
    }

    @Override
    public void close() {
        this.sessFactory.close();        
    }

}
