package com.htc.jee.jpa;


import java.io.Serializable;
import java.util.List;

public interface EmpDao extends Serializable {
   public void getEmps();
   public void close();
}
