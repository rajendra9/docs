package testing;


import java.time.LocalDate;
import java.util.List;

import com.htc.jee.jpa.EmpDao;
import com.htc.jee.jpa.EmpDaoImpl;
import com.htc.jee.jpa.EmpHiber;

public class TestEmpDao {

    

    public static void main(String[] args) {
        EmpDao empDao = new EmpDaoImpl();
        empDao.getEmps();
        
        empDao.close();
    }

}
