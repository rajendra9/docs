drop table cache_emps;


create table cache_emps as

select e.employee_id empid,
e.first_name||' '||e.last_name empName,
j.job_title job,
e.hire_date hiredate,
e.salary salary,
l.city as location,
d.department_name deptName from employees e,
jobs j,departments d,locations l
where e.department_id=d.department_id and
e.job_id=j.job_id and
d.location_id=l.location_id;
