<template>
  <div id="app">
    <img src="./assets/logo.png">
    <h1>{{title}}</h1>
    <student></student>
  </div>
</template>

<script>
// [for local imports] import student from './student.vue 
export default {
  //components:{ 'student': student },
  data () {    
    return {
      title: 'HTC App'
    }
  },
  methods:{
   
  }
}
</script>

<style>
 #app{
   margin-left:380px;
 }
  h1{
    color: purple;
  }
 
</style>
