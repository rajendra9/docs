package htchiber.manyOneUni;


import java.io.Serializable;

public interface ManyOneUniDao extends Serializable {

	public boolean  saveDept(DeptDto dept);
	public boolean  saveEmp(EmployeeDto emp);
	public boolean  addExistingEmployeeToDept(int deptId, int empId);
	public void  close();
	
	
	
	
}
