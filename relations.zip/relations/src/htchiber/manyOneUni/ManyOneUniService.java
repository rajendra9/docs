package htchiber.manyOneUni;


import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


public class ManyOneUniService implements ManyOneUniDao {
	
	static SessionFactory sessFactory;
    static {
        sessFactory = HibernateBoot.getFactory(); 
    }
    
    public Session getSession() {
        return sessFactory.openSession();
    }           
	@Override
	public boolean saveDept(DeptDto dept) {
		boolean ret = false;       
        Session session = this.getSession();
        Transaction trans = session.beginTransaction();
        try{
           Serializable id = session.save(dept);
           if(id != null){
             ret = true;
             trans.commit();   
           }
        }catch(Exception ex){
            ex.printStackTrace();
            trans.rollback();
        }
        session.close();
        return ret;
     }
	

	@Override
	public boolean saveEmp(EmployeeDto emp) {
		boolean ret = false;       
        Session session = this.getSession();
        Transaction trans = session.beginTransaction();
        try{
           Serializable id = session.save(emp);
           if(id != null){
             ret = true;
             trans.commit();   
           }
        }catch(Exception ex){
            ex.printStackTrace();
            trans.rollback();
        }
        session.close();
        return ret;
     }
	

	@Override
	public boolean addExistingEmployeeToDept(int deptId, int empId) {
		boolean ret = false;
		Session session = this.getSession();
        Transaction trans = session.beginTransaction();
        DeptDto dept = new DeptDto();
        EmployeeDto emp = new EmployeeDto(); 
        try{
           session.load(dept, new Integer(deptId));
           session.load(emp, new Integer(empId));
           emp.setDept(dept);
           session.update(emp);
           trans.commit();
           ret = true;
        }catch(Exception ex) {
        	ex.printStackTrace();
            trans.rollback();	
        }
		return ret;
	}

	@Override
	public void close() {
		 sessFactory.close();      
		
	}

	
    
}
