package htchiber.manyOneUni;


import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@SuppressWarnings("serial")
@Entity
@Table(name="hiber_emp")
public class EmployeeDto implements Serializable {
	
	private  int  empId;
	private  String  empName;
	private  String  job;
	private  LocalDate hiredate;
	private  double  salary;
	private  DeptDto dept;
	
	
	@ManyToOne
	@JoinColumn(name="deptid")
	public DeptDto getDept() {
		return dept;
	}

	public void setDept(DeptDto dept) {
		this.dept = dept;
	}

	public EmployeeDto() {
		super();	
	}

	public EmployeeDto(int empId, String empName, String job, LocalDate hiredate, double salary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.job = job;
		this.hiredate = hiredate;
		this.salary = salary;
	}
    
	@Id
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}
    @Column(name="emp_name")
	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
   
	@Column
	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	@Column
	public LocalDate getHiredate() {
		return hiredate;
	}

	public void setHiredate(LocalDate hiredate) {
		this.hiredate = hiredate;
	}
	
    @Column
	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + empId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeDto other = (EmployeeDto) obj;
		if (empId != other.empId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", job=" + job + ", hiredate=" + hiredate
				+ ", salary=" + salary + "]";
	}
	
}
