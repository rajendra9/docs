package htchiber.manyOneUni;


import java.time.LocalDate;

public class TestManyOneUniDao {

    public static void main(String[] args) {
        ManyOneUniDao dao = new ManyOneUniService();
        
        DeptDto dept = new DeptDto(50, "SERVICES", "MICHIGAN");
        System.out.println(dao.saveDept(dept));
        
        LocalDate hDate = LocalDate.of(2012, 04, 15);
        EmployeeDto emp = new EmployeeDto(2323, "S.Ramnathan", "ANALYST", hDate, 5455.5);
        System.out.println(dao.saveEmp(emp));
        System.out.println(dao.addExistingEmployeeToDept(50, 2323)); 
           
        dao.close();
    }

}
