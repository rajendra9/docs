package htchiber.oneManyUni;

import java.io.Serializable;

public interface OneManyUniDao extends Serializable {

	public boolean  saveDept(DeptDto dept);
	public boolean  saveEmp(EmployeeDto emp);
	public boolean  addExistingEmployeeToDept(int deptId, int empId);
	public void  close();
	
	
	
	
}
