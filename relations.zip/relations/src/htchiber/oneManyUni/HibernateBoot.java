package htchiber.oneManyUni;

import java.io.Serializable;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.AvailableSettings;

public class HibernateBoot implements Serializable {

    static SessionFactory sessFactory;
    static {
        StandardServiceRegistry registry = null;
        try{ 
            System.out.println("HHHH");  
            
            registry = new StandardServiceRegistryBuilder()
                   .configure()
                   .applySetting(AvailableSettings.SHOW_SQL, true)
                   .applySetting(AvailableSettings.FORMAT_SQL, true)                   
                   .build();
            System.out.println("HHHH"+registry);  
               
               
         sessFactory = new MetadataSources(registry)
                       .addAnnotatedClass(DeptDto.class)
                       .addAnnotatedClass(EmployeeDto.class)                       
                       .buildMetadata()  // will give Metadata
                       .buildSessionFactory();
         System.out.println(sessFactory);
        }catch(Exception ex){
        	ex.printStackTrace();
            StandardServiceRegistryBuilder.destroy(registry);      
         }         
       }

    public static SessionFactory getFactory(){
       return HibernateBoot.sessFactory;   
    }
}
