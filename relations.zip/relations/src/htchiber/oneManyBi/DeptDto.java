package htchiber.oneManyBi;


import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="hiber_dept")
@SuppressWarnings("serial")
public class DeptDto implements Serializable {
  private  int  deptId;
  private  String  deptName;
  private  String  location;
  private  Set<EmployeeDto>  employees;
  
  {
	  employees = new HashSet<>();
  }
  
  @OneToMany(mappedBy="dept")  
  public Set<EmployeeDto> getEmployees() {
	return employees;
  }

  public void setEmployees(Set<EmployeeDto> employees) {
	 this.employees = employees;
  }

  public DeptDto() {
	super();
	// TODO Auto-generated constructor stub
  }

  public DeptDto(int deptId, String deptName, String location) {
	 super();
	 this.deptId = deptId;
	 this.deptName = deptName;
	 this.location = location;
  }
  @Id
  public int getDeptId() {
	 return deptId;
  }

  public void setDeptId(int deptId) {
	  this.deptId = deptId;
  }

  @Column(name="dept_name")
  public String getDeptName() {
	 return deptName;
  }

  public void setDeptName(String deptName) {
	 this.deptName = deptName;
  }
  
  @Column
  public String getLocation() {
      return location;
  }

  public void setLocation(String location) {
	  this.location = location;
  }

  @Override
  public int hashCode() {
	  final int prime = 31;
	  int result = 1;
	  result = prime * result + deptId;
	  return result;
  }

  @Override
  public boolean equals(Object obj) {
	  if (this == obj)
	     return true;
	  if (obj == null)
		  return false;
	  if (getClass() != obj.getClass())
		  return false;
	  DeptDto other = (DeptDto) obj;
	  if (deptId != other.deptId)
		  return false;
	  return true;
   }

   @Override
   public String toString() {
	  return "DeptDto [deptId=" + deptId + ", deptName=" + deptName + ", location=" + location + "]";
   } 
  
  
}
