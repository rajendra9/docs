drop  table if exists hiber_emp;
drop  table if exists hiber_dept;


create table hiber_dept as select deptno as deptId, dname dept_name, loc as location from dept;

alter table hiber_dept add constraint hiber_dept_pk primary key(deptId);


create table hiber_emp as select empno as empId, ename as emp_name, job,hiredate,sal as salary,deptno as deptId from emp;

alter table hiber_emp add constraint hiber_emp_pk primary key(empId);
alter table hiber_emp add constraint hiber_emp_fk foreign key(deptId) references hiber_dept(deptId);

select *  from hiber_dept;
select *  from hiber_emp;



