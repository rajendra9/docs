import React, { Component } from 'react';
import { connect }  from 'react-redux';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="col">
          <div><span>A:</span><span>{this.props.a}</span></div>
          <button onClick={this.props.updateA}>Update_A</button>
          </div>
          <div className="col">
          <div><span>B:</span><span>{this.props.b}</span></div>
          <button onClick={this.props.updateB}>Update_B</button>
        </div>
      </div>
    );
  }
}

const mapStoreToProps = (store)=>{
  return{
    a: store.a,
    b: store.b
  }
};

const mapDispatchToProps = (dispatch)=>{
  return{
    updateA: () => dispatch({type: 'UPDATE_A'}),
    updateB: () => dispatch({type: 'UPDATE_B'})
  }
};


export default connect(mapStoreToProps,mapDispatchToProps)(App);
