<template>
  <div>
   <form-helper>
   <!--  <h2 slot="title"> {{title}}</h2>
      <p slot="content"> i am the paragraph text for the slot</p> -->

    <div slot="formHeaders">
       <h2>This is the title of the form</h2>
       <p>Information about the form</p>  
        
    </div> 

     <div slot="formFields">
       <table>
         <tr><td><label>Username:</label></td><td><input type="text" name="username" placeholder="username here"/></td></tr>
         <tr><td><label>Password:</label></td><td><input type="password" name="pwd" placeholder="Password Here"/></td></tr>
       </table>
    </div> 
    <div slot="formControls">
     <button v-on:click="handleSubmit">Submit</button>
    </div>
   </form-helper>

  </div>
</template>

<script>
import formHelper from './components/formHelper.vue';
export default {
  components:{
    'form-helper': formHelper
  },
  
  data () {
    return {
      title: 'I am a dynamic Slot Title'
    }
  },
  methods:{

  }
}
</script>

<style>

</style>
