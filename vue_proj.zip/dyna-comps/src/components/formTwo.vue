<template>
    <div>
     <form-helper>
        <div slot="formHeader">
          <h3>Form Two-Login</h3>
          <p>Enter your details to log-in</p>
         </div> 
         <div slot="formFields">
          <input type="text"  placeholder="username"  required />
          <input type="password"  placeholder="password"  required />
          
          <label>Your Message</label>
          <textarea></textarea>
         </div>
         <div slot="formControls">
            <button v-on:click="handleSubmit">Login</button>
         </div>
    </form-helper>  

    </div>

</template>

<script>
import formHelper from './formHelper.vue'
export default {
  components: {
        'form-helper': formHelper
  },
  data () {
    return {

    }
  },
  methods:{
    handleSubmit: function(){
            alert('thanks for logging in (form two)');
    }
  }
}
</script>
 
<style>
body{
    margin: 0;
    font-family: 'Nunito SemiBold';
}
</style>