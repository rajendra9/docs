import React  from 'react';

const child = (props) => {
  return(
      <div>
          <button onClick={props.doWhatever}>{props.title}</button><br/>
          <label>{props.xyz}</label>
          
      </div>
  )
}

export default child;