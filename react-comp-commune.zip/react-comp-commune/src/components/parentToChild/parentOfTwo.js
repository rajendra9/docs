import React  from 'react';
import Child from './child';

const parentOfTwo = (props) => {
  return(
      <div>
        <Child  doWhatEver={props.changeTheWorld} title={props.title}/>
        <Child  doWhatEver={props.keepTheWorld} title={props.title}/>         
      </div>
  )
}

export default parentOfTwo;