import React, { Component } from 'react';

import Parent from './components/parentToChild/parent';

import ParentOfTwo from './components/parentToChild/parentOfTwo';

import './App.css';

class App extends Component {
  state = {
    title: 'Child-Button',
    secondTitle: 'Sibling-Buttons',
    world: 'Not Good'
  }
  changeTitle = (newTitle) =>{
    this.setState({title:newTitle});
  }
  changeWorld = (newWorld) =>{
    console.log(newWorld);
    this.setState({world:newWorld});
  }
  keepWorld = (oldWorld) =>{
    console.log(oldWorld);
    this.setState({world:oldWorld});
  }
  
  render() {
    return (
      <div className="App">
         <Parent title={this.state.title} doWhatever={this.changeTitle.bind(this,'New World')} />
         <hr/>
         <ParentOfTwo title={this.state.world} changeTheWorld={this.changeWorld.bind(this, 'United World')} keepTheWorld={this.keepWorld.bind(this, 'Same Old Blocks World')} />
      </div>
    );
  }
}

export default App;
