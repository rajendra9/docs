package  com.htc.spring.webflux;

import org.springframework.stereotype.Component;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import  reactor.core.publisher.Mono;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Optional;
import java.util.List;

@Component
public class  WelcomeHandler {

   @Autowired
   PersonsDao personService;

   public Mono<ServerResponse>  welcome(ServerRequest request){
   
    return ServerResponse.ok().contentType(MediaType.TEXT_PLAIN)
                     .body(BodyInserters.fromObject("Welcome To Spring WebFlux")); 

   }

    public Mono<ServerResponse>  welcomePerson(ServerRequest request){
   
      String message = "<div style='color:blue;font-size:18px;font-weight:bold'>Hi HTC Developer See Webflux</div>";
    return ServerResponse.ok().contentType(MediaType.TEXT_HTML)
                     .body(BodyInserters.fromObject(message)); 

   }
    
   public Mono<ServerResponse> searchPerson(ServerRequest request){
     String ssn = request.pathVariable("ssn");
     Optional<Person> searchOpt = personService.searchPeople(ssn);
     Person searched = searchOpt.get();
     return ServerResponse.ok().contentType(MediaType.APPLICATION_JSON)
                  .body(BodyInserters.fromObject(searched));       
     
   } 

    public Mono<ServerResponse> showAll(ServerRequest request){
     List<Person> personList = personService.getPeople();
    
     return ServerResponse.ok().contentType(MediaType.APPLICATION_JSON)
                  .body(BodyInserters.fromObject(personList));       
     
   }   

}