package  com.htc.spring.webflux;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;
import  reactor.core.publisher.Mono;

@Configuration
public class  WelcomeRouter {

     @Bean
     public RouterFunction<ServerResponse>  routeWelcome(WelcomeHandler handler){
   
      return RouterFunctions.route(RequestPredicates.GET("/")
              .and(RequestPredicates.accept       (MediaType.TEXT_PLAIN)),handler::welcome); 

     }
   
     @Bean
     public RouterFunction<ServerResponse>  routePerson(WelcomeHandler handler){
   
      return RouterFunctions.route(RequestPredicates.GET("/person")
              .and(RequestPredicates.accept       (MediaType.TEXT_HTML)),handler::welcomePerson); 

     }
      
     @Bean
     public RouterFunction<ServerResponse>  
                   routeForSearch(WelcomeHandler handler){
      
       return RouterFunctions.route(RequestPredicates.GET("/persons/{ssn}")
                  .and(RequestPredicates.accept(MediaType.APPLICATION_JSON)),handler::searchPerson);
     }

     @Bean
     public RouterFunction<ServerResponse>  
                   routeForAll(WelcomeHandler handler){
      
       return RouterFunctions.route(RequestPredicates.GET("/allPersons")
                  .and(RequestPredicates.accept(MediaType.APPLICATION_JSON)),handler::showAll);
     } 

    
}