package com.htc.spring.webflux;

import java.io.Serializable;


@SuppressWarnings("serial")
public class Person implements Serializable {
    
    
    private String ssn;
    
    private String firstName;
    
    private String lastName;
    
    private String address;
    
    private double income;
    
    public Person(String ssn, 
                  String firstName, 
                  String lastName,
                  String address,
                  double income) {
        super();
        this.ssn = ssn;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.income = income;
    }

    public Person() {
        // TODO Auto-generated constructor stub
    }

    public String getSsn() {
        return ssn;
    }

    public void setAdharId(String ssn) {
        this.ssn = ssn;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((ssn == null) ? 0 : ssn.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Person other = (Person) obj;
        if (ssn == null) {
            if (other.ssn != null)
                return false;
        } else if (!ssn.equals(other.ssn))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "Person [ssn=" + ssn + ", firstName=" + firstName + ", lastName=" + lastName + ", address="
                + address + ", income=" + income + "]";
    }

    public Person(String ssn) {
        super();
        this.ssn = ssn;
    }   

}
