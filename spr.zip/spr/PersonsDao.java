package com.htc.spring.webflux;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

public interface PersonsDao extends Serializable {
  public List<Person>  getPeople();
  public Optional<Person> searchPeople(String ssn);
  public boolean savePerson(Person person);
}
