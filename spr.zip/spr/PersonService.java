package com.htc.spring.webflux;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class PersonService implements PersonsDao {
    
    List<Person> people = new ArrayList<>();
    
    {
      System.out.println("KKKKKKK");  
      Collections.addAll(people,
              new Person("s4325", "muthu", "kumar", "pallavaram", 450000.512),
              new Person("s2325", "meenakshi", "sundaram", "tNagar",650000.4532),
              new Person("s1548", "sandhya", "miller", "chetpet", 598784.8768),
              new Person("s2387", "ramesh", "tandon", "washermanpet",765800.5465));    
    }

    public List<Person> getPeople() {
        return people;
    }

    public void setPeople(List<Person> people) {
        this.people = people;
    }
    

    public Optional<Person> searchPeople(String ssn) {
       Optional<Person> ret = Optional.empty();
       Person ssnPerson = new Person(ssn); 
       if(this.people.contains(ssnPerson)){
           int pos = this.people.indexOf(ssnPerson);
           Person searched = this.people.get(pos);           
           ret = Optional.of(searched);
       }
       return ret;
    }

    @Override
    public boolean savePerson(Person newPerson) {
       boolean ret = false;
       if(!this.people.contains(newPerson)){
          this.people.add(newPerson);
          System.out.println(this.people);
          ret = true;
       }
        return ret;
    }

}
