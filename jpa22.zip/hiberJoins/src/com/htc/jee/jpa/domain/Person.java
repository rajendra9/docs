package com.htc.jee.jpa.domain;

import java.io.Serializable;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Entity;
import javax.persistence.Column;
import java.util.Set;

@Entity
@SuppressWarnings("serial")
public class Person implements Serializable {

    @Id
    @Column(name="ADHAR_ID")
    private String adharId;

    private String address;

    private double income;

    @Column(name="PERSON_NAME")
    private String personName;

    private String profession;

    //bi-directional many-to-one association to Hobby
    @OneToMany(mappedBy="person")
    private Set<Hobby> hobbies;

    public Person() {
    }

    public String getAdharId() {
       return this.adharId;
    }

    public void setAdharId(String adharId) {
       this.adharId = adharId;
    }

    public String getAddress() {
       return this.address;
    }

    public void setAddress(String address) {
       this.address = address;
    }

    public double getIncome() {
       return this.income;
    }

    public void setIncome(double income) {
       this.income = income;
    }

    public String getPersonName() {
       return this.personName;
    }

    public void setPersonName(String personName) {
       this.personName = personName;
    }

    public String getProfession() {
         return this.profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public Set<Hobby> getHobbies() {
         return this.hobbies;
    }

    public void setHobbies(Set<Hobby> hobbies) {
        this.hobbies = hobbies;
    } 

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((adharId == null) ? 0 : adharId.hashCode());
         return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
          return true;
        if (obj == null)
          return false;
        if (getClass() != obj.getClass())
          return false;
        Person other = (Person) obj;
        if (adharId == null) {
         if (other.adharId != null)
           return false;
         } 
         else if (!adharId.equals(other.adharId))
           return false;
         return true;
    }

    @Override
    public String toString() {
       return "Person [adharId=" + adharId + ", address=" + address
                      + ", income=" + income + ", personName=" + personName
                      + ", profession=" + profession + "]";
    } 
	
}
