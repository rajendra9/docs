package com.htc.jee.appls;

import java.util.List;
import com.htc.jee.jpa.domain.Person;
import com.htc.jee.jpa.domain.Hobby;

public interface HobbyDAO {

	public List<Person> getPersons(String hobbyName);
	
	public List<Hobby>  getHobbies(double aboveIncome);
	
	public List<Person> getHobbyPersons(double aboveSpentTime);
	
	public List<String[]> getPersonHobby();
	
	public List<String[]> getHobbyPerson();
	
    public List<String[]> getPersonsHobbies();
}
