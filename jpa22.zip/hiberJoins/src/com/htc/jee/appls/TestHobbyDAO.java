package com.htc.jee.appls;

import java.util.List;

import com.htc.jee.jpa.domain.Hobby;
import com.htc.jee.jpa.domain.Person;

public class TestHobbyDAO {

    public static void main(String[] args) {
      HobbyDAO dao = new HobbyDAOImpl();      
      try {
        System.out.println("\ngetting persons of a particular Hobby");
        List<Person> persons = dao.getPersons("Book-Reading");
  
        for(Person p : persons){
          System.out.println(p);
        }
		  
        System.out.println("\ngetting persons who spent time more than 1 Hour");
                 
        persons = dao.getHobbyPersons(1);
        for(Person p : persons){
            System.out.println(p);
        }
		
        System.out.println("\ngetting Hobbies who has income higher than 50000");
        List<Hobby> hobbies = dao.getHobbies(50000.0);

        for(Hobby h : hobbies){
          System.out.println(h);
        }
		   
        System.out.println("\nRight Outer Join");
        List<String[]> names = dao.getPersonHobby();

        for(String[] arr : names) {
          for(String name : arr) {
             System.out.print(" "+name);
          }
          System.out.println();
        }
		  
        System.out.println("\nLeft Outer Join");
        names = dao.getHobbyPerson();

        for(String[] arr : names) {
          for(String name : arr) {
            System.out.print(" "+name);
          }
          System.out.println();
        }
		 
        
        System.out.println("\nFull Outer Join");
        names = dao.getPersonsHobbies();

        for(String[] arr : names) {
          for(String name : arr) {
            System.out.print(" "+name);
          }
          System.out.println();
        }
		  
      }catch(Exception e) {
         e.printStackTrace();
      }

    }

}
