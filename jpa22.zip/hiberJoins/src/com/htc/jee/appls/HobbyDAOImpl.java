package com.htc.jee.appls;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.htc.jee.jpa.domain.Hobby;
import com.htc.jee.jpa.domain.Person;


public class HobbyDAOImpl implements HobbyDAO {
	
     EntityManager em;
     EntityTransaction trans; 

     public HobbyDAOImpl() {
       super();
       EntityManagerFactory emf = 
                   Persistence.createEntityManagerFactory("myDB");
       em = emf.createEntityManager();
     }

     //who are the persons having this hobbyname
     public List<Person> getPersons(String hobbyName) {
        List<Person> ret = new ArrayList<Person>();
        String jpaQL = " select p from Hobby h inner join h.person p "+ 
                       " where h.hobbyName =:hn";
        TypedQuery<Person> qry = em.createQuery(jpaQL,Person.class);
        qry.setParameter("hn", hobbyName);
        ret = qry.getResultList();
        return ret;
     }

     public List<Hobby> getHobbies(double aboveIncome) {
       List<Hobby> ret = new ArrayList<Hobby>();
       String jpaQL = "select h from Hobby h inner join h.person p "+ 
                      "  where p.income > :abIncome";
       TypedQuery<Hobby> qry = em.createQuery(jpaQL, Hobby.class);
       qry.setParameter("abIncome", aboveIncome);
       ret = qry.getResultList();
       return ret;
     }

     public List<Person> getHobbyPersons(double aboveSpentTime) {
        List<Person> ret = new ArrayList<Person>();
        String jpaQL = " select p from Hobby h inner join h.person p "+ 
                       " where h.spentTime>:st";
        Query qry = em.createQuery(jpaQL);
        qry.setParameter("st", aboveSpentTime);
        List li = qry.getResultList();
        ret.addAll(li);
        return ret;
     }
	
     public List<String[]> getHobbyPerson(){
       List<String[]> ret = new ArrayList<String[]>();
       String jpaQL = 
         "select h.hobbyName, p.personName from Hobby h Left outer join h.person p "; 
       Query qry = em.createQuery(jpaQL);
       List li = qry.getResultList();
       for(Object obj : li ) {
        Object[] arr = (Object[])obj;
        String hobbyName = (String)arr[0];
        String personName = (String)arr[1];
        String[] names = {hobbyName,personName};
        ret.add(names);
       }
       return ret;
     }
	  
     public List<String[]> getPersonHobby(){
       List<String[]> ret = new ArrayList<String[]>();
       String jpaQL = 
         "select h.hobbyName, p.personName from Hobby h right outer join h.person p "; 
       Query qry = em.createQuery(jpaQL);
       List li = qry.getResultList();
       for(Object obj : li ) {
         Object[] arr = (Object[])obj;
         String hobbyName = (String)arr[0];
         String personName = (String)arr[1];
         String[] names = {hobbyName, personName};
         ret.add(names); 
       }
       return ret;
     }

     public List<String[]> getPersonsHobbies(){
         List<String[]> ret = new ArrayList<String[]>();
         String jpaQL = 
           "select h.hobbyName, p.personName from Hobby h full join h.person p "; 
         Query qry = em.createQuery(jpaQL);
         List li = qry.getResultList();
         for(Object obj : li ) {
           Object[] arr = (Object[])obj;
           String hobbyName = (String)arr[0];
           String personName = (String)arr[1];
           String[] names = {hobbyName, personName};
           ret.add(names); 
         }
         return ret;
       }

     
}
