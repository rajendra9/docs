drop  table if exists dealer_product;
drop table  if exists mmproducts;

drop  table if exists mmdealers;

create table mmproducts(id integer constraint SALE_PK primary key,
pname varchar(20),
cost decimal(8,2)); 

create table mmdealers(id integer constraint DEAL_PK primary key,
dname varchar(20),
address varchar(30), 
turnover decimal(8,2));


create table dealer_product(product_id integer,
dealer_id integer ,constraint dp_PK primary key(product_id,dealer_id));


alter table dealer_product add constraint dp_FK1 foreign key(dealer_id) references mmdealers(id);

alter table dealer_product add constraint dp_FK2 foreign key(product_id) references mmproducts(id);

commit;


