package hibermmuni.domain;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.ManyToMany;


@Entity
@Table(name="mmproducts")
@SuppressWarnings("serial")
public class UniProduct implements  Comparable<UniProduct>,java.io.Serializable {
   
 private  int          prodId;
 private  String       prodName;
 private  double       cost;
  
 public UniProduct(){
  super(); 
 }

 public UniProduct(int prodId, String name, double cost){
  super();	
  this.prodId = prodId;
  prodName = name;
  this.cost = cost;
 }
 
@Column
 public double getCost(){
  return cost;
 }

 public void setCost(double cost){
  this.cost = cost;
 }
 
 @Id
 @Column(name="ID")
 public int getProdId(){
  return prodId;
 }

 public void setProdId(int prodId){
  this.prodId = prodId;
 }
 @Column(name="PNAME")
 public String getProdName(){
  return prodName;
 }

 public void setProdName(String prodName){
  this.prodName = prodName;
 }

 @Override
 public String toString()  {
  StringBuilder sb = new StringBuilder();
  sb.append("Prod-Id:" + prodId + " Name: " + prodName + " Cost:" + cost);
  return sb.toString();
 }

 public int compareTo(UniProduct arg0){
  return this.prodId-arg0.prodId;
 }

 	
}