package hibermmuni.domain;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.ManyToMany;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;

@Entity
@Table(name="mmdealers")
@SuppressWarnings("serial")
public class UniDealer implements java.io.Serializable {

 private  int           dealerId;
 private  String        dealerName;
 private  String        address;
 private  double        turnover;
 private  Set<UniProduct>  products;
  
 @Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + dealerId;
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	UniDealer other = (UniDealer) obj;
	if (dealerId != other.dealerId)
		return false;
	return true;
}

{
  products = new HashSet<UniProduct>(); 
 } 
 
 public  UniDealer() {}

 public  UniDealer(int dealerId, String n, String addr, double turn){
  this.dealerId = dealerId;
  dealerName = n;
  address = addr;
  turnover = turn;  
 }
    
 public String showProducts() {
  StringBuffer sb = new StringBuffer();
  UniProduct p = null;
  for(Object obj : products){
   p = (UniProduct)obj;
   sb.append(p+"\r\n");
  } 
  return sb.toString();
 }
  
 @Column 
 public String getAddress(){
  return address;
 }
  
 public void setAddress(String address){
  this.address = address;
 }
 
 @Id
 @Column(name="ID")
 public int getDealerId(){
  return dealerId;
 }
  
 public void setDealerId(int dealerId) {
  this.dealerId = dealerId;
 }
 
 @Column(name="DNAME")
 public String getDealerName() {
  return dealerName;
 }
  
 public void setDealerName(String dealerName){
  this.dealerName = dealerName;
 }
  
 @ManyToMany
 @JoinTable(
         name="DEALER_PRODUCT",
         joinColumns=
         @JoinColumn(name="DEALER_ID", referencedColumnName="ID"),
         inverseJoinColumns=
         @JoinColumn(name="PRODUCT_ID",referencedColumnName="ID")
 )
 public Set<UniProduct> getProducts(){
  return products;
 }
  
 public void setProducts(Set<UniProduct> products) {
  this.products = products;
 }
  
 @Column
 public double getTurnover(){
  return turnover;
 }
  
 public void setTurnover(double turnover){
  this.turnover = turnover;
 }
 
 @Override
 public String toString() {
  StringBuilder sb = new StringBuilder();
  sb.append("Dealer-Id:"+dealerId+
            " Name:"+dealerName+
            " Address:"+address+
            " TurnOver:"+turnover);
  return sb.toString();
 }
  
}