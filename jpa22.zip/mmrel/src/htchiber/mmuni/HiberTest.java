package htchiber.mmuni;

import javax.persistence.Query;

import hibermmbi.domain.Dealer;
import hibermmbi.domain.Product;

import java.util.List;
import java.util.Set;
import java.util.HashSet;
import javax.persistence.Persistence;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;


public class HiberTest {

  EntityManager  em;
  EntityTransaction trans;
  EntityManagerFactory factory;

  public HiberTest(){
    try {
          factory =    Persistence.createEntityManagerFactory("myDB");
     em = factory.createEntityManager();
   }catch(Exception e){
      e.printStackTrace();
   }
 } 

  public void persistDealer(Dealer dlr){
   trans = em.getTransaction();
   trans.begin();
   try {
     em.persist(dlr);
     trans.commit();
   }catch(Exception e){
       System.out.println("error:"+e);
       trans.rollback();
   } 
  } 

  public void persistProduct(Product prod) {
      trans = em.getTransaction();
      trans.begin();
      try {
        em.persist(prod);
        trans.commit();
      }catch(Exception e){
          System.out.println("error:"+e);
          trans.rollback();
      } 
  } 

  public boolean createProductsDealer(Dealer dlr, int prodId){
    trans = em.getTransaction();
    trans.begin();
    boolean ret = false;
    try {
     Query query = em.createQuery(" select prd from Product prd "+
                 " where prd.prodId=:pid");
     query.setParameter("pid",new Integer(prodId));
     Product pd = (Product)query.getSingleResult();
     dlr.getProducts().add(pd);
     em.persist(dlr);
     System.out.println(dlr.getProducts());
     ret = true; 
    }catch(Exception e) {
       System.out.println("Error "+e);
        trans.rollback();
    }
    trans.commit(); 
    return ret;
 }
   
 public boolean createDealersProduct(Product prd,
                                     int ... dIds){
    trans = em.getTransaction();
    trans.begin();
    boolean ret = false;
    try {
    	em.persist(prd);
         
        String ids = "";   
        for(int i=0;i<dIds.length;i++) {
          if(i==dIds.length-1) {
           ids += dIds[i]; 
        }
        else {
            ids += dIds[i]+",";
        }
     }
     Query query = em.createQuery("select dlr from Dealer dlr "+
                  " where dlr.dealerId in ("+ids+")");
     System.out.println(ids);
     List list = query.getResultList();
     Dealer dl = null;
     Set<Dealer> dealerSet = new HashSet<Dealer>();
     for(Object obj : list) {
       dl = (Dealer)obj;
       dl.getProducts().add(prd);
       em.merge(dl);
     }
     em.flush();
     System.out.println(prd.getDealers());
     ret = true; 
    }catch(Exception e) {
      System.out.println("Error "+e);  
      trans.rollback();
    }
    trans.commit();  
    return ret;
   }
 public void close()
 {
	 if(factory!=null)
		 factory.close();
 }
 public static void main(String[] args)throws Exception {
  HiberTest ht = new HiberTest();
  Product p1 = new Product(1, "Lux", 19.50);   
  Product p2 = new Product(2, "Pears", 25.80);
  Product p3 = new Product(3, "Cinthol", 19.80);
  ht.persistProduct(p1);
  ht.persistProduct(p2);
  ht.persistProduct(p3);
  System.out.println("Products created");
   
  Dealer d1 = new Dealer(10, "ABC & Co","ChromePet",222.90); 
  Dealer d2 = new Dealer(20, "JDB & Co","Tambaram",2322.90);   
  ht.persistDealer(d1);  
  System.out.println("1 st Dealer created");

  int prdId = 1;
  ht.createProductsDealer(d2,prdId);
  System.out.println("2 nd Dealer created");  
  System.out.println("Dealer-Product added");

  Dealer d3 = new Dealer(30,"PannerVel & Co","T.Nagar",4322.90);
  ht.persistDealer(d3);
  System.out.println("3 rd Dealer created");
  Product p4 = new Product(4, "Cinthol", 19.80);
  ht.createDealersProduct(p4,10,30);
  System.out.println("Product-Dealer added");
  
  ht.close();
 }

}  