package hibermmbi.domain;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.ManyToMany;


@Entity
@Table(name="mmproducts")
@SuppressWarnings("serial")
public class Product implements  Comparable<Product>,java.io.Serializable {
   
 private  int          prodId;
 private  String       prodName;
 private  double       cost;
 private  Set<Dealer>  dealers; 
 
 
 @ManyToMany(mappedBy="products")
 public Set<Dealer> getDealers(){
  return dealers;
 }

 public void setDealers(Set<Dealer> dealers){
  this.dealers = dealers;
 }
 
 {
  dealers = new HashSet<Dealer>();      
 }
 
 public Product(){
  super(); 
 }

 public Product(int prodId, String name, double cost){
  super();	
  this.prodId = prodId;
  prodName = name;
  this.cost = cost;
 }
 
@Column
 public double getCost(){
  return cost;
 }

 public void setCost(double cost){
  this.cost = cost;
 }
 
 @Id
 @Column(name="ID")
 public int getProdId(){
  return prodId;
 }

 public void setProdId(int prodId){
  this.prodId = prodId;
 }
 @Column(name="PNAME")
 public String getProdName(){
  return prodName;
 }

 public void setProdName(String prodName){
  this.prodName = prodName;
 }

 @Override
 public String toString()  {
  StringBuilder sb = new StringBuilder();
  sb.append("Prod-Id:" + prodId + " Name: " + prodName + " Cost:" + cost);
  return sb.toString();
 }

 public int compareTo(Product arg0){
  return this.prodId-arg0.prodId;
 }

 public String showDealers(){
  StringBuilder sb = new StringBuilder();
  Dealer d = null;
  for(Dealer obj : dealers) {
   sb.append(d+"\r\n");
  }
  return sb.toString();
 }
	
}