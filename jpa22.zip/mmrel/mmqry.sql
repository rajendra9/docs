select * from mmproducts;

select * from mmdealers;

select dp.product_id,sp.pname,dp.dealer_id,d.dname from
mmproducts sp ,mmdealers d,dealer_product dp
where sp.id=dp.product_id and d.id=dp.dealer_id;