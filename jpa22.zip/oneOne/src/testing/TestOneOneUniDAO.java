package testing;

import java.util.List;

import htcJpasUni.Car;
import htcJpasUni.Employee;
import htcJpasUni.OneOneUniDAO;
import htcJpasUni.OneOneUniDAOImpl;

public class TestOneOneUniDAO {

  public static void main(String[] args) {
    OneOneUniDAO dao = new OneOneUniDAOImpl();	  
    try {
      System.out.println("creating users");
      Employee emp = new Employee("1010", "Satyan", 23500.5);
      System.out.println("saved is: " + dao.saveEmployee(emp));
      emp = new Employee("1020", "Sivan", 21600.5);
      System.out.println("saved is: " + dao.saveEmployee(emp));
      emp = new Employee("1030", "Mani", 24100.5);
      System.out.println("saved is: " + dao.saveEmployee(emp));
      Car car = new Car("TN23 AD 5654", "Scorpio", 655000.0);
      System.out.println("saved is: " + dao.saveCar(car));
      car = new Car("TN22 AD 4454","Hyundai i10", 455000.0);
      System.out.println("saved is: " + dao.saveCar(car));
      System.out.println("saved is: " + 
             dao.addCarToEmployee("TN23 AD 5654","1030"));
      
      System.out.println("saved is: " + 
               dao.addCarToEmployee("TN22 AD 4454", "1020"));
      List<Employee> emps = dao.getCarOwnedEmployees();
      System.out.println(emps);
      
    }catch(Exception e) {
      e.printStackTrace();
    }
  }

}