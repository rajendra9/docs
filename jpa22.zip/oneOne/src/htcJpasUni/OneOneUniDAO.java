package htcJpasUni;

import java.io.Serializable;
import java.util.List;



public interface OneOneUniDAO extends Serializable {
   public boolean saveEmployee(Employee emp);
   public boolean saveCar(Car car);
   public boolean addCarToEmployee(String carNum, String empNum);
   public List<Employee> getCarOwnedEmployees();
   
   
}
