package htcJpasBi;

import java.io.Serializable;
import java.util.List;



public interface OneOneDAO extends Serializable {
   public boolean saveEmployee(BiEmployee emp);
   public boolean saveCar(BiCar car);
   public boolean addCarToEmployee(String carNum, String empNum);
   public List<BiEmployee> getCarOwnedEmployees();
   
   
}
