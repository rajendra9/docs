package htcJpasBi;

import java.util.List;
import java.util.ArrayList;
import javax.persistence.Persistence;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

public class OneOneDAOImpl implements OneOneDAO {

    EntityManager em;
    EntityTransaction trans;
         
    public OneOneDAOImpl() {
      EntityManagerFactory factory = 
         Persistence.createEntityManagerFactory("myDB");
         em = factory.createEntityManager();                
    }
    
    public boolean saveEmployee(BiEmployee emp) {
       boolean  ret = false; 
       trans = em.getTransaction();
       trans.begin();
       try {
         em.persist(emp);
         ret = true;
         trans.commit();
       }catch(Exception e){
          trans.rollback();
          e.printStackTrace();
       }
       return ret;
    }

  
    public boolean saveCar(BiCar car) {
       boolean  ret = false; 
       trans = em.getTransaction();
       trans.begin();
       try {
         em.persist(car);
         ret = true;
          trans.commit();
       }catch(Exception e){
          trans.rollback();
          e.printStackTrace();
       }
       return ret;
     }

    @Override
    public boolean addCarToEmployee(String carNum, String empNum) {
        boolean  ret = false; 
        trans = em.getTransaction();
        BiCar car = new BiCar();
        BiEmployee emp = new BiEmployee();
        trans.begin();
        try {
          car = em.getReference(htcJpasBi.BiCar.class,
                                 carNum);
          emp = em.getReference(htcJpasBi.BiEmployee.class,
                      empNum);
        
          car.setEmployee(emp);
          emp.setCar(car);
          em.merge(car);
          em.merge(emp);
          ret = true;
          trans.commit();
        }catch(Exception e){
          trans.rollback();
          e.printStackTrace();
        }
        return ret;
    }

    @Override
    public List<BiEmployee> getCarOwnedEmployees() {
      List<BiEmployee> ret = new ArrayList<BiEmployee>();  
      String qry = "Select e  from  Car c, c.employee e "+
                    " where e is not null";
      trans = em.getTransaction();
      trans.begin();
      try {
       List li = em.createQuery(qry).getResultList();
       ret.addAll(li);
       trans.commit();
      }catch(Exception e){
        trans.rollback();
        e.printStackTrace();
      }
      return ret;    
    }

}
