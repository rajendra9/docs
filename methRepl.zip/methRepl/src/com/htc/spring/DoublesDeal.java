package com.htc.spring;

import java.io.Serializable;
import java.math.BigDecimal;

@SuppressWarnings("serial")
public class DoublesDeal implements Serializable {


	public double subtractTwoDoubles(double d1, double d2) {
		return  d1 - d2;  
	}
	
	public double subtractTwoDoubles(BigDecimal d1, BigDecimal d2) {
		return  (d1.subtract(d2)).doubleValue();  
	}
	
		
}
