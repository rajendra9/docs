package com.htc.spring;

import java.lang.reflect.Method;
import java.math.BigDecimal;

import org.springframework.beans.factory.support.MethodReplacer;

public class DoublesDealReplacer implements MethodReplacer {

	public boolean validateMethod(Method meth) {
		if(!meth.getName().equalsIgnoreCase("subtractTwoDoubles")) {
	         return false;		
		}
		Class[] paramTypes = meth.getParameterTypes();  
		if(paramTypes.length != 2) {
	         return false;		
		}
		if(paramTypes[0] != double.class && paramTypes[1] != double.class) {
	      return false;
	    }
	    if(meth.getReturnType() != double.class) {
	    	return false;
	    }
	    return true;
	}
	@Override
	public Object reimplement(Object target, Method meth, Object[] params) throws Throwable {
		boolean isValid = this.validateMethod(meth);
		if(isValid) {
			BigDecimal bdOne = BigDecimal.valueOf((Double)params[0]);
			BigDecimal bdTwo = BigDecimal.valueOf((Double)params[1]);
			DoublesDeal dbDeal = (DoublesDeal)target;
			Double retVal = dbDeal.subtractTwoDoubles(bdOne,  bdTwo); 
			return retVal; 
		}
		return new Double(0.0);
	}

}
