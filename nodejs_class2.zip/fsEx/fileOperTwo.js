var fs = require("fs");

var buff = new Buffer(1024);


var file = "C:/myNode/inputs/polSci.dat";

fs.open(file, "r+", function(err, fd){
  
  if(err){
  
     return  console.error("error in writing");

  }

  console.log("file is going to be read through fd");
 
  fs.read(fd, buff, 0, buff.length, 0, function(err, bytes){
     if(err){
  
       return  console.error("error in reading");
 
     }

     console.log(bytes + " are read");
     
     if(bytes>0){

       console.log(buff.slice(0,bytes).toString());
     }

    });

    fs.close(fd,function(err){

      if(err){
 
        console.log("file is closing error");

      }else{
 
       console.log("file is closed");
  
      }

    });
 
   
});


