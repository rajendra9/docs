var fs = require("fs");

var dirPath = "c:/temp/forNode";


 

if(!fs.existsSync(dirPath)){
   fs.mkdir(dirPath, function(err){
 
   if(err){

       return console.error(err.stack);

    }
   
    console.info("directory created");

   });
}else{
  console.info("directory exists");

}