var fs = require("fs");

var file = "D:/myNode/inputs/input.dat";


fs.open(file,"r+", function(err,fd){

   if(err){
  
     return  console.error("error in opening file");
   
   }

   console.log("file opened successfully");
  
  
});
 

fs.stat(file,function(err,stats){
 
  if(err){

       return  console.error("error in opening file");
  
  }

  console.log(stats);

  console.log("Is file-" + stats.isFile());
  console.log("Is directory-"+stats.isDirectory());

});
