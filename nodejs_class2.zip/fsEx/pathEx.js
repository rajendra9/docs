var path = require("path"); 

var p = path.normalize("C:\\myNode\\db");

console.log(p);

console.log(path.resolve(p, "birds.sql"));

console.log("Dirname-"+path.dirname(p))
;


