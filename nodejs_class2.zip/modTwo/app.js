var hl= require('./MyRect');
var rect1 = new MyRect(120,10);
console.log(rect1.area());
rect1.show();
var rect2 = new MyRect(120,12);
console.log(MyRect.compare(rect2, rect1));
