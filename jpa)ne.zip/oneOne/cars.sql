drop  table if exists cars;

drop  table if exists caremployees;

create table caremployees(empid varchar(5) primary key,
                          empname varchar(15),
                          salary decimal(8,2));

create table cars(empno varchar(5), 
                            carno varchar(18) primary key,
                          brand varchar(15),
                          cost decimal(10,2));


alter  table cars add constraint car_UQ unique(empno);
alter  table cars add constraint car_FK foreign key(empno)  references caremployees(empid);

