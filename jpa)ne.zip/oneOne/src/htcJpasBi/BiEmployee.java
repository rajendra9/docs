package  htcJpasBi;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="CAREMPLOYEES")
public class BiEmployee implements  java.io.Serializable {
   
   @Id
   @Column(name="EMPID")
   String       empId;

   @Column
   String       empName;

   @Column
   double       salary;
	
   @OneToOne(mappedBy="employee")   
   BiCar car;
   
   public BiCar getCar() {
     return car;
   }

   public void setCar(BiCar car) {
      this.car = car;
   }

public String getEmpId() {
     return empId;
   }

   public void setEmpId(String empId) {
     this.empId = empId;
   }

   public String getEmpName(){
     return empName;
   }

   public void setEmpName(String empName) {
     this.empName = empName;
   }
   
   public double getSalary() {
     return salary;
   }

   public void setSalary(double salary) { 
     this.salary = salary;
   }  
  
   public BiEmployee() {
	super();             
   }
 
   public BiEmployee(String empId,
                   String empName,
	           double salary) {
     super();
     this.empId = empId;
     this.empName = empName;
     this.salary = salary;
  }

  @Override
  public String toString() {
     StringBuffer sb = new StringBuffer();
     sb.append("Emp-Id:"+empId+" Name: "+empName+" Salary:"+salary);
     return sb.toString();
  }

  public int compareTo(BiEmployee arg0) {
    return this.empId.compareTo(arg0.empId);
  }

  
}
