package testing;

import java.util.List;

import htcJpasBi.BiCar;
import htcJpasBi.BiEmployee;
import htcJpasBi.OneOneDAO;
import htcJpasBi.OneOneDAOImpl;

public class TestOneOneDAO {

  public static void main(String[] args) {
    OneOneDAO dao = new OneOneDAOImpl();	  
    try {
      System.out.println("creating Employees");
      BiEmployee emp = new BiEmployee("1010", "Satyan", 23500.5);
      System.out.println("saved is: " + dao.saveEmployee(emp));
      emp = new BiEmployee("1020", "Sivan", 21600.5);
      System.out.println("saved is: " + dao.saveEmployee(emp));
      emp = new BiEmployee("1030", "Mani", 24100.5);
      System.out.println("saved is: " + dao.saveEmployee(emp));
      BiCar car = new BiCar("TN23 AD 5654", "Scorpio", 655000.0);
      System.out.println("saved is: " + dao.saveCar(car));
      car = new BiCar("TN22 AD 4454","Hyundai i10", 455000.0);
      System.out.println("saved is: " + dao.saveCar(car));
      System.out.println("saved is: " + 
             dao.addCarToEmployee("TN23 AD 5654","1030"));
      
      System.out.println("saved is: " + 
               dao.addCarToEmployee("TN22 AD 4454", "1020"));
      List<BiEmployee> emps = dao.getCarOwnedEmployees();
      System.out.println(emps);
      
    }catch(Exception e) {
      e.printStackTrace();
    }
  }

}