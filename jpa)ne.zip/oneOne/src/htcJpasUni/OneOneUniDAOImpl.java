package htcJpasUni;

import java.util.List;
import java.util.ArrayList;
import javax.persistence.Persistence;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

public class OneOneUniDAOImpl implements OneOneUniDAO {

    EntityManager em;
    EntityTransaction trans;
         
    public OneOneUniDAOImpl() {
      EntityManagerFactory factory = 
         Persistence.createEntityManagerFactory("myDB");
         em = factory.createEntityManager();                
    }
    
    public boolean saveEmployee(Employee emp) {
       boolean  ret = false; 
       trans = em.getTransaction();
       trans.begin();
       try {
         em.persist(emp);
         ret = true;
         trans.commit();
       }catch(Exception e){
          trans.rollback();
          e.printStackTrace();
       }
       return ret;
    }

  
    public boolean saveCar(Car car) {
       boolean  ret = false; 
       trans = em.getTransaction();
       trans.begin();
       try {
         em.persist(car);
         ret = true;
          trans.commit();
       }catch(Exception e){
          trans.rollback();
          e.printStackTrace();
       }
       return ret;
     }

    @Override
    public boolean addCarToEmployee(String carNum, String empNum) {
        boolean  ret = false; 
        trans = em.getTransaction();
        Car car = new Car();
        Employee emp = new Employee();
        trans.begin();
        try {
          car = em.getReference(htcJpasUni.Car.class,
                                 carNum);
          emp = em.getReference(htcJpasUni.Employee.class,
                      empNum);
          car.setEmployee(emp);
          em.merge(car);
          ret = true;
          trans.commit();
        }catch(Exception e){
          trans.rollback();
          e.printStackTrace();
        }
        return ret;
    }

    @Override
    public List<Employee> getCarOwnedEmployees() {
      List<Employee> ret = new ArrayList<Employee>();  
      String qry = "Select e  from  Car c, c.employee e "+
                    " where e is not null";
      trans = em.getTransaction();
      trans.begin();
      try {
       List li = em.createQuery(qry).getResultList();
       ret.addAll(li);
       trans.commit();
      }catch(Exception e){
        trans.rollback();
        e.printStackTrace();
      }
      return ret;    
    }

}
