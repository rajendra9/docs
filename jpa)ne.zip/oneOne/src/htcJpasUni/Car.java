package htcJpasUni;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="CARS")
public class Car implements java.io.Serializable {
    
    @Id
    @Column(name="CARNO")
    String        carNumber;
 
    @Column(name="BRAND")
    String        carBrand;
    
    @Column
    double        cost;  
    
    @OneToOne(optional=true,targetEntity=Employee.class)
    @JoinColumn(name="EMPNO")
    Employee      employee;
    
    
    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Car(String carNumber, 
               String carBrand,                
               double cost) {
        super();        
        this.carBrand = carBrand;
        this.carNumber = carNumber;
        this.cost = cost;
    }

    public  Car() { } 
  
    
    public String getCarNumber() {
	return carNumber;
    }
  
    public void setCarNumber(String carNumber) {
	this.carNumber = carNumber;
    }

    
    public String getCarBrand() {
	return carBrand;
    }
  
    public void setCarBrand(String carBrand) {
	this.carBrand = carBrand;
    }

    @Column
    public double getCost() {
	return cost;
    }

    public void setCost(double cost) {
	this.cost = cost;
    }
   
    @Override
    public String toString() {
  	StringBuffer sb = new StringBuffer();
  	sb.append("Car-Number:"+carNumber+
                  " Brand-Name:"+carBrand+
  	              " Cost:"+cost);
  	return sb.toString();
    }
   
}
