drop table if exists myusers;

create table myusers(user_id  integer primary key,
username  varchar(20),
email varchar(20),
age integer);

insert into myusers values(100,'Harsha','harsha@gmail.com',26);

commit;