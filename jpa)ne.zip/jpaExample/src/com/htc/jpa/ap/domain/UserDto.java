package com.htc.jpa.ap.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.htc.jpa.ap.utils.ToStringCreator;

@Entity
@Table(name="MYUSERS")
@SuppressWarnings("serial")
public class UserDto implements Serializable {

 private long    userId;
 private String  username;
 private String  email;
 private int     age;
 
 public UserDto(){}

 public UserDto(long userId, String username, String email, int age) {
  super();
  this.userId = userId;
  this.username = username;
  this.email = email;
  this.age = age;
 }

 @Id
 @Column(name="USER_ID")
 public long getUserId() {
        return userId;
 }
 
 public void setUserId(long userId) {
  this.userId = userId;
 }
 
 @Column
 public String getUsername() {
  return username;
 }
 
 public void setUsername(String username) {
  this.username = username;
 }

 public String getEmail() {
  return email;
 }

 public void setEmail(String email) {
  this.email = email;
 }
 
 @Column
 public int getAge() {
   return age;
 }
 
 public void setAge(int age) {
   this.age = age;
 }


 public int hashCode() {
     final int prime = 31;
     int result = 1;
     result = prime * result + (int) (userId ^ (userId >>> 32));
     return result;
 }


 public boolean equals(Object obj) {
     if (this == obj)
         return true;
     if (obj == null)
         return false;
     if (getClass() != obj.getClass())
         return false;
     UserDto other = (UserDto) obj;
     if (userId != other.userId)
         return false;
     return true;
 }


 public String toString() {
  return ToStringCreator.toString(this);
 } 
    
}
