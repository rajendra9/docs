package com.htc.ap.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.htc.jpa.ap.domain.UserDto;

public class UserDaoImpl implements UserDao {

   EntityManager em;
   EntityTransaction trans;
	
   public UserDaoImpl() {
     EntityManagerFactory factory = 
        Persistence.createEntityManagerFactory("myDb");
     em = factory.createEntityManager();		
   }
	
   public boolean createUser(UserDto user) {
     boolean  ret = false; 
     trans = em.getTransaction();
     trans.begin();
     try {
       em.persist(user);
       ret = true;
       trans.commit();
     }catch(Exception e){
        trans.rollback();
        e.printStackTrace();
     }
     return ret;
   }

   public boolean updateUser(long userId, String email, int age) {
      boolean  ret = false; 
      trans = em.getTransaction();
      UserDto user = new UserDto();
      trans.begin();
      try {
        user = em.getReference(com.htc.jpa.ap.domain.UserDto.class,
                               new Long(userId));
        user.setAge(age);
	user.setEmail(email);
	em.merge(user);
	ret = true;
        trans.commit();
      }catch(Exception e){
        trans.rollback();
        e.printStackTrace();
      }
      return ret;
   }

   public boolean deleteUser(long userId) {
     boolean  ret = false; 
     trans = em.getTransaction();
     UserDto user = new UserDto();
     trans.begin();
     try {
      user = em.getReference(com.htc.jpa.ap.domain.UserDto.class, 
                             new Long(userId));
      em.remove(user);
      ret = true;
      trans.commit();
     }catch(Exception e){
        trans.rollback();
	e.printStackTrace();
     }
     return ret;
   }
	
   public Optional<UserDto> findUser(long userId) {
      Optional<UserDto>   ret = Optional.empty(); 
      trans = em.getTransaction();
      trans.begin();
     try {
      UserDto user = em.getReference(com.htc.jpa.ap.domain.UserDto.class, 
                            new Long(userId));
      ret = Optional.ofNullable(user); 
      trans.commit();
     }catch(Exception e){
       trans.rollback();
       e.printStackTrace();
     }
     return ret;
  }

  public List<UserDto> listAllUsers() {
     List<UserDto> ret = new ArrayList<UserDto>();
     trans = em.getTransaction();
     trans.begin();
     try {
      String qryStr = "select u from UserDto u";
      ret = em.createQuery(qryStr, UserDto.class).getResultList();
      trans.commit();
     }catch(Exception e){
       trans.rollback();
       e.printStackTrace();
     }
      return ret;
  }  

}