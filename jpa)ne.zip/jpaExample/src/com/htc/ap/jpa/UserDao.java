package com.htc.ap.jpa;

import java.util.List;
import java.util.Optional;

import com.htc.jpa.ap.domain.UserDto;


public interface UserDao {
   
   public  boolean       createUser(UserDto user);
   public  boolean       updateUser(long userId, String mail, int age);
   public  boolean       deleteUser(long userId);
   public  Optional<UserDto>   findUser(long userId);
   public  List<UserDto>  listAllUsers();
	
}
