package testing;

import java.util.Optional;

import com.htc.ap.jpa.UserDao;
import com.htc.ap.jpa.UserDaoImpl;
import com.htc.jpa.ap.domain.UserDto;

public class TestUserDao {

  public static void main(String[] args) {
    UserDao dao = new UserDaoImpl();	  
    try {
      System.out.println("creating users");
      UserDto user1 = new UserDto(1L, "Prasad", "raja@gmail.com", 61);
      System.out.println("saved is:"+dao.createUser(user1));
      user1 = new UserDto(2L, "Sandeep", "sandeep@gmail.com", 24);
      System.out.println("saved is:"+dao.createUser(user1));
      user1 = new UserDto(3L, "Mohanlal", "mohanlal@gmail.com", 56);
      System.out.println("saved is:"+dao.createUser(user1));
      user1 = new UserDto(4L, "Madhusudan", "mohanlal@gmail.com",26);
      System.out.println("saved is:"+dao.createUser(user1));
      System.out.println("users:"+dao.listAllUsers());
		  
      System.out.println("updating an user");
      boolean boo = dao.updateUser(2L, "sandeep@hotmail.com", 55);
      System.out.println("updated is:"+boo);
      System.out.println("users:"+dao.listAllUsers());
		  
      System.out.println("Finding an user");
      Optional<UserDto> userOpt = dao.findUser(3L);
      
      if(userOpt.isPresent()) {
    	  System.out.println(userOpt.get());
      }
      
		  
      System.out.println("Deleting an user");
      dao.deleteUser(4L);
      System.out.println("users:"+dao.listAllUsers());
	  
    }catch(Exception e) {
      e.printStackTrace();
    }
  }

}