create table hr_emps as 
select employee_id as emp_id, first_name||' '||last_name as empName,job_title as job,email,phone_number as phone,salary,department_name as deptName,city,country_name as country from
employees e, departments d, jobs j,locations l,countries c
where e.department_id = d.department_id and
e.job_id=j.job_id and d.location_id=l.location_id 
and l.country_id=c.country_id;

alter table hr_emps add constraint hr_emps_pk primary key(emp_id);
select * from hr_emps;