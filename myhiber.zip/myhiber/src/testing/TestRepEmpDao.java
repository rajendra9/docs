package testing;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.htc.jpa22.RepEmpDao;
import com.htc.jpa22.RepEmpService;
import com.htc.jpa22.domain.RepEmp;

@SuppressWarnings("serial")
public class TestRepEmpDao implements Serializable {
   
    List<RepEmp> list;
    RepEmpDao dao;
    
    {
       dao = new RepEmpService();       
    }
   
    public String saveRepEmp(int empId, String empName,
    		                 String job, String email,
    		                 String phone, double salary,
                             String deptName, String hiredateStr, 
                             String city, String country) {
       DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
       LocalDate hDate = LocalDate.parse(hiredateStr, formatter);
       RepEmp forSaving = new RepEmp(empId, empName, job, hDate, salary, deptName, city, country);
       forSaving.setPhone(phone);
       forSaving.setEmail(email);
       boolean ret = dao.saveRepEmp(forSaving);
       if(ret) {
    	   return forSaving.toShortString() +" is persisted without any problems"; 
       }
       else {
    	   return "Problems in saving " +forSaving.getEmpId() +" not persisted as there are problems";     	    	   
       }   
    }
     
    public String updateEmp(int id, String newJob, double newSal) {
       boolean ret = dao.promoteEmp(id, newJob, newSal);
       if(ret) {
    	   return "Employee with Id:" + id + " is Promioted successfully"; 
       }
       else {
    	   return "Problems in promoting, employee of id: " + id +" ,there are problems";     	    	   
       }
    }
    
    public String getAll(){
    	list = dao.findAllEmps();
    	StringBuffer sb = new StringBuffer();
    	list.forEach((e) -> sb.append(e.toString()+"\r\n"));
    	return sb.toString();
    }
    
    public String getEmp(int id) {
      String ret = "NA";	
      Optional<RepEmp> opt = dao.findEmpById(id);
      if(opt.isPresent()) {
    	ret = opt.get().toString(); 	
      }
      return ret;
    }
    
    public String getEmpsSalaryHigher(double givenSal){
    	list = dao.findEmpsBySalHigherThan(givenSal);
    	StringBuffer sb = new StringBuffer();
    	list.forEach((e) -> sb.append(e.toString()+"\r\n"));
    	return sb.toString();
    }
    
    public String getEmpsByJob(String jb){
    	list = dao.findEmpsByJob(jb);
    	StringBuffer sb = new StringBuffer();
    	list.forEach((e) -> sb.append(e.toString()+"\r\n"));
    	return sb.toString();
    }
    
    public String groupByDept() {
      Map<String, List<RepEmp>>	map = dao.groupEmpsByDept();
      StringBuffer sb = new StringBuffer();
      sb.append("<div align=center><h2>Employees By Department</h2><table>");
      map.forEach((k,v)-> sb.append("<tr><td>"+ k +"</td></tr><tr><td>" + v + "<td></tr>"));
      sb.append("</table></div>");
      return sb.toString();        	
    }
    
    
    
    public static void main(String ... args) {
    	TestRepEmpDao testRepEmpDao = new TestRepEmpDao();
    	
    	String ret = testRepEmpDao.saveRepEmp(5432, "Sunder Rajan", "Developer", "sundu44@gmail.com", "9878787877", 32500.5, "JEE", "2018-02-09", "Madurai", "India");
        System.out.println("Saved Result " + ret);
       
        String searched = testRepEmpDao.getEmp(104);
        System.out.println("Searched Result " + ret);
        
        String deptGroups = testRepEmpDao.groupByDept();
        System.out.println("Group by Dept " + deptGroups);
        
        String filterByJob = testRepEmpDao.getEmpsByJob("Accountant");
        System.out.println("Filter by job 'Accountant':: " + filterByJob);
        
        String salaryAbove = testRepEmpDao.getEmpsSalaryHigher(8000.0);
        System.out.println("Salary Above '8000.0':: " + salaryAbove);
        
        String updatedInfo = testRepEmpDao.updateEmp(104, "Sr Programmer", 7100.0);
        System.out.println("Promotion result:" + updatedInfo);
        
        String allEmps = testRepEmpDao.getAll();
        System.out.println("Al;l Emps::" + allEmps);
        
    }
    
}
