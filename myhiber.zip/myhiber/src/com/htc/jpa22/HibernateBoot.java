package com.htc.jpa22;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateBoot {
   
	static SessionFactory sessionFactory;
	
	static {
	  try {	
		Configuration cfg = new Configuration();
		cfg = cfg.configure();
		cfg = cfg.addAnnotatedClass(com.htc.jpa22.domain.RepEmp.class);
		sessionFactory = cfg.buildSessionFactory();
	   }
	  catch(Exception ex) {
		  ex.printStackTrace();
	  }
	}
	
	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}
