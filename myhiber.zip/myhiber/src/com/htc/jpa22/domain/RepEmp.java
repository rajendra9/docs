package com.htc.jpa22.domain;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="hr_emps")
@NamedQuery(name="all.emps", query="select e from RepEmp e")
@NamedQuery(name="one.emp", query="select e from RepEmp e where e.empId=:id")
public class RepEmp implements Serializable {
      private int empId;
      private String empName;
      private String job;      
      private String email;
      private String phone;
      private double salary;
      private String deptName;
      private LocalDate hiredate;
      private String city;      
      private String country;
      
      public RepEmp() {
		super();
	  }

	  @Column
      public LocalDate getHiredate() {
		  return hiredate;
	  }

	  public void setHiredate(LocalDate hiredate) {
		   this.hiredate = hiredate;
	  }

      public RepEmp(int empId, String empName, String job, LocalDate hiredate, double salary, String deptName,
		         String city, String country) {
		this.empId = empId;
		this.empName = empName;
		this.job = job;
		this.hiredate = hiredate;
		this.salary = salary;
		this.deptName = deptName;
		this.city = city;
		this.country = country;
	  }


	  @Id
      @Column(name="emp_id")
	  public int getEmpId() {
	      return empId;
      }

	  public void setEmpId(int empId) {
		  this.empId = empId;
	  }
    
	  @Column
	  public String getEmpName() {
	      return empName;
	  }

	  public void setEmpName(String empName) {
		  this.empName = empName;
	  }

	  @Column
	  public String getJob() {
		  return job;
	  }

	  public void setJob(String job) {
		  this.job = job;
	  }
	
	  @Column
	  public String getEmail() {
		  return email;
	  }

	  public void setEmail(String email) {
		  this.email = email;
	  }
	
	  @Column
	  public String getPhone() {
	      return phone;
	  }

	  public void setPhone(String phone) {
		  this.phone = phone;
	  }
	
	  @Column
	  public double getSalary() {
		  return salary;
	  }

	  public void setSalary(double salary) {
		   this.salary = salary;
	  }

	  @Column
	  public String getDeptName() {
		  return deptName;
	  }

	  public void setDeptName(String deptName) {
		   this.deptName = deptName;
	  }
	  
	  @Column
	  public String getCity() {
		   return city;
	  }
      
	  @Column
	  public void setCity(String city) {
		  this.city = city;
	  }
	  @Column
	  public String getCountry() {
		  return country;
	  }

	  public void setCountry(String country) {
		  this.country = country;
	  }

	  @Override
	  public int hashCode() {
		  final int prime = 31;
		  int result = 1;
		  result = prime * result + empId;
		  return result;
	  }

	  @Override
	  public boolean equals(Object obj) {
		 if (this == obj)
	 		return true;
	     if (obj == null)
	        return false;
		 if (getClass() != obj.getClass())
		   	return false;
		 RepEmp other = (RepEmp) obj;
		 if (empId != other.empId)
			return false;
		  return true;
	  }

	  @Override
	  public String toString() {
		return "RepEmp [empId=" + empId + ", empName=" + empName + ", job=" + job + ", email=" + email + ", phone="
				+ phone + ", salary=" + salary + ", deptName=" + deptName + ", city=" + city + ", country=" + country
				+ "]";
	  }    
	  
	  public String toShortString() {
		return "RepEmp [empId=" + empId + ", empName=" + empName + ", job=" + job + ", salary=" + salary + ", deptName=" + deptName + "]";
	  }    
}
