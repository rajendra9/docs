package com.htc.jpa22;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.htc.jpa22.domain.RepEmp;

@SuppressWarnings("serial")
public class RepEmpService implements RepEmpDao {
	
    static SessionFactory sessFactory;
    
    Transaction trans;
    
    static {
    	sessFactory = HibernateBoot.getSessionFactory();
    }
    
	public Session getSession() {
		return sessFactory.openSession();
	}
	
	
	@Override
	public boolean saveRepEmp(RepEmp emp) {
	   boolean ret = false;
	   Session session = this.getSession();
	   trans = session.beginTransaction();
	   try {	
	     session.save(emp);
	     trans.commit();
	     ret = true;
	   }catch(Exception ex) {
		  ex.printStackTrace();
		  trans.rollback();
	   }	   
	   session.close();	
	   return ret;
	}
	
	@Override
	public Optional<RepEmp> findEmpById(int id) {
	  Session session = this.getSession();
	  Optional<RepEmp> ret = Optional.empty();
	  trans = session.beginTransaction();
	  try {
        Query<RepEmp> query = session.createNamedQuery("one.emp",com.htc.jpa22.domain.RepEmp.class);		  
		query.setParameter("id", new Integer(id));
        ret = query.uniqueResultOptional();        
        trans.commit();  
	  }catch(Exception ex) {
		  ex.printStackTrace();
		  trans.rollback();
	  }
	  session.close();
	  return ret;
	}

	@Override
	public List<RepEmp> findAllEmps() {
		Session session = this.getSession();
		List<RepEmp> ret = new ArrayList<>();
	    trans = session.beginTransaction();
	    try {
		 Query<RepEmp> query = session.createNamedQuery("all.emps",com.htc.jpa22.domain.RepEmp.class);		  
		 ret = query.getResultList();        
	   	 trans.commit();  
	    }catch(Exception ex) {
		  ex.printStackTrace();
		  trans.rollback();
	    }
	    session.close();
		return ret;
	 }

	@Override
	public List<RepEmp> findEmpsBySalHigherThan(double sal) {
		Session session = this.getSession();
		List<RepEmp> ret = new ArrayList<>();
		trans = session.beginTransaction();
	    try {
		 Query<RepEmp> query = session.createNamedQuery("all.emps",com.htc.jpa22.domain.RepEmp.class);		  	  
		 Stream<RepEmp> stream = query.getResultStream();
		 ret = stream.filter((RepEmp e)-> e.getSalary()>sal).collect(Collectors.toList());
		 trans.commit();  
       }catch(Exception ex) {
			  ex.printStackTrace();
			  trans.rollback();
	   }
	   session.close(); 
	   return ret;
	}

	@Override
	public List<RepEmp> findEmpsByJob(String job) {
		Session session = this.getSession();
		List<RepEmp> ret = new ArrayList<>();
		trans = session.beginTransaction();
	    try {
	      Query<RepEmp> query = session.createNamedQuery("all.emps",com.htc.jpa22.domain.RepEmp.class);		  	  
	      Stream<RepEmp> stream = query.getResultStream();
	      ret = stream.filter((RepEmp e)-> e.getJob().equalsIgnoreCase(job)).collect(Collectors.toList());
	      trans.commit();  
	  }catch(Exception ex) {
		 ex.printStackTrace();
	     trans.rollback();
	  }
	  session.close();  
	  return ret;
	 }

	@Override
	public Map<String, List<RepEmp>> groupEmpsByDept() {
	   Map<String, List<RepEmp>>  ret = new HashMap<>();
	   Session session = this.getSession();
	   trans = session.beginTransaction();
	   try {
		 Query<RepEmp> query = session.createNamedQuery("all.emps",com.htc.jpa22.domain.RepEmp.class);		  	  
		 Stream<RepEmp> stream = query.getResultStream();
		 ret = stream.collect(Collectors.groupingBy(RepEmp::getDeptName));   
	     trans.commit();  
	   }catch(Exception ex) {
		 ex.printStackTrace();
		 trans.rollback();
	   }
	  session.close(); 
	  return ret;
	}

	@Override
	public void close() {
	  if(sessFactory != null) {
		  sessFactory.close();
	  }
	}


	@Override
	public boolean promoteEmp(int empId, String newJob, double newSalary) {
		  boolean ret = false;
		  Session session = this.getSession();
		  trans = session.beginTransaction();
		  try {	
		    RepEmp toBeUpdated = session.find(com.htc.jpa22.domain.RepEmp.class, new Integer(empId));
		    toBeUpdated.setJob(newJob);
		    toBeUpdated.setSalary(newSalary);
		    session.update(toBeUpdated);
		    trans.commit();
		    ret = true;
		  }catch(Exception ex) {
			  ex.printStackTrace();
			  trans.rollback();
		  }	   
		  session.close();	
		  return ret;
	}

	

}
