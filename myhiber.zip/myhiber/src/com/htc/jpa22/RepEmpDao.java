package com.htc.jpa22;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.htc.jpa22.domain.RepEmp;

public interface RepEmpDao extends Serializable {
   
	public boolean saveRepEmp(RepEmp emp);
	public boolean promoteEmp(int empId, String newJob, double newSalary);
	
	public Optional<RepEmp> findEmpById(int id);
	public List<RepEmp> findAllEmps();
	public List<RepEmp> findEmpsBySalHigherThan(double sal);
	public List<RepEmp> findEmpsByJob(String job);
	public Map<String,List<RepEmp>> groupEmpsByDept();	
	public void close();
	   
}
