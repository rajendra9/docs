package springex;

import java.util.List;

public abstract class StudentService implements Student {
    
     private  StudentCourses  courses;
    
     private  College  college;
	
     private  String[] subjects;
	
     private  String  course;
	
     public College getCollege() {
       return college;
     }

     public boolean admitStudent(int id, String name) {
       return this.college.enrollStudent(id, name);
     }

     public String[] getSubjects() {
       return subjects;
     }

	
    // public abstract Counselling getCounsellor();

     public void setCourses(StudentCourses courses) {
       this.courses = courses;
     }

     public void setCollege(College college) {
       this.college = college;
     }
      
     public String getCourse() {
        return this.course;
     }

     public void setCourse(String course) {
       this.course = course;
       List<String> subs = this.courses.getSubjects(course);
       this.subjects = subs.toArray(new String[] {""});
     }

}
