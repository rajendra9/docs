package springex;

import java.io.Serializable;
import java.util.Map;
import java.util.HashMap;

public class College implements Serializable {
    private String  name;
    private String  location;

    Map<Integer, String> students = 
         new HashMap<Integer, String>();
	
    public String getName() {
      return name;
    }
	
    public void setName(String name) {
      this.name = name;
    }
	
    public String getLocation() {
       return location;
    }
	
    public void setLocation(String location) {
      this.location = location;
    }

    @Override
    public String toString() {
      return "College [name=" + name + ", location=" + location + "]";
    }
   
    public boolean enrollStudent(int id, String name) {
      boolean  ret = false;
      if(!students.containsKey(id)) {
        students.put(id, name);	
        ret = true;
      }
      return  ret;		
    }

    public College(String name, String location) {
       super();
       this.name = name;
       this.location = location;
    }  
   
}