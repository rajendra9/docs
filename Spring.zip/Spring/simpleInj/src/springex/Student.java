package springex;

public interface Student {
	
   public College      getCollege();
   public String       getCourse();
   public boolean      admitStudent(int id, String name);
   public String[]     getSubjects();
   public Counselling  getCounsellor();
	
}
