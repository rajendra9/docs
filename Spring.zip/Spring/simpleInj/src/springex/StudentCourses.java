package springex;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class StudentCourses {
   private Map<String,List<String>> courseDetails;

   public StudentCourses() {
	 courseDetails = new HashMap<String,List<String>>();
	 List<String> subjects = new ArrayList<String>();
	 subjects.add("Maths");
	 subjects.add("Physics");
	 subjects.add("Chemistry");
	 subjects.add("English");
	 subjects.add("Telugu");
	 courseDetails.put("B.Sc[Engg]", subjects);
	 
	 subjects = new ArrayList<String>();
	 subjects.add("Biology");
	 subjects.add("Zoology");
	 subjects.add("Chemistry");
	 subjects.add("English");
	 subjects.add("Tamil");
	 courseDetails.put("B.Sc[BioChem]", subjects);
	 
	 subjects = new ArrayList<String>();
	 subjects.add("Maths");
	 subjects.add("Economics");
	 subjects.add("Commerce");
	 subjects.add("English");
	 subjects.add("Tamil");
	 courseDetails.put("B.A[Banks]", subjects);	 
   }
    
   public List<String> getSubjects(String course) {
	  List<String> ret = new ArrayList<String>();  
      if(this.courseDetails.containsKey(course)) {
    	  ret = this.courseDetails.get(course);
      }
      return ret;
   
   }
   
}