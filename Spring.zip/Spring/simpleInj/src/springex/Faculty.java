package springex;

public class Faculty implements Counselling {

   private   String  name;
	
   public String getName() {
     return name;
   }

   public void setName(String name) {
     this.name = name;
   }

   public void guideAndAdvice(int id, int year) {
     StringBuilder sb = new StringBuilder();	
     sb.append("\nFor Student of Id:"+id);
     sb.append(" in year-"+year);
     sb.append("\nCounselling is assigned to "+this.name);
     System.out.println(sb.toString());     
   }

}