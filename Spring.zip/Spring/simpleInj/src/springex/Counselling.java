package springex;

public interface Counselling {

   public void guideAndAdvice(int id, int year);
	
}
