package loosecoupling;

import java.io.Serializable;

public class PersonAddress implements Serializable {

    private  String   personName;
    private  Address  address;
    
    public PersonAddress() {
        
    }

    public PersonAddress(String personName, Address address) {
        super();
        this.personName = personName;
        this.address = address;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Addresse [personName=" + personName + ", address=" + address
                + "]";
    }

    
}
