package loosecoupling;

import java.util.Date;

public class PostOffice implements DocDispatcher {
    
    private String  city;
    private String  location;
    

    public PostOffice(String city, String location) {
        super();
        this.city = city;
        this.location = location;
    }
    
    public PostOffice() {
        super();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String dispatchDocument(String docName, PersonAddress addresse) {
      StringBuilder  ret = 
              new StringBuilder("\nThe Document "+docName+" is delivered to \n");
     
      String   mode = "using RailServices";
      if(addresse.getAddress().getCity().equalsIgnoreCase(this.city)) {
          if(addresse.getAddress().getArea().equalsIgnoreCase(this.location)) {
              mode = "Simple Postman Delivery";
          }
          else {
              mode = "Local van Delivery";
          }
      }
      ret.append(addresse.getPersonName()+" on "+new Date()+", "+mode);     
      return ret.toString();
    }

    public String toString() {
        return "PostOffice [city=" + city + ", location=" + location + "]";
    }

    
}
