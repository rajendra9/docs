package loosecoupling;

import java.io.Serializable;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;


@Configuration
public class MyBeanConfigurer implements Serializable {

    public MyBeanConfigurer() {
    }
  
    @Bean
    public DocDispatcher   govtDispatch() {
        return new PostOffice("Chennai", "Chromepet");
    }
    
    @Bean
    public DocDispatcher   byGoodwill() {
        return new FastCouriers("Hyderabad", "Blue-Bird");
    }
    
    @Bean
    public DocDispatcher   fastDispatch() {
        return new FaxComs("Hyderabad", "Star-Fax", "212-4563");
    }
    
}
