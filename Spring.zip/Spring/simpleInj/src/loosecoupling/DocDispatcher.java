package loosecoupling;

import java.io.Serializable;

public interface DocDispatcher extends Serializable {
    
  public  String  dispatchDocument(String docName, PersonAddress addresse) ;
  
}
