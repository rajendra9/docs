package loosecoupling;

import java.util.Date;

public class FaxComs implements DocDispatcher {
    
    private String  city;
    private String  shopName;
    private String  faxMachineNum;
    
    public FaxComs() {
        super();        
    }

    public FaxComs(String city, String shopName, String faxMachineNum) {
        super();
        this.city = city;
        this.shopName = shopName;
        this.faxMachineNum = faxMachineNum;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getFaxMachineNum() {
        return faxMachineNum;
    }

    public void setFaxMachineNum(String faxMachineNum) {
        this.faxMachineNum = faxMachineNum;
    }
    
    public String dispatchDocument(String docName, PersonAddress addresse) {
        StringBuilder  ret = 
                new StringBuilder("\nThe Document "+docName+" is delivered to \n");
       
        String   mode = "using Net Gateway Services";
        if(addresse.getAddress().getCity().equalsIgnoreCase(this.city)) {
            mode = "Low paid fax Delivery";
        }

        ret.append(addresse.getPersonName()+" on "+new Date()+
                   ", "+mode+" from "+this.shopName+
                   " via their fax-machin-no "+this.faxMachineNum);     
        return ret.toString();
      }
    
  
}
