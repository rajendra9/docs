package loosecoupling;

import java.util.Date;

public class FastCouriers implements DocDispatcher {
    
    private String  city;
    private String  name;
    

    public FastCouriers(String city, String name) {
        super();
        this.city = city;
        this.name = name;
    }
    
    public FastCouriers() {
        super();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String dispatchDocument(String docName, PersonAddress addresse) {
      StringBuilder  ret = 
              new StringBuilder("\nThe Document "+docName+" is delivered to \n");
     
      String   mode = "using Airway Services";
      if(addresse.getAddress().getCity().equalsIgnoreCase(this.city)) {
          mode = "LocalCourier Boy Delivery";
      }

      ret.append(addresse.getPersonName()+" on "+new Date()+", "+mode+
                 " by "+this.name+" couriers");     
      return ret.toString();
    }

    public String toString() {
        return "FastCouriers [city=" + city + ", name=" + name + "]";
    }

}
