package basics2;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("idProof")
public class IdProof implements Serializable {
    @Value("email")
	private String type;
    @Value("sund@hotmail.com")
    private String idGiven;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getIdGiven() {
		return idGiven;
	}
	public void setIdGiven(String idGiven) {
		this.idGiven = idGiven;
	}
	@Override
	public String toString() {
		return "IdProof [type=" + type + ", idGiven=" + idGiven + "]";
	}
    
	
    
	
	
}
