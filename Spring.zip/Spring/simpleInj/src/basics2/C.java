package basics2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class C {
   A a;
   
    public C() {        
    }
    
   @Autowired
   public C(A a) {
	System.out.println("param Constructor");   
       this.a = a;
   }

   public void useAinC() {
       System.out.println("A In C");
       a.disp();
   }
   
}
