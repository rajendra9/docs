package basics2;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;

public class Person {
   @Value("sandeep") 
   private String name;
   
   
   @Resource(name="idProof")
   private IdProof idProof;
   
   public Person() {
        
   }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

	public IdProof getIdProof() {
		return idProof;
	}

	public void setIdProof(IdProof idProof) {
		this.idProof = idProof;
	}

    
}
