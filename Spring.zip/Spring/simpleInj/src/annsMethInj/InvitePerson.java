package annsMethInj;

public interface InvitePerson {
      public String invitePerson(String personName);
}
