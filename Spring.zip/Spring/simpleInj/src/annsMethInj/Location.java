package annsMethInj;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component("location")
public class Location implements Serializable {    

    private String city;
    private String area;
    private int distanceFromCentral;
    
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public int getDistanceFromCentral() {
        return distanceFromCentral;
    }

    public void setDistanceFromCentral(int distanceFromCentral) {
        this.distanceFromCentral = distanceFromCentral;
    }

    
    public Location() {
        super();    
        this.city = "Chennnai";
        this.area = "TNagar";
        this.distanceFromCentral = 18;    
    }
    
    public Location(String city, String area, int distanceFromCentral) {
        super();
        this.city = city;
        this.area = area;
        this.distanceFromCentral = distanceFromCentral;
    }
    
    @Override
    public String toString() {
        return "Location [city=" + city + ", area=" + area + ", distanceFromCentral=" + distanceFromCentral + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((area == null) ? 0 : area.hashCode());
        result = prime * result + ((city == null) ? 0 : city.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Location other = (Location) obj;
        if (area == null) {
            if (other.area != null)
                return false;
        } else if (!area.equals(other.area))
            return false;
        if (city == null) {
            if (other.city != null)
                return false;
        } else if (!city.equals(other.city))
            return false;
        return true;
    }
    
    
}
