package annsMethInj;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CustomerInvite implements Serializable {
    
    InvitePerson inviting;
    
    @Autowired
    Location location;
    
    @Autowired
    public CustomerInvite(InvitePerson inviting){ 
        this.inviting = inviting;
    } 
    
    public String inviteAllPersons(String ... persons){
       StringBuilder sb = new StringBuilder();
       sb.append("At " + location + "\r\n");
       for(String person : persons){
          sb.append(this.inviting.invitePerson(person)+"\r\n");  
       }
       return sb.toString();
    }

    public CustomerInvite() {
        super();
        System.out.println("JJJJJ");
    }

}
