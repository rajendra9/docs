package annauto;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Employee implements Serializable {
    
    @Autowired
    private  Department  dept;
 
    @Autowired
    private  Salary      salary;
    
 	
    public Department getDept() {
       return dept;
    }
	
    public void setDept(Department dept) {
        this.dept = dept;
    }
	
	
    public Salary getSalary() {
       return salary;
    }
	
    public void setSalary(Salary salary) {
       this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee [dept=" + dept + ", salary=" + salary + "]";
    }

    
    
}
