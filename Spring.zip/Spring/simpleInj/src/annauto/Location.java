package annauto;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class Location implements Serializable {
    private  String   locId = "Ch210";
    private  String   locName = "Uppal";
    
    
    public Location() {
        super();
    }

    public Location(String locId, String locName) {
       super();
       this.locId = locId;
       this.locName = locName;
    }

    public String getLocId() {
       return locId;
    }

    public void setLocId(String locId) {
      this.locId = locId;
    }

    public String getLocName() {
        return locName;
    }

    public void setLocName(String locName) {
        this.locName = locName;
    }

    @Override
    public String toString() {
      return "\nLocation [locId=" + locId + ", locName=" + locName + "]";
    }
    
	
}
