package annauto;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Salary implements Serializable {
   @Autowired
   private  BaseSalary   baseSalary;
   @Autowired
   private  Allowances   allowances;
   
   public  Salary(BaseSalary baseSalary,
                  Allowances allowances) {
     this.baseSalary = baseSalary;
     this.allowances = allowances;  
   }

   public BaseSalary getBaseSalary() {
	 return baseSalary;
   }
   
   public void setBaseSalary(BaseSalary baseSalary) {
	  this.baseSalary = baseSalary;
   }
   
   public Allowances getAllowances() {
	  return allowances;
   }
   
   public void setAllowances(Allowances allowances) {
	  this.allowances = allowances;
   }

   @Override
   public String toString() {
	   return "\nSalary:\n[baseSalary=" + baseSalary + ", allowances=" + allowances
			+ "]";
   }
   
}
