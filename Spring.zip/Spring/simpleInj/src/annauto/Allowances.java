package annauto;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class Allowances implements Serializable {
    private   double   hra = 8500.0;
    private   double   cca = 2500.5;
    private   double   specialAllowance = 6000.0;
	
    
    public Allowances() {
       super();
    }

    public Allowances(double hra, 
                      double cca, 
		      double specialAllowance) {
	super();
	this.hra = hra;
	this.cca = cca;
	this.specialAllowance = specialAllowance;
    }

    public double getHra() {
	return hra;
    }

    public void setHra(double hra) {
	this.hra = hra;
    }

    public double getCca() {
      return cca;
    }

    public void setCca(double cca) {
       this.cca = cca;
    }

    public double getSpecialAllowance() {
       return specialAllowance;
    }

    public void setSpecialAllowance(double specialAllowance) {
       this.specialAllowance = specialAllowance;
    }

    @Override
    public String toString() {
      return "\nAllowances [hra=" + hra + ", cca=" + cca
             + ", specialAllowance=" + specialAllowance + "]";
    }  
    
}
