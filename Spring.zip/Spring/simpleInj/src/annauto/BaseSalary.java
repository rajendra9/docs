package annauto;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class BaseSalary implements Serializable {
    private   double   basic = 21000.0;
    private   double   da = 18000.0;    
	
    
    public BaseSalary() {
        super();        
    }

    public double getBasic() {
	return basic;
    }

    public void setBasic(double basic) {
       this.basic = basic;
    }

    public double getDa() {
      return da;
    }

    public void setDa(double da) {
      this.da = da;
    }

    public BaseSalary(double basic, double da) {
        super();
        this.basic = basic;
	this.da = da;		
    }

    @Override
    public String toString() {
        return "\nBaseSalary [basic=" + basic + ", da=" + da + "]";
    }
    
}
