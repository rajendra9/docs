package annauto;

import java.io.Serializable;
import org.springframework.stereotype.Component;

@Component
public class WorkArea implements Serializable {
    private  String   deptId = "S1";
    private  String   deptName = "Testing";
    
    public WorkArea() {
        super();
    }

    public WorkArea(String deptId, String deptName) {
      super();
      this.deptId = deptId;
      this.deptName = deptName;
    }

    public String getDeptId() {
       return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    @Override
    public String toString() {
       return "\nWorkArea [deptId=" + deptId + ", deptName=" + deptName + "]";
    }
	
	
	
	
}
