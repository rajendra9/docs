package annauto;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class Department implements Serializable {
    
    @Autowired
    private  WorkArea  workArea;
    
    @Autowired
    private  Location   location;
      
    public WorkArea getWorkArea() {
       return workArea;
    }
	
    public void setWorkArea(WorkArea workArea) {
       this.workArea = workArea;
    }
	
    public Location getLocation() {
       return location;
    }
	
    public void setLocation(Location location) {
        this.location = location;
    }

    @Override
    public String toString() {
       return "\nDepartment:\n[workArea=" + workArea + ", location=" + location
		+ "]";
    }
      
      
}
