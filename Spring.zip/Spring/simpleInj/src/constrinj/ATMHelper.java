package constrinj;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import org.springframework.stereotype.Component;

@SuppressWarnings("serial")
@Component
public class ATMHelper implements Serializable {
   Set<AccountInfo> accounts;
   
   {
     accounts = new HashSet<>();
     AccountInfo info = new AccountInfo("S34543", "Subbarao", "S", 12000.5);
     info.setBankInfo("SBI Bank", "Vanasthalipuram", "Hyderabad");
     accounts.add(info);
     
     info = new AccountInfo("S435498", "Sethu Madhavan", "S", 11000.5);
     info.setBankInfo("SBI Bank", "Tambaram West", "Chennai");
     accounts.add(info);
     
     info = new AccountInfo("S56512", "Madivanan", "S", 9500.5);
     info.setBankInfo("Indian Bank", "Tambaram West", "Chennai");
     accounts.add(info);
     
     info = new AccountInfo("R64339", "Syed Pasha", "R", 20000.5);
     info.setBankInfo("Axis Bank", "Tambaram West", "Chennai");
     accounts.add(info);
     
     info = new AccountInfo("S75416", "Mathews", "S", 9800.5);
     info.setBankInfo("Axis Bank", "Tambaram West", "Chennai");
     accounts.add(info);
     
     info = new AccountInfo("S54654", "Manik Sarkar", "S", 11500.5);
     info.setBankInfo("Indian Bank", "Tambaram West", "Chennai");
     accounts.add(info);
     
     info = new AccountInfo("S65411", "Piyush Chawla", "S", 21000.5);
     info.setBankInfo("SBI Bank", "Tambaram West", "Chennai");
     accounts.add(info);
     
     info = new AccountInfo("C32232", "Madhavan", "S", 14300.5);
     info.setBankInfo("SBI Bank", "Tambaram West", "Chennai");
     accounts.add(info);
     
   }
   
   public String getAccountInfo(String accNum, String accType) {
       for(AccountInfo info : accounts){
        if(   info.getAccId().equalsIgnoreCase(accNum)
           && info.getAccType().equalsIgnoreCase(accType)){
            return info.toString();
        }
       }
       return "NONE";
   }
   
}
