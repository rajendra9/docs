package constrinj;

import java.io.Serializable;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Printer implements Serializable {

    ATMHelper  helper;
    
    @Autowired
    public Printer(ATMHelper helper) {
        this.helper = helper;
    }
    
    public void displayDetailsAfterTrans(String id, String type){
        String info = helper.getAccountInfo(id, type);
        System.out.println("Transaction done on "+LocalDateTime.now());
        System.out.println("Details of the Account Holder is:");
        System.out.println(info);
    }

}
