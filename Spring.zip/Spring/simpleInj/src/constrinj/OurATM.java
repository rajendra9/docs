package constrinj;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;

public class OurATM implements Serializable {
    
    @Autowired
    Printer printer;
    
    public void printInfo(String id, String type){
        printer.displayDetailsAfterTrans(id, type);
    }
    
    

}
