package constrinj;

import java.io.Serializable;

@SuppressWarnings("serial")
public class AccountInfo implements Serializable {
    private   String   accId;
    private   String   accName;
    private   double   balance;
    private   String   accType;
    private   String   bankName;
    private   String   branch;
    private   String   city;
    
    public AccountInfo() {
        super();
    }

    public AccountInfo(String accId, String accName, String accType, double balance) {
        super();
        this.accId = accId;
        this.accName = accName;
        this.balance = balance;
        this.accType = accType;
    }
    
    public void setBankInfo(String  bankName, String branch, String city){
        this.bankName = bankName;
        this.branch = branch;
        this.city = city;
    }

    public String getAccId() {
        return accId;
    }

    public void setAccId(String accId) {
        this.accId = accId;
    }

    public String getAccName() {
        return accName;
    }

    public void setAccName(String accName) {
        this.accName = accName;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getAccType() {
        return accType;
    }

    public void setAccType(String accType) {
        this.accType = accType;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

   
    @Override
    public String toString() {
        return "AccountInfo [accId=" + accId + ", accName=" + accName + ", balance=" + balance + ", accType=" + accType
                + ", bankName=" + bankName + ", branch=" + branch + ", city=" + city + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((accId == null) ? 0 : accId.hashCode());
        result = prime * result + ((accType == null) ? 0 : accType.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AccountInfo other = (AccountInfo) obj;
        if (accId == null) {
            if (other.accId != null)
                return false;
        } else if (!accId.equals(other.accId))
            return false;
        if (accType == null) {
            if (other.accType != null)
                return false;
        } else if (!accType.equals(other.accType))
            return false;
        return true;
    }
    
    
    
    
    
    
    
}
