package testing;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import annauto.Employee;

@Configuration
@ComponentScan("annauto")
public class TestAnnAuto {

  @Bean(name="emp")
  public Employee employee(){
      return new Employee();
  }
  
  public static void main(String[] args) {
   ApplicationContext factory =
      new AnnotationConfigApplicationContext(testing.TestAnnAuto.class);
        
        Employee emp = 
            (Employee)factory.getBean("emp"); 
             
        System.out.println(emp);
     
  }  

}