package testing;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import constrinj.OurATM;

@Configuration
@ComponentScan("constrinj")
public class TestConstrInj {

    @Bean 
    public OurATM getAtm(){
        return new OurATM();
    }
    
    public static void main(String[] args) {
  ApplicationContext  ctx =
     new AnnotationConfigApplicationContext(TestConstrInj.class);
      OurATM atm = ctx.getBean(OurATM.class);
      String id = "S34543", type = "S";
      atm.printInfo(id, type);
    }
}
