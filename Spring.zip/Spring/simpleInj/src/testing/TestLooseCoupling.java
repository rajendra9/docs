package testing;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import loosecoupling.Address;
import loosecoupling.DocDispatcher;
import loosecoupling.PersonAddress;

public class TestLooseCoupling {
 
  public static void main(String[] args) throws Exception{
  
   try {
    ApplicationContext factory
        = new FileSystemXmlApplicationContext("simple.xml");
    Address addr1 = 
        new Address("32B", "Barakhamba Road",
             "Gokhale Chowk", "New Delhi", "110002" );
    Address addr2 = 
            new Address("No-6", "SBI-Colony,Arundhati Street", 
                "Saidabad", "Hyderabad", "500044" );
       
    PersonAddress  person1 = new PersonAddress("Sanjeev Mathur", addr1);
    PersonAddress  person2 = new PersonAddress("Yadagiri Rao", addr2);
    
    DocDispatcher dispatcher = 
    		(DocDispatcher)factory.getBean("govtDispatch");
    System.out.println(dispatcher.dispatchDocument("Marriage-Card", person1));
    System.out.println(dispatcher.dispatchDocument("Tax-Reimbursement", person2));

    dispatcher = (DocDispatcher)factory.getBean("byGoodwill");
    System.out.println(dispatcher.dispatchDocument("Birthday-Invitation",                                     person1));
    System.out.println(dispatcher.dispatchDocument("Child-Progress-Report",                            person2));

    dispatcher = (DocDispatcher)factory.getBean("fastDispatch");
    System.out.println(dispatcher.dispatchDocument("Exam-Success-Greeting-Card",                           person1));
    System.out.println(dispatcher.dispatchDocument("Mutual-Fund-Dividends",                          person2));
   
   }
    catch(Exception e) {
     System.out.println(e);
    }   
  }

}