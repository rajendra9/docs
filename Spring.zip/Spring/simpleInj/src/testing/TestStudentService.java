package testing;


import java.util.Arrays;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import springex.Counselling;
import springex.Student;


public class TestStudentService {

    public static void main(String[] args) throws Exception {
     
    ApplicationContext factory = 
      new FileSystemXmlApplicationContext("simpInj.xml");
        
    Student student = (Student)factory.getBean("student");
     
    System.out.println(student.getClass());   
    
    System.out.println("\n\nCollege is:"+student.getCollege());
    
    System.out.println("\nCourse is:"+student.getCourse());   
  
    String[]   subs = student.getSubjects();
      
    System.out.println("\nStudent subjects are:");
    System.out.println(Arrays.toString(subs));
        
    boolean boo = student.admitStudent(100, "SethuMadhavan");
    System.out.println("\nStudent admitted is:"+boo);
        
    Counselling counsel = student.getCounsellor();
    counsel.guideAndAdvice(100, 2010);
    }

}