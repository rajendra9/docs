package testing;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import annsMethInj.CustomerInvite;
import annsMethInj.InvitePerson;

@Configuration
@ComponentScan("annsMethInj")
public class CustomerMeet {
   
    /*@Bean 
    public InvitePerson getCustomerInvite(){
        return( (p) -> "Hello " + p + " Welcome To Spring Programming ");
    }*/ 
    
    @Bean 
    public InvitePerson getCustomerInvite(){
        InvitePerson ret = new InvitePerson() {
           public String invitePerson(String personName) {
        	 return "Hello " + personName + " Welcome To Spring Programming ";
           }
        };
        return ret;  
    } 
    
    
    public static void main(String[] args) {
      ApplicationContext  ctx =
              new AnnotationConfigApplicationContext(testing.CustomerMeet.class);
      CustomerInvite custInvite = ctx.getBean(annsMethInj.CustomerInvite.class);
      String inviteMessages = 
       custInvite.inviteAllPersons("Sandeep","Sujata","Manoj","SamyDoss","Mrudula");
      System.out.println(inviteMessages);
    } 

}
