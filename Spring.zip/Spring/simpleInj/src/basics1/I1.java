package basics1;

import org.springframework.stereotype.Component;

@Component("one")
public class I1 implements I {

    public I1() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public void show(String str) {
       System.out.println("First Interface Implementation class");
       System.out.println(str.toUpperCase());
    }

}
