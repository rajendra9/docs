package basics1;

public interface I {
   public void show(String str);   
}
