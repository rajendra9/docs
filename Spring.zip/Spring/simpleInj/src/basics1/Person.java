package basics1;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;



public class Person {
   @Value("satish") 
   private String name; 
   
    public Person() {
        // TODO Auto-generated constructor stub
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    
}
