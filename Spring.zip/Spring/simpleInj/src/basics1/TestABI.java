package basics1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
public class TestABI {

    @Bean 
    public Person person() {
        return new Person();
    }
    
   @Bean 
   public A a() {
       return new A();
   }    
   
  
   
   
    public static void main(String[] args) {
      ApplicationContext ctx = 
       new AnnotationConfigApplicationContext(TestABI.class); 
      B b = ctx.getBean(B.class);
      b.useAandI();
      
    
    }

}
