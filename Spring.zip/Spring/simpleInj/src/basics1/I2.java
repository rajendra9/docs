package basics1;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("two")
public class I2 implements I {

    public I2() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public void show(String str) {
       System.out.println("Interface two implementation class");
    	System.out.println(str.toLowerCase());
    }

}
