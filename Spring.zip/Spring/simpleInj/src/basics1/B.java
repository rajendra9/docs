package basics1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
@Component
public class B {
    
    I i;
    A a;
    
    public B() { }
    
    @Autowired
    public void setI(@Qualifier("one") I i) {
        this.i = i;
    }

    @Autowired
    public void setA(A a) {
        this.a = a;
    }

    public void useAandI() {
        i.show("Ramesh Kumar");
        a.disp();
    }
    
}
