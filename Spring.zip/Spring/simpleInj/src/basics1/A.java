package basics1;

import org.springframework.beans.factory.annotation.Autowired;

public class A {

    public A() {
       System.out.println("A constructor");
    }
   
    private Person person;
    
    @Autowired
    public void setPerson(Person person) {        
      System.out.println("setter");
      this.person = person;  
    }
    
    public void disp() {
        System.out.println("Name: " + person.getName());
    }
    
    
    
    
}
