drop table if exists sampemp4;

create table sampemp4 as
select empno as emp_id,ename as emp_name,job,
sal as emp_sal,deptno as dept_id from emp;

alter table sampemp4 add constraint sampemp4_pk primary key(emp_id);

alter table sampemp4 alter column job type varchar(16);
alter table sampemp4 alter column emp_sal type decimal(9,2);

delete from sampemp4
where dept_id is null;
select *  from sampemp4;