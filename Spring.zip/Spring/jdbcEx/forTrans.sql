drop table if exists item_trans;
drop table if exists item_master;

create table item_master(item_id integer primary key,
item_name  varchar(25),
item_cost decimal(9,2));

create table item_trans(order_id integer primary key,
order_date date,
item_id integer references item_master(item_id),
customer  varchar(25),
order_qty integer);


