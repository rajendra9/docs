drop table if exists sampemps4;

create table sampemps4 as
 select empno as emp_id,ename as emp_name,job,coalesce(comm,0) as emp_comm,
 sal as emp_sal,deptno as dept_id from emp;
 
alter table sampemps4 add constraint sampemps4_PK primary key(emp_id);

alter table sampemps4 alter column job  type varchar(16);

alter table sampemps4 alter column emp_sal type decimal(9,2);

alter table sampemps4 alter column emp_comm set default 0.0;

delete from sampemps4
where dept_id is null;

 
