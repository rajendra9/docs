drop function if exists sendpaydtls(IN eno integer,
OUT ann_sal decimal(10,2),
OUT ann_comm decimal(10,2));
create function sendpaydtls(IN eno integer,OUT ann_sal decimal(10,2),
OUT ann_comm decimal(10,2)) as $body$
declare
       cnt integer;  
    
begin
      select  count(1) into cnt from emp where empno=$1; 
       
      if(cnt=0) then 
       ann_sal := 0;
       ann_comm := 0;
      else
       select sal*12,coalesce(comm,0)*12 into ann_sal, ann_comm from emp
       where empno=$1;
      end if;
      return;
end $body$ language plpgsql;     

 