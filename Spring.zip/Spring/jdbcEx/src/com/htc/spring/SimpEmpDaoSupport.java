package com.htc.spring;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

public class SimpEmpDaoSupport implements SimpleEmp4Dao {
    DataSource ds;
    JdbcTemplate jdbcTemplate;
    
    final String SQL_ALL = "select emp_id, emp_name, job, emp_sal,"+
            " dept_id from sampemp4";
//false not to lazily initiate SQLExceptionTranslator
    public SimpEmpDaoSupport(DataSource ds) {
        this.ds = ds;
        jdbcTemplate = new JdbcTemplate(ds, false);        
    }

    @Override
    public boolean  addEmp(SampEmp4 emp) {
      boolean  ret = false;
      SimpleJdbcInsert insert = new SimpleJdbcInsert(ds);
      int result = insert.withTableName("sampemp4")
           .usingColumns("emp_id", "emp_name", "job", "emp_sal", "dept_id")
                   .execute(new BeanPropertySqlParameterSource(emp));
      if(result > 0){
          ret = true;
      }
      return  ret;    
    }
    
    private SampEmp4 mapRowToObject(Map<String,Object> rowMap) {
        SampEmp4 obj = new SampEmp4();
        Set<Map.Entry<String, Object>> entries = rowMap.entrySet();
        for(Map.Entry<String, Object> entry: entries) {
            if(entry.getKey().equalsIgnoreCase("emp_id")) {
               obj.setEmpId((Integer)entry.getValue());  
            }
            else if(entry.getKey().equalsIgnoreCase("emp_name")) {
                obj.setEmpName((String)entry.getValue());  
            }
            else if(entry.getKey().equalsIgnoreCase("job")) {
                obj.setJob((String)entry.getValue());  
            }
            else if(entry.getKey().equalsIgnoreCase("emp_sal")) {
                BigDecimal num = (BigDecimal)entry.getValue();
                obj.setEmpSal(num.doubleValue());  
            }
            else if(entry.getKey().equalsIgnoreCase("dept_id")) {
                obj.setDeptId((Integer)entry.getValue());  
            }
        }
        return obj;
    }
    
    public SampEmp4 findEmployee(int eno) {
        String objSql = "select emp_id, emp_name, job, emp_sal,"+
                        " dept_id from sampemp4 where emp_id=?";
        Object[] params = { new Integer(eno) };
        Map<String,Object> rowMap = jdbcTemplate.queryForMap(objSql, params);
        SampEmp4 ret = this.mapRowToObject(rowMap);
        return ret;
     }   
    
    
    @Override
    public List<SampEmp4> getAll() {
       List<SampEmp4> ret = new ArrayList<>();
  List<Map<String, Object>> rowsList = this.jdbcTemplate.queryForList(SQL_ALL);
       System.out.println(rowsList);
       for(Map<String, Object> rowMap : rowsList) {
          SampEmp4 obj = this.mapRowToObject(rowMap);
          ret.add(obj);
       }
       return ret; 
    }    
    public boolean updateEmpSalary(int empId, double newSalary) {
       String sqlStr = "update sampemp4 set  emp_sal = ? where emp_id=?";
       
       int rows = this.jdbcTemplate.update(sqlStr, new Double(newSalary), new Integer(empId));
       if(rows == 1) {
    	   return true;
       }
       return false;
    }    
    
    @Override
    public void performCall(int eno) {
       SimpleJdbcCall call = new SimpleJdbcCall(ds);
       call = call.withProcedureName("sendpaydtls");
       call.declareParameters(new SqlParameter("eno", Types.INTEGER));
       call.declareParameters(new SqlOutParameter("ann_sal", Types.NUMERIC));
       call.declareParameters(new SqlOutParameter("ann_comm", Types.NUMERIC));
       Map<String, Object> params = new HashMap<>();
       params.put("eno", new Integer(eno));
       Map<String, Object> results = call.execute(params);
       System.out.println("Employees:" + eno + " Details");
       System.out.println("Total Annual Salary:" + results.get("ann_sal"));
       System.out.println("Total Annual Commission:" + results.get("ann_comm"));  
    }


}


