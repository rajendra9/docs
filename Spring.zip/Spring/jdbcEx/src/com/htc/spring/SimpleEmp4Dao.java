package com.htc.spring;

import java.io.Serializable;
import java.util.List;

public interface SimpleEmp4Dao extends Serializable {

    public boolean addEmp(SampEmp4 emp);
    public boolean updateEmpSalary(int empId, double newSalary);
    public SampEmp4 findEmployee(int eno);
    public void performCall(int eno);
    public List<SampEmp4> getAll();    
}
