package com.htc.spring.trans;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;


@Configuration
@PropertySource("classpath:jdbc.properties")
@EnableTransactionManagement
public class ItemJdbcConfig {
  
  @Autowired
  Environment env;
  
  @Bean
  public DataSource dataSource() {
      DriverManagerDataSource ds =
              new DriverManagerDataSource();   
      String driverCl = env.getProperty("db.driver");
      ds.setDriverClassName(driverCl);
      ds.setUrl(env.getProperty("db.url"));
      System.out.println(env.getProperty("db.password"));
      ds.setUsername(env.getProperty("db.username"));
      ds.setPassword(env.getProperty("db.password"));
      System.out.println("***"+ds);
      return ds;
     }  
  
  @Bean
  public  DataSourceTransactionManager getTransManager() {
	  DataSourceTransactionManager txManager = 
 new org.springframework.jdbc.datasource.DataSourceTransactionManager(dataSource());
	  return txManager;
  }
  
  @Bean(name="itemTransDao")
  public ItemTransDaoService getDao(){
      ItemTransDaoService dao = new ItemTransDaoService(dataSource());
      return dao;
  }

}
