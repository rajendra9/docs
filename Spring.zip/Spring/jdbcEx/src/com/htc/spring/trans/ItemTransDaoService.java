package com.htc.spring.trans;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

public class ItemTransDaoService implements ItemTransDao {
    DataSource ds;
    JdbcTemplate jdbcTemplate;   
    
    public ItemTransDaoService(DataSource ds) {
        this.ds = ds;
        jdbcTemplate = new JdbcTemplate(ds, false);        
    }


	@Transactional
	public String createItemAndOrder(int itemId, String itemName, double cost, int orderId, int orderQty,int transItemId, String customer) {
		StringBuffer sb = new StringBuffer("problems In insert");
	  try {	
		int row = jdbcTemplate.update(ITEM_MASTER_ROW_CREATE, 
				new Integer(itemId), itemName, new Double(cost));
		if(row > 0) {
			sb.setLength(0);
			sb.append("Master row created");
		}
		
		java.sql.Date dt = java.sql.Date.valueOf("2018-3-11");
		row = jdbcTemplate.update(ITEM_TRANS_ROW_CREATE, 
				new Integer(orderId), dt ,new Integer(transItemId), customer, new Integer(orderQty));
		if(row>0) {
			sb.append("\nChild Row created");
		}
	  }
	  catch(DataAccessException ex) {
		  System.out.println(ex);
	  }
		return sb.toString();
	}


	@Override
	public void showDetails() {
	     List<?> list = jdbcTemplate.queryForList(SQL_ALL);
	     list.forEach(System.out::println);		
	}

    

}
