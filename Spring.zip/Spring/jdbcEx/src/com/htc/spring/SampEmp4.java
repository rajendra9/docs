package com.htc.spring;

import java.io.Serializable;

@SuppressWarnings("serial")
public class SampEmp4 implements Serializable {
    private  int  empId;
    private  String  empName;
    private  String  job;
    private  double  empSal;
    private  int  deptId;
    
    public SampEmp4() {
        super();    
    }

    public SampEmp4(int empId, String empName, String job, double salary, int deptId) {
        super();
        this.empId = empId;
        this.empName = empName;
        this.job = job;
        this.empSal = salary;
        this.deptId = deptId;
    }

    public SampEmp4(int empId) {
        super();
        this.empId = empId;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public double getEmpSal() {
        return empSal;
    }

    public void setEmpSal(double salary) {
        this.empSal = salary;
    }

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + empId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SampEmp4 other = (SampEmp4) obj;
        if (empId != other.empId)
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "SampEmp4 [empId=" + empId + ", empName=" + empName + ", job=" + job + ", salary=" + empSal + ", deptId="
                + deptId + "]";
    } 
    
    
}
