package testing;


import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.htc.spring.SampEmp4;
import com.htc.spring.trans.ItemTransDao;


public class TestItemTransDao {
 
  
  public static void main(String[] args) {
   try {   
    ApplicationContext factory =
        new AnnotationConfigApplicationContext(com.htc.spring.trans.ItemJdbcConfig.class);
        
    ItemTransDao dao = 
           (ItemTransDao)factory.getBean("itemTransDao"); 
    String ret = dao.createItemAndOrder(101, "Pin20", 201.5, 1000, 10, 101, "M/s Star Auto Traders");
    System.out.println(ret);
    
    ret = dao.createItemAndOrder(111, "Bush80", 102.5, 1010, 20, 111, "M/s Vinay Auto Stores");
    System.out.println(ret);
    
    dao.showDetails();
    ret = dao.createItemAndOrder(121, "Rings", 452.5, 1020, 20, 141, "M/s Bhasha Traders");
    System.out.println(ret);
    
    dao.showDetails();    
   }
   catch(Exception e) {
         e.printStackTrace();
   }
 } 

}