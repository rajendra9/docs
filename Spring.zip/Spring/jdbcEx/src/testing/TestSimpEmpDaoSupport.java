package testing;


import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.List;

import com.htc.spring.SampEmp4;
import com.htc.spring.SimpleEmp4Dao;


public class TestSimpEmpDaoSupport {
 
  
  public static void main(String[] args) {
   try {   
    ApplicationContext factory =
        new AnnotationConfigApplicationContext(com.htc.spring.SimpleEmpJdbcConfig.class);
        
    SimpleEmp4Dao dao = 
           (SimpleEmp4Dao)factory.getBean("simpDao"); 
    SampEmp4 emp = new SampEmp4(2224, "Sandesh", "SALESMAN", 24010.5, 30);
    boolean boo = dao.addEmp(emp);
    System.out.println("New Employee with 2224 empid is inserted:" + boo);
    System.out.println("\nSearching");
    System.out.println(dao.findEmployee(7654));
    System.out.println("\nQuerying for All Employees");
    List<SampEmp4> empList = dao.getAll();
    empList.forEach(System.out::println);
    boolean isUpdated = dao.updateEmpSalary(7900, 1250.0);
    System.out.println("\n" + isUpdated + "\n");
    empList = dao.getAll();
    empList.forEach(System.out::println);
    
    System.out.println("\nExecuting a procedure ");
    dao.performCall(7654);  
   }
   catch(Exception e) {
         e.printStackTrace();
   }
 } 

}