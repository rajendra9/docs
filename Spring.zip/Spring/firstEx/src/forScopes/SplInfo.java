package forScopes;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("two")
@Scope("prototype")
public class SplInfo {
    String info;
	static int instanceCount = -1;
    public SplInfo() {
      ++instanceCount;	
	   System.out.println("Spl Info constructor");	
	   this.info = "prototype-" + instanceCount;
    }
	public String getInfo() {
		return info;
	}
	
	public void setInfo(String info) {
		this.info = info;
	}


	
	

}
