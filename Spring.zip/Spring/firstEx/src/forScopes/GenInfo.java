package forScopes;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("one")
@Scope("singleton")
public class GenInfo {
    String info;
    static int instanceCount = -1;	
    public GenInfo() {
	   System.out.println("Gen Info constructor");	
	   ++instanceCount;
	   this.info = "Singleton--" + instanceCount;
    }

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}
}
