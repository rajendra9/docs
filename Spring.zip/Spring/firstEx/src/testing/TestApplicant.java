package testing;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.config.CustomEditorConfigurer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import java.beans.PropertyEditor;
import com.htc.spring.dates.Applicant;

@Configuration
@ComponentScan("com.htc.spring.dates")
public class TestApplicant {

   @Bean
   public CustomEditorConfigurer getCustomEditor() {
	   CustomEditorConfigurer editorConfigurer = 
			   new CustomEditorConfigurer();
	   Map<Class<?>,Class<? extends PropertyEditor>> editors 
	           = new HashMap<>();
	   editors.put(java.time.LocalDate.class,
			   com.htc.spring.dates.LocalDateConverterEditor.class);
	   editorConfigurer.setCustomEditors(editors);
	   return editorConfigurer;
    }
    public static void main(String[] args) {
      AnnotationConfigApplicationContext factory = 
            new AnnotationConfigApplicationContext(TestApplicant.class);
      Applicant appl = (Applicant)factory.getBean("appl");     
      System.out.println(appl);
      factory.close();
    }

}