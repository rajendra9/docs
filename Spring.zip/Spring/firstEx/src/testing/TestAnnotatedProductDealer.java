package testing;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import com.htc.spring.anns.ProductDAO;
import com.htc.spring.anns.ProductDealer;

@Configuration
@ComponentScan("com.htc.spring.anns")
public class TestAnnotatedProductDealer {

	public static void main(String[] args) {
	  ApplicationContext ctx = 
			      new AnnotationConfigApplicationContext(TestAnnotatedProductDealer.class);
	  ProductDAO oraDao = (ProductDAO)ctx.getBean("ora");
	  
	  ProductDealer dealer = (ProductDealer)ctx.getBean(ProductDealer.class);
      String result = dealer.saleAProduct(100, "SonyTV", 45003.5);  
      System.out.println("default:" + result);
      
      dealer.setDao(oraDao);
      result = dealer.saleAProduct(100, "SonyTV", 45003.5);  
      System.out.println("After Change:" + result);
      
	}

}
