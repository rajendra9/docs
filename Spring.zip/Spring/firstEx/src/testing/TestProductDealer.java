package testing;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.htc.spring.ProductDAO;
import com.htc.spring.ProductDealer;

public class TestProductDealer {

	public static void main(String[] args) {
	  ApplicationContext ctx = 
			      new FileSystemXmlApplicationContext("looseCoupling.xml");
	  ProductDAO oraDao = (ProductDAO)ctx.getBean("ora");
	  
	  ProductDealer dealer = (ProductDealer)ctx.getBean("dealer");
      String result = dealer.saleAProduct(100, "SonyTV", 45003.5);  
      System.out.println("default:" + result);
      
      dealer.setDao(oraDao);
      result = dealer.saleAProduct(100, "SonyTV", 45003.5);  
      System.out.println("After Change:" + result);
      
	}

}