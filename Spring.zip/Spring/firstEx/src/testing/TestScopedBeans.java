package testing;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import forScopes.GenInfo;
import forScopes.SplInfo;

@Configuration
@ComponentScan("forScopes")
public class TestScopedBeans {

	
    public static void main(String[] args) {
      AnnotationConfigApplicationContext ctx = 
			      new AnnotationConfigApplicationContext(TestScopedBeans.class); 
      GenInfo instanceOne = (GenInfo)ctx.getBean("one");
      System.out.println(instanceOne.getInfo());
      
      GenInfo instanceTwo = (GenInfo)ctx.getBean("one");
      System.out.println(instanceTwo.getInfo());
      
      SplInfo splInstanceOne = (SplInfo)ctx.getBean("two");
      System.out.println(splInstanceOne.getInfo());
      
      SplInfo splInstanceTwo = (SplInfo)ctx.getBean("two");
      System.out.println(splInstanceTwo.getInfo());
      ctx.close();
    }

}
