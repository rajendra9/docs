package com.htc.spring.anns;

import org.springframework.stereotype.Component;

@Component("pst")
public class ProductPSSaver implements ProductDAO {

	@Override
	public String saveProduct(int id, String name, double cost) {
	   return "Annotation based  Saving in Postgresql  Database";
	}

}
