package com.htc.spring.anns;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class ProductDealer implements Serializable {
    ProductDAO  dao;

	@Autowired
    public void setDao(@Qualifier("pst")ProductDAO dao) {
		this.dao = dao;
	}
    
	public String saleAProduct(int id, String name, double cost) {
		return dao.saveProduct(id, name, cost);
	}
	
}
