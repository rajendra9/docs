package com.htc.spring.anns;

import java.io.Serializable;

public interface ProductDAO extends Serializable {
  public String saveProduct(int id, String name, double cost);
}
