package com.htc.spring;

import java.io.Serializable;

public class ProductDealer implements Serializable {
    ProductDAO  dao;

	public void setDao(ProductDAO dao) {
		this.dao = dao;
	}
    
	public String saleAProduct(int id, String name, double cost) {
		return dao.saveProduct(id, name, cost);
	}
	
}