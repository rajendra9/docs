package com.htc.spring;

public class ProductPSSaver implements ProductDAO {

	@Override
	public String saveProduct(int id, String name, double cost) {
	   return "Saving in Postgresql  Database";
	}

}