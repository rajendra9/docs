package com.spring.mvc.config;



import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration.Dynamic;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;
import org.thymeleaf.spring4.SpringTemplateEngine;
import org.thymeleaf.spring4.view.ThymeleafViewResolver;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

public class SprWebInitializer implements WebApplicationInitializer {

    @Override
    public void onStartup(ServletContext ctx) throws ServletException {
       AnnotationConfigWebApplicationContext webCtx =
               new AnnotationConfigWebApplicationContext();           
        webCtx.register(SprConfig.class);
        webCtx.setServletContext(ctx);
        
        Dynamic servlet = ctx.addServlet("dispatcher",new DispatcherServlet(webCtx));
        servlet.setInitParameter("throwExceptionIfNoHandlerFound", "true");
        servlet.addMapping("/");
        servlet.addMapping("/resources");
        servlet.setLoadOnStartup(1);
    }
    
   
  
}
