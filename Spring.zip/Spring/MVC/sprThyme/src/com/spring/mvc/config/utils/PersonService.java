package com.spring.mvc.config.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import com.spring.mvc.config.domain.Person;

@Service
@SuppressWarnings("serial")
public class PersonService implements PersonsUsage {
    
    List<Person> people = new ArrayList<>();
    
    {
      System.out.println("KKKKKKK");  
      Collections.addAll(people,
              new Person("4325 6542 1232", "muthu", "kumar", "pallavaram", 450000.512),
              new Person("2325 4524 1891", "meenakshi", "sundaram", "tNagar",650000.4532),
              new Person("5425 1548 2343", "sandhya", "miller", "chetpet", 598784.8768),
              new Person("2387 7593 3897", "ramesh", "tandon", "washermanpet",765800.5465));    
    }

    public List<Person> getPeople() {
        return people;
    }

    public void setPeople(List<Person> people) {
        this.people = people;
    }
    

    public Optional<Person> searchPeople(String adharId) {
       Optional<Person> ret = Optional.empty();
       Person adharPerson = new Person(adharId); 
       if(this.people.contains(adharPerson)){
           int pos = this.people.indexOf(adharPerson);
           Person searched = this.people.get(pos);           
           ret = Optional.of(searched);
       }
       return ret;
    }

    @Override
    public boolean savePerson(Person newPerson) {
       boolean ret = false;
       if(!this.people.contains(newPerson)){
          this.people.add(newPerson);
          System.out.println(this.people);
          ret = true;
       }
        return ret;
    }

}
