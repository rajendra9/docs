package com.spring.mvc.config.controllers;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.springframework.stereotype.Component;

@Component
public class Authenticator implements java.io.Serializable {
   ConcurrentMap<String, String> users = new ConcurrentHashMap<>();
   
   public Authenticator() {
       users.put("prasad","prasad123");
       users.put("satish","satish123");       
   }
    
   public boolean validate(String un, String pwd){
       boolean ret = false;
       if(users.containsKey(un)){
           if(users.get(un).equalsIgnoreCase(pwd)){
               ret = true;
           }               
       }
       return ret;
   }

}
