package com.spring.mvc.config.utils;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import com.spring.mvc.config.domain.Person;

public interface PersonsUsage extends Serializable {
  public List<Person>  getPeople();
  public Optional<Person> searchPeople(String adharId);
  public boolean savePerson(Person person);
}
