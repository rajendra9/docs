package com.htc.spring.domain;



import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;

@SuppressWarnings("serial")
@Entity
@Table(name="spr4emps")
@NamedQuery(name="emps.all",query="select e from EmpDTO e")
public class EmpDTO implements Serializable {
    private  int     empId;
    private  String  empName;
    private  double  salary;
    private  String  job;
    private  String  deptName;
    private  LocalDate    hiredate;
    
    @Column(name="job")
    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }     
    
    public EmpDTO() {
        
    }  
    
    public EmpDTO(int empId, 
                  String empName, 
                  String job,
                  double salary, 
                  String deptName,
                  LocalDate hiredate) {
        super();
        this.empId = empId;
        this.empName = empName;
        this.job = job;
        this.salary = salary;
        this.deptName = deptName;
        this.hiredate = hiredate;
    }

    @Id
    @Column(name="emp_id")
    public int getEmpId() {
        return empId;
    }
    
    public void setEmpId(int empId) {
        this.empId = empId;
    }

    @Column(name="emp_name")
    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    @Column(name="salary")
    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Column(name="dept_name")
    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    @Column(name="hdate")
    public LocalDate getHiredate() {
        return hiredate;
    }

    public void setHiredate(LocalDate hiredate) {
        this.hiredate = hiredate;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + empId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        EmpDTO other = (EmpDTO) obj;
        if (empId != other.empId)
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "EmpDTO [empId=" + empId + ", empName=" + empName + ", salary="
                + salary + ", deptName=" + deptName + ", hiredate=" + hiredate
                + "]";
    }   

}
