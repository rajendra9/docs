package com.htc.spring.domain;

import java.io.Serializable;



@SuppressWarnings("serial")
public class EmpTO implements Serializable {
    private  int     empId;
    private  String  empName;
    private  double  salary;
    private  String  job;
    private  String  deptName;
    private  String  hiredate;
    
    
    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }
    
    public EmpTO() {
        
    }  
    
    public EmpTO(int empId, 
                  String empName, 
                  String job,
                  double salary, 
                  String deptName,
                  String hiredate) {
        super();
        this.empId = empId;
        this.empName = empName;
        this.job = job;
        this.salary = salary;
        this.deptName = deptName;
        this.hiredate = hiredate;
    }

    public int getEmpId() {
        return empId;
    }
    
    public void setEmpId(int empId) {
        this.empId = empId;
    }

    
    public String getEmpName() {
        return empName;
    }


    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public double getSalary() {
        return salary;
    }


    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getDeptName() {
        return deptName;
    }


    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getHiredate() {
        return hiredate;
    }

    public void setHiredate(String hiredate) {
        this.hiredate = hiredate;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + empId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        EmpTO other = (EmpTO) obj;
        if (empId != other.empId)
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "EmpDTO [empId=" + empId + ", empName=" + empName + ", salary="
                + salary + ", deptName=" + deptName + ", hiredate=" + hiredate
                + "]";
    }   

}
