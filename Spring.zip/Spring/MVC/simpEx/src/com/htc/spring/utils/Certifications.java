package com.htc.spring.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.springframework.stereotype.Component;

@Component
public class Certifications {
   ConcurrentMap<String, Double>  certificateFees;

   {
	   certificateFees = new ConcurrentHashMap<>();
	   certificateFees.put("OCP-SCWCD",6500.5);
	   certificateFees.put("OCP-SCJP",7200.5);
	   certificateFees.put("MCSE", 8500.8);
	   certificateFees.put("OCP",7500.5);
	   certificateFees.put("Science-Talent",6200.5);
	   certificateFees.put("Arts-Proficiency",3500.5);
	   certificateFees.put("CCA",12500.5);
   }
  
   public double getFees(String cert) { 
	   double ret = 0.0;
	   if(certificateFees.containsKey(cert)) {
		   ret = certificateFees.get(cert);
	   }
	   return ret;
   }
   
   public String[] getCertificates() {
	   List<String> li = new ArrayList<>();
	   li.addAll(certificateFees.keySet());
	   return li.toArray(new String[] {""});
   }

}
