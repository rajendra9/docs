package com.spring4.web.ex;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class SimpleNumbersController {    
    	
	
    @RequestMapping(value="/compute",method=RequestMethod.POST)
    public String adding(@RequestParam("num1") double num1,
    		@RequestParam("num2") double num2, @RequestParam("act") String act,Model model ){
        
    	if(act.equalsIgnoreCase("add")) {    	
    	  model.addAttribute("result", new Double(num1+num2));
    	}
    	else if(act.equalsIgnoreCase("subtract")) {
    		double ret = (num1>num2) ? (num1-num2) : (num2-num1);
        	model.addAttribute("result", new Double(ret));
        }  
       	else if(act.equalsIgnoreCase("multiply")) {
       		model.addAttribute("result", new Double(num1 * num2));        	
        } 
       	else if(act.equalsIgnoreCase("divide")) {
       		double ret = (num1>num2) ? (num1/num2) : (num2/num1);
        	model.addAttribute("result", new Double(ret));        	
        }
    	return "simpResult";
    }
    
   
        
    @RequestMapping(value="/",method=RequestMethod.GET)
    public String index(Model model){
        return "index";
    }
    
       
    
}
