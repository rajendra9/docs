package com.spring4.web.ex;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes({"map"})
public class SimpleEmployeeController {

    @Autowired
    EmpDAO  dao;
    
    @RequestMapping(value="/welcome",method=RequestMethod.GET)
    public String welcome(@RequestParam(value="name",
             required=false,defaultValue="Universe")String name, Model model ){
        //Model class is->org.springframework.validation.support.BindingAwareModelMap
        model.addAttribute("name", name);
        return "welcome";
    }
    
    @RequestMapping(value="/search",method=RequestMethod.GET)
    public String searchEmp(@RequestParam(value="empId", required=true)String empId, Model model ){
        Employee searched = dao.search(Integer.parseInt(empId));
        model.addAttribute("employee", searched);
        return "searched";
    }
    
    @RequestMapping(value="/find/{eno}",method=RequestMethod.GET)
    public String findEmp(@PathVariable("eno")int eno, Model model ){
        Employee searched = dao.search(eno);
        model.addAttribute("employee", searched);
        return "searched";
    }
    
    @RequestMapping(value="/",method=RequestMethod.GET)
    public String index(Model model){
        return "index";
    }
    
    @GetMapping("/saveEmp")
    public String saveAddEmp(Model model){
        model.addAttribute("emp", new Employee());
        return "saveEmp";
    }   
   
    @PostMapping("/saveEmp")
    public String saveByAddShop(@RequestPart("empPicture") Part profileImage,
                                @ModelAttribute("emp")Employee emp,Model model) {
       String ret = "error";
        System.out.println("url contacted");
        String pfName = profileImage.getSubmittedFileName();
        try{
         profileImage.write(pfName);
         emp.setProfileImageFile(pfName);
         boolean isSaved = dao.saveEmployee(emp);
         System.out.println("****"+emp);
         if(isSaved){
            model.addAttribute("eno", emp.getEmpId()); 
            ret = "redirect:/find/{eno}";
         }         
        }catch(Exception ex){
          ex.printStackTrace();
        }
        return ret;
     }
    
    @RequestMapping(value="/sessDemo",method=RequestMethod.GET)
    public String forSess(Model model, HttpSession session){
        session.setAttribute("map", new HashMap<String,String>());
        return "forSess";
    }
    @RequestMapping(value="/sessionDemo",method=RequestMethod.POST)
    public String forShowSess(@RequestParam("brand")String brand, Model model, HttpSession session){
        Map<String, String> map = (Map<String,String>)session.getAttribute("map");
        map.put("aaa", "HTC");
        map.put("brand", brand);        
        return "sessShow";
    }   
   
    
}
