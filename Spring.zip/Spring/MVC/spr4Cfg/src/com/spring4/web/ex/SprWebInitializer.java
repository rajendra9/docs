package com.spring4.web.ex;

import javax.servlet.MultipartConfigElement;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration.Dynamic;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

public class SprWebInitializer implements WebApplicationInitializer {

    @Override
    public void onStartup(ServletContext ctx) throws ServletException {
       AnnotationConfigWebApplicationContext webCtx =
               new AnnotationConfigWebApplicationContext();
        webCtx.register(SprConfig.class);
        webCtx.setServletContext(ctx);
        
        /*
         * create a folder in
         *  E:\praeelipse2\sprweb4_ws\.metadata\.plugins\org.eclipse.wst.server.core\tmp0\work\Catalina\localhost\spr4
         *
         */
        Dynamic servlet = ctx.addServlet("dispatcher",new DispatcherServlet(webCtx));
       
        servlet.setMultipartConfig(new MultipartConfigElement("/uploads"));
        servlet.addMapping("/");
        servlet.setLoadOnStartup(1);
    }

}
