package com.spring4.web.ex;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.springframework.stereotype.Component;

@Component
public class EmpService implements EmpDAO {
    ConcurrentMap<Integer,Employee> employees;
    public EmpService() {
      employees = new ConcurrentHashMap<>();
      Employee emp = new Employee(100,"Surendran","Asst Manager",35000.0,304);
      employees.put(emp.getEmpId(), emp);
      emp = new Employee(120,"Madhavan","Dy Manager",45000.0,100);
      employees.put(emp.getEmpId(), emp);
      emp = new Employee(140,"Sampath","Supervisor",21000.0,140);
      employees.put(emp.getEmpId(), emp);
    }

    @Override
    public Employee search(int id) {
      if(employees.containsKey(id)){
          return this.employees.get(id);
      }
        return new Employee();
    }

    @Override
    public boolean saveEmployee(Employee emp) {
      boolean  ret = false;
      int id = emp.getEmpId();
      if(!employees.containsKey(id)){
       this.employees.put(id,emp);
       ret  = true;    
      }
      return ret;
    }
    
    

}
