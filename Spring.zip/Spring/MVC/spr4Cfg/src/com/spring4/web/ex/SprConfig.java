package com.spring4.web.ex;

import org.springframework.context.annotation.ComponentScan;

import java.io.IOException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.view.UrlBasedViewResolver;

//Marks this class as configuration
@Configuration
//Specifies which package to scan
@ComponentScan("com.spring4.web.ex")
//Enables Spring's annotations
@EnableWebMvc
public class SprConfig extends WebMvcConfigurerAdapter {

    @Override
    public void configureViewResolvers(ViewResolverRegistry registry) {
        registry.jsp("/WEB-INF/sprViews/",".jsp");
    }
    
    /*@Bean
    public MultipartResolver multipartResolver() throws IOException {
      CommonsMultipartResolver multipartResolver =
                            new CommonsMultipartResolver();   
      multipartResolver.setUploadTempDir(new FileSystemResource("/uploads"));
      multipartResolver.setMaxInMemorySize(0);
      return multipartResolver;
    }*/
    
}
