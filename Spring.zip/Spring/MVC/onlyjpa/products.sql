drop table if exists products;

drop sequence if exists prodid_seq;

create sequence prodid_seq start with 1000;

create table products(prod_id integer primary key,
prod_name varchar(20),
prod_type varchar(1),
cost decimal(8,2));

insert into products values(100,'A100','A',120.5);
insert into products values(200,'A120','A',340.5);
insert into products values(300,'B210','B',550.5);
insert into products values(400,'B432','C',355.5);
insert into products values(500,'B243','C',435.5);
insert into products values(600,'B543','C',512.5);

commit;




commit;

