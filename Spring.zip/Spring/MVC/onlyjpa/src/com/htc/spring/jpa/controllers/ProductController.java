package com.htc.spring.jpa.controllers;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.htc.spring.jpa.ProductDTO;
import com.htc.spring.jpa.ProductDao;

@Controller
public class ProductController {

    @Autowired
    ProductDao  dao;    
    
    @GetMapping({"/","/home"})
    public String welcome(Model model ){
         return "home";
    }
    
    @RequestMapping(value="/listProds",method=RequestMethod.GET)
    public String listProds(Model model ){
    	System.out.println("list Prods");
        List<ProductDTO> list = dao.findAll();
        model.addAttribute("products", list);
        return "listDisp";
    }
    
    @GetMapping("/forSearch")
    public String searching(Model model ){
      return "searchProd";    
    }
    
    @PostMapping("/forSearch")
    public String postSearching(@RequestParam("productId") int prodId, Model model ){
        System.out.println("search in process");
    	Optional<ProductDTO> searchedOpt = dao.searchProduct(prodId); 
    	if(searchedOpt.isPresent()) {
           model.addAttribute("searched", searchedOpt.get());
    	}
    	return "searched";    
    }
    
    @GetMapping("/forDelete")
    public String deleting(){
      return "deleteProd";    
    }
    
    @PostMapping("/forDelete")
    public String postDeleting(@RequestParam("productId") int prodId, Model model ){
        System.out.println("delete in process");
    	boolean ret  = dao.deleteProduct(prodId); 
    	if(ret) {
           model.addAttribute("msg", prodId + " product deleted");
    	}
    	return "deleted";    
    }
    
    @GetMapping("/forUpdate")
    public String loadUpdate(){
        return "updateProd";
    }
    
    @PostMapping(value="/forUpdate")
    public  String empUpdate(@RequestParam(value="productId", required=true)int id,
            @RequestParam(value="newCost", required=true)double newCost, Model model){
      boolean boo = false;
      String msg = "";
      boo = dao.updateProduct(id,  newCost);
         if(boo){
           msg = "Product with " + id +" is updated Successfully<br/>";   
         }
         else{
           msg = "Product with " + id +" is not updated Successfully<br/>";     
         }
      
      model.addAttribute("msg", msg); 
      return "updated";      
    }
    
    @GetMapping("/forSave")
    public String toSave(Model model){
        model.addAttribute("product", new ProductDTO());
        return "saveProd";
    }      
    
    @PostMapping("/forSave")
    public  String savingProduct(@ModelAttribute("product") ProductDTO prod, Model model){
        String msg = "";
        System.out.println("KKK" + prod);
        boolean boo = dao.persistProduct(prod); 
                
      if(boo){
         msg = prod + " is saved";                      
      }
      else {
    	  msg = "problems in saving";
      }
      model.addAttribute("msg", msg);
      return "saved";
    }  
   
    @RequestMapping(value="/mySearch",method=RequestMethod.GET)
    public String mySearch(Model model ){
      System.out.println("gggg");
      throw new RuntimeException("not viewable");    
    }
    
     
}
