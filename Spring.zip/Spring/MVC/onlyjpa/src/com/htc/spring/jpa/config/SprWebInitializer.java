package com.htc.spring.jpa.config;



import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration.Dynamic;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

public class SprWebInitializer implements WebApplicationInitializer {

    @Override
    public void onStartup(ServletContext ctx) throws ServletException {
       AnnotationConfigWebApplicationContext webCtx =
               new AnnotationConfigWebApplicationContext();
        webCtx.register(SprConfig.class);
        webCtx.register(SpringJpaConfig.class);
        webCtx.setServletContext(ctx);
        
        Dynamic servlet = ctx.addServlet("dispatcher",new DispatcherServlet(webCtx));
        servlet.setInitParameter("throwExceptionIfNoHandlerFound", "true");
        servlet.addMapping("/");
        servlet.addMapping("/resources");
        servlet.setLoadOnStartup(1);
    }
    
  
}
