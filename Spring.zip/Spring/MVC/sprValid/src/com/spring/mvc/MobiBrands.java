package com.spring.mvc;


import java.util.ArrayList;


public class MobiBrands extends ArrayList<String> {

    public MobiBrands() {
      this.add("Sony");
      this.add("Samsung");
      this.add("Moto-G");
      this.add("Vivo");
      this.add("LG");
      this.add("HTC");
      this.add("Nokia");
      this.add("Imtex");           
    }

    
}
