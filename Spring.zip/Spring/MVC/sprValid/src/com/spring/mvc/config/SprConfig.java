package com.spring.mvc.config;

import org.springframework.context.annotation.ComponentScan;

import java.util.Locale;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.i18n.CookieLocaleResolver;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

//Marks this class as configuration
@Configuration
//Specifies which package to scan
@ComponentScan({"com.spring.mvc.config","com.spring.mvc"})
//Enables Spring's annotations
@EnableWebMvc
public class SprConfig extends WebMvcConfigurerAdapter {

    @Override
    public void configureViewResolvers(ViewResolverRegistry registry) {
      registry.jsp("/WEB-INF/sprViews/", ".jsp");    
    }

    
  @Bean(name="validator")
  public LocalValidatorFactoryBean getValidator(){
    Locale.setDefault(Locale.US);
    LocalValidatorFactoryBean validatingBean = new LocalValidatorFactoryBean();
    validatingBean.setValidationMessageSource(createMessageSource());
    return validatingBean;
 }
  
 @Bean(name="messageSource")
 public MessageSource createMessageSource(){
   ReloadableResourceBundleMessageSource messageSource 
       = new ReloadableResourceBundleMessageSource(); 
   messageSource.setBasename("resources/ValidationMessages");
   messageSource.setDefaultEncoding("UTF-8");
   System.out.println("Message Source created");
   return messageSource;
 }         
    
    @Bean(name="localeResolver")
    public LocaleResolver createLocaleResolver(){
       CookieLocaleResolver resolver = new CookieLocaleResolver();
       resolver.setDefaultLocale(new Locale("en"));
       resolver.setCookieName("myLocaleCookie");
       resolver.setCookieMaxAge(4800);
       return resolver;       
    }
    
       
   
}
