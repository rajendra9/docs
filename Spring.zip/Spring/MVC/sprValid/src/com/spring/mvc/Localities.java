package com.spring.mvc;


import java.util.HashMap;
import java.util.Map;

public class Localities extends HashMap<String,String> {

    public Localities() {
      this.put("Sec","Secunderabad");   
      this.put("malakpet","Malakpet-Bank Colony");
      this.put("Tambaram_W","Tambaram West");
      this.put("Tambaram_E","Tambaram East");
      this.put("Chromepet_W","Chromepet West");
      this.put("Chromepet_E","Chromepet East");
      this.put("Mambalam_W","Mambalam West");
      this.put("Mambalam_E","Tambaram East");
      this.put("NungamBakkam_W","NungamBakkam West");
      this.put("NungamBakkam_E","NungamBakkam East");
      this.put("Adyar_N","Adyar North");
      this.put("Adyar_S","Adyar South");
      this.put("Guindy_W","Guindy West");
      this.put("Guindy_E","Guindy East");
      this.put("Saida","Saidabad");
      this.put("MPet","MalakPet"); 
      
    }

    
}
