package com.spring.mvc;



import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Arrays;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Size;

import javax.validation.constraints.NotEmpty;

@SuppressWarnings("serial")
public class MobiShop implements Serializable {
   
   @NotBlank
   @Size(min=6, max=20)
   private  String  shopName;
   
   @NotBlank
   @Size(min=4, max=18)
   private  String  locality;
   
   @NotEmpty
   private  String  city;
   
   @Min(2)
   @Max(5)
   private  int   yearsOfGuarantee;
   
   private String[] rankBrands;
   
   public String[] getRankBrands() {
    return rankBrands;
   }

   public void setRankBrands(String[] rankBrands) {
    this.rankBrands = rankBrands;
   }

   @DecimalMin("100000.0")
   @DecimalMax("4000000.0")
   private  double  turnover;
  
   //date-of-establishment
   
   @PastOrPresent
   private LocalDate doe = LocalDate.now(); 
   
  
   public int getYearsOfGuarantee() {
       return yearsOfGuarantee;
   }

   public void setYearsOfGuarantee(int yearsOfGuarantee) {
       this.yearsOfGuarantee = yearsOfGuarantee;
   }
   
   @Override
   public String toString() {
	return "MobiShop [shopName=" + shopName + ", locality=" + locality + ", city=" + city + ", yearsOfGuarantee="
			+ yearsOfGuarantee + ", rankBrands=" + Arrays.toString(rankBrands) + ", turnover=" + turnover + ", doe="
			+ doe + "]";
   }

   public MobiShop() {
      super();
   }
  

   public MobiShop(String shopName, String locality, String city, int yearsOfGuarantee, double turnover) {
     super();
     this.shopName = shopName;
     this.locality = locality;
     this.city = city;
     this.yearsOfGuarantee = yearsOfGuarantee;
     this.turnover = turnover;
   }

    public String getShopName() {
      return shopName;
    }

    public void setShopName(String shopName) {
      this.shopName = shopName;
    }

    public String getLocality() {
       return locality;
    }

    public void setLocality(String locality) {
       this.locality = locality;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
       this.city = city;
    }

    public double getTurnover() {
        return turnover;
    }

    public void setTurnover(double turnover) {
       this.turnover = turnover;
    }

    public LocalDate getDoe() {
        return doe;
    }

    public void setDoe(LocalDate doe) {
        this.doe = doe;
        ;
    }

   
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((locality == null) ? 0 : locality.hashCode());
        result = prime * result + ((shopName == null) ? 0 : shopName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        MobiShop other = (MobiShop) obj;
        if (locality == null) {
           if (other.locality != null)
              return false;
        }  else if (!locality.equals(other.locality))
             return false;
        if (shopName == null) {
           if (other.shopName != null)
               return false;
        } else if (!shopName.equals(other.shopName))
             return false;
         return true;
      }

      public MobiShop(String shopName, String locality) {
        super();
        this.shopName = shopName;
        this.locality = locality;
      }
   
   
   
   
}
