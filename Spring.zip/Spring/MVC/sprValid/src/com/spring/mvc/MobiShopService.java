package com.spring.mvc;

import java.time.Instant;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.springframework.stereotype.Service;

@Service
public class MobiShopService implements MobiShopDAO {
    
    
    
    
    ConcurrentMap<String, MobiShop> shopMap = new ConcurrentHashMap<>();
    
    {
      System.out.println("KKKKKKK");
      LocalDate estDate = LocalDate.of(2017,  Month.AUGUST, 15);
      MobiShop shop = new MobiShop("Sanjeeva", "Chromepet", "Chennai", 2, 2000000.5);
      shop.setDoe(estDate);
      shopMap.put("ch_ch_100",shop);
      
      estDate = LocalDate.of(2018,  Month.MARCH, 10);
      shop = new MobiShop("Universal", "Tambaram", "Chennai", 3, 2200000.5);
      shop.setDoe(estDate);
      shopMap.put("ch_ta_110",shop);
      
       
      estDate = LocalDate.of(2017,  Month.AUGUST, 16);
      shop = new MobiShop("PoomPuhar", "Tambaram", "Chennai", 2, 2400000.5);
      shop.setDoe(estDate);
      shopMap.put("ch_ta_120",shop);
    } 

    @Override
    public List<MobiShop> getShops() {
        List<MobiShop> ret = new ArrayList<>();
        ret.addAll(shopMap.values());
        return ret;
    }

   

    @Override
    public boolean saveMobileShop(String key, MobiShop shop) {
       System.out.println(key + "::" + shop); 
        if(!shopMap.containsKey(key)){
            shopMap.putIfAbsent(key,  shop);
            return true;
        }
        return false;
    }

   
}
