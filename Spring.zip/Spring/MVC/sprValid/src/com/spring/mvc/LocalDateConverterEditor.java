package com.spring.mvc;

import java.beans.PropertyEditorSupport;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class LocalDateConverterEditor 
     extends PropertyEditorSupport {

	//DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE;
	
	DateTimeFormatter dateTimeFormatter =
			 DateTimeFormatter.ofPattern("yyyy-MM-dd");
	
	public String getAsText() {
	   LocalDate obj = (LocalDate)this.getValue();
	   return obj.format(dateTimeFormatter);
	}

	
	public void setAsText(String str) throws IllegalArgumentException {
	  LocalDate dt = LocalDate.parse(str, dateTimeFormatter);
	  super.setValue(dt);
	}

}
