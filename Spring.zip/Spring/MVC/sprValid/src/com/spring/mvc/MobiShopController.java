package com.spring.mvc;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.handler.annotation.support.MethodArgumentNotValidException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;


@Controller
public class MobiShopController {

     
   @Autowired
   MobiShopDAO shopDao;
  
   @InitBinder
   public void bindData(WebDataBinder binder){
     binder.registerCustomEditor(java.time.LocalDate.class, 
    		                     new LocalDateConverterEditor());   
     
   }
   @ModelAttribute("localities")
   public Map<String,String> getLocalities(){
     return new Localities();
   }
   
   @ModelAttribute("brands")
   public List<String> getBrands(){
     return new MobiBrands();
   }
   
   @RequestMapping(value="/", method=RequestMethod.GET)
   public String index(Model model){
       model.addAttribute("msg","Welcome to Spring Validation");
       return "index";
   }
   
   @GetMapping("/saveShop")
   public String saveAddShop(Model model){
       model.addAttribute("shop", new MobiShop());
       return "saveShop";
   }
  
  
   @PostMapping("/saveShop")
   public String saveByAddShop(@ModelAttribute("shop")@Valid MobiShop shop,
                               BindingResult errors,
                               @RequestParam("key")String key,
                               HttpServletRequest request,
                               RedirectAttributes attrs )                       
                                
                                                              {
     System.out.println("url contacted");
       System.out.println("****"+shop);
       if(errors.hasErrors()){          
           System.out.println("errors"); 
           return "saveShop";
       }
       boolean ret = shopDao.saveMobileShop(key, shop);
       if(ret){
            return "shopAdded";
       }
       else{
         return "error";  
       }
   }
}
