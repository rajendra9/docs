package foraop;

import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.DoubleAdder;
import java.util.concurrent.ConcurrentSkipListMap;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

@Component("simpleMeths")
public class SimpleMethsImpl implements SimpleMeths {
    DoubleAdder adder = new DoubleAdder();
    ConcurrentNavigableMap<String,List<String>> passIssues = new ConcurrentSkipListMap<>();
    {
      List<String> names = Arrays.asList("swaroop","nandagopal","suguna","rajesh");
      passIssues.put("10-01-2018", names);  
    }
    @Override
    public  double addAmounts(int count){
       ThreadLocalRandom random = ThreadLocalRandom.current();
       for(int i=0;i<count;i++){
           adder.add(random.nextDouble(1000.0));
       }
       return adder.doubleValue();
    }
    
    @Override
    public boolean registerPerson(String person){
      LocalDate locDate = LocalDate.now();
      String dt = locDate.format(DateTimeFormatter.ofPattern("dd-MM-YYYY")); 
      if(passIssues.containsKey(dt)){
          passIssues.get(dt).add(person); 
      }
      else{
         List<String> list = new ArrayList<>();
         list.add(person);
         passIssues.put(dt, list); 
      }
      System.out.println(passIssues);
      return true;
    }
    
    @Override
    public String computePower(String input){
        double dbl = Double.parseDouble(input);
        return "The Power to 5 of "+dbl+" is::"+Math.pow(dbl, 5);
    }
    
    @Override
    public boolean changeRegistration(String dt, String oldPerson, String newPerson){
        boolean ret = false;
        if(passIssues.containsKey(dt)){
          List<String> passIssued = passIssues.get(dt);
          if(passIssued.contains(oldPerson)){
              int index = passIssued.indexOf(oldPerson);
              passIssued.set(index,newPerson);
              System.out.println(passIssued);
              ret = true;
          }
        }
        return ret;
     }
   
     @Override
     public String arrageDarshanPrasadAtKoil(String ngoMember){
       StringBuilder sb = new StringBuilder();
       sb.append("if " + ngoMember + " pays money-100 ");
       sb.append("Darshan and Prasad will be provided at ");
       sb.append("Tirupati on Diwali");
       return sb.toString();           
     }
    
    
}
