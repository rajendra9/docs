package foraop;

public interface SimpleMeths {
    public String computePower(String input);
    public boolean registerPerson(String person);
    public boolean changeRegistration(String dt,String oldPerson, String newPerson);
    public  double addAmounts(int count);
    public String arrageDarshanPrasadAtKoil(String ngoMember);
}
