package foraop;

import java.math.BigDecimal;
import java.math.MathContext;
import java.time.LocalDate;
import java.util.logging.Logger;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.SimpleFormatter;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.After;

import springex.utils.HeartfullnesMembers;

@Aspect
public class AspectsWeavingBean {
   Logger logger;
    public AspectsWeavingBean() {
      logger = Logger.getLogger(this.getClass().getCanonicalName());
      try{
         FileHandler fh = new FileHandler("passChange.dat",true);
         fh.setFormatter(new SimpleFormatter());
         logger.addHandler(fh);
      }catch(Exception ex){
          throw new RuntimeException(ex.getMessage());
      }
    }
    
    public String getTitleName(String person){
        StringBuilder sb = new StringBuilder();
        if(person.contains(" ")){
         String[] tokens = person.split("\\s");
         for(String token : tokens){
          sb.append(Character.toUpperCase(token.charAt(0))+token.substring(1)+" ");
         }
        }
        return sb.toString().trim(); 
    }
    
    public String giveDoubleFreeOfNonDigits(String input){
       char[] chars = input.toCharArray();
       StringBuilder sb = new StringBuilder();
       for(char ch : chars){
         if(Character.isDigit(ch)|| ch=='.'){
            sb.append(ch); 
         }
         else{
             continue;
         }
       }
       double dbl = Double.parseDouble(sb.toString());
       String ret = "The Power to 5 of "+dbl+" is-"+Math.pow(dbl, 5);
       return ret;       
    }
        
    @Before("execution(* foraop.SimpleMeths.registerPerson(..))")
    public void changeName(JoinPoint jp){
        String pers = (String)jp.getArgs()[0];
        pers = this.getTitleName(pers);
        SimpleMethsImpl target = (SimpleMethsImpl)jp.getTarget();
        logger.log(Level.INFO, "" + pers + " came for registration");       
    }
    
    @AfterReturning(pointcut="execution(* foraop.SimpleMeths.addAmounts(..))",returning="compDouble" )
    public void changeCost(JoinPoint jp, double compDouble){
       BigDecimal decimal = new BigDecimal(compDouble);
       double ret = decimal.round(MathContext.DECIMAL32).doubleValue();
       System.out.println("rounded Value is:" + ret);       
    }
    
    @AfterThrowing(pointcut="execution(* foraop.SimpleMeths.computePower(..))",throwing="ex")
    public void showCorrectResult(JoinPoint jp, Throwable ex){
       String input = (String)jp.getArgs()[0];
       if(ex instanceof NumberFormatException){
        String ret = this.giveDoubleFreeOfNonDigits(input);
        System.out.println("with Correct Input gives::"+ret);
       }
    }
    
    @After("execution(* foraop.SimpleMeths.changeRegistration(..))")
    public void logRegChange(JoinPoint jp){
       String oldPerson = (String)jp.getArgs()[1];
       String newPerson = (String)jp.getArgs()[2];
       StringBuilder sb = new StringBuilder();
       sb.append("Pass given is changed from "+oldPerson);
       sb.append(" and changd to "+newPerson);
       sb.append(" on "+LocalDate.now());
       logger.log(Level.WARNING, sb.toString()); 
    }
    
    @Around("execution(* foraop.SimpleMeths.arrageDarshanPrasadAtKoil(..))")
    public Object addConcesion(ProceedingJoinPoint jp)throws Throwable{
       String member = (String)jp.getArgs()[0];
       String result = (String)jp.proceed();
       HeartfullnesMembers heartMembers = new HeartfullnesMembers();
       if(heartMembers.isMember(member)){
         result = result.replace("100","50"); 
       }
       return result;
    }    
}
