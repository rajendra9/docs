package com.htc.spring.aop;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;

import org.springframework.stereotype.Component;

@Component("baseIfImpl")
public class BaseIfImpl implements BaseIf {
    
    public void compute1(BigDecimal bd1, BigDecimal bd2) {
      BigDecimal result = bd1.add(bd2,MathContext.DECIMAL32);
      System.out.println("Result is:"+result);
    }
    
    public void compute2(BigInteger bi1, BigInteger bi2) {
        BigInteger result = bi1.multiply(bi2);
        System.out.println("Result is:"+result);
    }
   
    public BigDecimal compute3(String bd1, String bd2) throws Exception {
        BigDecimal bdA = new BigDecimal(bd1);
        BigDecimal bdB = new BigDecimal(bd2);
        return bdA.subtract(bdB);      
    }

    @Override
    public BigDecimal[] compute4(String bd1, String bd2) {
      BigDecimal bdA = new BigDecimal(bd1);
      BigDecimal bdB = new BigDecimal(bd2);
      BigDecimal[] result = bdA.divideAndRemainder(bdB);
      return result;
    }

    @Override
    public String toString() {
        return "BaseIfImpl Class";
    }

    @Override
    public String returnConstants() {
       return "e is:"+Math.E+" pi is:"+Math.PI;
    }

}
