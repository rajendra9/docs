package com.htc.spring.aop;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

public interface BaseIf extends Serializable {
    
  public void compute1(BigDecimal bd1,BigDecimal bd2);
  
  public void compute2(BigInteger bi1,BigInteger bi2);

  public BigDecimal compute3(String bd1, String bd2)throws Exception; 
  
  public BigDecimal[] compute4(String bd1, String bd2);

  public String returnConstants();
}
