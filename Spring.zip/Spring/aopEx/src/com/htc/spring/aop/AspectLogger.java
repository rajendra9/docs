package com.htc.spring.aop;

import java.math.BigDecimal;
import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;


@Aspect
public class AspectLogger {
    

  public AspectLogger() {
        super();
       System.out.println("Aspect class");
    }

  @Before("execution(* com.htc.spring.aop.BaseIfImpl.compute1(..))")
  public void forMethBefore(JoinPoint jp){
    Signature signature = jp.getSignature();
    System.out.println("Signature:"+signature);
    BaseIfImpl target = (BaseIfImpl)jp.getTarget();
    System.out.println(target);
    Object[] args = jp.getArgs();
    System.out.println(Arrays.toString(args));    
  }

  @After("execution(* com.htc.spring.aop.BaseIfImpl.compute2(..))")
  public void forMethAfter(JoinPoint jp){
    Signature signature = jp.getSignature();
    System.out.println("Signature:"+signature);
    BaseIfImpl target = (BaseIfImpl)jp.getTarget();
    System.out.println(target);
    Object[] args = jp.getArgs();
    System.out.println(Arrays.toString(args));    
  }  
   
  @AfterReturning(
	pointcut="execution(* com.htc.spring.aop.BaseIfImpl.compute4(..))",
          returning="result")
  public void forMethAfterReturning(JoinPoint jp,Object result){
    Signature signature = jp.getSignature();
    System.out.println("Signature:"+signature.getName());
    BaseIfImpl target = (BaseIfImpl)jp.getTarget();
    System.out.println(target);
    Object[] args = jp.getArgs();
    BigDecimal[] res = (BigDecimal[])result;
    System.out.println(Arrays.toString(args)); 
    System.out.println("Result is:"+Arrays.toString(res));
  }
  @AfterThrowing(
		pointcut="execution(* com.htc.spring.aop.BaseIfImpl.compute3(..))",
          throwing="ex")
  public void forMethAfterThrowing(JoinPoint jp,Throwable ex){
    Signature signature = jp.getSignature();
    System.out.println("Signature:"+signature.getName());
    BaseIfImpl target = (BaseIfImpl)jp.getTarget();
    System.out.println(target);
    Object[] args = jp.getArgs();
    System.out.println("\narguments");
    System.out.print(Arrays.toString(args)); 
    System.out.println("Thrown Exception is:"+ex);
  } 
  
  @Around("execution("
  		+ "* com.htc.spring.aop.BaseIfImpl.returnConstants(..))")
  public Object forMethAround(ProceedingJoinPoint jp)throws Throwable {
    System.out.println("Before");
    Signature signature = jp.getSignature();
    System.out.println("Signature:"+signature.getName());
    BaseIfImpl target = (BaseIfImpl)jp.getTarget();
    System.out.println(target);
    String result = (String)jp.proceed();
    System.out.println("After");
    result = result.toUpperCase();
    return result;
  }
  
}