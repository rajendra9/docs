package xmlaop;

public class SingingBean {
  
  public void sing(String songStart) {
   System.out.println(songStart+"....la...la...la...adhirenu na style......");  
  }

}
