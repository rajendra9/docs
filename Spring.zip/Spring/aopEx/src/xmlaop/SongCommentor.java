package xmlaop;

public class SongCommentor {
  
    public void atSongStart() {
      System.out.println("\nfirst calm yourself,"+
                         " forgetting competition,"+
                         " please focus on 'Raga'");
      System.out.println();
    }
	
    public void atSongEnd() {
      System.out.println(); 
      System.out.println("very nice, good performance");   }
    }
