package forafterreturning;

public class SimpBean {

    public String wish(String person){
        return "Hi! "+person+" wish you all the best";
    }
    
}