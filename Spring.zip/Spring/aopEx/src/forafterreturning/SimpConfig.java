package forafterreturning;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy; 
import org.springframework.context.annotation.Bean;


@Configuration
@EnableAspectJAutoProxy(proxyTargetClass=true)
public class SimpConfig  {
 
   @Bean(name="simpBean")
   public SimpBean getSimple() {
     return new SimpBean();
   }
   
   @Bean
   public AspectConfig getAspect(){
       return new AspectConfig();
   }
   
}