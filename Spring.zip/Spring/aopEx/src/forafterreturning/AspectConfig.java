package forafterreturning;


import org.aspectj.lang.JoinPoint;


import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class AspectConfig {
  
  public AspectConfig() {
    super();
    System.out.println("Aspect class");
  }

  @AfterReturning(pointcut="execution(* forafterreturning.SimpBean.wish(..))",
          returning="result")
  public void showAfterReturning(JoinPoint jp,Object result){
    SimpBean target = (SimpBean)jp.getTarget();
    System.out.println(target);
    String arg = (String)jp.getArgs()[0];
    System.out.println("Person is :"+arg);
    System.out.println("See how aop works");
    
  }
  
  
}