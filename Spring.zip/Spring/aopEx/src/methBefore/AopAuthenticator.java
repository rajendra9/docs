package methBefore;

import java.util.HashSet;
import java.util.Set;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AopAuthenticator {
 Set<AllowedOfficerVO> allowedUsers;
 AuthenticRecorder recorder;
 
 public AopAuthenticator() {
  System.out.println("constructor");	 
  recorder = new AuthenticRecorder();
  allowedUsers = new HashSet<AllowedOfficerVO>();
  allowedUsers.add(new AllowedOfficerVO("AAA","aaa","ProjectManager"));
  allowedUsers.add(new AllowedOfficerVO("BBB","bbb","ProjectArchitect"));
  allowedUsers.add(new AllowedOfficerVO("CCC","ccc","TeamLeader"));
  allowedUsers.add(new AllowedOfficerVO("DDD","ddd","ConfigManager"));
 }

 
 @Before("execution(* methBefore.MalayasiaClientDevelopers.getMalayasiaBound(..))")
 public void before(JoinPoint jp) {
   System.out.println("Fired");
   AllowedOfficerVO officer = recorder.getLoginUser();
   if(officer == null) {
    System.out.println("No user ! not allowed to ask this info");
    throw new ForbiddenException("Not allowed");
   }
   else if(allowedUsers.contains(officer)) {
    System.out.println("Please you are eligible");
   }
   else {
    System.out.println(officer.getUsername()+
                " You are not allowed to ask this info");
    throw new ForbiddenException("You are Not allowed");
   }
 }

}
