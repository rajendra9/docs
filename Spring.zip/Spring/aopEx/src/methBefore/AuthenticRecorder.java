package methBefore;

import org.springframework.stereotype.Component;

/* class that meant to hold current invoking user credentials */


@Component("recorder")
public class AuthenticRecorder {
  public static ThreadLocal<AllowedOfficerVO> allowed =
      new ThreadLocal<AllowedOfficerVO>();
    
  public void logon(String uname,String pword,String role) {
   AllowedOfficerVO officer = new AllowedOfficerVO(uname, pword, role);
   allowed.set(officer);
  }
  
  public void logout() {
   allowed.remove();
  }
  
  public AllowedOfficerVO getLoginUser() {
   return allowed.get();
  }
}
