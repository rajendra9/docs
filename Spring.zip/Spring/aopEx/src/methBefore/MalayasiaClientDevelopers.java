package methBefore;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import org.springframework.stereotype.Component;

@Component("malayasia")
public class MalayasiaClientDevelopers {
 private String[] possibles =
 {"Saravanan(28)", "Vijay Babu", "Shankar", "Muthu kumar",
  "Satish Kumar", "Sridhar", "Mahesh Kumar", "Thirunavakarasu"
 };
 
 public Set<String> getMalayasiaBound() {
  Set<String> list = new HashSet<String>();
  Random rand = new Random();
  int len = possibles.length;
  int cnt = 0;
  while(true) {
   if(cnt==5) { break; }
   int index = rand.nextInt(len);
   String forAdding = possibles[index]; 
   if(!list.contains(forAdding)){
    list.add(forAdding);
    cnt++;
   }
  }
  return list;
 }
 
 
 
}
