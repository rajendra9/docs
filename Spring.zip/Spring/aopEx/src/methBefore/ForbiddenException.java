package methBefore;

public class ForbiddenException extends SecurityException {
   private String cause;

   public ForbiddenException(String arg0) {
    super(arg0);
    this.cause = arg0; 
   }

   public String getMessage(){
     return this.cause;
   }   
   
}