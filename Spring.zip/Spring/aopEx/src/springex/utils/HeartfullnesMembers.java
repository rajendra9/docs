package springex.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HeartfullnesMembers {
    List<String> members;
    
    {
      members = new ArrayList<>();
      Collections.addAll(members,"Subbarao", "N.KasiNath", "Adyar Govindan", 
    		       "R.Gopalam","R.DhandayudhaPani","K.Yadagiri");
    }
    
    public boolean isMember(String name){
        return members.contains(name);
    }

}
