package forMethIntro;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Examination implements Serializable {

    private String examName;
    private String course;
     
    public Examination() {
        super();    
    }

    public Examination(String examName, String course) {
        super();
        this.examName = examName;
        this.course = course;
    }

    public String getExamName() {
        return examName;
    }

    public void setExamName(String examName) {
        this.examName = examName;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((examName == null) ? 0 : examName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Examination other = (Examination) obj;
        if (examName == null) {
            if (other.examName != null)
                return false;
        } else if (!examName.equals(other.examName))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "Examination [examName=" + examName + ", course=" + course + "]";
    }
    
    public static List<Examination>  getAvailableExams() {
        List<Examination> ret = new ArrayList<Examination>();
        ret.add(new Examination("OCP-SCWCD","BCA"));
        ret.add(new Examination("OCP-SCJP","BCA"));
        ret.add(new Examination("MCSE","BCA"));
        ret.add(new Examination("OCP","BCA"));
        ret.add(new Examination("Science-Talent","BSC"));
        ret.add(new Examination("Arts-Proficiency","BA"));
        ret.add(new Examination("CCA","BCOM"));
        return ret;
    }
     
}