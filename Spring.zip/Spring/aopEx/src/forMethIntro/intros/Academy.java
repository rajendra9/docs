package forMethIntro.intros;

import org.springframework.stereotype.Component;

@Component("trainer")
public class Academy implements Sports {

  public void joinSports() {
     System.out.println("\nUtilizing retired Experts,"+
           " Coaching and Practice are being provided ");
  }

}
