package forMethIntro.intros;

public interface Sports {
  
    public void joinSports();

}
