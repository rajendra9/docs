package forMethIntro;

import java.util.List;
import java.util.Scanner;
import org.springframework.stereotype.Component;

@Component("education")
public class AcademicStudent implements Educated {

    private   int       studentId;
    private   String    studentName;
    private   int       age;
    private   Courses   course;
       
       
    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }
    
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int getAge() {
        return age;
    }
    
    public void setAge(int age) {
        this.age = age;
    }

    public Courses getCourse() {
        return course;
    }
    
    public void setCourse(Courses course) {
        this.course = course;
    }
    

    
    private  boolean isAvailable(String crs) {
        boolean ret = false;
        Courses given = Courses.valueOf(crs);
        for(Courses cr : Courses.values()) {
            if(cr == given) {
               ret = true;
               break;
            }
        }
        return ret;
    }    
    
    public void study(String givenCourse) {
      if(this.isAvailable(givenCourse)){
        System.out.println(
            "Enrollment and Training Schedules are being made to study");  
      }
      this.course = Courses.valueOf(givenCourse);
    }

    
    public void appearForExam(Examination exam) {
       List<Examination> examList = 
              Examination.getAvailableExams();
      if(examList.contains(exam)) {
          System.out.println("Student "+this.studentName+
                             " is appearing for "+exam);   
      }

    }
    
    public void developHobbies() {
      System.out.println("Book Reading and Playing Sports"+
             " are to given high preference");
    }

}