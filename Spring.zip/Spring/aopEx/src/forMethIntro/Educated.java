package forMethIntro;

public interface Educated {
  
  public void study(String course);
  public void appearForExam(Examination exam);
  public void developHobbies();
    
}
