package forMethIntro;

public enum Courses {
	
	       BSC(new String[] {"maths","physics", "chemistry"}),
	       BA(new String[] {"maths","economics", "politics"}),
	       BCA(new String[] {"mainframes","java", ".net"}),
	       BCOM(new String[]{"company-law", "Mercantile-law","cost-accounts"});
	       
	       String[]  subjects;
	       Courses(String[] subjects){
	         this.subjects = subjects;          
	       }
	       public String[] getSubjects() {
	         return subjects;
	       }
}
