package forMethIntro;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.annotation.DeclareParents;
import org.springframework.stereotype.Component;

import forMethIntro.intros.Sports;

@Aspect
@Component
public class SportsWeaver {

@Pointcut("execution(* forMethIntro.AcademicStudent.developHobbies(..))")
    public void play(){
        
    }
    @DeclareParents(value="forMethIntro.*+",
            defaultImpl=forMethIntro.intros.Academy.class)
    public static Sports sports;
    
    
    @After("play() && this(sprtsParam)") 
    public void cultivateSports(Sports sprtsParam) {
        sprtsParam.joinSports();
    }
}