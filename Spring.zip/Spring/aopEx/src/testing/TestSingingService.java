package testing;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import xmlaop.SingingBean;
public class TestSingingService {
 
  public static void main(String[] args) {
  
   try {
    ApplicationContext factory = 
      new FileSystemXmlApplicationContext("xmlAop.xml"); 
    SingingBean singer = (SingingBean)factory.getBean("singer"); 
                        
    singer.sing("Ippudu Chudu..");
    
   }catch(Exception e) {
      System.out.println(e);
   }   
  }

}