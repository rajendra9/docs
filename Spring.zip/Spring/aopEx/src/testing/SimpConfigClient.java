package testing;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import forafterreturning.SimpBean;


public class SimpConfigClient {
 
  public static void main(String[] args) {
    try {   
    
      ApplicationContext factory =
          new AnnotationConfigApplicationContext(forafterreturning.SimpConfig.class);
        
      SimpBean sb = 
            (SimpBean)factory.getBean("simpBean"); 
      
      System.out.println(sb.wish("DeviDayalan"));
     }
      catch(Exception e) {
         e.printStackTrace();
      }
    } 

}