package testing;

import org.apache.log4j.FileAppender;
import org.apache.log4j.HTMLLayout;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import methBefore.AuthenticRecorder;
import methBefore.ForbiddenException;
import methBefore.MalayasiaClientDevelopers;

@Configuration
@ComponentScan("methBefore")
@EnableAspectJAutoProxy
public class TestAopAuthenticator {

 

 public static void main(String[] args){
   
  
  try {
   Logger logger  = Logger.getRootLogger();
   logger.addAppender(new FileAppender(new HTMLLayout(),
                      "log1.log",true));
   ApplicationContext ctx =
		   new AnnotationConfigApplicationContext(TestAopAuthenticator.class);
   
   AuthenticRecorder recorder = (AuthenticRecorder)ctx.getBean("recorder");
   recorder.logon("AAA","aaa","ProjectManager");
  
  MalayasiaClientDevelopers developers = (MalayasiaClientDevelopers)ctx.getBean("malayasia");
   System.out.println(developers.getMalayasiaBound());
   recorder.logout();
   recorder.logon("ZZZ","zzz","ProjectDeveloper");
   System.out.println(developers.getMalayasiaBound());
   recorder.logout();
  }
  catch(ForbiddenException e){
   System.out.println(e.getMessage());
  }
  catch(Exception e){
   System.out.println(e.getMessage());
  }
  
 }
  
}
