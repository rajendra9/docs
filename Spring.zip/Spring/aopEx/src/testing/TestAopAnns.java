package testing;

import com.htc.spring.aop.BaseIf;
import java.math.BigInteger;
import java.math.BigDecimal;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class TestAopAnns {
 
  public static void main(String[] args) {
  
   try {
    
    BeanFactory factory = 
      new FileSystemXmlApplicationContext("annAop.xml"); 
    BaseIf base = (BaseIf)factory.getBean("baseIfImpl"); 
    System.out.println("Invoking Aspect");

    base.compute1(new BigDecimal(32.0), new BigDecimal(28.0));

    base.compute2(new BigInteger("3"), new BigInteger("9"));

    BigDecimal[] results = base.compute4("14.5", "3.2");

    String consts = base.returnConstants();
    System.out.println(consts);

    BigDecimal res = base.compute3("14.5a", "3.2");

   }catch(Exception e) {
     System.out.println(e);
    }   
  }

}