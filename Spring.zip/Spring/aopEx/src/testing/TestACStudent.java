package testing;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import forMethIntro.Educated;
import forMethIntro.intros.Sports;
@Configuration
@ComponentScan({"forMethIntro","forMethIntro.intros"})
@EnableAspectJAutoProxy
public class TestACStudent {
 
  public static void main(String[] args) {
  
   try {
    
    AnnotationConfigApplicationContext factory = 
      new AnnotationConfigApplicationContext(TestACStudent.class); 
    Educated student = (Educated)factory.getBean("education"); 
    System.out.println();
    student.study("BCA");
    System.out.println();
    System.out.println("Invoking Aspect in developHobbies method");
    student.developHobbies();    
    
    Sports sports = (Sports)factory.getBean("education");
    System.out.println("\nInvoking throw direct "+
                       "interface retreival\n");
    
    sports.joinSports();
       
    }
    catch(Exception e) {
     System.out.println(e);
    }   
  }

}