package testing;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import foraop.AspectsWeavingBean;
import foraop.SimpleMeths;
import foraop.SimpleMethsImpl;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
@EnableAspectJAutoProxy
public class TestSimpleMeths {
   
    @Bean(name="simpleMeths") 
    public SimpleMeths  simpleMeths(){
        return new SimpleMethsImpl();
    }
    
    @Bean AspectsWeavingBean getAspectsWeavingBean(){
        return new AspectsWeavingBean();
    }
    
    public static void main(String[] args) {
      ApplicationContext  ctx =
              new AnnotationConfigApplicationContext(testing.TestSimpleMeths.class);
      SimpleMeths  meths = ctx.getBean(SimpleMeths.class);
      Scanner scan = new Scanner(System.in);
     
      String res = meths.arrageDarshanPrasadAtKoil("Subbarao");
      System.out.println(res);
      res = meths.arrageDarshanPrasadAtKoil("Arun Kumar");
      System.out.println(res);
      double ret = meths.addAmounts(3);
      System.out.println("3 times random adding gives "+ret);
      boolean result = meths.changeRegistration("10-07-2016", "swaroop","sukumaran");
      System.out.println("Enter a person");
      String person = scan.nextLine();
      result = meths.registerPerson(person);
      System.out.println(result); 
      System.out.println("Enter a double");
      String num = scan.nextLine();
      res = meths.computePower(num);
      System.out.println(res); 
    
    }

}
