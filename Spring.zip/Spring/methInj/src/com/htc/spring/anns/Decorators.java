package com.htc.spring.anns;

import org.springframework.stereotype.Component;

@Component
public class Decorators {

	public Decorators() {
		// TODO Auto-generated constructor stub
	}
	
	public String arrangeFunctionInfra() {
		StringBuffer sb = new StringBuffer();
		sb.append("Utilities like stage,seating, Sound Systems wii be arranged");
		sb.append("/n Lighting, Cleanliness, Guest's Reception will be arranged");
		return sb.toString();
	}

}
