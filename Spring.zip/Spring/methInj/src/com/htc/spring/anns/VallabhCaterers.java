package com.htc.spring.anns;

import static com.htc.spring.anns.CateringCategory.LOW_BUDGET;
import static com.htc.spring.anns.CateringCategory.HIGH_BUDGET;
import static com.htc.spring.anns.CateringCategory.MEDIUM_BUDGET;


public class VallabhCaterers implements Catering {

	@Override
	public String arrangeFoodAsPerPlate(CateringCategory category, int noOfPeople) {
		double plateRate = 0.0;
		if(category == LOW_BUDGET) {
			if(noOfPeople<50) {
				plateRate = 65.5;
			}
			else {
				plateRate = 63.5;
			}
		}
		else if(category == MEDIUM_BUDGET) {
			if(noOfPeople<50) {
				plateRate = 105.5;
			}
			else {
				plateRate = 101.5;
			}
		} 
		else if(category == HIGH_BUDGET) {
			if(noOfPeople<50) {
				plateRate = 155.5;
			}
			else {
				plateRate = 146.5;
			}
		} 
		return "In this category " + category + ", Plate Rate for " + noOfPeople + " members is::" + plateRate;
		
	}

}
