package com.htc.spring.anns;

public interface Catering {
   public String arrangeFoodAsPerPlate(CateringCategory category, int noOfPeople);
}
