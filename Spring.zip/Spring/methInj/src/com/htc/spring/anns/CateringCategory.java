package com.htc.spring.anns;

public enum CateringCategory {
      LOW_BUDGET, MEDIUM_BUDGET, HIGH_BUDGET;
}
