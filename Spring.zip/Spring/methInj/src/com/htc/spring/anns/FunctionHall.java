package com.htc.spring.anns;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FunctionHall implements Serializable {
  
	Catering caterer;
	
	@Autowired
	Decorators decorators;
	
	@Autowired
	public void setCaterers(Catering caterer) {
		this.caterer = caterer;
	}
	
	public void arrangeFunction(CateringCategory category, int peopleCount) {
		String res = decorators.arrangeFunctionInfra();
		System.out.println(res);
		res = this.caterer.arrangeFoodAsPerPlate(category, peopleCount);
		System.out.println(res);
	}
		
	
    
}
