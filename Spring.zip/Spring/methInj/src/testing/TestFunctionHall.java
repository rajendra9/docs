package testing;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.htc.spring.anns.Catering;
import com.htc.spring.anns.CateringCategory;
import com.htc.spring.anns.FunctionHall;
import com.htc.spring.anns.VallabhCaterers;

@Configuration
@ComponentScan("com.htc.spring.anns")
public class TestFunctionHall {

	
    @Bean
    public Catering getCaterer() {
    	return new VallabhCaterers();
    }
    
	public static void main(String[] args) {
	  ApplicationContext ctx = 
			      new AnnotationConfigApplicationContext(TestFunctionHall.class);
	  
	  
	  FunctionHall functionHall = (FunctionHall)ctx.getBean(FunctionHall.class);
      functionHall.arrangeFunction(CateringCategory.MEDIUM_BUDGET, 220);
      
	}

}
