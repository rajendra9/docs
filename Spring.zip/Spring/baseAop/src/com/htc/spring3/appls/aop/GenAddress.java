package com.htc.spring3.appls.aop;

public class GenAddress {

  public String address(String person) {
    return "Hi! "+person;
  }
  
}
