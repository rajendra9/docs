
package com.htc.spring3.appls.aop;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class AddressAdvice implements MethodInterceptor {

  @Override
  public Object invoke(MethodInvocation inv) throws Throwable {
   Object retObj =  inv.proceed();
   String ret = (String)retObj;
   String arg = (String)inv.getArguments()[0];
   int index = ret.indexOf(arg);
   StringBuilder sb = new StringBuilder(ret);
   sb.insert(index,"Sree ");
   sb.append(",have a  Good Day");
   return sb.toString();
  }

}
