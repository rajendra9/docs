package com.htc.spring3.appls.aop;

import org.springframework.aop.framework.ProxyFactory;


public class TestAddressAdvice {
 
  public static void main(String[] args) {
  
   try {
    
    ProxyFactory factory = new ProxyFactory();
    GenAddress genObj = 
                        new GenAddress();
    System.out.println("Before:"+genObj.address(" Venkat Rao"));
    factory.addAdvice(new AddressAdvice());
    factory.setTarget(genObj);
    GenAddress target = 
      (GenAddress)factory.getProxy();
   
    System.out.println("After:"+target.address(" Venkat Rao"));
    }
    catch(Exception e) {
     System.out.println(e);
    }   
  }

}