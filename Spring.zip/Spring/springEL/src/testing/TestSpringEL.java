package testing;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.htc.spring.PersonTO;


@Configuration
@ComponentScan("com.htc.spring")
public class TestSpringEL {

    public static void main(String[] args) {
      ApplicationContext  ctx =
              new AnnotationConfigApplicationContext(TestSpringEL.class);
      PersonTO person = (PersonTO)ctx.getBean("person");
      System.out.println(person);
     
    }
}
