package com.htc.spring;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@SuppressWarnings("serial")
public class PeopleSource implements java.io.Serializable{
    
    
    Map<String, Long> cityInfo;
    
    {
       cityInfo = new HashMap<>();
       cityInfo.put("hyderabad",10300000L);
       cityInfo.put("chennai",10150000L);
       cityInfo.put("bengaluru",15400000L);
       cityInfo.put("mumbai",22430000L);       
       cityInfo.put("delhi",19400000L);
       cityInfo.put("kolkota",13200000L);
    }

    public long getPopulation(String city) {
    	long ret = 0L;
    	if(cityInfo.containsKey(city)) {
    		ret = cityInfo.get(city);
    	}
    	return ret;
    }
    
}