package com.htc.spring;

import java.io.Serializable;

@SuppressWarnings("serial")
public class WorkingCity implements Serializable {

    private   String  name;
    private   String  state;
    private   String  country;        	
    private   long  population;
	
    public WorkingCity() {
    } 

    public WorkingCity(String name, 
                       String state, 
                       String country, 
                       long population) {
      super();
      this.name = name;
      this.state = state;
      this.country = country;
      this.population = population;
    }
    
    public String getName() {
      return name;
    }

    public void setName(String name) {
      this.name = name;
    }

    public String getState() {
      return state;
    }

    public void setState(String state) {
      this.state = state;
    }

    public String getCountry() {
      return country;
    }

    public void setCountry(String country) {
      this.country = country;
    }

    public long getPopulation() {
      return population;
    }

    public void setPopulation(long population) {
      this.population = population;
    }

    @Override
    public String toString() {
      return "WorkingCity [name=" + name + ", state=" + state + 
             "\n,country=" + country + ", population=" + 
             population + "]";
    }
	
}