package com.htc.spring;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@SuppressWarnings("serial")
@Component("people")
public class People implements Serializable {
   
   
   private String area;
   
   
   private long pincode;
   private String city;
   private String info;
   
   public String getArea() {
	  return area;
   }
   
   @Required
   @Value("Dilsukhnagar")
   public void setArea(String area) {
	  this.area = area;
   }

   public long getPincode() {
	  return pincode;
   }
   
   @Required
   @Value("500027")   
   public void setPincode(long pincode) {
	  this.pincode = pincode;
   }

   public String getCity() {
	   return city;
   }

   @Value("hyderabad")
   public void setCity(String city) {
	    this.city = city;
   }
   
   @PostConstruct
   public void init() {
	   System.out.println("initializing people");
       this.info = "Current Population is:"+new PeopleSource().getPopulation(this.city);
   }
   
   @PreDestroy
   public void destroy() {
	   System.out.println("destroying people object");
       this.info = "NA";
   }

   public String getInfo() {
	  return info;
   }

   public void setInfo(String info) {
    	this.info = info;
   }  
   
}
