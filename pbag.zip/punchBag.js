new Vue({
    el: '#vue-punchbag-app',
    data:{
        name:'',
        age: 0
    },
    methods:{
       
    }
})