Ext.application({
  name: 'ST',
  appFolder:'app',
  controllers: [
   'ProdItems'
  ],
  launch: function() {
   Ext.create('Ext.container.Viewport',{
    layout: 'fit',
    margin: '10 150 15 150',
    maxWidth:560,
    maxHeight:360,
    items:[
      {
       xtype: 'panel',
       title: 'ProdItems',
       html:'<h1>list of storeItems will come here</h1>'
    }
   ]
  });
 }

});