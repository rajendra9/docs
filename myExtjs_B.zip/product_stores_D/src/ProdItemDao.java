package com.htc.extjs.util;

import java.util.List;
import com.htc.extjs.domain.ProdItem;

public interface ProdItemDao extends java.io.Serializable {
    
  public List<ProdItem> getProdItems();
  
  public boolean saveProdItem(ProdItem item);
  
  public boolean updateProdItem(ProdItem item);
  
  public boolean removeProdItem(int prodItemId);
  
  public ProdItem searchProdItem(int prodItemId);
  
  
}
