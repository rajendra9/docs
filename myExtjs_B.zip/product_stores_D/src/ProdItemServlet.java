package com.htc.extjs.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import com.htc.extjs.domain.ProdItem;
import com.htc.extjs.util.ProdItemDao;
import com.htc.extjs.util.ProdItemDaoImpl;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import flexjson.transformer.DateTransformer;
import flexjson.JSONSerializer;

public class ProdItemServlet extends HttpServlet {

   ProdItemDao dao;  
   
   public void init() {
     System.out.println("KKKKKK");   
     dao = new ProdItemDaoImpl();
   } 
 
   public void destroy() {
     super.destroy();
     dao = null;
   }
   
   protected void doGet(HttpServletRequest request,
                        HttpServletResponse response) 
      throws ServletException, IOException {
      process(request, response);
   }
   protected void doPost(HttpServletRequest request,
                         HttpServletResponse response) 
       throws ServletException, IOException {
       process(request, response);	
   }

   private String addSuccess(StringBuffer content,boolean flag){
       int index = content.indexOf("{");
       String incl = "\"success\":"+flag+",";
       content.insert(index+1, incl);
       return content.toString();
   }
   private void process(HttpServletRequest request,
                        HttpServletResponse response) 
        throws ServletException, IOException {
     PrintWriter out = response.getWriter();
     JSONSerializer serializer = new JSONSerializer();
     //response.setContentType("application/json");
     String action = request.getParameter("act");
     if(action.equalsIgnoreCase("list")){
         System.out.println("listing"); 
         listResponse(out, request, serializer, action);
     }
     else if(action.equalsIgnoreCase("edit")){
        System.out.println("editing");  
        editResponse(out, request, serializer, action);
     }  
     else if(action.equalsIgnoreCase("add")){
         System.out.println("adding");
         addResponse(out, request, serializer, action);
     }
     else if(action.equalsIgnoreCase("delete")){
         deleteResponse(out, request, serializer, action);
     }  
  
   }    
   private void listResponse(PrintWriter out, 
                             HttpServletRequest request,
                             JSONSerializer serializer,
                             String action)
           throws IOException{
      List<ProdItem> list = dao.getProdItems();
      serializer.rootName("prodItems");
      DateTransformer transformer = new DateTransformer("yyyy-MM-dd");
      serializer = serializer.transform(transformer,java.util.Date.class); 
      String data = serializer.exclude("*.class").serialize(list);
      StringBuffer content = new StringBuffer(data);
      String toBeSent = this.addSuccess(content, true);
      out.println(toBeSent);
      out.flush();
   }
   private void editResponse(PrintWriter out, 
                             HttpServletRequest request,
                             JSONSerializer serializer,
                             String action)
                             throws IOException{
      Date pDate = new Date(); 
      String idStr = request.getParameter("id");
      String name = request.getParameter("name");
      String dateStr = request.getParameter("procDate").trim();
      System.out.println("...."+dateStr);
      String costStr = request.getParameter("cost");
      String qtyStr = request.getParameter("qty");      
      SimpleDateFormat sdf = 
          new SimpleDateFormat("yyyy/MM/dd");
      try {
        pDate = sdf.parse(dateStr);  
      }catch(ParseException pe){
          pe.printStackTrace();
      }
      System.out.println("...."+pDate);
      int id = Integer.parseInt(idStr);
      double cost = Double.parseDouble(costStr);
      int qty = Integer.parseInt(qtyStr);
      ProdItem forUpdate = 
              new ProdItem(id,name,pDate,cost,qty);
      System.out.println("...."+forUpdate);
               
      boolean boo = dao.updateProdItem(forUpdate);
      if(boo) {
       System.out.println("######");
      
       List<ProdItem> list = dao.getProdItems();
       serializer.rootName("prodItems");
       DateTransformer transformer = new DateTransformer("yyyy-MM-dd");
       serializer = serializer.transform(transformer,java.util.Date.class); 
       String data = serializer.exclude("*.class").serialize(list);
       StringBuffer content = new StringBuffer(data);
       String toBeSent = this.addSuccess(content, true);
       
       out.println(toBeSent);
       out.flush();
      } 
      else {
       String fail  =
        "\"success\":false,\"msg\":\""+action+" not successful\"";  
       out.println(fail);
       out.flush();         
      }
   }

   private void addResponse(PrintWriter out, 
                            HttpServletRequest request,
                            JSONSerializer serializer,
                            String action)
           throws IOException{
     Date pDate = new Date(); 
     String idStr = request.getParameter("id");
     String name = request.getParameter("name");
     String dateStr = request.getParameter("procDate").trim();
     System.out.println("..."+dateStr);      

     String costStr = request.getParameter("cost");
     String qtyStr = request.getParameter("qty");      
     SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
     try {
       pDate = sdf.parse(dateStr);  
     }catch(ParseException pe){
        pe.printStackTrace();
     }
     int id = Integer.parseInt(idStr);
     double cost = Double.parseDouble(costStr);
     int qty = Integer.parseInt(qtyStr);

     ProdItem forAdd = 
      new ProdItem(id,name,pDate,cost,qty);
     
     boolean boo = dao.saveProdItem(forAdd);
     if(boo) {
       System.out.println("@@@@@"+forAdd);
       List<ProdItem> list = dao.getProdItems();
       serializer.rootName("prodItems");
       DateTransformer transformer = new DateTransformer("yyyy-MM-dd");
       serializer = serializer.transform(transformer,java.util.Date.class); 
       String data = serializer.exclude("*.class").serialize(list);
       StringBuffer content = new StringBuffer(data);
       String toBeSent = this.addSuccess(content, true);
       out.println(toBeSent);
       out.flush();
     }
     else {
        System.out.println("JJJJJ");
         String fail  =
           "\"success\":false,\"msg\":\""+action+" not successful\"";  
         out.println(fail);
         out.flush();        
        }
    }
    private void deleteResponse(PrintWriter out, 
                                HttpServletRequest request,
                               JSONSerializer serializer,
                               String action)
           throws IOException{
     String idStr = request.getParameter("id");
     int id = Integer.parseInt(idStr);
     boolean boo = dao.removeProdItem(id);
     if(boo) {
       List<ProdItem> list = dao.getProdItems();
       serializer.rootName("prodItems");
       DateTransformer transformer = new DateTransformer("yyyy-MM-dd");
       serializer = serializer.transform(transformer,java.util.Date.class); 
       String data = serializer.exclude("*.class").serialize(list);
       StringBuffer content = new StringBuffer(data);
       String toBeSent = this.addSuccess(content, true);
       out.println(toBeSent);
       out.flush();
     }
     else {
      String fail  =
        "\"success\":false,\"msg\":\""+action+" not successful\"";  
      out.println(fail);
      out.flush();     
     }
    }


}
