package com.htc.extjs.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="PRODITEMS")
public class ProdItem implements Serializable {
     
    private  int     prodItemId;
    private  String  prodItemName;
    private  Date    procDate;
    private  double  cost;
    private  int     qty;
    
    public ProdItem() {
       
    }

    public ProdItem(int prodItemId, 
                    String prodItemName, 
                    Date procDate,
                    double cost,
                    int qty) {
        super();
        this.prodItemId = prodItemId;
        this.prodItemName = prodItemName;
        this.procDate = procDate;
        this.cost = cost;
        this.qty = qty;
    }

    public void setProdItemId(int prodItemId) {
        this.prodItemId = prodItemId;
    }

    
    public void setProdItemName(String prodItemName) {
        this.prodItemName = prodItemName;
    }

    public void setProcDate(Date procDate) {
        this.procDate = procDate;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + prodItemId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ProdItem other = (ProdItem) obj;
        if (prodItemId != other.prodItemId)
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "ProdItem [prodItemId=" + prodItemId + ", prodItemName="
                + prodItemName + ", procDate=" + procDate + ", cost=" + cost
                + ", qty=" + qty + "]";
    }
    
    @Id
    @Column(name="PROD_ITEM_ID")
    public int getProdItemId() {
        return prodItemId;
    }
    
    @Column(name="PROD_ITEM_NAME")
    public String getProdItemName() {
        return prodItemName;
    }

    @Temporal(TemporalType.DATE)
    @Column(name="PROCURED_DATE")
    public Date getProcDate() {
        return procDate;
    }
    
    @Column
    public double getCost() {
        return cost;
    }

    @Column
    public int getQty() {
        return qty;
    }   
    

}
