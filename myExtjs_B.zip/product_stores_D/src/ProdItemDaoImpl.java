package com.htc.extjs.util;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.htc.extjs.domain.ProdItem;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Date;


public class ProdItemDaoImpl implements ProdItemDao {
 
    EntityManager em;
    EntityTransaction trans;
	
    public ProdItemDaoImpl() {
     EntityManagerFactory factory = 
  	   Persistence.createEntityManagerFactory("myDB");
     em = factory.createEntityManager();
    }

    @Override
    public List<ProdItem> getProdItems() {
      List<ProdItem> ret = new ArrayList<ProdItem>();
      String sql = "select pt from ProdItem pt";
      trans = em.getTransaction();
      trans.begin();
      try {
      TypedQuery<ProdItem> query =
              em.createQuery(sql,com.htc.extjs.domain.ProdItem.class);
      
      ret = query.getResultList();
      trans.commit();
      }catch(Exception ex){
        trans.rollback();
        ex.printStackTrace();
      }
      return ret;
    }

    @Override
    public boolean saveProdItem(ProdItem item) {
       boolean ret = false;
       trans = em.getTransaction();
       trans.begin();
       try {
         em.persist(item);       
         ret = true;
         trans.commit();
       }catch(Exception ex){
         trans.rollback();
         ex.printStackTrace();
       }
       return ret;
    }

    @Override
    public boolean updateProdItem(ProdItem item) {
      System.out.println("%%%"+item);
      boolean ret = false;
      trans = em.getTransaction();
      trans.begin();
      try {
        em.merge(item);       
        ret = true;
        trans.commit();
      }catch(Exception ex){
        trans.rollback();
        ex.printStackTrace();
      }
      return ret;
    }

    @Override
    public boolean removeProdItem(int prodItemId) {
      boolean ret = false;
      trans = em.getTransaction();
      trans.begin();
      try {
       ProdItem del = 
             em.getReference(com.htc.extjs.domain.ProdItem.class,
                             new Integer(prodItemId));       
       if(del != null){
        em.remove(del);
        ret = true;
       } 
       trans.commit();
      }catch(Exception ex){
        trans.rollback(); 
        ex.printStackTrace();
      }
      return ret;
    }

    @Override
    public ProdItem searchProdItem(int prodItemId) {
      ProdItem ret = new ProdItem();
      trans = em.getTransaction();
      trans.begin();
      try {
       ret = 
          em.getReference(com.htc.extjs.domain.ProdItem.class,
                          new Integer(prodItemId));       
       trans.commit();      
      }catch(Exception ex){
        trans.rollback();  
        ex.printStackTrace();
      }
      return ret;
    }  
    
}