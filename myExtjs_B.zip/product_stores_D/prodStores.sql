drop table proditems;

create table proditems(prod_item_id number primary key,
prod_item_name varchar2(20),procured_date date,cost number(8,2),qty number);


insert into proditems values(120,'Dell Computer','12-may-2012',43230.5,3);
 
insert into proditems values(130,'Compaq Computer','15-may-2012',48540.5,2);
 
insert into proditems values(140,'HP Computer','16-may-2012',45370.5,6);
 
insert into proditems values(150,'Mac Computer','16-may-2012',49522.5,3);
 
insert into proditems values(160,'LG Computer','19-may-2012',39120.5,6);
 
insert into proditems values(170,'Samsung Computer','21-may-2012',34870.5,3);

commit; 