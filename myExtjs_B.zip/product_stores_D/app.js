Ext.application({
  name: 'ST',
  appFolder:'app',
  controllers: [
   'ProdItems'
  ],
  launch: function() {
   Ext.create('Ext.container.Viewport',{
    layout: 'fit',
    margin: '10 150 15 150',
    maxWidth:560,
    maxHeight:360,
    items:[
      {
       xtype: 'prodItemsList',
       title: '<center>ProdItems</center>',       
    }
   ]
  });
 }

});