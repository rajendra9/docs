Ext.define('ST.view.prodItem.List', {
   extend: 'Ext.grid.Panel',
   alias: 'widget.prodItemsList',
   title: '<h1 align="center">All StoreItems</h1>',
   autoScroll: true,
   autoHeight: true,
   autoWidth: true,
   trackMouseOver: true,
   initComponent: function() {
      this.store = 'ProdItems',
      this.columns = [
       {id: 'prodItemId' ,header: 'ProdItem-Id', width:80, sortable:true,dataIndex:'prodItemId'},
       {header: 'ProdItem-Name', width: 120, dataIndex:'prodItemName'},
       {header: 'Procured-Date', width: 200, dataIndex:'procDate',xtype: 'datecolumn',format: 'Y/m/d',
        field:{
            xtype: 'datefield',
            format: 'Y/m/d'
        }
       },
       {header: 'Cost', width: 80, dataIndex:'cost'},
       {header: 'Qty', width: 80, dataIndex:'qty'}
      ];
      this.callParent(arguments);
     }
    }); 
        
              