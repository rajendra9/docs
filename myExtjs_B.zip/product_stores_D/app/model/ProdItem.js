Ext.define('ST.model.ProdItem',{
  extend: 'Ext.data.Model',
  fields: [
    {name:'prodItemId',type: 'int'},
    {name:'prodItemName',type: 'string'},
    {name:'procDate',type: 'date',format: 'Y/m/d'},
    {name:'cost',type: 'float'},
    {name:'qty',type: 'int'}
  ]
 });
        
