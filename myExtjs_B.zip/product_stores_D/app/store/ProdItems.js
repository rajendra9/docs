Ext.define('ST.store.ProdItems', {
  extend: 'Ext.data.Store',
  model: 'ST.model.ProdItem',
  autoLoad: true,
  proxy:{
    type:'ajax',
    url: 'itemsComp?act=list',
    reader: {
      type: 'json',
      root: 'prodItems',
      successProperty: 'success'
    }
   }
});  
    