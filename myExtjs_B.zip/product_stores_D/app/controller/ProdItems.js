
Ext.define('ST.controller.ProdItems', {
  extend: 'Ext.app.Controller',
  stores: ['ProdItems'],
  models: ['ProdItem'],
  views: [
      'prodItem.List'
  ],  

  init: function() {
     this.control({
       'viewport>panel':{
          render: this.onPanelRendered
        }
      });
    }, 
    onPanelRendered: function() {
         console.log('The Panel has rendered');
    }
});
