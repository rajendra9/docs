const comp1 = Vue.component('greeting',{
    template:'<h3>Hello {{name}} please listen, I am a Reusable Component<br/><br/><button v-on:click="changeName">change Name</button></h3>',
    data: function() {
        return   {
            name: 'Prasad'
        }     
    },
    methods:{
        changeName: function(){
            this.name = 'Sarveswar'
        }
    }
});
const comp2= Vue.component('wishes',{
    template:'<h3>Hello accept my {{wish}} <br/><br/><button v-on:click="changeWish">change Wish</button></h3>',
    data: function() {
        return   {
            wish: 'Many Happy Returns of your Birthday'
        }     
    },
    methods:{
        changeWish: function(){
            this.wish = 'Happy Bon Voyage'
        }
    }
});


new Vue({
    el: '#vue-multi-comp',
    data:{       
    },
    methods:{       
    },
    computed:{      
    }
});
