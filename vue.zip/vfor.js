new Vue({
    el: '#vfor-app',
    data:{
       emps: [ 
        {empId: 230, empName: 'Subba Rao', job: 'Manager', location: 'HTC Global'},
        {empId: 435, empName: 'Madivanan', job: 'Asst_Manager', location: 'HTC Caretech'},
        {empId: 532, empName: 'Vinay Kumar', job: 'Dy_Manager', location: 'HTC Ciber'}
        ]
    },
    methods:{
       
    }
})