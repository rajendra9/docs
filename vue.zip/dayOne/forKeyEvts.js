new Vue({
    el: '#vue-key-evt-app',
    data:{
        name:'',
        age: 0
    },
    methods:{
       storeName: function(){
          console.log('you entered name text field');
          
       },
       storeAge: function(){
        console.log('you entered age text field'+event);
         
       }
    }
})