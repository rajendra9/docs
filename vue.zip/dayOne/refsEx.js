
new Vue({
    el: '#vue-refs-app',
    data:{  
        output:'your favourite food',
        content:'hai'     
    },
    methods:{ 
        readRefs: function(){
            console.log(this.$refs.input.value);
            this.output = this.$refs.input.value;
            this.content = this.$refs.divContent.innerHTML;
        }      
    },
    computed:{      
    }
});
