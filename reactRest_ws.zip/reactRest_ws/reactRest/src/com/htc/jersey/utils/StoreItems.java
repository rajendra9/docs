package com.htc.jersey.utils;


import java.util.concurrent.ConcurrentHashMap;

import javax.json.Json;
import javax.json.JsonObjectBuilder;

public class StoreItems extends ConcurrentHashMap<Integer,ItemDTO> {
  
  public StoreItems() {
   ItemDTO dto = new ItemDTO(100,"MicroOven",13500.0);
   this.put(dto.getItemId(),dto);
   
   dto = new ItemDTO(200,"Dressing Table",17800.5);
   this.put(dto.getItemId(),dto);
   
   dto = new ItemDTO(300,"WashingMachine",28500.5);
   this.put(dto.getItemId(),dto);
   
   dto = new ItemDTO(400, "TV", 34500.5);
   this.put(dto.getItemId(),dto);
   
   dto = new ItemDTO(500, "SmartPhone",12000.5);
   this.put(dto.getItemId(),dto);
   
  }

  
  public ItemDTO getItem(int id) {
   ItemDTO ret = new ItemDTO();
   if(this.containsKey(id)) {
    ret = this.get(id);   
   }
   return ret;
  }  

  public boolean addItem(String idStr , String name, String costStr) {
	 int id = Integer.parseInt(idStr);
	 double cost = Double.parseDouble(costStr);
	 
	 ItemDTO dto = new ItemDTO(id, name, cost);
	 this.put(dto.getItemId(),dto);
	 return true;
  }
  
  
  public String getItemJson(int id) {
      ItemDTO item = new ItemDTO();
      if(this.containsKey(id)) {
       item = this.get(id);   
      }
      JsonObjectBuilder objBuilder = 
              Json.createObjectBuilder();
      objBuilder.add("itemId", item.getItemId());
      objBuilder.add("itemName", item.getItemName());
      objBuilder.add("itemCost", item.getItemCost());
      return objBuilder.build().toString();
     }  

}