package com.htc.jersey;

import static javax.json.stream.JsonParser.Event.VALUE_NUMBER;
import static javax.json.stream.JsonParser.Event.VALUE_STRING;

import java.io.InputStream;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.htc.jersey.utils.ReactPersonDao;
import com.htc.jersey.utils.ReactPersonService;


// The Java class will be hosted at the URI path "/items"
@Path("/react")
public class ReactJSResource {
    ReactPersonDao persDao = new ReactPersonService();
    @GET    
    public Response wish(){
       Response.ResponseBuilder builder = Response.status(200);    
       builder = builder.entity("{\"msg\":\"Welcome To Angular Resource\"}");
               // .header("Access-Control-Allow-Origin", "*");
       return builder.build();
    }
    
    @GET
    @Path("/all")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll(){
        System.out.println("contacted");
        Response.ResponseBuilder builder = Response.status(200);
        JsonArray arr = this.persDao.getJsonPersons(); 
        builder = builder.entity(arr.toString());                 
        return builder.build();
     }
    @POST
    @Path("/add")
    @Produces(MediaType.APPLICATION_JSON)
    public Response addPerson(InputStream in){
        System.out.println("contacted for post");
        String idStr = "", pName = "", job = "", dobStr = "";
        double income = 0.0;
        JsonParser parser = Json.createParser(in);
        StringBuffer sb = new StringBuffer();
        while(parser.hasNext()){
     	 Event  evt = parser.next();
          if(evt==VALUE_STRING) {
      	  sb.append(parser.getString()+"|");	
      	 }
          else if(evt==VALUE_NUMBER) {
         	  sb.append("" + parser.getBigDecimal()+"|");	
          }
        }
        System.out.println(sb.toString());
        String[] tokens = sb.toString().split("[|]");
        idStr = tokens[0].trim();
        pName = tokens[1].trim();
        dobStr = tokens[2].trim();
        job = tokens[3].trim();
        income = Double.parseDouble(tokens[4]);
        
        JsonObject obj = this.persDao.savePerson(idStr, pName, dobStr, job, income); 
        System.out.println(obj.toString());
        Response.ResponseBuilder builder = Response.status(200);
        builder = builder.entity(obj.toString());                 
        return builder.build();
     }

    @PUT
    @Path("/update")
    @Produces(MediaType.APPLICATION_JSON)
    public Response updatePerson(InputStream in){
        System.out.println("contacted for update");
        String idStr = "", newJob = "";
        double newIncome = 0.0;
        JsonParser parser = Json.createParser(in);
        StringBuffer sb = new StringBuffer();
        while(parser.hasNext()){
     	 Event  evt = parser.next();
          if(evt==VALUE_STRING) {
      	  sb.append(parser.getString()+"|");	
      	 }
         else if(evt==VALUE_NUMBER) {
          sb.append("" + parser.getBigDecimal()+"|");	
         }
        }
        System.out.println(sb.toString());
        String[] tokens = sb.toString().split("[|]");
        newJob = tokens[0].trim();
        newIncome = Double.parseDouble(tokens[1]);
        idStr = tokens[2];
        JsonObject obj = this.persDao.updatePerson(idStr, newJob, newIncome); 
        System.out.println(obj.toString());
        Response.ResponseBuilder builder = Response.status(200);
        builder = builder.entity(obj.toString());                 
        return builder.build();
     }
    
    @DELETE
    @Path("/delete/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deletePerson(@PathParam("id")String id){
        System.out.println("contacted for delete");
        JsonObject obj = this.persDao.removePerson(id); 
        System.out.println(obj.toString());
        Response.ResponseBuilder builder = Response.status(200);
        builder = builder.entity(obj.toString());                 
        return builder.build();
     }
    
}