
Ext.define('ST.controller.ProdItems', {
  extend: 'Ext.app.Controller',
  init: function() {
   console.log('Initiates production items ,'+
      ' this will occur even before application launch occurs');
   }
});
