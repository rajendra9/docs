use samp;

go


drop table if exists dbo.ciber_orders;

create table dbo.ciber_orders(order_id varchar(15) primary key,
order_date  date, items varchar(35),
customer varchar(30),cost numeric(10,2));

insert into dbo.ciber_orders values ('c1000', '2018-09-21', 'pin2|bush3|nut30', 'M/s Suguna Motors', 1230.5);
insert into dbo.ciber_orders values ('c1100', '2018-08-13', 'piston3|bolt3|nut20', 'M/s Varadan Auto', 13430.5);
insert into dbo.ciber_orders values ('c1200', '2018-11-11', 'ClutchPlates|Clutch bush','M/s Dandapani AutoParts', 21240.5);
insert into dbo.ciber_orders values ('c1300', '2018-06-21', 'Gasket|Engine Bush','M/s SyedAli Auto Motors', 6530.5);
insert into dbo.ciber_orders values ('c1400', '2018-10-18', 'Valves|bush10','M/s KalaiSelvan Motors', 7630.5);
