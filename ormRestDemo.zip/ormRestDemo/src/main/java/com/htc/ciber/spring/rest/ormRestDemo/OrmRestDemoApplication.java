package com.htc.ciber.spring.rest.ormRestDemo;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateExceptionTranslator;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

import com.htc.ciber.spring.rest.utils.OrdersOrmDao;
import com.htc.ciber.spring.rest.utils.OrdersOrmService;


@SpringBootApplication
public class OrmRestDemoApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(OrmRestDemoApplication.class, args);		
	}

}

