package com.htc.ciber.spring.orm.domain;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement
public class OrderTo implements Serializable {

  private  String      orderId;
  private  String      orderDate;
  private  String      items;
  private  double      cost;
  private  String      customer;

 
  public OrderTo(String orderId) {
     super();
     this.orderId = orderId;  
  }

  public OrderTo(){}

  public double getCost() {
     return cost;
  }

  public void setCost(double cost) {
     this.cost = cost;
  }
 
  public String getOrderId() {
    return orderId;
  }

  public void setOrderId(String orderId) {
      this.orderId = orderId;
  }

  @Override
  public String toString() {
	return "OrderTo [orderId=" + orderId + ", orderDate=" + orderDate + ", items=" + items + ", cost=" + cost
	 		+ ", customer=" + customer + "]";
  }

  public String getItems() {
	 return items;
  }

  public void setItems(String items) {
	 this.items = items;
  }

  public String getOrderDate() {
	  return orderDate;
  }

  public void setOrderDate(String orderDate) {
	 this.orderDate = orderDate;
  } 

  public String getCustomer() {
	 return customer;
  }

  public void setCustomer(String customer) {
	this.customer = customer;
  }

  public OrderTo(String orderId, String orderDate, String items, double cost, String customer) {
	 super();
	 this.orderId = orderId;
	 this.orderDate = orderDate;
	 this.items = items;
	 this.cost = cost;
	 this.customer = customer;
  }    

}