package com.htc.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.htc.web.domain.HtcEmployee;

@WebServlet("/deptEmpListTest")
@SuppressWarnings("serial")
public class EmpListenerDeptServlet extends HttpServlet {

  public void doGet(HttpServletRequest req,
                    HttpServletResponse res)
   throws IOException, ServletException  {
	res.setContentType("text/html");
	PrintWriter out = res.getWriter();
	ServletContext stx = this.getServletContext();
    List<HtcEmployee> emps = 
       (List<HtcEmployee>)stx.getAttribute("emps");
    String dept = req.getParameter("dept");
    emps = emps.stream().filter(e -> e.getDeptName().equalsIgnoreCase(dept)).collect(Collectors.toList()); 
    out.println("<html<head><style type='text/css'>td{ margin: 12px; padding:12px;}</style></head><body>");
    out.println("<div align='center'><h3 style='color:blue;'>"+dept.toUpperCase()+" Employees</h3>");
    out.println("<table>");
    emps.forEach(e -> out.println(e.toString()));
    out.println("</table></div><body></html>");    
    out.close(); 
  }

}