package com.htc.listeners;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.sql.DataSource;

import com.htc.web.domain.HtcEmployee;

@WebListener
public class EmployeeContextListener implements ServletContextListener {

	@Resource(name="jdbc/myPostgres", type=javax.sql.DataSource.class)
	DataSource ds;
	
	
    static final String SQL_STR = 
	"select  emp_id, empName, job, hiredate, salary, deptName, city from htc_emps";
	
    private List<HtcEmployee> populate() {
    	List<HtcEmployee> ret = new ArrayList<>();
        HtcEmployee  emp = null;
    	java.sql.Date dt = null;
    	java.time.LocalDate locDate = null;
    	Connection conn = null;
    	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
        try {
	       conn = ds.getConnection();	 
	       PreparedStatement pstmt = conn.prepareStatement(SQL_STR);
	       ResultSet rs = pstmt.executeQuery();
	       BigDecimal salDecim = null;
	       while(rs.next()){
	    	 emp = new HtcEmployee();  
	         emp.setEmpId(rs.getInt(1));
	         emp.setEmpName(rs.getString(2));
	         emp.setJob(rs.getString(3));
	         dt = rs.getDate(4);
	         locDate = LocalDate.parse(dt.toString().trim(), formatter);
	         emp.setHiredate(locDate);
	         emp.setSalary(rs.getDouble(5));
	         emp.setDeptName(rs.getString(6));
	         emp.setCity(rs.getString(7));
	         ret.add(emp);
	       }
	     }catch(SQLException ex){
	         ex.printStackTrace();
	     }finally{
	        try{
	           if(conn != null) { conn.close(); } 
	        }catch(SQLException sq){}
	     }
         return ret;
	   }

	@Override
	public void contextDestroyed(ServletContextEvent evt) {
		ServletContext stx = evt.getServletContext();
		stx.removeAttribute("emps");
	}

	@Override
	public void contextInitialized(ServletContextEvent evt) {
	   List<HtcEmployee> emps = this.populate();
	   ServletContext stx = evt.getServletContext();
	   stx.setAttribute("emps", emps);
	}
	  
	
}
