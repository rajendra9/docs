package com.htc.web.domain;

import java.io.Serializable;
import java.time.LocalDate;

@SuppressWarnings("serial")
public class HtcEmployee implements Serializable {
	private int empId;
	private String empName;
	private String job;
	private  double salary;
	private LocalDate  hiredate;
   	private String deptName;
	private String city;
	
	public HtcEmployee() {
		super();		
	}

	

	public double getSalary() {
		return salary;
	}



	public void setSalary(double salary) {
		this.salary = salary;
	}



	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public LocalDate getHiredate() {
		return hiredate;
	}

	public void setHiredate(LocalDate hiredate) {
		this.hiredate = hiredate;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + empId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HtcEmployee other = (HtcEmployee) obj;
		if (empId != other.empId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "<tr><td>" + empId + "</td><td>" + empName + "</td><td>" + job + "</td><td>" + hiredate
				+ "</td><td>" + salary + "<td><td>"+ deptName + "</td><td>" + city +"</td></tr>"; 
	}	
	
}
