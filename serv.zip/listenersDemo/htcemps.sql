drop table if exists htc_emps; 

create table htc_emps as 
select employee_id as emp_id, 
first_name||' '||last_name as empName,
job_title as job,hire_date as hiredate,
salary,
department_name as deptName,city from
employees e, departments d, jobs j,locations l
where e.department_id = d.department_id and
e.job_id=j.job_id and d.location_id=l.location_id;

alter table htc_emps add constraint htc_emps_pk primary key(emp_id);