package demojaxb;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Marshaller;

import samp.Products;
import samp.Product;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

import java.util.ListIterator;


public class JaxbDemoTwo {

 public static void main(String[] args)
  throws Exception {
 
  JAXBContext jxb = JAXBContext.newInstance("samp");
  Unmarshaller um = jxb.createUnmarshaller();
  Products prods = 
    (Products)um.unmarshal(new File("products.xml"));
  Product prod = null;
  java.util.List<Product> lt = prods.getProduct();
  ListIterator<Product> iter = lt.listIterator();
  while(iter.hasNext()) {
   prod = iter.next();
   if(prod.getBrand().equalsIgnoreCase("sony")) {
    iter.remove();
   }
  } 
  Marshaller msh = jxb.createMarshaller(); 
  msh.setProperty    (Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.TRUE);
  PrintWriter out = 
   new PrintWriter(new FileWriter("delProducts.xml"));
  msh.marshal(prods,out);
  msh.marshal(prods,System.out);
  out.close();
 }

}