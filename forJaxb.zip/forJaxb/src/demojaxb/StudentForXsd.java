package demojaxb;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlAccessType;
import java.util.List;
import java.util.ArrayList;


@XmlRootElement(name="StudentForXsd" )
@XmlType(name="StudentType",propOrder={"stuId", "stuName", "course","address","subjectsList"})
@XmlAccessorType(value=XmlAccessType.PUBLIC_MEMBER)
public class StudentForXsd {

    private String stuId;
    private String stuName;
    private String course;
    private String college;

    private List<String>  subjectsList;
    
    private Address address;
    
    private String description;
    
    public String getDescription() {
        return description;
    }

    @XmlTransient
    public void setDescription(String description)  {
        this.description = description;
    }

    public StudentForXsd() {
     subjectsList = new ArrayList<String>();
    }

    public StudentForXsd(String stuId,
                         String stuName,
                         String course) {
        super();
        this.stuId = stuId;
        this.stuName = stuName;
        this.course = course;
        subjectsList = new ArrayList<String>();
    }
    
   public List<String>  getSubjectsList() {
     return subjectsList;
   }
   
   @XmlElementWrapper(name="subjects", required=true)
   @XmlElement(name="subject" , nillable=false, required=true)
   public  void setSubjectsList(List<String> newSubjects) {
     subjectsList = newSubjects;
   }

    public String getStuId() {
        return stuId;
    }

    @XmlID
    @XmlElement(required=true)
    public void setStuId(String stuId) {
        this.stuId = stuId;
    }

    public String getStuName() {
        return stuName;
    }
    @XmlElement(required=true,nillable=false)
    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public String getCourse() {
        return course;
    }

    @XmlElement(required=true,nillable=false)
    public void setCourse(String course) {
        this.course = course;
    }  

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + stuId.hashCode();
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final StudentForXsd other = (StudentForXsd) obj;
        if (!stuId.equals(other.stuId))
            return false;
        return true;
    }
    
    public String getCollege() {
        return college;
    }
    
    @XmlAttribute (required=true)
    public void setCollege(String college) {
        this.college = college;
    }

    public Address getAddress() {
        return address;
    }
    
    @XmlElement(name="address", type=Address.class,nillable=false,required=true)  
    public void setAddress(Address address)  {
        this.address = address;
    }
    
    @Override
    public String toString()  {
      return ToStringCreator.toStringInLine(this);  
    } 

}