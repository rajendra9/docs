package demojaxb;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Marshaller;
import dtdex.ObjectFactory;
import dtdex.Dept;
import dtdex.Emp;
import dtdex.Email;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.List;

public class JaxbDTD {
  
 public static void main(String[] args)
  throws Exception {
   
  JAXBContext jbCtx = JAXBContext.newInstance("dtdex");
  Unmarshaller unmarshaller = jbCtx.createUnmarshaller();

  Dept dept = 
   (Dept)unmarshaller.unmarshal(new File("dept.xml"));

  List<Emp> empList = dept.getEmp();
  ObjectFactory of = new ObjectFactory();

  Emp emp = of.createEmp();
  Email email = of.createEmail();
  email.setvalue("sankar@hotmail.com");

  List<Object> emailList = emp.getEmailOrUrl();
  emailList.add(email);
  emp.setId("c106");
  emp.setName("Shankar");

  empList.add(emp);
  Marshaller marshaller = jbCtx.createMarshaller();
  marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
                  Boolean.TRUE);
  PrintWriter out = 
     new PrintWriter(new FileWriter("newDept.xml"));
  marshaller.marshal(dept,out);
  marshaller.marshal(dept,System.out);
 }

} 