package demojaxb;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Marshaller;
import samp.ObjectFactory;
import samp.Products;
import samp.Product;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.math.BigInteger;

public class JaxbDemo {

 public static void main(String[] args)
  throws Exception {
  
  JAXBContext jxb = JAXBContext.newInstance("samp");
  Unmarshaller um = jxb.createUnmarshaller();
  Products prods = (Products)um.unmarshal(new File("products.xml"));
  ObjectFactory obf = new ObjectFactory(); 
 
  Product prod = obf.createProduct();
  prod.setQty(new BigInteger("20"));
  prod.setBrand("LG");
  prod.setName("TV");
  prod.setId(new BigInteger("210"));
    
  java.util.List<Product> lt = prods.getProduct();
  lt.add(prod);
    
  Marshaller msh = jxb.createMarshaller(); 
  msh.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
                Boolean.TRUE);
  PrintWriter out = 
      new PrintWriter(new FileWriter("products.xml"));
  msh.marshal(prods,out);
  msh.marshal(prods,System.out);
 
  out.close();
 }

}