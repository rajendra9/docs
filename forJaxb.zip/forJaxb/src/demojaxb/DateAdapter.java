package demojaxb;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import javax.xml.bind.annotation.adapters.XmlAdapter;


public class DateAdapter extends 
            XmlAdapter<String,java.util.Date> {
    SimpleDateFormat sdf = 
            new SimpleDateFormat("dd-MM-yyyy");
    @Override
    public String marshal(Date date) throws Exception {
        return sdf.format(date);      
    }

    @Override
    public Date unmarshal(String dtStr) throws Exception {
      Date ret = new Date(); 
      try{
         ret = sdf.parse(dtStr);   
      }catch(ParseException pe){
          System.out.println(pe);
      }
      return ret;
    }
    
}

