package demojaxb;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.Marshaller;
import samp.ObjectFactory;
import samp.Products;
import samp.Product;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.math.BigInteger;

public class JaxbCreate {

 public static void main(String[] args)
   throws Exception {
  
  JAXBContext jxb = JAXBContext.newInstance("samp");
   ObjectFactory obf = new ObjectFactory();

  Products prods = obf.createProducts();
  
  Product  prod1 = obf.createProduct();
  prod1.setQty(new BigInteger("20"));
  prod1.setBrand("LG");
  prod1.setName("TV");
  prod1.setId(new BigInteger("210"));   
  
  Product  prod2 = obf.createProduct();
  prod2.setQty(new BigInteger("30"));
  prod2.setBrand("SamsSung");
  prod2.setName("TV");
  prod2.setId(new BigInteger("310"));
  
  java.util.List<Product> lt = prods.getProduct();
  lt.add(prod1);
  lt.add(prod2);
  
  Marshaller msh = jxb.createMarshaller(); 
  msh.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.TRUE);
  PrintWriter out = 
     new PrintWriter(new FileWriter("FreshProducts.xml"));
  msh.marshal(prods,out);
  msh.marshal(prods,System.out);
  out.close();
 }

}