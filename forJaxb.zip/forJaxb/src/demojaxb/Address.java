package demojaxb;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlAccessType;


@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(name="address_ty",
        propOrder={"houseNo","street","area","city","pincode"})
public class Address {
   @Override
    public String toString()   {
      return ToStringCreator.toStringInLine(this);        
    }

   private String houseNo;
   private String street;
   private String area;
   private String city;
   private int pincode;
   
    public Address() {
    }

    public Address(String houseNo,
                   String street,
                   String area,
                   String city,
                   int pincode) {
        super();
        this.houseNo = houseNo;
        this.street = street;
        this.area = area;
        this.city = city;
        this.pincode = pincode;
    }

    public String getHouseNo() {
        return houseNo;
    }

    @XmlElement(type=String.class)
    public void setHouseNo(String houseNo) {
        this.houseNo = houseNo;
    }

    public String getStreet() {
        return street;
    }

    @XmlElement(type=String.class)
    public void setStreet(String street) {
        this.street = street;
    }

    public String getArea() {
        return area;
    }

    @XmlElement(type=String.class)
    public void setArea(String area) {
        this.area = area;
    }

    public String getCity() {
        return city;
    }
     
    @XmlElement(type=String.class)
    public void setCity(String city) {
        this.city = city;
    }

    public int getPincode() {
        return pincode;
    }
    
    @XmlElement(type=Integer.class)
    public void setPincode(int pincode) {
        this.pincode = pincode;
    }

}