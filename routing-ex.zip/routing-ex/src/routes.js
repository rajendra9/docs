import showPosts from './components/showPosts.vue';
import listPosts from './components/listPosts.vue';
import addPost from './components/addPost.vue';

export  default [
    { path:'/', component:showPosts},
    { path:'/list', component: listPosts},
    { path:'/add', component: addPost}
]