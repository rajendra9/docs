import Vue from 'vue'
import App from './App.vue'
import VueResource from 'vue-resource';
import VueRouter from 'vue-router';
import myRoutes from './routes';

import { SSL_OP_DONT_INSERT_EMPTY_FRAGMENTS } from 'constants';

Vue.use(VueResource);
Vue.use(VueRouter);
const myRouter = new VueRouter({
   routes: myRoutes
});

new Vue({
  el: '#app',
  render: h => h(App),
  router: myRouter
})
