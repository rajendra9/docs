<template>
  <div  id="showPosts">
    <h1>All posts</h1>
     <input type="text" v-model="search" placeholder="blog to search" />
      <div v-for="gotPost in filteredGotPosts" v-bind:key="gotPost.id" class="single-post">
      <h3 v-rainbow>{{gotPost.title| toUppercase}}</h3>
      <article>{{gotPost.body | snippet}}</article>
    </div>
  </div>
</template>

<script>
import searchMixin from '../mixins/searchMixin';
export default {
  
  
  data () {
    return {
     gotPosts: [],
     search:'',
    }
  },
  methods:{

  },
  created(){
      this.$http.get('http://jsonplaceholder.typicode.com/posts')
                .then(function(data){                  
                  this.gotPosts = data.body.slice(0,12);
                });
  },
  computed:{
   
  },
  filters:{
    /*'to-uppercase': function(value){
      return value.toUpperCase();
    }*/
    toUppercase(value){
      return value.toUpperCase();
    },
    'snippet': function(value){
        return value.slice(0, 100) + '. . . .';
    }
  },
  directives:{
    'rainbow':{
      bind(el, binding,vnode){
        el.style.color = '#'+Math.random().toString(16).slice(2,8);
      }
    }
  },
  mixins:[searchMixin]

}
</script>

<style>
 #showPosts{
  max-width: 800px;
  margin: 0 auto;
 }
 .single-post{
  padding: 20px;
  margin: 20px 0;
  box-sizing: border-box;
  background: #eee; 
 }

</style>
