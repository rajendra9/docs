package com.spring4.web.ex;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.htc.spring.utils.Certifications;


@Controller
public class CertificateController {    
    	
	@Autowired
	Certifications certifications;
	
	
	@ModelAttribute("certs")
	public String[] getCerts(){
		return certifications.getCertificates();
	}
	
    @RequestMapping(value="/findCharges",method=RequestMethod.POST)
    public String finding(@RequestParam("certi") String certi, Model model ){
           double charges = this.certifications.getFees(certi);
           model.addAttribute("charges","for-" + certi +  " charges are:"+ charges);
    	   return "showCharges";
    }   
        
    @RequestMapping(value="/certi",method=RequestMethod.GET)
    public String certification(){
        return "inCerti";
    }
    
       
    
}
