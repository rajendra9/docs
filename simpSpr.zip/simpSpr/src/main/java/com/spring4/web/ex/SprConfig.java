package com.spring4.web.ex;

import org.springframework.context.annotation.ComponentScan;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

//Marks this class as configuration
@Configuration
//Specifies which package to scan
@ComponentScan({"com.spring4.web.ex","com.htc.spring.utils"})
//Enables Spring's annotations
@EnableWebMvc
public class SprConfig extends WebMvcConfigurerAdapter {

    @Override
    public void configureViewResolvers(ViewResolverRegistry registry) {
        registry.jsp("/WEB-INF/sprviews/",".jsp");
    }
    
    /*@Bean
    public MultipartResolver multipartResolver() throws IOException {
      CommonsMultipartResolver multipartResolver =
                            new CommonsMultipartResolver();   
      multipartResolver.setUploadTempDir(new FileSystemResource("/uploads"));
      multipartResolver.setMaxInMemorySize(0);
      return multipartResolver;
    }*/
    
}
