package myWebRest;
import java.io.Serializable;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.UriInfo;

@Path("/environ")
@SuppressWarnings("serial")
public class EnvironResource implements Serializable {

  @GET
  public String info(@Context UriInfo info,
                     @Context HttpHeaders headers){
      StringBuilder sb = new StringBuilder("Meta Info\r\n");
      sb.append("The service is deployed at");
      sb.append(info.getAbsolutePath());
      sb.append("\r\nThe headers Information is:\r\n");
      sb.append(this.writeHeaders(headers));
      sb.append("\r\n");
      return sb.toString();
  }
  
  private String writeHeaders(HttpHeaders headers){
      StringBuilder sb = new StringBuilder();
      for(String header : headers.getRequestHeaders().keySet()){
          sb.append(header);
          sb.append(":");
          sb.append(headers.getRequestHeader(header));
          sb.append("\r\n");
      }
      return sb.toString();
  }
}
