package myWebRest.utils;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@SuppressWarnings("serial")
public class ItemDTO  implements Serializable {

   private int    itemId;

   private String itemName;

   private double  itemCost;

   public ItemDTO(){}

   public ItemDTO(int id, String name, double cost) {
     this.itemId = id;
     this.itemName = name;
     this.itemCost = cost;
   }

   public int getItemId() {
     return  itemId;
   }
   
   public void setItemId(int id){
    this.itemId = id;
   }

   public String getItemName() {
     return  itemName;
   }
   
   public void setItemName(String name){
    this.itemName = name;
   }

   public double getItemCost() {
     return  itemCost;
   }
   
   public void setItemCost(double cost){
    this.itemCost = cost;
   }

   public String toString(){
    return itemId+":"+itemName+":"+itemCost;
   }

}
       
