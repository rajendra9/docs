package myWebRest.utils;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class StudentDelegate implements Serializable {
    List<StudentTO>  students;
    public StudentDelegate() {
       students = new ArrayList<>();
       students.add(new StudentTO("c100", "Rajesh","MF","Khammam"));
       students.add(new StudentTO("c200", "Venkatesh",".Net","Anantapur"));
       students.add(new StudentTO("c400", "Madhavan","Oracle","KancheePuram"));
       students.add(new StudentTO("c500", "Manimaran","JEE","Erode"));  
    }
    public boolean updateStudentAddress(StudentTO student){
       System.out.println("before:" + students);
       boolean  ret = false;
       for(StudentTO stu : students){
        if(stu.getStuId().equalsIgnoreCase(student.getStuId())){
          System.out.println(stu+" LLLL");  
          stu.setAddress(student.getAddress());      
          ret = true;
        }
       }
       System.out.println("after:" + students);
        return ret;
    }   
    
    public boolean deleteStudent(String id){
      boolean  ret = false;
      Iterator<StudentTO> iter = students.iterator();  
      while(iter.hasNext()){
        StudentTO stu = iter.next();
        if(stu.getStuId().equalsIgnoreCase(id)){
          iter.remove();
          ret = true;
          break;
        }
      }
      System.out.println("after:" + students);
      return ret;
    }
    
    public boolean addStudent(StudentTO student){
       if(!students.contains(student)){
           students.add(student);
           System.out.println("added "+student);
           students.forEach(System.out::println);
           
           return true;
       }
       return  false;
    }   
    
    public StudentTO searchStudent(String id){
        StudentTO search = new StudentTO(id);
        if(students.contains(search)){
            int pos = students.indexOf(search);
            return students.get(pos);
        }
        return  null;
     }
    
    public String getAllStudents() {
    	StringBuffer sb = new StringBuffer("<div align=center>");
    	for(StudentTO s : students) {
    	   sb.append(s.toString()+"<br/>");	
    	}
    	sb.append("</div>");
    	return sb.toString();
    }

}
