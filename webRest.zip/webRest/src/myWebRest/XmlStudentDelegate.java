package myWebRest;

import java.io.Serializable;

import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class XmlStudentDelegate implements Serializable {
    static List<Student>  students;
    
   static {
       students = new ArrayList<>();
       students.add(new Student("c100", "Rajesh","MF","Khammam"));
       students.add(new Student("c200", "Venkatesh",".Net","Anantapur"));
       students.add(new Student("c400", "Madhavan","Oracle","KancheePuram"));
       students.add(new Student("c500", "Manimaran","JEE","Erode"));  
    }
    public List<Student> getStudents() {
        return students;
    }
}
