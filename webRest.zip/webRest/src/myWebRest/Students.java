package myWebRest;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


@XmlRootElement
@XmlType(name="students",propOrder={"students"})
@XmlAccessorType(value=XmlAccessType.PUBLIC_MEMBER)
public class Students  {

   List<Student> students = new ArrayList<>();

   public List<Student> getStudents() {
	  return students;
   }
   @XmlElement(name="student",required=true)
   public void setStudents(List<Student> students) {
	   this.students = students;
   }
   
   
 

}