drop table if exists rsproducts;

create table rsproducts(prod_id integer primary key,
prod_name  varchar(20),
prod_cost  decimal(9,2));

insert into rsproducts values(120,'Piston',324.5);
commit;

select *  from rsproducts;
delete  from rsproducts where prod_id=130;
