import { Component, OnInit } from '@angular/core';
import {Observable} from 'rxjs';
import { HttpClient }  from '@angular/common/http'
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-view-repos',
  templateUrl: './view-repos.component.html',
  styleUrls: ['./view-repos.component.css']
})
export class ViewReposComponent implements OnInit {
 list: Observable<any[]>;
  constructor(private _http: HttpClient) { 
    const path= 'https://api.github.com/search/repositories?q=angular';
    this.list = _http.get<{items:any[]}>(path)
    .pipe(
      map(data => data.items),
    )
  }

  ngOnInit() {
  }

}
