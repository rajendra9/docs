package com.htc.cdi;
import java.util.HashSet;
public class SetDemo  {

 public static void main(String[] args) {
  HashSet<Integer> set = new HashSet<Integer>();
  boolean boo = set.add(new Integer(5));
  System.out.println(boo);
  set.add(new Integer(10));
    
  boo = set.add(new Integer(5));
  System.out.println(boo);
  System.out.println(set);
    
 }
}
 