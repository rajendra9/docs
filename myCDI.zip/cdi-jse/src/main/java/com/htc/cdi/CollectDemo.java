package com.htc.cdi;
   // A PROGRAM USING VECTORS AND ITERATOR METHODS
import java.util.Vector;

public class CollectDemo {

 public static void main(String[] arg) {
  Vector<Integer> cd1 = new Vector<Integer>(10,5);
  Vector<Integer> cd2 = new Vector<Integer>(10,5);

  for(int i=0;i<10;i++) {
   cd1.add(i,new Integer(i));
  }   
  for(int i=50;i<60;i++) {
   cd2.add(i-50,new Integer(i)); 
  }
  System.out.println("\ncollection cd1 contents are");

  for(Integer t : cd1) {
   System.out.print(" " + t);
  }   
  Integer it1 = new Integer(3);
  System.out.println("\n\ncd1 contains it1 is :::" +
                     cd1.contains(it1));
     
  cd1.insertElementAt(new Integer(20), 0);
  System.out.println("\nnow the element at 0th position is:::" +                        cd1.elementAt(0)); 
  System.out.println("\nSize of collection is :::" + cd1.size());

  System.out.println("\nElement at 5 is " + cd1.elementAt(5));
  cd1.removeElementAt(5);
  System.out.println("\nElement at 5 is " + cd1.elementAt(5));

  cd1.addAll(cd2);

 System.out.println("\nAfter addition collection "+
                    " cd1 contents are");

 for(Integer t : cd1) {
  System.out.print(" "+t);
 }          
 cd1.retainAll(cd2);          
 System.out.println("\n\nAfter retaining only cd2's  " + 
                    " collection cd1 contents are");
  for(Integer t : cd1) {
   System.out.print(" "+t);   
  }
 }

}