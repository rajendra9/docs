package com.htc.cdi;

public class SimpleEvent {

}
