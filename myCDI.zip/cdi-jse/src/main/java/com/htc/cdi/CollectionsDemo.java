package com.htc.cdi;
/* all methods are static methods of Collections class */
import java.util.ArrayList;
import  java.util.Collections;
import static java.util.Collections.*;
import java.util.Comparator;

public class CollectionsDemo {
   
 public static void show(ArrayList<Integer> al)     {
  for(Integer t : al)
  System.out.print(" "+t);  
  System.out.println("\n");
 }

 public static void main(String args[]) {
  ArrayList<Integer> aList = new ArrayList<Integer>();
  for(int i=0;i<10;i++) {
   aList.add(new Integer(i));
  }
  System.out.println("\nContents of Collection\n");
  show(aList);

  reverse(aList);
  System.out.println("\nResults of reverse\n"); 
  show(aList);        
      
  System.out.println("\nMin of Arraylist is: " + 
                        min(aList) + "\n");
  System.out.println("\nMax of Arraylist is: " + 
                        max(aList) + "\n");
     
  swap(aList, 3, 5);
  System.out.println("\nResults of Swapping\n"); 
  show(aList);
       
  shuffle(aList);
  System.out.println("\nResults of Shuffling\n");
  show(aList);
      
  sort(aList);
  System.out.println("\nResults of Sorting\n");
  show(aList);   
      
  rotate(aList, 2);  
  System.out.println("\nResults of Rotation\n");
  show(aList);
       
  fill(aList, new Integer(100));
  System.out.println("\nResults of Filling\n");
  show(aList);

  aList = new ArrayList<Integer>();
  Integer int5 = new Integer(5); 
  aList.add(int5);
  aList.add(int5);
  
  for(int i=0;i<10;i++) {
   aList.add(new Integer(i));
  }
   
  System.out.println("\nFrequency of Integer '5' is:" + 
                        frequency(aList, int5));
       
  Comparator<Integer> revComp = Collections.reverseOrder();
  Collections.sort(aList, revComp);
      
  System.out.println("\nReverse sorting Results:");

  System.out.println("\n" + aList);
            
  Collections.replaceAll(aList, 5, 500);
      
  System.out.println("\nReplacement Results:");
 
  System.out.println("\n" + aList);
 }

}

/* other methods are binarySearch(List,element),copy(list target,list source)   
 unmodifiableCollection(Collection)
  synchronizedCollection(Collection)
ex: for copy
   ArrayList<Integer> destList = 
           new ArrayList<Integer>(aList.size());
   Collections.fill(destList, new Integer(0));
   Collections.copy(destList,aList);

ex: for unmodifiableCollection
  Collection<Integer> col = Collections.unmodifiableCollection(aList);
   then invoke & test any modifying methods on col 

  disjoint(Collection<T> col1, Collection<T> col2)
   Returns true if col1 & col2 have no elements in common. 

*/