package com.htc.cdi;

import javax.enterprise.inject.se.SeContainer;
import javax.enterprise.inject.se.SeContainerInitializer;

public class TestCdi {

		
	public static void main(String[] args) {		
		SeContainerInitializer seContainerInit =
			       SeContainerInitializer.newInstance();
		SeContainer seContainer = seContainerInit.initialize();
		seContainer.getBeanManager().fireEvent(new SimpleEvent());
		seContainer.close();
	}

}
