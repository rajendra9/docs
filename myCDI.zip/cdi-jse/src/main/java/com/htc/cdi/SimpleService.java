package com.htc.cdi;

import javax.enterprise.inject.Default;
import javax.inject.Inject;


public class SimpleService {

	@Inject
	public Welcome welcome;
	
	
	public void welcomeUse() {
		welcome.welcome("87", "98");
	}
}
