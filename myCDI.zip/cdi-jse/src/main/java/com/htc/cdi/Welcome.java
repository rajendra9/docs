package com.htc.cdi;

public class Welcome{
 
  static {    
    System.out.println("Welcome to Java");
   }
  
  public void welcome(String ...args){
     String hello = "Hello world!";
     System.out.println(hello);   
     int one = Integer.parseInt(args[0]);
     int two = Integer.parseInt(args[1]);    
     System.out.println("addition Gives " + (one + two));
  }
  
}