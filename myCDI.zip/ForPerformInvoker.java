package com.htc.basic.refl;

import java.lang.reflect.Method;

public class ForPerformInvoker {
    
	ForPerform forPerform;
	StringBuilder sb = new StringBuilder();
    
	{
		forPerform = new ForPerform();
	}
	
	public void show() {
		System.out.println(sb.toString());
		sb.setLength(0);
	}
	
	public void executeNormal(int times) {
		long  nanoStartTime = System.nanoTime();
		for(int i=0;i<times;i++) {
		   sb.append(forPerform.manipulate(200.5)+"---");	
		}
		long  nanoEndTime = System.nanoTime();
		sb.append("\r\nTook " + (nanoEndTime - nanoStartTime) + " nano seconds.\r\n");
		
	}
	public void executeReflectively(int times) {
	   try {	
		Class<?> cl = ForPerform.class;
		Method meth = cl.getDeclaredMethod("manipulate",double.class);
		long  nanoStartTime = System.nanoTime();
		for(int i=0;i<times;i++) {
		   sb.append(meth.invoke(forPerform, 200.5) + "----");	
		}
		long  nanoEndTime = System.nanoTime();
		sb.append("\r\nTook " + (nanoEndTime - nanoStartTime) + " nano seconds.");
	   }catch(Exception ex) {
		   ex.printStackTrace();
	   }	   
	}
	public static void main(String[] args) {
	  ForPerformInvoker forPerformInvoker = new ForPerformInvoker();
	  forPerformInvoker.executeNormal(20);
	  forPerformInvoker.show();
	  forPerformInvoker.executeReflectively(20);	
	  forPerformInvoker.show();
	}

}
