package com.htc.basic.refl;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.concurrent.ThreadLocalRandom;

public class ForPerform {

	public double manipulate(double multi) {
       ThreadLocalRandom random = ThreadLocalRandom.current();
       double ret =  random.nextDouble(multi);
       BigDecimal deci = BigDecimal.valueOf(ret);
       deci = deci.round(MathContext.DECIMAL32);
       random = null;
       return deci.doubleValue();
       
	}
	
}
