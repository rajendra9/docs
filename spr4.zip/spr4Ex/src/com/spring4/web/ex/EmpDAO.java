package com.spring4.web.ex;

import java.io.Serializable;

public interface EmpDAO extends Serializable {
   public Employee  search(int id);
   public boolean saveEmployee(Employee emp);
}
