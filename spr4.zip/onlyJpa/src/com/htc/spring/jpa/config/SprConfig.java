package com.htc.spring.jpa.config;

import org.springframework.context.annotation.ComponentScan;

import java.util.Properties;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;


//Marks this class as configuration
@Configuration
//it sees it's own package and sub-packages
@ComponentScan({"com.htc.spring.jpa.config","com.htc.spring.jpa","com.htc.spring.jpa.controllers"})
//Enables Spring's annotations
@EnableWebMvc
public class SprConfig extends WebMvcConfigurerAdapter {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
      registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");   
    }

    @Override
    public void configureViewResolvers(ViewResolverRegistry registry) {
      registry.jsp("/WEB-INF/sprviews/", ".jsp");    
    }

    @Bean(name="simpleMappingExceptionResolver")
    public SimpleMappingExceptionResolver createSimpleMappingResolver(){
        SimpleMappingExceptionResolver excepResolver =
                new SimpleMappingExceptionResolver();
        Properties mappings = new Properties();
        mappings.setProperty("DataAccessException", "dataAccessError");
        mappings.setProperty("org.springframework.orm.hibernate5.HibernateJdbcException", "dataAccessError");
        mappings.setProperty("IOException", "ioError");
        mappings.setProperty("RuntimeException", "excep");
        excepResolver.setExceptionMappings(mappings);
        excepResolver.setDefaultErrorView("error");
        excepResolver.setExceptionAttribute("ex");
        return excepResolver;
    }
    
    
   
}
