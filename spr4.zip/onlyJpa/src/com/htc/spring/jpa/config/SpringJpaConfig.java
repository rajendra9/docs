package com.htc.spring.jpa.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;




@Configuration
@EnableTransactionManagement
@ComponentScan("com.htc.spring.jpa")
@PropertySource({"classpath:jdbc.properties"})
public class SpringJpaConfig {
    
    @Autowired
    private Environment env;
    @Bean
    public DataSource dataSource(){
      DriverManagerDataSource ds = new DriverManagerDataSource();
      String driverCl = env.getProperty("db.driver");
      ds.setDriverClassName(driverCl);
      ds.setUrl(env.getProperty("db.url"));
      ds.setUsername(env.getProperty("db.username"));
      ds.setPassword(env.getProperty("db.password"));
      return ds;
    }
    
    @Bean
    public HibernateJpaVendorAdapter configureVendorAdapter(){
        HibernateJpaVendorAdapter jpaVendorAdapter =
                           new HibernateJpaVendorAdapter();
      jpaVendorAdapter.setDatabase(Database.POSTGRESQL);
      jpaVendorAdapter.setShowSql(true);
      jpaVendorAdapter.setGenerateDdl(false);
      return jpaVendorAdapter;
    }

     private Properties getJpaProperties(){
       Properties jpaProperties = new Properties();
       jpaProperties.put("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect");
       jpaProperties.put("hibernate.globally_quoted_identifiers","true");
       jpaProperties.put("hibernate.cglib.use_reflection_optimizer","true");
       jpaProperties.put("hibernate.format_sql","true");
       jpaProperties.put("hibernate.show_sql","true");
       return jpaProperties;
    }    
     
    
    @Bean 
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(){
        LocalContainerEntityManagerFactoryBean emFactoryBean =
                             new LocalContainerEntityManagerFactoryBean();
        emFactoryBean.setJpaVendorAdapter(configureVendorAdapter());
        emFactoryBean.setPackagesToScan("com.htc.spring.jpa");              
        
        emFactoryBean.setPersistenceUnitName("myPostgres");         
        emFactoryBean.setDataSource(dataSource());
        emFactoryBean.setJpaProperties(getJpaProperties());
        return emFactoryBean;
    }

    @Bean
    @Autowired
    public JpaTransactionManager transactionManager() {
       JpaTransactionManager txManager = new JpaTransactionManager();
       txManager.setEntityManagerFactory(entityManagerFactory().getObject());  
       return txManager;
    }
  
    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
       return new PersistenceExceptionTranslationPostProcessor();
    }
    
    
   
}
