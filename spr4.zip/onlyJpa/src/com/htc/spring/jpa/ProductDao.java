package com.htc.spring.jpa;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

public interface ProductDao extends Serializable {

     public boolean persistProduct(ProductDTO prod);
     public boolean updateProduct(int prodId, double newCost);
     public Optional<ProductDTO> searchProduct(int prodId);
     public boolean deleteProduct(int prodId);
     public List<ProductDTO>  findAll();   
     

}
