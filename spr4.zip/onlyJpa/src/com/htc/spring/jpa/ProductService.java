package com.htc.spring.jpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Repository
@SuppressWarnings("serial")
@Transactional(propagation=Propagation.REQUIRED)
public class ProductService implements ProductDao {

	
   @PersistenceContext
    EntityManager em;

	@Override
	public boolean persistProduct(ProductDTO prod) {
		boolean ret = false;
		try {
		   em.persist(prod);
		   ret = true;
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return ret;
	}

	@Override
	public boolean updateProduct(int prodId, double newCost) {
		boolean ret = false;
		try {
		   ProductDTO  searched = em.getReference(ProductDTO.class, new Integer(prodId));
		   searched.setCost(newCost);
		   em.merge(searched);
		   ret = true;
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return ret;	
	}

	@Override
	public Optional<ProductDTO> searchProduct(int prodId) {
		Optional<ProductDTO> ret = Optional.ofNullable(new ProductDTO());
		try {
		   ProductDTO  searched = em.getReference(ProductDTO.class, new Integer(prodId));
		   System.out.println(searched);
		   ret = Optional.of(searched);		  
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return ret;
	}

	@Override
	public boolean deleteProduct(int prodId) {
		boolean ret = false;
		try {
		   ProductDTO  searched = em.getReference(ProductDTO.class, new Integer(prodId));
		   em.remove(searched);
		   ret = true;
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return ret;
	}

	@Override
	public List<ProductDTO> findAll() {
		List<ProductDTO> ret = new ArrayList<>();
		try {
		   TypedQuery<ProductDTO> qry = 
				   em.createNamedQuery("all_choose",  ProductDTO.class);
		   ret = qry.getResultList();		  
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return ret;
		
	}

}
