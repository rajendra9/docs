

const initialState ={
   funds: 5000.0,
   history: []
}
const fundsReducer = (state = initialState, action) =>{
   const newState = {...state};
   switch(action.type){
     case 'Funds_Up':return {
       ...state,
       funds: state.funds += action.value,
       history: state.history.concat({funds:state.funds + action.value})
     }
     break;
     case 'Funds_Down':
     return {
       ...state,
       funds: state.funds -= action.value,
       history: state.history.concat({funds:state.funds - action.value})
     }
     break;
   }
   return newState;
}

export default fundsReducer;