

const initialState ={
   funds: 5000.0,
   history: []
}
const fundsReducer = (state = initialState, action) =>{
   const newState = {...state};
   if(action.type === 'FUNDS_UP'){  
        return {...state,
       funds: state.funds + action.value,
       history: state.history.concat({funds:state.funds + action.value})
     }
    }
    else if (action.type === 'FUNDS_DOWN'){
      return {
       ...state,
       funds: state.funds - action.value,
       history: state.history.concat({funds:state.funds - action.value})
     } 
    }
    else if (action.type === 'DEL_ITEM'){
      return {
       ...state,
       history: state.history.filter((item,index) =>{ 
          return (index !== action.key);
       })
      } 
   }
   return newState;
}

export default fundsReducer;