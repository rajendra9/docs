import React, { Component } from 'react';
import './App.css';
import {connect} from 'react-redux';

class App extends Component {
  render() {
    return (
      <div className="App">
        <div>Society Amount:<span>{this.props.funds}</span></div><br/>
        <button onClick={this.props.onFundsUp}>Funds Deposit</button><br/><br/>
        <button onClick={this.props.onFundsDown}>Funds Spend</button><br/>         
        <hr/>
        <div>History</div>
        <div>
          <ul>
            {
              this.props.history.map((item,index)=>{
                return(<li 
                className='history-item'
                key={index} 
                onClick={() => this.props.onDelItem(index)}>
                {item.funds}
                </li>)
              })
            }
          </ul>

        </div>

      </div>
    );
  }
}
const  mapStateToProps = (state)=>{
 return {
   funds: state.funds,
   history: state.history
 }
};

const mapDispatchToProps = (dispatch)=>{
  return {
    onFundsUp: ()=> dispatch({type: 'FUNDS_UP', value: 1000.0}),
    onFundsDown: ()=> dispatch({type: 'FUNDS_DOWN', value: 800.0}),
    onDelItem: (id)=> dispatch({type: 'DEL_ITEM', key: id})    
  };
};



export default connect(mapStateToProps, mapDispatchToProps)(App);
