import React, { Component } from 'react';
import './App.css';
import {connect} from 'react-redux';

class App extends Component {
  render() {
    return (
      <div className="App">
        <div>Society Amount:<span>{this.props.funds}</span></div><br/>
        <button onClick={this.props.onFundsUp}>Funds Deposit</button><br/><br/>
        <button onClick={this.props.onFundsDown}>Funds Spend</button><br/>         
        <hr/>
        <div>History</div>
        <div>
          <ul>
            {
              this.props.history.map((index,item)=>{
                return(<li key={index}>item.funds</li>)
              })
            }
          </ul>

        </div>

      </div>
    );
  }
}
const  mapStateToProps = (state)=>{
 return {
   funds: state.funds,
   history: state.history
 }
};

const mapDispatchToProps = (dispatch)=>{
  return {
    onFundsUp : ()=> dispatch({type: 'Funds_Up', value: 1000.0}),
    onFundsDown : ()=> dispatch({type: 'Funds_Down', value: 800.0}),
   };
};



export default connect(mapStateToProps, mapDispatchToProps)(App);
