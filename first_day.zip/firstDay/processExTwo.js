
//both stdin,stdout/stderr are blocking
//end event won't fire on windows 

process.stdin.on('data',function(chunk){
   var dt = chunk.toString();
   if(dt =='exit\r\n'){
     process.stdout.write('reading over');
     process.exit(0);
   }
   else{
      process.stdout.write('read data:'+dt+'###');
   }
});


