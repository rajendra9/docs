package com.htc.hospital.dto;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="appoinment")
public class Appoinment {
	@Id
	private int appoinmentId;
	private int patientId;
	private String patientName;
	private String gender;
	private int age;
	private String priority;
	private String disease;
	private LocalDate appoinmentDate;
	private double amount;
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Appoinment(int appoinmentId, int patientId, String patientName, String gender, int age,
			LocalDate appoinmentDate) {
		super();
		this.appoinmentId = appoinmentId;
		this.patientId = patientId;
		this.patientName = patientName;
		this.gender = gender;
		this.age = age;
		this.appoinmentDate = appoinmentDate;
	}
	public Appoinment(int appoinmentId, int patientId, String patientName, String gender, int age, String priority,
			String disease, LocalDate appoinmentDate, double amount) {
		super();
		this.appoinmentId = appoinmentId;
		this.patientId = patientId;
		this.patientName = patientName;
		this.gender = gender;
		this.age = age;
		this.priority = priority;
		this.disease = disease;
		this.appoinmentDate = appoinmentDate;
		this.amount = amount;
	}
	public int getAppoinmentId() {
		return appoinmentId;
	}
	public void setAppoinmentId(int appoinmentId) {
		this.appoinmentId = appoinmentId;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getDisease() {
		return disease;
	}
	public void setDisease(String disease) {
		this.disease = disease;
	}
	public Appoinment(int appoinmentId, int patientId, String patientName, String gender, int age, String priority,
			String disease, LocalDate appoinmentDate) {
		super();
		this.appoinmentId = appoinmentId;
		this.patientId = patientId;
		this.patientName = patientName;
		this.gender = gender;
		this.age = age;
		this.priority = priority;
		this.disease = disease;
		this.appoinmentDate = appoinmentDate;
	}
	public int getPatientId() {
		return patientId;
	}
	@Override
	public String toString() {
		return "Appoinment [appoinmentId=" + appoinmentId + ", patientId=" + patientId + ", patientName=" + patientName
				+ ", gender=" + gender + ", age=" + age + ", priority=" + priority + ", disease=" + disease
				+ ", appoinmentDate=" + appoinmentDate + ", amount=" + amount + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + appoinmentId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Appoinment other = (Appoinment) obj;
		if (appoinmentId != other.appoinmentId)
			return false;
		return true;
	}
	public Appoinment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public LocalDate getAppoinmentDate() {
		return appoinmentDate;
	}
	public void setAppoinmentDate(LocalDate appoinmentDate) {
		this.appoinmentDate = appoinmentDate;
	}
}
