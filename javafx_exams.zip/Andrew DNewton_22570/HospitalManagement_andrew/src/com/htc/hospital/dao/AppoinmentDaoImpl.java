package com.htc.hospital.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.htc.hospital.dto.Appoinment;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class AppoinmentDaoImpl implements AppoinmentDao {
	EntityTransaction trans;
	EntityManagerFactory emFactory;
	EntityManager em;


	//Price List For diseases
	Map<String,Double> amount=new HashMap<>();



	public AppoinmentDaoImpl() {
		emFactory = Persistence.createEntityManagerFactory("myDB");
		amount.put("Fever", 150.00);
		amount.put("Diarrohea", 500.00);
		amount.put("Cough", 50.00);
		amount.put("Diabetes", 1000.00);
	}

	@Override
	public boolean addAppoinment(Appoinment appoinment) {
		try {
			em = emFactory.createEntityManager();
			trans = em.getTransaction();
			trans.begin();
			em.persist(appoinment);
			trans.commit();
			em.close();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@Override
	public boolean deleteAppoinmnet(int appoinmnentId) {
		try {
			em = emFactory.createEntityManager();
			trans = em.getTransaction();
			trans.begin();
			Appoinment appoinmnet = em.getReference(Appoinment.class, new Integer(appoinmnentId));
			em.remove(appoinmnet);
			trans.commit();
			em.close();
			return true;
		} catch (Exception ex) {
			trans.rollback();
			return false;
		}
	}

	@Override
	public boolean deleteAppoinmnentOfTwoYears() {
		try {
			em = emFactory.createEntityManager();
			trans = em.getTransaction();
			trans.begin();
			int result=em.createQuery("DELETE Appoinment a Where CURRENT_DATE-a.appoinmentDate>=730").executeUpdate();
			trans.commit();
			em.close();
			if(result>0)
				return true;
		return false;
		}catch (Exception e) {
			return false;
		}
	}

	@Override
	public ObservableList<Appoinment> getPriorityPatients() {
		ObservableList<Appoinment> appoinmentList=FXCollections.observableArrayList();
		try{
		em = emFactory.createEntityManager();
		trans = em.getTransaction();
		trans.begin();
		TypedQuery<Appoinment> result=em.createQuery("select a from Appoinment a",Appoinment.class);
		List<Appoinment>  appoinmnets=result.getResultList();
		appoinmentList.addAll(appoinmnets);
		trans.commit();
		em.close();
		return appoinmentList;
		}
		catch (Exception e) {
			return null;
		}
	}
	public double getAmount(String disease){
		/*for(Map.Entry<String, Double> amt: amount.entrySet()){
			if(amt.getKey().equalsIgnoreCase(disease))
			{
				return amt.getValue();
			}
		}*/
		if(amount.containsKey(disease)){
			return amount.get(disease);
		}
		else
			return 00.00;
	}
}
