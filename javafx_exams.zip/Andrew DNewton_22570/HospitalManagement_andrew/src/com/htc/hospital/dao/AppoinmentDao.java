package com.htc.hospital.dao;

import com.htc.hospital.dto.Appoinment;

import javafx.collections.ObservableList;

public interface AppoinmentDao {
	boolean addAppoinment(Appoinment appoinment);
	boolean deleteAppoinmnet(int appoinmnentId);
	boolean deleteAppoinmnentOfTwoYears();
	ObservableList<Appoinment> getPriorityPatients();
	public double getAmount(String disease);
}
