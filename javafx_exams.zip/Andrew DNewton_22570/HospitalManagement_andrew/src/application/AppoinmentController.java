package application;

import java.io.IOException;

import com.htc.hospital.dao.AppoinmentDao;
import com.htc.hospital.dao.AppoinmentDaoImpl;
import com.htc.hospital.dto.Appoinment;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AppoinmentController{
	@FXML
	Button add, home, delete;
	@FXML
	TextField appoinmentId, patientId, patientName, gender, age, priority, disease;
	@FXML
	DatePicker appoinmentDate;
	@FXML
	TextArea ta;


	//Redirecting From Appoinment Page to Hospital Home page
	@FXML
	public void home(ActionEvent evt) throws IOException {
		Parent root;
		Stage mainStage;
		mainStage = (Stage) home.getScene().getWindow();
		root = (Parent) FXMLLoader.load(getClass().getResource("Hospital.fxml"));
		Scene scene = new Scene(root);
		mainStage.setScene(scene);
		mainStage.show();
	}

	@FXML
	public void initialize() {
		AppoinmentDao appoinmnetDao = new AppoinmentDaoImpl();
		add.setOnAction((event) -> {
			System.out.println("Add");
			if (appoinmnetDao.addAppoinment(new Appoinment(Integer.parseInt(appoinmentId.getText().trim()),
					Integer.parseInt(patientId.getText().trim()), patientName.getText().trim(), gender.getText().trim(),
					Integer.parseInt(age.getText().trim()), priority.getText().trim(), disease.getText().trim(),
					appoinmentDate.getValue(),appoinmnetDao.getAmount(disease.getText().trim())))) {
				System.out.println("Added");
				Double amount=appoinmnetDao.getAmount(disease.getText().trim());
				ta.setText("");
				ta.appendText("Appoinmnent Accepted!!\n");
				ta.appendText("Amount to be paid "+amount+"\n");
				ta.appendText("Please be available on "+appoinmentDate.getValue()+" for consulting the doctor");
			}
			else{
				ta.setText("");
				ta.appendText("Failed!!");
			}
		});
		delete.setOnAction((event)->{
			if(appoinmnetDao.deleteAppoinmnet(new Integer(appoinmentId.getText().trim()))){

				ta.setText("");
				ta.appendText("Appoinmnet Cancelled Successfully");
			}
			else{
				ta.setText("");
				ta.appendText("Error in cancelling");
			}
		});
	}
}
