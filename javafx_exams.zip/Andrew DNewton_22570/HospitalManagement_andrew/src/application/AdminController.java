package application;

import java.io.IOException;
import java.time.LocalDate;

import com.htc.hospital.dao.AppoinmentDao;
import com.htc.hospital.dao.AppoinmentDaoImpl;
import com.htc.hospital.dto.Appoinment;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class AdminController {
	@FXML
	Button delete,home;
	@FXML
	Pagination page;
	@FXML
	TextArea ta;

	ObservableList<Appoinment> appoinments;
	//pagination
	TableView<Appoinment> tb;
	TableColumn<Appoinment,Integer> appoinmentId;
	TableColumn<Appoinment,Integer> patientId;
	TableColumn<Appoinment,String> patientName;
	TableColumn<Appoinment,String> gender;
	TableColumn<Appoinment,Integer> age;
	TableColumn<Appoinment,String> priority;
	TableColumn<Appoinment,String> disease;
	TableColumn<Appoinment,LocalDate> appoinmentDate;
	TableColumn<Appoinment,Double> amount;


	public int dataSize;
	static final int RECS_PER_PAGE=10;


	private Node createPage(int currIndex){
        int fromIndex = currIndex * RECS_PER_PAGE;
        int toIndex = Math.min(fromIndex + RECS_PER_PAGE, dataSize);
        tb.setItems(FXCollections.observableArrayList(appoinments.subList(fromIndex, toIndex)));
        return new BorderPane(tb);
    }

	//Redirecting From Appoinment Page to Hospital Home page
	@FXML
	public void home(ActionEvent evt) throws IOException {
		Parent root;
		Stage mainStage;
		mainStage = (Stage) home.getScene().getWindow();
		root = (Parent) FXMLLoader.load(getClass().getResource("Hospital.fxml"));
		Scene scene = new Scene(root);
		mainStage.setScene(scene);
		mainStage.show();
	}

	@SuppressWarnings("unchecked")
	@FXML
	public void initialize(){


		//Pagination
		AppoinmentDao appoinmnetDao=new AppoinmentDaoImpl();
		System.out.println("In admin Controller");
		appoinments=appoinmnetDao.getPriorityPatients();
		dataSize=appoinments.size();
		tb=new TableView<Appoinment>();
		appoinmentId=new TableColumn<Appoinment,Integer>("appoinmentId");
		appoinmentId.setCellValueFactory(new PropertyValueFactory<Appoinment,Integer>("appoinmentId"));
		patientId=new TableColumn<Appoinment,Integer>("patientId");
		patientId.setCellValueFactory(new PropertyValueFactory<Appoinment,Integer>("patientId"));
		patientName=new TableColumn<Appoinment,String>("patientName");
		patientName.setCellValueFactory(new PropertyValueFactory<Appoinment,String>("patientName"));
		gender=new TableColumn<Appoinment,String>("gender");
		gender.setCellValueFactory(new PropertyValueFactory<Appoinment,String>("gender"));
		age=new TableColumn<Appoinment,Integer>("age");
		age.setCellValueFactory(new PropertyValueFactory<Appoinment,Integer>("age"));
		priority=new TableColumn<Appoinment,String>("priority");
		priority.setCellValueFactory(new PropertyValueFactory<Appoinment,String>("priority"));
		disease=new TableColumn<Appoinment,String>("disease");
		disease.setCellValueFactory(new PropertyValueFactory<Appoinment,String>("disease"));
		appoinmentDate=new TableColumn<Appoinment,LocalDate>("appoinmentDate");
		appoinmentDate.setCellValueFactory(new PropertyValueFactory<Appoinment,LocalDate>("appoinmentDate"));
		amount=new TableColumn<Appoinment,Double>("amount");
		amount.setCellValueFactory(new PropertyValueFactory<Appoinment,Double>("amount"));
		tb.getColumns().addAll(appoinmentId,patientId,patientName,gender,age,priority,disease,appoinmentDate,amount);
		int pgCnt = (int)Math.round(Math.ceil((double)dataSize/RECS_PER_PAGE));
		page.setPageCount(pgCnt);
        page.setCurrentPageIndex(0);
        page.setPageFactory(this::createPage);


        //Deleting appoinments which is older than 2 years

        delete.setOnAction((action)->{
        	if(appoinmnetDao.deleteAppoinmnentOfTwoYears()){
        		ta.setText("");
        		ta.appendText("Removed Successfully");
        	}
        	else
        	{
        		ta.setText("");
        		ta.appendText("Something went wrong");
        	}
        });

	}
}
