package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class HospitalController {

	@FXML
	Button appoinment,login;

	@FXML
	HBox hBox;


	//Navigation from home to Appoinment Page
	@FXML
	public void appoinment(ActionEvent evt) throws IOException {
		System.out.println("In appoinment");
		Parent root;
		Stage mainStage;
		mainStage = (Stage) appoinment.getScene().getWindow();
		root = (Parent) FXMLLoader.load(getClass().getResource("Appoinment.fxml"));
		Scene scene = new Scene(root);
		mainStage.setScene(scene);
		mainStage.show();
	}


	//Navigation from home to Admin Page
	@FXML
	public void admin(ActionEvent evt) throws IOException {
		System.out.println("In admin");
		Parent root;
		Stage mainStage;
		mainStage = (Stage) login.getScene().getWindow();
		root = (Parent) FXMLLoader.load(getClass().getResource("Admin.fxml"));
		Scene scene = new Scene(root);
		mainStage.setScene(scene);
		mainStage.show();
	}

	@FXML
	public void initialize() {
		DropShadow effect=new DropShadow();
		effect.setOffsetX(5.0);
		effect.setOffsetY(5.0);
		effect.setColor(Color.GRAY);
		hBox.setEffect(effect);
	}
}
