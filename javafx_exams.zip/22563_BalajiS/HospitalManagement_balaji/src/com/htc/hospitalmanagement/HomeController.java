package com.htc.hospitalmanagement;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class HomeController  implements Initializable{
	  @FXML
	  private Button patient;

	  @FXML
	  private Button management;

	  //Button navigation handler
	  @FXML
	  private  void buttonActionHandler(ActionEvent evt)throws IOException{
	     Parent root;
	     Stage mainStage;
	     if(evt.getSource()== patient){
	         mainStage = (Stage)patient.getScene().getWindow();
	         root =
	          (Parent)FXMLLoader.load(getClass().getResource("Patient.fxml"));
	     }
	     else{
	         mainStage = (Stage)management.getScene().getWindow();
	         root =
	          (Parent)FXMLLoader.load(getClass().getResource("Management.fxml"));
	     }
	      Scene scene = new Scene(root);
	      mainStage.setScene(scene);
	      mainStage.show();
	  }


	  public void initialize(URL loc, ResourceBundle resources){
	     System.out.println("init fired");
	  }

}
