package com.htc.hospitalmanagement;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import com.htc.hospitalmanagement.dto.Appointment;
import com.htc.hospitalmanagement.services.AppointmentDAO;
import com.htc.hospitalmanagement.services.AppointmentDAOImpl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class ManagementController implements Initializable {

	private AppointmentDAO dao = new AppointmentDAOImpl();

	@FXML
	private Button back;

	@FXML
	private Button filter;

	@FXML
	private Button delete;

	// Table
	public static final int RECS_PER_PAGE = 10;
	public int dataSize;

	ObservableList<Appointment> appointments;

	@FXML
	private Pagination pagination;

	TableView<Appointment> tbl;

	TableColumn<Appointment, Integer> appointment_id;

	TableColumn<Appointment, Integer> patient_id;

	TableColumn<Appointment, String> patient_name;

	TableColumn<Appointment, Integer> p_age;

	TableColumn<Appointment, String> p_disease;

	TableColumn<Appointment, String> p_gender;

	TableColumn<Appointment, String> p_priority;

	TableColumn<Appointment, LocalDate> date_of_appointment;

	TableColumn<Appointment, Double> p_charges;

	//Assigning the From and to indices.
	private Node createPage(int currIndex) {
		int fromIndex = currIndex * RECS_PER_PAGE;
		int toIndex = Math.min(fromIndex + RECS_PER_PAGE, dataSize);
		tbl.setItems(FXCollections.observableArrayList(appointments.subList(fromIndex, toIndex)));
		return new BorderPane(tbl);
	}

	//Button navigation handler
	@FXML
	private void buttonActionHandler(ActionEvent evt) throws IOException {
		Parent root;
		Stage mainStage;
		mainStage = (Stage) back.getScene().getWindow();
		root = (Parent) FXMLLoader.load(getClass().getResource("Home.fxml"));
		Scene scene = new Scene(root);
		mainStage.setScene(scene);
		mainStage.show();
	}

	//Creating table coulmns and Assigning values from the database
	@SuppressWarnings("unchecked")
	public void getpagination() {

		dataSize = appointments.size();
		tbl = new TableView<Appointment>();
		tbl.setFixedCellSize(RECS_PER_PAGE * 7);

		appointment_id = new TableColumn<Appointment, Integer>("Appointment id");
		appointment_id.setCellValueFactory(new PropertyValueFactory<Appointment, Integer>("appointmentId"));

		patient_id = new TableColumn<Appointment, Integer>("Patient id");
		patient_id.setCellValueFactory(new PropertyValueFactory<Appointment, Integer>("patientId"));

		patient_name = new TableColumn<Appointment, String>("Patient Name");
		patient_name.setCellValueFactory(new PropertyValueFactory<Appointment, String>("patientName"));

		p_age = new TableColumn<Appointment, Integer>("Age");
		p_age.setCellValueFactory(new PropertyValueFactory<Appointment, Integer>("age"));

		p_disease = new TableColumn<Appointment, String>("Disease");
		p_disease.setCellValueFactory(new PropertyValueFactory<Appointment, String>("disease"));

		p_gender = new TableColumn<Appointment, String>("Gender");
		p_gender.setCellValueFactory(new PropertyValueFactory<Appointment, String>("gender"));

		p_priority = new TableColumn<Appointment, String>("Priority");
		p_priority.setCellValueFactory(new PropertyValueFactory<Appointment, String>("priority"));

		date_of_appointment = new TableColumn<Appointment, LocalDate>("Date of appointment");
		date_of_appointment.setCellValueFactory(new PropertyValueFactory<Appointment, LocalDate>("dateOfAppointment"));

		p_charges = new TableColumn<Appointment, Double>("Charges");
		p_charges.setCellValueFactory(new PropertyValueFactory<Appointment, Double>("charges"));

		tbl.getColumns().addAll(appointment_id, patient_id, patient_name, p_age, p_disease, p_gender, p_priority,
				date_of_appointment, p_charges);
		int pgCnt = (int) Math.round(Math.ceil((double) dataSize / RECS_PER_PAGE));
		pagination.setPageCount(pgCnt);
		pagination.setCurrentPageIndex(0);
		pagination.setPageFactory(this::createPage);

	}

	public void initialize(URL loc, ResourceBundle resources) {
		appointments = dao.getAllAppointments();
		getpagination();
		if (filter != null) {
			filter.setOnAction(new EventHandler<ActionEvent>() {
				public void handle(ActionEvent evt) {
					appointments = dao.filterAppointments();
					getpagination();
				}
			});
		}
		if (delete != null) {
			delete.setOnAction(new EventHandler<ActionEvent>() {
				public void handle(ActionEvent evt) {
					dao.deleteAppointments();
					appointments = dao.getAllAppointments();
					getpagination();
				}
			});
		}
	}

}