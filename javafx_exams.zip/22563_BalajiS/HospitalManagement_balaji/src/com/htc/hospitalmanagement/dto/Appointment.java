package com.htc.hospitalmanagement.dto;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="Appointment")
@NamedQuery(name="cancel",query="DELETE Appointment a WHERE a.patientId=:patientId AND a.dateOfAppointment=:dateOfAppointment")
@NamedQuery(name="select",query="SELECT a FROM Appointment a WHERE a.patientId=:patientId AND a.dateOfAppointment=:dateOfAppointment")
@NamedQuery(name="search",query="SELECT a FROM Appointment a WHERE a.patientId=:patientId")
public class Appointment {

	@Id
	private int appointmentId;
	@Column
	private int patientId;
	@Column
	private String patientName;
	@Column
	private String gender;
	@Column
	private int age;
	@Column
	private String priority;
	@Column
	private String disease;
	@Column
	private LocalDate dateOfAppointment;
	@Column
	private double charges;

	public int getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getDisease() {
		return disease;
	}
	public void setDisease(String disease) {
		this.disease = disease;
	}
	public LocalDate getDateOfAppointment() {
		return dateOfAppointment;
	}
	public void setDateOfAppointment(LocalDate dateOfAppointment) {
		this.dateOfAppointment = dateOfAppointment;
	}

	public double getCharges() {
		return charges;
	}
	public void setCharges(double charges) {
		this.charges = charges;
	}
	public Appointment(int appointmentId, int patientId, String patientName, String gender, int age, String priority,
			String disease, LocalDate dateOfAppointment, double charges) {
		super();
		this.appointmentId = appointmentId;
		this.patientId = patientId;
		this.patientName = patientName;
		this.gender = gender;
		this.age = age;
		this.priority = priority;
		this.disease = disease;
		this.dateOfAppointment = dateOfAppointment;
		this.charges = charges;
	}

	public Appointment(int appointmentId, int patientId, String patientName, String gender, int age, String priority,
			String disease, LocalDate dateOfAppointment) {
		super();
		this.appointmentId = appointmentId;
		this.patientId = patientId;
		this.patientName = patientName;
		this.gender = gender;
		this.age = age;
		this.priority = priority;
		this.disease = disease;
		this.dateOfAppointment = dateOfAppointment;
	}
	public Appointment() {
		super();

	}
	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", patientId=" + patientId + ", patientName="
				+ patientName + ", gender=" + gender + ", age=" + age + ", priority=" + priority + ", disease="
				+ disease + ", dateOfAppointment=" + dateOfAppointment + ", charges=" + charges + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + appointmentId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Appointment other = (Appointment) obj;
		if (appointmentId != other.appointmentId)
			return false;
		return true;
	}



}
