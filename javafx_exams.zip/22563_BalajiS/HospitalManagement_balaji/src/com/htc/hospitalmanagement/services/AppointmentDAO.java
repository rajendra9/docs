package com.htc.hospitalmanagement.services;

import java.time.LocalDate;
import java.util.List;

import com.htc.hospitalmanagement.dto.Appointment;

import javafx.collections.ObservableList;

public interface AppointmentDAO {

	public boolean addAppointment(Appointment appointment);

	public boolean deleteAppointments();

	public ObservableList<Appointment> filterAppointments();

	public boolean cancelAppointment(int patientId, LocalDate dateOfAppointment);

	public Appointment getAppointment(int patientId, LocalDate dateOfAppointment);

	public List<String> getLists(String category);

	public ObservableList<Appointment> getAllAppointments();

	public ObservableList<Appointment> getAppointmentByPatientId(int i);

}
