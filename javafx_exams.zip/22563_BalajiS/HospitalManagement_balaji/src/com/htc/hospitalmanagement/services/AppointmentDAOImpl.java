package com.htc.hospitalmanagement.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.htc.hospitalmanagement.dto.Appointment;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class AppointmentDAOImpl implements AppointmentDAO {

	EntityTransaction trans;
	EntityManagerFactory emFactory;
	EntityManager em;

	public AppointmentDAOImpl() {
		emFactory = Persistence.createEntityManagerFactory("postgres");
	}

	public List<String> getLists(String category){
		List<String> list = new ArrayList<>();
		if(category.equals("gender")){
			list.add("Male");
			list.add("Female");
		}else{
			list.add("Normal");
			list.add("Urgent");
		}
		return list;
	}

	@Override
	public boolean addAppointment(Appointment appointment) {
		boolean returnFlag = false;
		em = emFactory.createEntityManager();
		trans = em.getTransaction();
		trans.begin();
		try {
			em.persist(appointment);
			trans.commit();
			returnFlag = true;

		} catch (Exception e) {
			e.printStackTrace();
			trans.rollback();
			returnFlag = false;
		} finally {
			em.close();
		}
		return returnFlag;
	}

	@Override
	public boolean deleteAppointments() {
		boolean ret = false;
		em = emFactory.createEntityManager();
		trans = em.getTransaction();
		trans.begin();
		try {
			Query query = em.createQuery(
					"DELETE Appointment a WHERE Current_DATE-a.dateOfAppointment>=730");
			int affectedRows = query.executeUpdate();
			trans.commit();
			if (affectedRows >= 1) {
				ret = true;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			trans.rollback();
			ret = false;
		} finally {
			em.close();
		}
		return ret;
	}

	@Override
	public ObservableList<Appointment> filterAppointments() {
		ObservableList<Appointment> data = null;
		try {
			data = FXCollections.observableArrayList();
			em = emFactory.createEntityManager();
			trans = em.getTransaction();
			trans.begin();
			TypedQuery<Appointment> query = em.createQuery(
					"SELECT a FROM Appointment a WHERE priority='urgent' OR dateOfAppointment = current_date",
					Appointment.class);
			data.addAll(query.getResultList());
			trans.commit();
		} catch (Exception e) {
			e.printStackTrace();
			trans.rollback();
		} finally {
			em.close();
		}
		return data;
	}

	@Override
	public boolean cancelAppointment(int patientId, LocalDate dateOfAppointment) {
		boolean ret = false;
		em = emFactory.createEntityManager();
		trans = em.getTransaction();
		trans.begin();
		try {
			Query query = em.createNamedQuery("cancel");
			query.setParameter("patientId", new Integer(patientId));
			query.setParameter("dateOfAppointment", dateOfAppointment);
			int affectedRows = query.executeUpdate();
			trans.commit();
			if (affectedRows >= 1) {
				ret = true;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			trans.rollback();
			ret = false;
		} finally {
			em.close();
		}
		return ret;
	}

	@Override
	public Appointment getAppointment(int patientId, LocalDate dateOfAppointment) {
		Appointment app = new Appointment();
		em = emFactory.createEntityManager();
		trans = em.getTransaction();
		trans.begin();
		try {
			TypedQuery<Appointment> query = em.createNamedQuery("select", Appointment.class);
			query.setParameter("patientId", new Integer(patientId));
			query.setParameter("dateOfAppointment", dateOfAppointment);
			app = query.getResultList().get(0);
			trans.commit();

		} catch (Exception ex) {
			ex.printStackTrace();
			trans.rollback();

		} finally {
			em.close();
		}
		return app;
	}

	@Override
	public ObservableList<Appointment> getAllAppointments() {
		ObservableList<Appointment> data = null;
		try {
			data = FXCollections.observableArrayList();
			em = emFactory.createEntityManager();
			trans = em.getTransaction();
			trans.begin();
			TypedQuery<Appointment> query = em.createQuery(
					"SELECT a FROM Appointment a",
					Appointment.class);
			data.addAll(query.getResultList());
			trans.commit();
		} catch (Exception e) {
			e.printStackTrace();
			trans.rollback();
		} finally {
			em.close();
		}
		return data;
	}

	@Override
	public ObservableList<Appointment> getAppointmentByPatientId(int patientId) {
		ObservableList<Appointment> data = null;
		em = emFactory.createEntityManager();
		trans = em.getTransaction();
		trans.begin();
		try {
			data = FXCollections.observableArrayList();
			TypedQuery<Appointment> query = em.createNamedQuery("search", Appointment.class);
			query.setParameter("patientId", new Integer(patientId));
			data.addAll(query.getResultList());
			trans.commit();

		} catch (Exception ex) {
			ex.printStackTrace();
			trans.rollback();

		} finally {
			em.close();
		}
		return data;
	}

}
