package com.htc.hospitalmanagement;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Objects;
import java.util.ResourceBundle;

import com.htc.hospitalmanagement.dto.Appointment;
import com.htc.hospitalmanagement.services.AppointmentDAO;
import com.htc.hospitalmanagement.services.AppointmentDAOImpl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class PatientController implements Initializable {

	private AppointmentDAO dao = new AppointmentDAOImpl();

	@FXML
	private TextField appointmentId, patientId, patientName, age, disease;

	@FXML
	private ComboBox<String> gender, priority;

	@FXML
	private DatePicker dateOfAppointment;

	@FXML
	private Button submit;

	@FXML
	private Button back;

	@FXML
	private TextArea result;

	// Delete
	@FXML
	private TextField searchPatientId;

	@FXML
	private DatePicker searchDOA;

	@FXML
	private Button cancel;

	@FXML
	private TextArea searchResult;

	@FXML
	private Button search;

	// Table
	public static final int RECS_PER_PAGE = 10;
	public int dataSize;

	ObservableList<Appointment> appointments;

	@FXML
	private Pagination pagination;

	TableView<Appointment> tbl;

	TableColumn<Appointment, Integer> appointment_id;

	TableColumn<Appointment, Integer> patient_id;

	TableColumn<Appointment, String> patient_name;

	TableColumn<Appointment, Integer> p_age;

	TableColumn<Appointment, String> p_disease;

	TableColumn<Appointment, String> p_gender;

	TableColumn<Appointment, String> p_priority;

	TableColumn<Appointment, LocalDate> date_of_appointment;

	TableColumn<Appointment, Double> p_charges;

	//Button navigation handler
	@FXML
	private void buttonActionHandler(ActionEvent evt) throws IOException {
		Parent root;
		Stage mainStage;
		mainStage = (Stage) back.getScene().getWindow();
		root = (Parent) FXMLLoader.load(getClass().getResource("Home.fxml"));
		Scene scene = new Scene(root);
		mainStage.setScene(scene);
		mainStage.show();
	}

	//Assigning the From and to indices.
	private Node createPage(int currIndex) {
		int fromIndex = currIndex * RECS_PER_PAGE;
		int toIndex = Math.min(fromIndex + RECS_PER_PAGE, dataSize);
		tbl.setItems(FXCollections.observableArrayList(appointments.subList(fromIndex, toIndex)));
		return new BorderPane(tbl);
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		gender.setItems(FXCollections.observableArrayList(dao.getLists("gender")));
		priority.setItems(FXCollections.observableArrayList(dao.getLists("priority")));
		// appointments = dao.getAllAppointments();
		getpagination();
		if (submit != null) {
			submit.setOnAction(new EventHandler<ActionEvent>() {
				public void handle(ActionEvent evt) {
					Appointment appointment = new Appointment(Integer.parseInt(appointmentId.getText().trim()),
							Integer.parseInt(patientId.getText().trim()), patientName.getText().trim(),
							gender.getValue(), Integer.parseInt(age.getText().trim()), priority.getValue(),
							disease.getText().trim(), dateOfAppointment.getValue());
					appointment.setCharges(getCharges(disease.getText().trim()));
					boolean retFlag = dao.addAppointment(appointment);
					if (retFlag) {
						result.setText("Appointment added\n"+"Charges for the appointment is "+getCharges(disease.getText().trim()));
					} else {
						result.setText("Problems in adding Appointment");
					}
				}
			});
		}

		if (search != null) {
			search.setOnAction(new EventHandler<ActionEvent>() {
				public void handle(ActionEvent evt) {
					if (!searchPatientId.getText().isEmpty()) {
						getpagination();
					} else {
						searchResult.setText("Please enter patient id");
					}
				}
			});
		}

		if (cancel != null) {
			cancel.setOnAction(new EventHandler<ActionEvent>() {
				public void handle(ActionEvent evt) {
					if (!searchPatientId.getText().isEmpty() && !Objects.isNull(searchDOA.getValue())) {
						boolean retFlag = dao.cancelAppointment(Integer.parseInt(searchPatientId.getText().trim()),
								searchDOA.getValue());
						if (retFlag) {
							searchResult.setText("Appointment cancelled");
						} else {
							searchResult.setText("Error in cancelling appointment");
						}
						getpagination();
					} else {
						searchResult.setText("Please enter patient id And Date of Appointment");
					}
				}
			});
		}

	}

	//Get charges based on Disease
	public double getCharges(String disease) {
		double charge = 0;
		switch (disease) {
		case "fever":
			charge = 100.00;
			break;

		case "heart disease":
			charge = 500.00;
			break;

		case "cancer":
			charge = 1000.00;
			break;

		default:
			charge = 200;
		}

		return charge;
	}

	//Creating table coulmns and Assigning values from the database
	@SuppressWarnings("unchecked")
	public void getpagination() {
		if (!searchPatientId.getText().isEmpty()) {
			appointments = dao.getAppointmentByPatientId(Integer.parseInt(searchPatientId.getText().trim()));
			dataSize = appointments.size();
			tbl = new TableView<Appointment>();
			tbl.setFixedCellSize(RECS_PER_PAGE * 7);

			appointment_id = new TableColumn<Appointment, Integer>("Appointment id");
			appointment_id.setCellValueFactory(new PropertyValueFactory<Appointment, Integer>("appointmentId"));

			patient_id = new TableColumn<Appointment, Integer>("Patient id");
			patient_id.setCellValueFactory(new PropertyValueFactory<Appointment, Integer>("patientId"));

			patient_name = new TableColumn<Appointment, String>("Patient Name");
			patient_name.setCellValueFactory(new PropertyValueFactory<Appointment, String>("patientName"));

			p_age = new TableColumn<Appointment, Integer>("Age");
			p_age.setCellValueFactory(new PropertyValueFactory<Appointment, Integer>("age"));

			p_disease = new TableColumn<Appointment, String>("Disease");
			p_disease.setCellValueFactory(new PropertyValueFactory<Appointment, String>("disease"));

			p_gender = new TableColumn<Appointment, String>("Gender");
			p_gender.setCellValueFactory(new PropertyValueFactory<Appointment, String>("gender"));

			p_priority = new TableColumn<Appointment, String>("Priority");
			p_priority.setCellValueFactory(new PropertyValueFactory<Appointment, String>("priority"));

			date_of_appointment = new TableColumn<Appointment, LocalDate>("Date of appointment");
			date_of_appointment
					.setCellValueFactory(new PropertyValueFactory<Appointment, LocalDate>("dateOfAppointment"));

			p_charges = new TableColumn<Appointment, Double>("Charges");
			p_charges.setCellValueFactory(new PropertyValueFactory<Appointment, Double>("charges"));

			tbl.getColumns().addAll(appointment_id, patient_id, patient_name, p_age, p_disease, p_gender, p_priority,
					date_of_appointment, p_charges);
			int pgCnt = (int) Math.round(Math.ceil((double) dataSize / RECS_PER_PAGE));
			pagination.setPageCount(pgCnt);
			pagination.setCurrentPageIndex(0);
			pagination.setPageFactory(this::createPage);
		}
	}
}
