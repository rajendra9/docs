package demojaxb;
import java.io.File;
import java.io.PrintWriter;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import forweb.BkTy;
import forweb.BksTy;
import forweb.ObjectFactory;

public class JaxbBookDemo {  

	Marshaller marshaller;
	Unmarshaller unMarshaller;
	ObjectFactory objFactory;
	public JaxbBookDemo() {
	  try {	
	   JAXBContext ctx = JAXBContext.newInstance("forweb");
	   marshaller = ctx.createMarshaller();
	   unMarshaller = ctx.createUnmarshaller();
	   objFactory = new ObjectFactory();
	  }catch(Exception ex) {
	    	 ex.printStackTrace(); 
	  }
	}
	public JAXBElement<BksTy> getRoot() {
	  JAXBElement<BksTy> rootJaxb = null;
	   try {   
	    rootJaxb = (JAXBElement<BksTy>)unMarshaller.unmarshal(new File("saxExerBooks.xml"));
	   }catch(Exception ex) {
	  	 ex.printStackTrace(); 
	   }
	    return rootJaxb;	
	 }
	 
	 public void saveRootBack(JAXBElement<BksTy> changedRootNode) {
      try {
	   marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
	               Boolean.TRUE);
	   PrintWriter out = new PrintWriter("saxExerBooks.xml");
	   marshaller.marshal(changedRootNode, out);
	   out.close();
	  }catch(Exception ex) {
	    	 ex.printStackTrace();
	  }
	}
	
	public boolean addBook(BkTy book) {
			boolean ret = false;
			try {
			 JAXBElement<BksTy> rootJaxb = this.getRoot();
			 BksTy rootBooks = rootJaxb.getValue();
			 List<BkTy> list = rootBooks.getBook();
			 list.add(book);		
			 JAXBElement<BksTy> changedRootJaxb = objFactory.createBooks(rootBooks);
			 this.saveRootBack(changedRootJaxb);
			 ret = true;
			}catch(Exception ex) {
				ex.printStackTrace();
			}
			return ret;
		}	
	public boolean removeBook(String id) {
	  boolean ret = false;
	   try {
		 JAXBElement<BksTy> rootJaxb = this.getRoot();
		 BksTy rootBooks = rootJaxb.getValue();
		 List<BkTy> list = rootBooks.getBook();
		 list.removeIf(elt -> elt.getId().equalsIgnoreCase(id));	
		 JAXBElement<BksTy> changedRootJaxb = objFactory.createBooks(rootBooks);
		 this.saveRootBack(changedRootJaxb);
		 ret = true;
       }catch(Exception ex) {
				ex.printStackTrace();
       }	
	   return ret;
  	}


}