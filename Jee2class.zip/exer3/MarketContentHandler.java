package exers.three;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;


public class MarketContentHandler extends MyDefHandler {  
 
 private boolean isBurmaBazar = false;
 private String itName = "";
 public StringBuffer sb = new StringBuffer(1000);

 List<BurmaItem>  burmaItemsList = new ArrayList<>();
 
 public void startElement(String uri, String localname,
                          String qname, Attributes attrs)
  throws SAXException {
 
  if(qname.equalsIgnoreCase("market")) {
    String marketName = attrs.getValue("name");    
    isBurmaBazar = marketName.equalsIgnoreCase("BurmaBazar");   
  }
  sb.setLength(0);
 }
 
 public void characters(char[] chars, int start, int len)
  throws SAXException {
  sb.append(chars,start,len);      
 }

  public void endElement(String uri, String localname, String qname)
   throws SAXException {
   BurmaItem item = null;	  
   if(qname.equalsIgnoreCase("item-name") && isBurmaBazar) {
	  itName = sb.toString().trim();
	  
   }
   if(qname.equalsIgnoreCase("item-cost") && isBurmaBazar) {
	   item = new BurmaItem();
	   double cst = Double.parseDouble(sb.toString().trim());  
       item.setName(itName);
	   item.setCost(cst);
       burmaItemsList.add(item);
       itName = "";
   }
  
   if(qname.equalsIgnoreCase("market")) {
	  isBurmaBazar = false;
   }      
  
  }
  @Override
  public void endDocument() throws SAXException {
	System.out.println(burmaItemsList);
	Collections.sort(burmaItemsList);
	
	System.out.println("Lowest Price is: " + burmaItemsList.get(0));
	System.out.println("Highest Price is: " + burmaItemsList.get(burmaItemsList.size()-1));
	
  
  }
  
   
 }  