package exers.three;

import java.io.Serializable;

public class BurmaItem implements Serializable,Comparable<BurmaItem> {
    String  name;
    double  cost;
    @Override
	public int compareTo(BurmaItem other) {
		return Double.valueOf(this.cost).compareTo(Double.valueOf(other.cost));
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "BurmaItem [name=" + name + ", cost=" + cost + "]";
	}
    
}
