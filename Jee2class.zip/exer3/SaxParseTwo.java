package exers.three;

import javax.xml.parsers.SAXParser;

import saxvalid.SaxParse;

public class SaxParseTwo {
	
	public static void main(String args[])throws Exception {        
		  String filename = "markets.xml";
		  SAXParser p = new SaxParse().getParser("markets.xsd");
		  p.parse(filename, new MarketContentHandler());

    }

}
