package com.htc.jaxb.utils;

import java.io.File;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import forweb.BkTy;
import forweb.BksTy;
import forweb.ObjectFactory;

public class JaxbBookDaoImpl implements JaxbBooksDao {
    Marshaller marshaller;
    Unmarshaller unMarshaller;
    JAXBContext ctx;
    static String sep = File.separator;
    static final String DEST = "D:" + sep + "praeelipse" + sep + "jaxb_ws" + sep + "jaxbUse" + sep + "src" + sep + "saxExerBooks.xml";
    ObjectFactory objFactory;
    public JaxbBookDaoImpl() {
      try {	
        ctx = JAXBContext.newInstance("forweb");
        marshaller = ctx.createMarshaller();
        unMarshaller = ctx.createUnmarshaller();
        objFactory = new ObjectFactory();
      }catch(Exception ex) {
    	 ex.printStackTrace(); 
      }
    }
    public JAXBElement<BksTy> getRoot() {
    	JAXBElement<BksTy> rootJaxb = null;
    	try {   
    	ClassLoader clLoader = this.getClass().getClassLoader();
        InputStream inStream = clLoader.getResourceAsStream("saxExerBooks.xml");
        rootJaxb = (JAXBElement<BksTy>)unMarshaller.unmarshal(inStream);
      }catch(Exception ex) {
    	 ex.printStackTrace(); 
      }
      return rootJaxb;	
    }
    public void saveRootBack(JAXBElement<BksTy> changedRootNode) {
     try {
       marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
               Boolean.TRUE);
       PrintWriter out = new PrintWriter(DEST);
       marshaller.marshal(changedRootNode, out);
       out.close();
     }catch(Exception ex) {
    	 ex.printStackTrace();
     }
    }
	@Override
	public boolean addBook(BkTy book) {
		boolean ret = false;
		try {
		 JAXBElement<BksTy> rootJaxb = this.getRoot();
		 BksTy rootBooks = rootJaxb.getValue();
		 List<BkTy> list = rootBooks.getBook();
		 list.add(book);		
		 JAXBElement<BksTy> changedRootJaxb = objFactory.createBooks(rootBooks);
		 this.saveRootBack(changedRootJaxb);
		 ret = true;
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return ret;
	}

	@Override
	public boolean removeBook(String id) {
		boolean ret = false;
		try {
		 JAXBElement<BksTy> rootJaxb = this.getRoot();
		 BksTy rootBooks = rootJaxb.getValue();
		 List<BkTy> list = rootBooks.getBook();
		 list.removeIf(elt -> elt.getId().equalsIgnoreCase(id));	
		 System.out.println(list);
		 JAXBElement<BksTy> changedRootJaxb = objFactory.createBooks(rootBooks);
		 this.saveRootBack(changedRootJaxb);
		 ret = true;
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return ret;
	}

}
