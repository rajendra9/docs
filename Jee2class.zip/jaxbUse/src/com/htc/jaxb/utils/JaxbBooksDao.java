package com.htc.jaxb.utils;

import java.io.Serializable;
import forweb.BkTy;

public interface JaxbBooksDao extends Serializable {
    public boolean addBook(BkTy book);
    public boolean removeBook(String id);
    
}
