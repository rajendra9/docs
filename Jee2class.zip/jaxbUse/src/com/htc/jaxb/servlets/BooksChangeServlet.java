package com.htc.jaxb.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.htc.jaxb.utils.JaxbBookDaoImpl;
import com.htc.jaxb.utils.JaxbBooksDao;

import forweb.BkTy;


@WebServlet("/jaxbBook")
@SuppressWarnings("serial")
public class BooksChangeServlet extends HttpServlet {
	
	JaxbBooksDao dao;

	@Override
	public void init() throws ServletException {
		dao = new JaxbBookDaoImpl();
	}

	@Override
	public void destroy() {
		dao = null;
	}
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  doPost(request, response);	
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    response.setContentType("text/html"); 
		PrintWriter out = response.getWriter();	
		
		boolean ret = false;
		String act = request.getParameter("action");
		String id = request.getParameter("id").trim();
		System.out.println("***" + id);
		if(act.equalsIgnoreCase("adding")) {		
		 String name = request.getParameter("bookName").trim();
		 String author = request.getParameter("author").trim();
		 String pubDate = request.getParameter("pubDate").trim();
		 String publisher = request.getParameter("publisher").trim();
		 String costStr = request.getParameter("cost").trim();
		 double cost = Double.parseDouble(costStr);
		 BkTy book = new BkTy();
		 book.setId(id);
		 book.setName(name);
		 book.setAuthor(author);
		 book.setPubDate(pubDate);
		 book.setPublisher(publisher);
		 book.setPrice(cost);
		 ret  = dao.addBook(book);
		  if(ret) {
			   out.println("New Book with " + id + "successfully added");
			   out.flush();
		   }
	    }
		
		else if(act.equalsIgnoreCase("deleting")) {
		System.out.println("for delete");
		   ret = dao.removeBook(id);
		   if(ret) {
			   out.println("Book with " + id + "successfully removed");
			   out.flush();
		   }
		}
	}
}
