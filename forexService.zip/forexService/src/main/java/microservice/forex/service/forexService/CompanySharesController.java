package microservice.forex.service.forexService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CompanySharesController {

	@Autowired
	Environment env;
	
	@Autowired
	SharePricesRepository sharesRepository;
	
	@GetMapping("/sharePrice/company/{companyId}")
	public CompanyShare findSharePrice(@PathVariable("companyId")long companyId) {
		CompanyShare ret = sharesRepository.findById(companyId);
		ret.setPort(Integer.parseInt(env.getProperty("local.server.port")));
		return ret;
	}
}
