package microservice.forex.service.forexService;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SharePricesRepository extends JpaRepository<CompanyShare, Long> {
   CompanyShare findById(long companyId);
}
