package microservice.forex.service.forexService;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForexServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForexServiceApplication.class, args);
	
		System.out.println("Press 'Enter' to terminate");
		Scanner scan = new Scanner(System.in);
        scan.nextLine();
        System.out.println("Exiting");
        scan.close();
        System.exit(1);

	}

}

