package gormrels

class CakeItem {

  String cakeName
  int shelfLifeHours
  double cost
   
  static mapping = {
    table "CAKE_ITEMS"
    version false
    id column: "cake_item_id"
    id generator: "sequence", 
       params:[sequence:"ITEMID_SEQ"]
  } 

  static belongsTo = [bakeryShop: BakeryShop]
  static constraints = {
     cakeName(blank:false,maxSize:30,minSize:4)
     shelfLifeHours(max:240)
     cost(range:5..2000,scale:1)       
  }

  String toString(){
   "Id: " + this.id + "Name: " + this.cakeName + " ShelfLife: "+
    this.shelfLifeHours + " Cost: " + this.cost
  }

}
