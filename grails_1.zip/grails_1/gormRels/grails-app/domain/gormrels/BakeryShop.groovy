package gormrels

class BakeryShop {

  String shopName
  String address
  float turnoverLacs
  
  static constraints = {
    shopName(size: 6..20)
    address nullable: true
    turnoverLacs(range: 2.0..200.5) 
  }
  static hasMany = [cakeItems: CakeItem]    

  static mapping = {
    table "BAKERY_SHOP"
    version  false
    id column: "bakery_shop_id"
    id generator: "sequence", params: [sequence: "SHOPID_SEQ"] 
  } 

  String toString(){
   "Id: " + this.id + "Name: " + this.shopName + " Address: "+
   this.address + "Turnover: " + this.turnoverLacs
  }  


}
