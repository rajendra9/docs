package gormrels

import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class BakeryShopController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond BakeryShop.list(params), model:[bakeryShopCount: BakeryShop.count()]
    }

    def show(BakeryShop bakeryShop) {
        respond bakeryShop
    }

    def create() {
        respond new BakeryShop(params)
    }

    @Transactional
    def save(BakeryShop bakeryShop) {
        if (bakeryShop == null) {
            transactionStatus.setRollbackOnly()
            notFound()
            return
        }

        if (bakeryShop.hasErrors()) {
            transactionStatus.setRollbackOnly()
            respond bakeryShop.errors, view:'create'
            return
        }

        bakeryShop.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'bakeryShop.label', default: 'BakeryShop'), bakeryShop.id])
                redirect bakeryShop
            }
            '*' { respond bakeryShop, [status: CREATED] }
        }
    }

    def edit(BakeryShop bakeryShop) {
        respond bakeryShop
    }

    @Transactional
    def update(BakeryShop bakeryShop) {
        if (bakeryShop == null) {
            transactionStatus.setRollbackOnly()
            notFound()
            return
        }

        if (bakeryShop.hasErrors()) {
            transactionStatus.setRollbackOnly()
            respond bakeryShop.errors, view:'edit'
            return
        }

        bakeryShop.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'bakeryShop.label', default: 'BakeryShop'), bakeryShop.id])
                redirect bakeryShop
            }
            '*'{ respond bakeryShop, [status: OK] }
        }
    }

    @Transactional
    def delete(BakeryShop bakeryShop) {

        if (bakeryShop == null) {
            transactionStatus.setRollbackOnly()
            notFound()
            return
        }

        bakeryShop.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'bakeryShop.label', default: 'BakeryShop'), bakeryShop.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'bakeryShop.label', default: 'BakeryShop'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
