package gormrels

import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class CakeItemController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond CakeItem.list(params), model:[cakeItemCount: CakeItem.count()]
    }

    def show(CakeItem cakeItem) {
        respond cakeItem
    }

    def create() {
        respond new CakeItem(params)
    }

    @Transactional
    def save(CakeItem cakeItem) {
        if (cakeItem == null) {
            transactionStatus.setRollbackOnly()
            notFound()
            return
        }

        if (cakeItem.hasErrors()) {
            transactionStatus.setRollbackOnly()
            respond cakeItem.errors, view:'create'
            return
        }

        cakeItem.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'cakeItem.label', default: 'CakeItem'), cakeItem.id])
                redirect cakeItem
            }
            '*' { respond cakeItem, [status: CREATED] }
        }
    }

    def edit(CakeItem cakeItem) {
        respond cakeItem
    }

    @Transactional
    def update(CakeItem cakeItem) {
        if (cakeItem == null) {
            transactionStatus.setRollbackOnly()
            notFound()
            return
        }

        if (cakeItem.hasErrors()) {
            transactionStatus.setRollbackOnly()
            respond cakeItem.errors, view:'edit'
            return
        }

        cakeItem.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'cakeItem.label', default: 'CakeItem'), cakeItem.id])
                redirect cakeItem
            }
            '*'{ respond cakeItem, [status: OK] }
        }
    }

    @Transactional
    def delete(CakeItem cakeItem) {

        if (cakeItem == null) {
            transactionStatus.setRollbackOnly()
            notFound()
            return
        }

        cakeItem.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'cakeItem.label', default: 'CakeItem'), cakeItem.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'cakeItem.label', default: 'CakeItem'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
