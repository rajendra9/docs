package gormrels

class QueriesController {
    def sb = ''<<''
   
  def index() {
    flash.message = "From Queries Controller"
    redirect(action: "issueQrys") 
  }
  
  def issueQrys(){
  }

  
  def queryOne(){
    def shopId = params.int("shp_id")
    def bakShop = BakeryShop.get(shopId)
    sb = ''<<''
    sb << "1."
    sb << bakShop.toString()
    sb << '\r\n 2.'
    def qry = BakeryShop.where { id== shopId }
    bakShop = qry.find()
    sb << bakShop.toString()
    sb << '\r\n3.'
    bakShop = BakeryShop.find { id== shopId }
    sb << bakShop.toString()
    render sb.toString() 
  }

  def queryTwo(){
    def limitCost = Float.parseFloat(params.lmCost)
    def cakeList = CakeItem.findAllByCostLessThan(limitCost) 
    sb = ''<<''
    cakeList.each { sb << "${it}\n" }
    render sb.toString() 
  }

  def queryThree(){
    def shelfLife = params.int("shLfVal")
    def cntShelf = CakeItem.countByShelfLifeHours(shelfLife) 
    render "No-of-Items of this shelfLife-" + cntShelf 
  }

  def queryFour(){
    def shopId = params.int("shp_id")
    def bakShop = BakeryShop.get(shopId)
    sb = ''<<''
    def itemsList = bakShop.cakeItems
    itemsList.each { sb << "${it}\n" }
    render sb.toString()   
  }

  def queryFive(){
    def shopId = params.int("shp_id")
    def shop = BakeryShop.get(shopId)
    def cakeQuery = CakeItem.where { bakeryShop == shop }
    def maxCatItem = cakeQuery.find(max: 1,sort: 'cost', order: 'desc')
    render maxCatItem.toString()
   }

  def querySix(){
    def shelfQry = 
   CakeItem.where {}.projections { distinct "shelfLifeHours" } 
    def shelfList = shelfQry.list() 
    sb = ''<<''
    shelfList.each { sb << "${it}-" }
    render sb.toString()[0..-2] 
  }
   
  def querySeven(){
    def criteria = CakeItem.createCriteria()
    def ret = ""
    def results= criteria.list {
     createAlias("bakeryShop","shopAlias")
     projections {
        groupProperty("shopAlias.address")
        sum("cost")
     }     
    }  
    sb = ''<<''
    sb << "Group By Cost::"
    results.each { sb << "${it}-" }
    ret  = sb.toString()[0..-2]
    sb = ''<<''
    sb << "Group By Count::"
    criteria = CakeItem.createCriteria()
    results= criteria.list {
     createAlias("bakeryShop","shopAlias")
     projections {
        groupProperty("shopAlias.address")
        rowCount("cnt")
     } 
      order("cnt","desc")    
    }  
    results.each { sb << "${it}-" }
    ret += sb.toString()[0..-2]
    render ret  
  }

  def queryEight(){
    def bakeryQry = 
      BakeryShop.where { cakeItems.size() >= 3 } 
    def shopList = bakeryQry.list(sort: "shopName") 
    sb = ''<<''
    shopList.each { sb << "${it}--" }
    render sb.toString()[0..-3] 
  } 
  

}
