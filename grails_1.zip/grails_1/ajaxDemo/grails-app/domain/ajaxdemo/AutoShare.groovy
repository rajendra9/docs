package ajaxdemo

 

class AutoShare {

  
   
String shareName
   String location
   Date enrollDt
   Date quoteDt 
   float shareQuote
   long shareId 

   static mapping = {
     table "GR_SHARES"
     version false
     id column: "share_id", name: "shareId"
     id generator: "sequence", params: [sequence: "grshareid_seq"]  
   }

  static constraints = {
   shareName(blank: false, unique: true, maxSize: 25, minSize: 6) 
   location(blank: false)
  }


  String toString(){
    return "ShareId:" + shareId + "<br/>ShareName:" + shareName + "<br/> Enrolled-Date:" + enrollDt + "<br/>Quoted-Date:" + quoteDt + "<br/>Quote-Price:" + shareQuote         

  }



}