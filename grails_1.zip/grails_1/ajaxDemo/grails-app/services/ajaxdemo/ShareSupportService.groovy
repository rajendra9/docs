package ajaxdemo

import grails.transaction.Transactional

@Transactional
class ShareSupportService {

    @Transactional(readOnly=true) 
    def  getAllLocations() {
       def companyShares = AutoShare.list()
       println companyShares.getClass()
       def companyLocations = companyShares.location
       companyLocations = companyLocations.unique()  
       return companyLocations
    }


   @Transactional(readOnly=true) 
   def getCompanies(loc) {
      def autoShares = AutoShare.findAllByLocation(loc)
      def  shareCompanies = autoShares.shareName
      return shareCompanies
   }

   @Transactional(readOnly=true) 
   def getShareInfo(name) {
      def autoShare = AutoShare.findByShareName(name)
      println autoShare
      autoShare
  } 

}
