package ajaxdemo

import groovy.json.JsonBuilder

class AutoShareController {

  def shareSupportService

    def builder

    def showLocations(){
       builder = new JsonBuilder()
       def locs = shareSupportService.getAllLocations()
       builder.call(locs)
       render builder.toPrettyString()
    }

    def showCompanies(){
       def loc = params.loca
       builder = new JsonBuilder()
       def companies = shareSupportService.getCompanies(loc)
       builder.call(companies)
       render builder.toPrettyString()
    }

    def showCompany(){
       def company = params.company
       def autoShare = shareSupportService.getShareInfo(company)
       render autoShare.toString()
    }

    def entry(){
    }

    def index() { 
      redirect(action: "entry")
    }
   
}
