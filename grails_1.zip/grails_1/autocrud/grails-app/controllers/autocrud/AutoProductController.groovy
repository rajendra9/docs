package autocrud

import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class AutoProductController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond AutoProduct.list(params), model:[autoProductCount: AutoProduct.count()]
    }

    def show(AutoProduct autoProduct) {
        respond autoProduct
    }

    def create() {
        respond new AutoProduct(params)
    }

    @Transactional
    def save(AutoProduct autoProduct) {
        if (autoProduct == null) {
            transactionStatus.setRollbackOnly()
            notFound()
            return
        }

        if (autoProduct.hasErrors()) {
            transactionStatus.setRollbackOnly()
            respond autoProduct.errors, view:'create'
            return
        }

        autoProduct.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'autoProduct.label', default: 'AutoProduct'), autoProduct.id])
                redirect autoProduct
            }
            '*' { respond autoProduct, [status: CREATED] }
        }
    }

    def edit(AutoProduct autoProduct) {
        respond autoProduct
    }

    @Transactional
    def update(AutoProduct autoProduct) {
        if (autoProduct == null) {
            transactionStatus.setRollbackOnly()
            notFound()
            return
        }

        if (autoProduct.hasErrors()) {
            transactionStatus.setRollbackOnly()
            respond autoProduct.errors, view:'edit'
            return
        }

        autoProduct.save flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'autoProduct.label', default: 'AutoProduct'), autoProduct.id])
                redirect autoProduct
            }
            '*'{ respond autoProduct, [status: OK] }
        }
    }

    @Transactional
    def delete(AutoProduct autoProduct) {

        if (autoProduct == null) {
            transactionStatus.setRollbackOnly()
            notFound()
            return
        }

        autoProduct.delete flush:true

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'autoProduct.label', default: 'AutoProduct'), autoProduct.id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'autoProduct.label', default: 'AutoProduct'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
