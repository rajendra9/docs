package autocrud

class AutoProduct {
 
   String prodName
   float prodCost
   String customer
   Date registerDt
    
   static mapping = {
     table "GR_PRODUCTS"
     version false
     id column: "prod_id"
     id generator: "sequence",params: [sequence: "PRODID_SEQ"]
   }
   static constraints = {
    prodName (blank:false, maxSize:30, minSize:8)
   }

}