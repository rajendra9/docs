package com.htc.ciber.spring.orm.rels.ormRelDemo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.htc.ciber.spring.orm.domain.StoreOrderDto;

public interface StoreOrderRepository extends JpaRepository<StoreOrderDto, String> {

}
