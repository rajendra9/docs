export default {
  computed:{
    filteredGotPosts: function(){
        return this.gotPosts.filter((gotPost)=>{
          return gotPost.title.match(this.search);
        });
      }   
  }
}