package com.htc.ciber.spring.rest.utils;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.htc.ciber.spring.rest.domain.OrderDto;
import com.htc.ciber.spring.rest.domain.OrderTo;

@Repository
@Transactional
@SuppressWarnings("serial")
public class OrdersOrmService implements OrdersOrmDao  {
	
   private HibernateTemplate template;
   
   DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
   
   public OrderDto translateAsDto(OrderTo order) {
	   OrderDto orderEntity = new OrderDto();
	   orderEntity.setCost(order.getCost());
	   orderEntity.setCustomer(order.getCustomer());
	   orderEntity.setItems(order.getItems());
	   orderEntity.setOrderId(order.getOrderId());
	   LocalDate dt = LocalDate.parse(order.getOrderDate(), formatter);
	   orderEntity.setOrderDate(dt);
	   return  orderEntity;    
   }
   
   public OrderTo translateAsTo(OrderDto orderEntity) {
	   OrderTo order = new OrderTo();
	   order.setCost(orderEntity.getCost());
	   order.setCustomer(orderEntity.getCustomer());
	   order.setItems(orderEntity.getItems());
	   order.setOrderId(orderEntity.getOrderId());
	   LocalDate dt = orderEntity.getOrderDate();
	   String dtStr = formatter.format(dt);
	   order.setOrderDate(dtStr);
	   return  order;    
   }
   
   public OrdersOrmService() {
       super();        
   }  

   @Autowired
   public void setSessionFactory(SessionFactory sessionFactory) {
       template = new HibernateTemplate(sessionFactory);
   }
   
   
   @Override
   public List<OrderTo> getAllOrders() {
	   List<OrderTo> ret = new ArrayList<>();
       try{   
           List<OrderDto> entities =  
        		   (List<OrderDto>)template.findByNamedQuery("all.orders");
           for(OrderDto orderEntity : entities) {
        	   ret.add(this.translateAsTo(orderEntity)); 
           }
       } catch(Exception ex){
          ex.printStackTrace();   
       }
       return ret;
 
   }



   @Override
   public OrderTo getOrder(int orderId) {
		return null;
   }

   

   @Override
   public boolean saveOrder(String ordId, String ordDate, String items, double cost, String customer) {
	   boolean  ret = false;
	   OrderTo order = new OrderTo(ordId, ordDate,items, cost, customer); 
	   OrderDto orderEntity = this.translateAsDto(order);
	   try{   
	     Serializable obj = template.save(orderEntity);
	     if(!Objects.isNull(obj)){
	      System.out.println("Object Saved");
	      ret = true;
	     }
	    }catch(Exception e){
	      e.printStackTrace();	      
	    }
	    return ret;
	 }



   @Override
   public boolean updateOrder(String ordI, String newCustomer, double newCost) {
	
	 return false;
   }



   @Override
   public boolean deleteOrder(String ordId) {
	
	  return false;
   }



   

 
 
   
   
}