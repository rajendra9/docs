package com.htc.ciber.spring.rest.utils;

import java.io.Serializable;
import java.util.List;

import org.hibernate.SessionFactory;

import com.htc.ciber.spring.rest.domain.OrderTo;



public interface OrdersOrmDao extends Serializable {
	
  public List<OrderTo>  getAllOrders();
  
  public void setSessionFactory(SessionFactory sf);
  
  public OrderTo getOrder(int orderId);
 
  public boolean saveOrder(String ordId, String ordDate, String items, double cost, String customer);
  
  public boolean updateOrder(String ordI, String newCustomer, double newCost);

  public boolean deleteOrder(String ordId);
}
