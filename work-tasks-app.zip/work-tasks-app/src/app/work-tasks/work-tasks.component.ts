import { Component, OnInit } from '@angular/core';
import { WorkTask } from './work_task';
import  {TasksService}  from '../shared/tasks.service';

@Component({
  selector: 'app-work-tasks',
  templateUrl: './work-tasks.component.html',
  styleUrls: ['./work-tasks.component.css']
})
export class WorkTasksComponent implements OnInit {
  workTasks: WorkTask[];
  formVisible: boolean = false;
  constructor(private _tasksService: TasksService) { }

  ngOnInit() {
      this.workTasks = this._tasksService.getWorkTasks();
  }

}
