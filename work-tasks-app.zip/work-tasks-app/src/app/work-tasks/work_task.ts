export class WorkTask {
    taskName: string;
    dueDate: Date;
    completed?:boolean;
}