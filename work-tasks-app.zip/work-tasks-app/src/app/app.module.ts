import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {TasksService}  from './shared/tasks.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WorkTasksComponent } from './work-tasks/work-tasks.component';
import { MatButtonModule, MatDatepickerModule, MatInputModule, MatNativeDateModule, MatFormFieldModule, MatCheckboxModule, MatListModule, MatCardModule } from '@angular/material';
import { SubmittedDirective } from './shared/submitted.directive';

@NgModule({
  declarations: [
    AppComponent,
    WorkTasksComponent,
    SubmittedDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatButtonModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatListModule,
    MatCardModule,
    MatCheckboxModule
  ],
  providers: [TasksService],
  bootstrap: [AppComponent]
})
export class AppModule { }
