import { Injectable } from '@angular/core';
import { WorkTask }  from '../work-tasks/work_task';

@Injectable({
  providedIn: 'root'
})
export class TasksService {
  workTasks: WorkTask[] = [{
    taskName: 'First',
    dueDate: new Date('2019-03-10'),
    completed: true
  },
{
  taskName: 'Second',
  dueDate: new Date('2019-03-12'),
  completed: false
},
{
  taskName: 'Third',
  dueDate: new Date('2019-03-18'),
  completed: false
} ];

  constructor() { }

  getWorkTasks():WorkTask[] {
    return this.workTasks;
  }
}
