<template>
 <footer>
     <h2 >{{copyright}}-{{title}}</h2>
     
 </footer>
</template>

<script>
 
export default{
   props: {     
   title: {
      type: String      
   } 
 },
    data(){
        return{
           copyright: 'Copyright 2018 Prasad, Chennai'
        }
    },
     methods:{
       changeTitle: function() {
          this.title = 'KKKKKKKK';
       }    
 }

}

</script>
<style scoped>

</style>