package com.htc.jee.jpa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.htc.jee.jpa.domain.RepEmp;

public class RepEmpService implements RepEmpDao {

	EntityManagerFactory factory;
	EntityManager em;
	EntityTransaction trans;
	
	{
		factory = Persistence.createEntityManagerFactory("myDb");
		System.out.println("****" + factory);
		em = factory.createEntityManager();
	}
	
	@Override
	public Optional<RepEmp> findEmpById(int id) {
	  Optional<RepEmp> ret = Optional.empty();
	  trans = em.getTransaction();
	  trans.begin();
	  try {
        TypedQuery<RepEmp> query = em.createNamedQuery("one.emp",com.htc.jee.jpa.domain.RepEmp.class);		  
		query.setParameter("id", new Integer(id));
        ret = Optional.of(query.getSingleResult());        
        trans.commit();  
	  }catch(Exception ex) {
		  ex.printStackTrace();
		  trans.rollback();
	  }
	  return ret;
	}

	@Override
	public List<RepEmp> findAllEmps() {
	   List<RepEmp> ret = new ArrayList<>();
	   trans = em.getTransaction();
	   trans.begin();
	   try {
		 TypedQuery<RepEmp> query = em.createNamedQuery("all.emps",com.htc.jee.jpa.domain.RepEmp.class);		  
		 ret = query.getResultList();        
	   	 trans.commit();  
	    }catch(Exception ex) {
		  ex.printStackTrace();
		  trans.rollback();
	    }
		return ret;
	 }

	@Override
	public List<RepEmp> findEmpsBySalHigherThan(double sal) {
       List<RepEmp> ret = new ArrayList<>();
	   trans = em.getTransaction();
	   trans.begin();
	   try {
		 TypedQuery<RepEmp> query = em.createNamedQuery("all.emps",com.htc.jee.jpa.domain.RepEmp.class);		  	  
		 Stream<RepEmp> stream = query.getResultStream();
		 ret = stream.filter((RepEmp e)-> e.getSalary()>sal).collect(Collectors.toList());
		 trans.commit();  
       }catch(Exception ex) {
			  ex.printStackTrace();
			  trans.rollback();
		  }
	  return ret;
	}

	@Override
	public List<RepEmp> findEmpsByJob(String job) {
	  List<RepEmp> ret = new ArrayList<>();
	  trans = em.getTransaction();
	  trans.begin();
	  try {
	    TypedQuery<RepEmp> query = em.createNamedQuery("all.emps",com.htc.jee.jpa.domain.RepEmp.class);		  	  
	    Stream<RepEmp> stream = query.getResultStream();
	    ret = stream.filter((RepEmp e)-> e.getJob().equalsIgnoreCase(job)).collect(Collectors.toList());
	    trans.commit();  
	  }catch(Exception ex) {
		 ex.printStackTrace();
	     trans.rollback();
	  }
	  return ret;
	 }

	@Override
	public Map<String, List<RepEmp>> groupEmpsByDept() {
	   Map<String, List<RepEmp>>  ret = new HashMap<>();
	   trans = em.getTransaction();
	   trans.begin();
	   try {
		 TypedQuery<RepEmp> query = em.createNamedQuery("all.emps",com.htc.jee.jpa.domain.RepEmp.class);		  	  
		 Stream<RepEmp> stream = query.getResultStream();
		 ret = stream.collect(Collectors.groupingBy(RepEmp::getDeptName));   
	     trans.commit();  
	   }catch(Exception ex) {
		 ex.printStackTrace();
		 trans.rollback();
	   }
	  return ret;
	}

	@Override
	public void close() {
	  if(factory != null) {
		  factory.close();
	  }
	}

}
