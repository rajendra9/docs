package prajsp;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.htc.jee.jpa.RepEmpDao;
import com.htc.jee.jpa.RepEmpService;
import com.htc.jee.jpa.domain.RepEmp;

@SuppressWarnings("serial")
public class RepEmpBean implements Serializable {
   
    List<RepEmp> list;
    RepEmpDao dao;
    
    {
       dao = new RepEmpService();       
    }
   
    public List<RepEmp> getAll(){
    	list = dao.findAllEmps();
    	return list;
    }
    
    public String getEmp(int id) {
      String ret = "NA";	
      Optional<RepEmp> opt = dao.findEmpById(id);
      if(opt.isPresent()) {
    	ret = opt.get().toString(); 	
      }
      return ret;
    }
    
    public List<RepEmp> getEmpsSalaryHigher(double givenSal){
    	list = dao.findEmpsBySalHigherThan(givenSal);
    	return list;
    }
    
    public List<RepEmp> getEmpsByJob(String jb){
    	list = dao.findEmpsByJob(jb);
    	return list;
    }
    
    private String dispList(List<RepEmp> list) {
       StringBuffer sb = new StringBuffer();
       for(RepEmp emp : list) {
    	   sb.append(emp.toString());
       }
       return sb.toString();    
    }
    public String groupByDept() {
      Map<String, List<RepEmp>>	map = dao.groupEmpsByDept();
      StringBuffer sb = new StringBuffer();
      sb.append("<div align=center><h2>Employees By Department</h2><table>");
      map.forEach((k,v)-> 
      {sb.append("<tr><td style='text-decoration:underline;font-size:18px;font-weight:bold;'>"+ k +"</td></tr>");
      sb.append("<tr><td>" + this.dispList(v) + "</td></tr>");});
      sb.append("</table></div>");
      String str = sb.toString();
      sb.setLength(0);
      return str;        	
    }
    
}
