<template>
  <div v-theme:column="'wide'" id="showPosts">
    <h1>All posts</h1>
    <div v-for="gotPost in gotPosts" v-bind:key="gotPost.id" class="single-post">
        <h3 v-rainbow>{{gotPost.title}}</h3>
        <article>{{gotPost.body}}</article>
    </div>
  </div>
</template>

<script>

export default {
  
  
  data () {
    return {
     gotPosts: []
    }
  },
  methods:{

  },
  created(){
      this.$http.get('http://jsonplaceholder.typicode.com/posts')
                .then(function(data){                  
                  this.gotPosts = data.body.slice(0,12);
                });
  }
}
</script>

<style>
 #showPosts{
  max-width: 800px;
  margin: 0 auto;
 }
 .single-post{
  padding: 20px;
  margin: 20px 0;
  box-sizing: border-box;
  background: #eee; 
 }

</style>
