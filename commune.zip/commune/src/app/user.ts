export interface User {
    name: string,
    email: string,
    job: string
}
