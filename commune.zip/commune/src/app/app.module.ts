import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { EnrollService } from './enroll.service';
import { HttpClientModule }  from '@angular/common/http';
import { AppComponent } from './app.component';
import { SpringForumsComponent } from './spring-forums/spring-forums.component';
import { FormsModule }  from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
    SpringForumsComponent
  ],
  imports: [
    BrowserModule, HttpClientModule, FormsModule
  ],
  providers: [EnrollService],
  bootstrap: [AppComponent]
})
export class AppModule { }
