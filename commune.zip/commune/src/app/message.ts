export interface Message {
}
