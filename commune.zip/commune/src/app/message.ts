export interface Message {
    msg: string;
}
