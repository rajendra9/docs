import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spring-forums',
  templateUrl: './spring-forums.component.html',
  styleUrls: ['./spring-forums.component.css']
})
export class SpringForumsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
