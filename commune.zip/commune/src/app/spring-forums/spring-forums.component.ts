import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { User }  from '../user';
import { EnrollService } from '../enroll.service';
import { Message }  from '../message';
import { Observable   } from 'rxjs';

@Component({
  selector: 'app-spring-forums',
  templateUrl: './spring-forums.component.html',
  styleUrls: ['./spring-forums.component.css']
})
export class SpringForumsComponent implements OnInit {
  public feedback: Message;
  @Input() 
  forumUser: User;
  
  @Output()
  subscribe = new EventEmitter();
  
  constructor(private _enrollService : EnrollService ) { }
  subscibeToSpringForums(){
    let em = this.forumUser.email;
    let result:Observable<Message> = this._enrollService.receiveEvent(em);
    console.log(result); 
    result.subscribe({
        next: function(data){
        this.feedback = data;
      },
      error:function(err){
        console.log(err);
      }    
    });    
    this.subscribe.emit(em + this.feedback);
  }
  ngOnInit(){

  }

}