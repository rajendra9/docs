import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse} from '@angular/common/http';
import { Observable   } from 'rxjs';
import { Message }  from './Message';

@Injectable({
  providedIn: 'root'
})
export class EnrollService {

  private webUrl: string = "http://localhost:10080/anguRest/rest/ang/enroll?email=";
  constructor(private _http: HttpClient) { }
  receiveEvent(email:string) : Observable<Message> {
    return this._http.get<Message>(this.webUrl + email);      
  }

  
}
