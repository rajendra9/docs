import { Component } from '@angular/core';
import { User} from './user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public info: string;
  public forumUser: User = { name: '', email:'', job: ''}; 
  public isActivated: boolean = false;

  activate(){
    alert('hai');
    this.isActivated = true;
  }

  subscribe(email: string){    
    alert("Event emitted:"+ email);
    this.info = email;                  
  }

}
