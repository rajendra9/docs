new Vue({
    el: '#vue-compu-app',
    data:{
        cycloneRelief: 20,
        person: 0,
        organization: 0   
    },
    methods:{
      /* addFromPerson: function(){
           console.log('person add');
           return this.cycloneRelief + this.person;          
       },
       addFromOrganization: function(){
           console.log('organization add');
           return this.cycloneRelief + this.organization;                 
       }
      you have to remove braces in html file to avoid firing both methods*/ 
    },
    computed:{
        addFromPerson: function(){
            console.log('person add');
            return this.cycloneRelief + this.person;
           
        },
        addFromOrganization: function(){
            console.log('organization add');
            return this.cycloneRelief + this.organization;                 
        }
    }
})