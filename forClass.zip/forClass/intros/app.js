new Vue({
    el: '#vue-app',
    data:{
        name:'Surendran',
        course:'Javascript frameworks',
        website: 'hai.html',
        websiteTag:'<a href="hai.html">Click for Hai</a>'
    },
    methods:{
       welcome: function(person){
           return 'Hi, ' + person + ', Welcome to Vue JS, learn fast ' + this.course;
       }
    }
})