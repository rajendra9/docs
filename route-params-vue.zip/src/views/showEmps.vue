<template>
  <div id="vue-emps">
    
     <div v-for="(emp,index) in employees" v-bind:key="index">  
       <router-link v-bind:to="'/emps/'+ emp.emp_id"><span>{{emp.emp_id}}</span></router-link>
       
       <span>{{emp.emp_name}}</span>
       <span>{{emp.job}}</span>
       <span>{{emp.hire_date}}</span>
       <span>{{emp.salary}}</span>
       <span>{{emp.dept_name}}</span>
       <span>{{emp.city}}</span>    
   </div>
  </div>
</template>

<script>

export default{
data(){
    return {
      employees:[]  
    }
 },
 created(){
     this.$http.get('http://localhost:9090/vuerest/rest/vuemps/allEmps')
               .then(function(data){
                   console.log(data.body);
                   this.employees = data.body;
               });
 }
}
</script>

<style scoped>

</style>