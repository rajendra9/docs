<template>
 <div class="home">
    <h3>Welcome to Router Application<br/>
       Add An Employee</h3>
  <div id="add-emp">
  <form >
   <table>
    <tbody>
     <tr>
       <td><label>Enter Emp Id:</label></td>
       <td><input type="text" v-model.lazy="vueEmp.emp_id" /></td>
     </tr>  
     <tr>
       <td><label>Enter Emp Name:</label></td>
       <td><input type="text" v-model.lazy="vueEmp.emp_name" /></td>
     </tr>  
     <tr>
       <td><label>Select Emp Job:</label></td>
       <td><select class="mySelect" v-model.lazy="vueEmp.job">
                <option>---choose---</option>
                <option v-for="(job,index) in existing_jobs" v-bind:key="index">{{job}}</option>
           </select>
       </td>
     </tr>  
     <tr>
       <td><label>Enter Hire Date:</label></td>
       <td><input type="text" v-model.lazy="vueEmp.hire_date" /></td>
     </tr>  
     <tr>
       <td><label>Enter Salary:</label></td>
       <td><input type="text" v-model.lazy="vueEmp.salary" /></td>
     </tr>  
     <tr>
       <td><label>Enter Dept Name:</label></td>
       <td><select class="mySelect" v-model.lazy="vueEmp.dept_name">
                <option>---choose---</option>
                <option v-for="(dept,index) in existing_depts" v-bind:key="index">{{dept}}</option>
           </select>
       </td>
     </tr>  
     <tr>
       <td><label>Enter City:</label></td>
       <td><input type="text" v-model.lazy="vueEmp.city" /></td>
     </tr>  
    </tbody>
    </table>
    
    <hr/>
    <div class="buttons"><button v-on:click.prevent="saveEmp">Save Emp</button></div>
    </form> 
    <div v-if="submitted">
        {{restResult}}
    </div>  
  <div id="preview">
        <h3> Emp Preview</h3>
        <p> Emp-Id: {{vueEmp.emp_id}}</p>
        <p> Emp-Name: {{vueEmp.emp_name}} </p>
        <p> Emp-Job: {{vueEmp.job}} </p>
        <p> Hire-Date: {{vueEmp.hire_date}} </p>        
        <p> Salary: {{vueEmp.salary}} </p>
        <p> Dept Name: {{vueEmp.dept_name}} </p>
        <p> City: {{vueEmp.city}}</p>
    </div>
 </div>
</div>
</template>

<script>


export default {
  components: {
   
  },
  data(){
    return{
      vueEmp:{
          emp_id: 0,
          emp_name: '',
          job: '',
          hire_date:'',
          salary: 0.0,
          dept_name: '',
          city: ''
         },
      existing_jobs:['Administration Vice President','Administration Assistant',
      'Sales Manager','Sales Representative','Stock Manager','Programmer',
      'Finanace Manager', 'Accounting Manager', 'Accountant',
       'Marketing Manager','Marketing Representative','Shipping Clerk',
       'Stock Clerk', 'Public Accountant', 'Purchasing Clerk',
       'Public Relations Representative', 'Purchasing Manager',
       'Human Resources Representative' ],
      existing_depts:['Shipping', 'Sales', 'IT', 'Marketing',
        'Public Relations', 'Accounting', 'Administration',
        'Finance', 'Executive', 'Purchasing', 'Human Resources'],
      submitted: false,
      restResult: ''     
    }
  },
  methods:{
      saveEmp: function(){
          this.$http.post('http://localhost:9090/vuerest/rest/vuemps/saveEmp',this.vueEmp)
                    .then(function(data){
                        console.log(data);
                        this.submitted = true;
                        this.restResult=data.bodyText;
                    });
      }
   }
}
</script>
<style scoped>
.home *{
    box-sizing: border-box;
}
#add-emp{
    margin: 30px auto;
    max-width: 450px;
}
label{
    display: block;
    margin: 20px 0 10px;
}
input[type="text"] {
    display: block;
    width: 100%;
    padding: 8px;
}
#preview{
    padding: 10px 20px;
    border: 1px dotted #ccc;
    margin: 30px 0;
}
h3{
    text-decoration:underline;    
}

button{
    margin-top: 2px;
    width: 110px;
    height: 40px;
    border: 2px solid;
    text-align: center;
}
.buttons{
    margin-left: 100px;
    margin-top: 5px;
}
.mySelect{
    width: 100%;
    height: 45px;
}
</style>