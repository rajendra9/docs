<template>
 <div class="single-emp">
    <h3>Welcome to Router Application<br/>
       Single Emp Info</h3>
 <table><tr>
  <td>Emp-Id:</td><td>{{emp.emp_id}}</td></tr>
  <tr><td>Emp-Name:</td><td>{{emp.emp_name}}</td></tr>
  <tr><td>Emp-Job:</td><td>{{emp.job}}</td></tr>
  <tr><td>Emp-Hiredate:</td> <td>{{emp.hire_date}}</td></tr>
  <tr><td>Emp-Salary:</td><td>{{emp.salary}}</td></tr>
  <tr><td>Emp-Dept:</td><td>{{emp.dept_name}}</td></tr>
  <tr><td>Emp-City:</td> <td>{{emp.city}}</td></tr>
 </table>
</div>
</template>

<script>


export default {
  
  data(){
    return{
         empId: this.$route.params.id,
         isSearched: false,
         emp:{}     
    }
  },
  created(){      
          this.$http.get('http://localhost:9090/vuerest/rest/vuemps/'+this.empId)
                    .then(function(data){
                        this.isSearched = true;
                        this.emp=data.body;
                    });
      
   }
}
</script>
<style scoped>
.single-emp *{
    box-sizing: border-box;
}
.single-emp{
    margin: 0 auto;
    max-width: 850px;
}

h3{
    text-decoration:underline;    
}
.searched{
  margin-top: 3px;
  border: 2px dashed green;
}

</style>
