<template>
 <div class="updating">
    <h3>Welcome to Router Application<br/>
       Search An Employee</h3>
  <div id="update-emp">
  <form >
   <table>
    <tbody>
     <tr>
       <td><label>Enter Emp Id for Search:</label></td>
       <td><input type="text" v-model.lazy="newEmp.emp_id" /></td>
     </tr>  
     <tr>
       <td><label>Select Emp Job:</label></td>
       <td><select class="mySelect" v-model.lazy="newEmp.job">
                <option>---choose---</option>
                <option v-for="(job,index) in existing_jobs" v-bind:key="index">{{job}}</option>
           </select>
       </td>
     </tr> 
     <tr>
       <td><label>Enter Salary:</label></td>
       <td><input type="text" v-model.lazy="newEmp.salary" /></td>
     </tr> 
     <tr>
       <td><label>Enter Dept Name:</label></td>
       <td><select class="mySelect" v-model.lazy="newEmp.dept_name">
                <option>---choose---</option>
                <option v-for="(dept,index) in existing_depts" v-bind:key="index">{{dept}}</option>
           </select>
       </td>
     </tr>
    </tbody>
    </table>
    <br/>
    <hr/>
    <div class="buttons">
      <button v-on:click.prevent="updateEmp">Update Emp</button>
    </div>
    </form> 
    <div v-if="isUpdated" class="updated">
        {{updatedResult}}
    </div>    
 </div>
</div>
</template>

<script>


export default {
  components: {
   
  },
  data(){
    return{
        newEmp:{
         emp_id: 0,
         job: '',
         salary: 0.0,
         dept_name:''
        },
         isUpdated: false,
         updatedResult: '' ,
         existing_jobs:['Administration Vice President','Administration Assistant',
                        'Sales Manager','Sales Representative','Stock Manager',
                        'Programmer', 'Sr Programmer', 'Finanace Manager', 'Accounting Manager', 
                        'Accountant','Marketing Manager','Marketing Representative',
                        'Shipping Clerk', 'Stock Clerk', 'Public Accountant', 
                        'Purchasing Clerk', 'Public Relations Representative', 
                        'Purchasing Manager', 'Human Resources Representative' ],
         existing_depts:['Shipping', 'Sales', 'IT', 'Marketing',
           'Public Relations', 'Accounting', 'Administration',
            'Finance', 'Executive', 'Purchasing', 'Human Resources'],    
    }
  },
  methods:{
      updateEmp: function(){
          this.$http.put('http://localhost:9090/vuerest/rest/vuemps/updateEmp',this.newEmp)
                    .then(function(data){
                        this.isUpdated = true;
                        this.updatedResult=data.bodyText;
                    });
      }
   }
}
</script>
<style scoped>
.updating *{
    box-sizing: border-box;
}
#update-emp{
    margin: 30px auto;
    max-width: 450px;
}
label{
    display: block;
    margin: 20px 0 10px;
}
input[type="text"] {
    display: block;
    width: 100%;
    padding: 8px;
}
h3{
    text-decoration:underline;    
}
.updated{
  border: 2px dashed green;
}
button{
    margin-top: 2px;
    width: 110px;
    height: 40px;
    border: 2px solid;
    text-align: center;
}
.buttons{
    margin-left: 100px;
    margin-top: 5px;
}
.mySelect{
    width: 100%;
    height: 45px;
}
</style>
