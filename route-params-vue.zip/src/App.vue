<template>
  <div id="app">
    <div id="nav">
     <ul><li> <router-link exact to="/">Home</router-link> </li>
      <li><router-link exact to="/about">About</router-link></li>
      <li><router-link exact to="/showEmps">Show emps</router-link></li>
     
      <li><router-link exact to="/updateEmp">Update Emp</router-link></li>
    </ul>
      
      
     </div>
    <router-view/>
  </div>
</template>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

ul{
  list-style-type: none;
  text-align: center;
  margin: 0;
}
li{
  display: inline-block;
  margin: 0 10px;
}
a{
  color: #fff;
  text-decoration: none;
  padding: 6px 8px;
  border-radius: 10px;
}
#nav {
  background: #444;
  padding: 14px 0;
  margin-bottom: 20px;
}
.router-link-active{
  background: #eee;
  color: #444;
}


</style>
