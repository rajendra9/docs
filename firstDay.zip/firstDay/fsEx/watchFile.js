var fs = require('fs')
var filename = '../inputs/gen.dat'

fs.watch(filename,{
  persistent:true},
  function(event,filename){
    console.log(event +' resulted in a change in '+filename);
  });
    
