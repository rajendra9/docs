var fs = require("fs");


var data = "Indian history reflects all possible mental evolution of mankind";


var writeStream = fs.createWriteStream("D:/myNode/outputs/piped.dat");

var readStream = fs.createReadStream("D:/myNode/inputs/input.dat");

readStream.pipe(writeStream);


readStream.on('end', function(){

   console.log("piping is completed");

 });


writeStream.on('finish', function(){

   console.log("writing is compoleted"); 

});

writeStream.on('error', function(err){
  
  console.log(err.stack);

});


console.log("program ended");