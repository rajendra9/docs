const BufferList = require('bl');
var bl = new BufferList();

bl.append(new Buffer('AA'));
bl.append(new Buffer('BBB'));
bl.append('CCCC');
bl.append(new Buffer([0x4,0x3]));

console.log(bl.toString('ascii'));
console.log(bl.toString('ascii',0,9));
console.log(bl.slice(0,5).toString('ascii'));
console.log(bl.length);
console.log(bl.readUInt16BE(9));




