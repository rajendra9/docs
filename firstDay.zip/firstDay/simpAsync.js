var events = require("events");
var evtEmitter = new events.EventEmitter();
var arr = new Array(2,4,6,7,8,9,12,11);
var joined = "";
function show(){
  console.log(joined);
}
evtEmitter.on("adding", function()
  {
   joined = arr.join(":");
   setTimeout(show, 500);  
});
evtEmitter.emit("adding");
console.log("This is done");

