function async(obj){
  obj(); 
};

var myInterval = setInterval(function(){
  async(function(){
    console.log('async is done');
  });
 },500);

setInterval(function(){
  clearInterval(myInterval);
  process.exit(1);
 },2500);
