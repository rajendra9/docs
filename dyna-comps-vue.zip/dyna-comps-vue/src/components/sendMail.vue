<template>
    <div>
     <form-helper>
        <div slot="form-header">
          <h3>Form One-Contact us</h3>
          <p>Fill in this form to contact us</p>
         </div> 
         <div slot="form-fields">
           <table><tr><td>Your Name:</td>  
          <td><input type="text"  placeholder="name"  required /></td></tr>
          <tr><td><label>Your Message</label></td><td>
          <textarea rows="5" cols="55"></textarea></td></tr>
           </table>
         </div>
         <div slot="form-controls">
            <button v-on:click="handleSubmit">Send</button>
         </div>
    </form-helper>  

    </div>

</template>
<script>
import formHelper from './formHelper.vue'
export default {
 components: {
        'form-helper': formHelper
 },
  data () {
    return {

    }
  },
  methods:{
     handleSubmit: function(){
            alert('thanks for submitting form one & contacting us');
        }
    }
}
</script>
 
<style>
body{
    margin: 0;
    font-family: 'Nunito SemiBold';
}
</style>