<template>
    <div>
     <form-helper>
        <div slot="form-header">
          <h3>Form Two-Login</h3>
          <p>Enter your details to log-in</p>
         </div> 
         <div slot="form-fields">
           <table><tr><td>Username:</td>
          <td><input type="text"  placeholder="username"  required /></td></tr>
          <tr><td>Password:</td><td><input type="password"  placeholder="password"  required /></td></tr>
          </table>
         </div>
         <div slot="form-controls">
            <button v-on:click="handleSubmit">Login</button>
         </div>
    </form-helper>  

    </div>

</template>

<script>
import formHelper from './formHelper.vue'
export default {
  components: {
        'form-helper': formHelper
  },
  data () {
    return {

    }
  },
  methods:{
    handleSubmit: function(){
            alert('thanks for logging in (form two)');
    }
  }
}
</script>
 
<style>
body{
    margin: 0;
    font-family: 'Nunito SemiBold';
}
</style>