<template>
  <div>
    <keep-alive>
       <component v-bind:is="component"></component>
    </keep-alive>
   <button v-on:click="component = 'form-login'">show Form Login</button>
   <button v-on:click="component = 'form-mail'">show Form Mail</button>
     

  </div>
</template>

<script>
import login from './components/login.vue';
import sendMail from './components/sendMail.vue';

export default {
  components:{
    'form-login': login,
    'form-mail': sendMail
  },
  
  data () {
    return {
      component: 'form-login'
    }
  },
  methods:{

  }
}
</script>

<style>

</style>
