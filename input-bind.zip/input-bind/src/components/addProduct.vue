<template>
  <div id="add-product">
    <h2>Create a new Product</h2>
    <form>
        <table>
          <tr>
            <td>Enter Product Id:</td>
            <td><input type="text" v-model.lazy="product.prod_id" /></td>
          </tr>
          <tr>
            <td>Enter Product Name:</td>
            <td><input type="text" v-model.lazy="product.prod_name" /></td>
          </tr>
          <tr>
            <td>Enter Product Cost:</td>
            <td><input type="text" v-model.lazy="product.prod_cost" /></td>
          </tr>
          </table>
          <div id="radios">
            <label> Choose Supplier Name:</label><br/>
             <ul >
               <li  v-for="(suppl,index) in knownSuppliers" v-bind:key="index">
                 <input type="radio" name="supplier" v-bind:value="suppl"  v-model="product.supplier" />
                 <label>{{suppl}}</label>
               </li>               
             </ul>  
          </div>        
    </form>  
    <div id="preview">
        <h3> Product Preview</h3>
        <p> Prod-Id: {{product.prod_id}}</p>
        <p> Prod-Name: {{product.prod_name}} </p>
        <p> Prod-Cost: {{product.prod_cost}} </p>
        <p> Supplier: {{product.supplier}} </p>
    </div>
    
  </div>
</template>

<script>

export default {
  data(){
      return{
         product: {
             prod_id:0,
             prod_name:'',
             prod_cost:0.0,
             supplier:''
         },
         knownSuppliers: ['M/s Sampath Bros', 'M/s Panneer Das & Co', 'M/s Sameer Bros', 'M/s Kumaran Brothers']


      }
  }
}
</script>

<style scoped>
#add-product *{
    box-sizing: border-box;
}
#add-product{
    margin: 15px auto;
    max-width: 600px;
}
label{
    display: block;
    margin: 20px 0 10px;
}
input[type="text"] {
    display: block;
    width: 100%;
    padding: 8px;
}
#preview{
    padding: 10px 20px;
    border: 1px dotted #ccc;
    margin: 30px 0;
}
h3{
    margin-top: 10px;
}
#radios ul{
    list-style-type: none;
}   
#radios ul li{
    display: inline-block;
    margin: 0; 
}  
#radios ul label{
    margin: 2px;
    padding: 2px;
}
</style>
