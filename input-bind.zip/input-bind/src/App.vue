<template>
  <div>
    <add-product></add-product>
  </div>
</template>

<script>
import AddProduct from './components/addProduct.vue';
export default {
  components: {
    'add-product': AddProduct
  }
}
</script>

<style>
body {
  margin-top: 30px;
  font-family: 'Nunito SemiBold';
}
</style>
