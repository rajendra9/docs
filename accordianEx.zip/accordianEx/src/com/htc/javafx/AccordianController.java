package com.htc.javafx;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

public class AccordianController {

    @FXML
    TextArea taPyth;

    @FXML
    TextArea taArchi;

    @FXML
    TextArea taFar;

    private static final String PYTHA_TEXT =
            "Pythagoras made influential\ncontributions to " +
            "philosophy and\nreligion in later 6th century\n " +
            "BC.He is often revered as\n a great mathematician " +
            "and\n scientist and is best known\n for the Pythagorean " +
            "theorem\n which bears his name.\n However, because " +
            "legend \n and obfuscation cloud\n his work even more " +
            "than that\n of the  other pre-Socratic\n philosophers,"+
            "one can give \nonly a tentative account\n of his " +
            "teachings, and some\n have questioned whether\n he " +
            "contributed much to \nmathematics or natural philosophy." ;

    private static final String ARCHI_TEXT =
            "Generally considered the \ngreatest mathematician " +
            "of \nantiquity and one of the greatest\nof all time," +
            "Archimedes anticipated\n modern calculus and analysis\n " +
            "by applying concepts of\ninfinitesimals and the method " +
            "of\nexhaustion to derive and rigorously\n prove a range " +
            "of geometrical \ntheorems, including the area of \na "+
            "circle, the surface area and volume \nof a sphere, "+
            "and the area \nunder a parabola";

    private static final String FARADAY_TEXT =
           "Faraday received little formal\neducation, he " +
           "was one of the\nmost influential scientists in\nhistory."+
           "It was by his research on\nthe magnetic field around " +
           "a\nconductor carrying a direct current\nthat Faraday" +
           "established the\nbasis for the concept of the\n"+
           "electromagnetic field in physics.\nFaraday also "+
           "established\nthat magnetism could affect \nrays of "+
           "light and that there was\nan underlying relationship\n"+
           "between the two phenomena" ;



    @FXML
    void initialize(){
       this.taPyth.setText(PYTHA_TEXT);
       this.taArchi.setText(ARCHI_TEXT);
       this.taFar.setText(FARADAY_TEXT);
    }

}
