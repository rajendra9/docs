package com.jee.cdi2;


public class Welcome{
 
  static {    
    System.out.println("Welcome to Java");
   }
  
  public String welcome(String ...args){
     StringBuffer sb = new StringBuffer("Hello world!");
     int one = Integer.parseInt(args[0]);
     int two = Integer.parseInt(args[1]);    
     sb.append(" addition Gives " + (one + two));
     return sb.toString();
  }
  
}