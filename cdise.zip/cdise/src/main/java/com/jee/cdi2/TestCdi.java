package com.jee.cdi2;

import javax.enterprise.inject.Instance;
import javax.enterprise.inject.se.SeContainer;
import javax.enterprise.inject.se.SeContainerInitializer;

public class TestCdi {
	
	public static void main(String ... args) {		
		SeContainerInitializer seContainerInit =
			       SeContainerInitializer.newInstance();
		SeContainer seContainer = seContainerInit.initialize();
		Instance<SimpleService> serviceInstance = seContainer.select(com.jee.cdi2.SimpleService.class);
	    SimpleService simpleService = serviceInstance.get();
	   
	    String content = simpleService.welcomeUse();
	    System.out.println(content);
	}

}
