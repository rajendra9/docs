package com.jee.cdi2;


import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class SimpleService {

	@Inject
	private Welcome welcome;
	
	
	public String welcomeUse() {
		return welcome.welcome("87", "98");
	}
}
