import Vue from 'vue'
import App from './App.vue'

Vue.directive('myheading',{
  bind(el, binding, vnode){
    el.style.background = '#EEE8AA';
    el.style.color = '#480000';
  }
});
Vue.directive('maxtax',{
  bind(el, binding, vnode){
     let inputHandler = function(event){
       let eltVal = Number(event.target.value);
       if(eltVal>=100){
         event.target.value=0;
       }  
     }
     el.addEventListener('blur', inputHandler);
  }
})
Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
