<template>
  <div id="app">
       <h2 v-myheading>{{title}}</h2> 
       
       <label>Enter Item-Name:</label>
       <input  type="text" v-model="item_name"/><br/><br/>   
       <label>Enter Tax %:</label>
       <input v-maxtax type="text" v-model="tax"/>    
  </div>
</template>

<script>

export default {
  
  components: {
    
  },
  data(){
    return{
      title: 'Custom Directives Usage',
      item_name: '',
      tax:''
    }
  }

}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: blue;
  margin-top: 30px;
}
</style>
