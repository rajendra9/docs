package com.htc.ciber.spring.webDemo.domain;

import java.io.Serializable;

@SuppressWarnings("serial")
public class PersonTo implements Serializable {
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adharId == null) ? 0 : adharId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PersonTo other = (PersonTo) obj;
		if (adharId == null) {
			if (other.adharId != null)
				return false;
		} else if (!adharId.equals(other.adharId))
			return false;
		return true;
	}

	private String adharId;
    private String firstName;
    private String lastName;
    private String address;
    private double income;
    
    public PersonTo(String adharId, 
                  String firstName, 
                  String lastName,
                  String address,
                  double income) {
        super();
        this.adharId = adharId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.income = income;
    }

    public PersonTo() {
        // TODO Auto-generated constructor stub
    }

    public String getAdharId() {
        return adharId;
    }

    public void setAdharId(String adharId) {
        this.adharId = adharId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

	@Override
	public String toString() {
		return "PersonTo [adharId=" + adharId + ", firstName=" + firstName + ", lastName=" + lastName + ", address="
				+ address + ", income=" + income + "]";
	}

    
  
}


