package com.htc.ciber.spring.webDemo.utils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import com.htc.ciber.spring.webDemo.domain.PersonTo;

@SuppressWarnings("serial")
public class PersonService implements PersonDao {
	
	DataSource dataSource;
	JdbcTemplate jdbcTemplate;
	
	private static final String SQL_ALL = 
			  "select adhar_id, first_name, last_name, address, income from dbo.persons";
	
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}


	@Override
	public boolean savePerson(PersonTo person) {
		SimpleJdbcInsert insert =  new SimpleJdbcInsert(dataSource);
		  int result = insert.withTableName("dbo.persons")
		     .usingColumns("adhar_id", "first_name", "last_name", "address", "income")
		    .execute(new BeanPropertySqlParameterSource(person));
		  System.out.println("insert is:"+result);
		  return true;
	}

	@Override
	public boolean updatePersonAddress(String adharId, String newAddress) {
	  String sqlStr = "update dbo.persons set  address = ? where adhar_id=?";
	     
	  int rows = this.jdbcTemplate.update(sqlStr, newAddress, adharId);
	     
	  if(rows == 1) {
	  	   return true;
	  }
	  return false;
	}

	@Override
	public boolean updatePersonIncome(String adharId, double newIncome) {
		String sqlStr = "update dbo.persons set  income = ? where adhar_id=?";
	     
		  int rows = this.jdbcTemplate.update(sqlStr, new Double(newIncome), adharId);
		     
		  if(rows == 1) {
		  	   return true;
		  }
		  return false;
	}	

	@Override
	public boolean removePerson(String adharId) {
	  String sqlStr = "delete from  dbo.persons where adhar_id=?";
	     
	  int rows = this.jdbcTemplate.update(sqlStr, adharId);
		     
	  if(rows == 1) {
	   return true;
	  }
	  return false;		
	}

	private PersonTo mapRowToObject(Map<String,Object> rowMap) {
		 PersonTo ret = new PersonTo();
		 ret.setAdharId((String)rowMap.get("adhar_id"));
		 ret.setFirstName((String)rowMap.get("first_name")); 
		 ret.setLastName((String)rowMap.get("last_name")); 	    
	     ret.setAddress((String)rowMap.get("address"));
	     ret.setIncome(((BigDecimal)rowMap.get("income")).doubleValue());		    	
		 return ret;	
	 }

	@Override
	public List<PersonTo> getPersons() {
		List<PersonTo> ret = new ArrayList<>();
		   List<Map<String, Object>> rowMapList = 
				     this.jdbcTemplate.queryForList(SQL_ALL);     
		   System.out.println(rowMapList); 
		   for(Map<String,Object> rowMap : rowMapList) {
		    	 PersonTo obj = this.mapRowToObject(rowMap);
		    	 ret.add(obj);
		     }
		     return ret;
	}

	@Override
	public Optional<PersonTo> searchPerson(String adharId) {
		
		String objSql = "select adhar_id,first_name,last_name,address, income"+
                " from dbo.persons "+
                " where adhar_id=?";
        Object[] params = { adharId };
        Map<String,Object> rowMap = this.jdbcTemplate.queryForMap(objSql, params); 
        PersonTo searched = this.mapRowToObject(rowMap);	  
        return Optional.ofNullable(searched);         
	}

}
