package com.htc.ciber.spring.webDemo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.htc.ciber.spring.webDemo.domain.PersonTo;
import com.htc.ciber.spring.webDemo.utils.PersonDao;

@Controller
public class PersonController {
	
	@Autowired
	PersonDao personService;
	
	
	@GetMapping(value={"/","/home"})
	public String init() {
		return "Welcome";
	}

	
	@GetMapping("/list")
	public String list(Model model) {
		List<PersonTo> persList = personService.getPersons();
		model.addAttribute("persList", persList);
		return "persons";
	}
	
	@GetMapping("/addPerson")
	public String addPerson(Model model) {
		PersonTo person = new PersonTo();
		model.addAttribute("person", person);
		return "addPerson";
	}
	@GetMapping("/search/{adharId}")
	public String searchPerson(@PathVariable String adharId, Model model) {
		Optional<PersonTo> perOpt = personService.searchPerson(adharId);
		if(perOpt.isPresent()) {
		   model.addAttribute("searchResult", perOpt.get());
		}else {
			model.addAttribute("searchResult", "Problems in search");
		}
		return "searchedPerson";
	}
	
	@PostMapping("/search")
	public String searchPersonById(@RequestParam("id")String adharId, Model model) {
		Optional<PersonTo> perOpt = personService.searchPerson(adharId);
		if(perOpt.isPresent()) {
		   model.addAttribute("searchResult", perOpt.get());
		}else {
			model.addAttribute("searchResult", "Problems in search");
		}
		return "searchedPerson";
	}
	
	@GetMapping("/searching")
	public String toSearch(Model model) {
		return "doSearch";
	}
	
	@GetMapping("/updateAddress")
	public String toUpdateAddress(Model model) {
		return "doChangeAddress";
	}
	
	@PostMapping("/updateAddress")
	public String changePersonAddress(@RequestParam("adharId")String adharId,
			@RequestParam("newAddress")String newAddr, Model model) {
		System.out.println("Update Method");
		boolean boo = personService.updatePersonAddress(adharId, newAddr);
		if(boo) {
		   model.addAttribute("updateAddress", "Person with-" + adharId + "address Changed");
		}else {
			model.addAttribute("updateAddress", "Problems in update");
		}
		return "updatedPersonAddress";
	}
	@GetMapping("/updateIncome")
	public String toUpdateIncome(Model model) {
		return "doChangeIncome";
	}
	
	@PostMapping("/updateIncome")
	public String changePersonIncome(@RequestParam("adharId")String adharId,
			@RequestParam("newIncome")double newIncome, Model model) {
		System.out.println("Update Method");
		boolean boo = personService.updatePersonIncome(adharId, newIncome);
		if(boo) {
		   model.addAttribute("updateIncome", "Person with-" + adharId + " Income Changed");
		}else {
			model.addAttribute("updateIncome", "Problems in update");
		}
		return "updatedPersonIncome";
	}
	@PostMapping("/addPerson")
	public String savePerson(@ModelAttribute("person")PersonTo person,Model model) {
        boolean boo = personService.savePerson(person);		
		String msg = "";
		if(boo) {
			msg = "Person Object with id:" + person.getAdharId() + " has been Saved";
		}
		else {
			msg = "Problems in saving a person";
		}
        model.addAttribute("msg", msg);
		return "addedPerson";
	}

	@GetMapping("/deleting")
	public String toDelete(Model model) {
		return "doDelete";
	}
	@PostMapping("/deleting")
	public String deletePersonById(@RequestParam("adharId")String adharId, Model model) {
		boolean boo = personService.removePerson(adharId);
		if(boo) {
		   model.addAttribute("deleteResult","Person with-" + adharId + " has been removed");
		}else {
			model.addAttribute("deleteResult", "Problems in Deleting");
		}
		return "deletedPerson";
	}
	
}
