use samp;

go


drop table if exists dbo.persons;

create table dbo.persons(adhar_id varchar(15) primary key,
first_name  varchar(15), last_name varchar(15),
address varchar(50),income numeric(10,2));

insert into dbo.persons values('5432','Sudheer', 'Kumar','Tambaram, Chennai', 126000.0);
insert into dbo.persons values('4332','Janani', 'Rajan','Madurai, Chennai', 145000.0);
insert into dbo.persons values('6123','Muthu', 'Kumar','Tirunelveli, Chennai', 167000.0);
insert into dbo.persons values('7654','Sethu', 'Madhavan','Moosapet,Hyderabad', 141000.0);
insert into dbo.persons values('2543','Kesava', 'Rao,'Besant Road, Vijayawada', 206000.0);
