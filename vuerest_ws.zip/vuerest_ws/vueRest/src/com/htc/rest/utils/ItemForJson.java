package com.htc.rest.utils;

import java.io.Serializable;

import javax.json.bind.annotation.JsonbProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.json.bind.config.PropertyOrderStrategy;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@JsonbPropertyOrder(PropertyOrderStrategy.LEXICOGRAPHICAL)
@SuppressWarnings("serial")
public class ItemForJson  implements Serializable {
 
   @JsonbProperty("item_id")
   private String itemId;
   
   @JsonbProperty("item_name")
   private String itemName;
   
   @JsonbProperty("item_type")
   private String itemType;   
   
   @JsonbProperty("item_cost")
   private double  itemPrice;

   @JsonbProperty("customer")
   private String  customer;
   
   public ItemForJson(){}   

      
   public ItemForJson(String itemId, String itemName, String itemType, double itemPrice, String customer) {
	 super();
	 this.itemId = itemId;
	 this.itemName = itemName;
	 this.itemType = itemType;
	 this.itemPrice = itemPrice;
	 this.customer = customer;
   }

   
   public String getCustomer() {
	 return customer;
   }

   public void setCustomer(String customer) {
	  this.customer = customer;
   }

   
   public String getItemType() {
	return itemType;
   }


   public void setItemType(String itemType) {
	  this.itemType = itemType;
   }


   public String getItemId() {
      return  itemId;
   }
   
   public void setItemId(String id){
       this.itemId = id;
   }

   public String getItemName() {
     return  itemName;
   }
   
   public void setItemName(String name){
     this.itemName = name;
   }

   public double getItemPrice() {
      return  itemPrice;
   }
   
   public void setItemPrice(double price){
      this.itemPrice = price;
   }
        
   public String toString(){
      return this.itemId + ":" + this.itemName + ":" + this.itemPrice + ":" + this.customer;
   }

}
       
