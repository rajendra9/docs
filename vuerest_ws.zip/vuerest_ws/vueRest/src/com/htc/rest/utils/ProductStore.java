package com.htc.rest.utils;

import java.io.Serializable;

import javax.json.bind.JsonbBuilder;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


public class ProductStore implements Serializable {
  
	EntityTransaction trans;
    EntityManagerFactory factory;
    EntityManager em;
    
    {
    	factory = Persistence.createEntityManagerFactory("myDb");
        em = factory.createEntityManager();	
    }
    
    public ProductDto toDto(ProdInfo info) {
    	return new ProductDto(info.getProdId(),
    			              info.getProdName(),
    			              info.getProdCost(),
    			              info.getSupplier());    			
    }
    public ProdInfo fromDto(ProductDto dto) {
    	return new ProdInfo(dto.getProdId(),
    			            dto.getProdName(),
    			            dto.getProdCost(),
    			            dto.getSupplier());    			
    }
    
    
    public String searchRetAsJson(String id) {
	  System.out.println(id);
	  trans = em.getTransaction();
	  trans.begin();
	  ProductDto dto = new ProductDto();
	  try {
		dto = em.getReference(ProductDto.class, id);
		trans.commit();
	  }catch(Exception ex) {
		 ex.printStackTrace();
		 trans.rollback();
	  }
	 ProdInfo prod = this.fromDto(dto);
	 return JsonbBuilder.create().toJson(prod);
  }
  
  public String saveProduct(ProdInfo prod) {
	  String ret = "Problems in saving";
	  ProductDto toBeSaved = this.toDto(prod);
	  trans = em.getTransaction();
	  trans.begin();
	  try {
		em.persist(toBeSaved);
		trans.commit();
		ret = prod.toString() + " is saved.";
	  }catch(Exception ex) {
		 ex.printStackTrace();
		 trans.rollback();
	  }	  
	  return ret;
  }
 
   
  
}
