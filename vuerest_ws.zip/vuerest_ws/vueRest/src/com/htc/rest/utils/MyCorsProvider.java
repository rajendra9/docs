package com.htc.rest.utils;

import java.io.IOException;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.ext.Provider;

@Provider
public class MyCorsProvider implements ContainerResponseFilter {

    @Override
    public void filter(ContainerRequestContext reqCtx, ContainerResponseContext resCtx) throws IOException {
      resCtx.getHeaders().add("Access-Control-Allow-Origin", "*");
      resCtx.getHeaders().add("Access-Control-Allow-Headers", "origin, content-type, accept, authorization");
      resCtx.getHeaders().add("Access-Control-Allow-Credentials", "true");
      resCtx.getHeaders().add("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE, OPTIONS, HEAD");
      resCtx.getHeaders().add("Access-Control-Max-Age","1209600");
    }

}
