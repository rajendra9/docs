package com.htc.rest;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.json.bind.JsonbBuilder;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import com.htc.rest.utils.ProdInfo;
import com.htc.rest.utils.ProductStore;

@Path("/products")
public class ProductsResource {
    
	ProductStore prodStore = new ProductStore();
    
	@GET
	public String contact() {
		return "<h2>Welcome to JaxRs-2.1 Resource</h2"; 
	}
	
	@GET
	@Path("/{prodId}")
	public String  searchProduct(@PathParam("prodId") String prodId) {
	     return prodStore.searchRetAsJson(prodId);	
	}
	@POST
	@Path("/add")
	public String  saveProduct(InputStream inStream) {
		ProdInfo prod = new ProdInfo();
      try { 
		BufferedReader in = 
	    		new BufferedReader(new InputStreamReader(inStream));
	    String jsonStr = in.readLine();
	    prod = JsonbBuilder.create().fromJson(jsonStr, ProdInfo.class);;
	   
	  }catch(Exception ex) {
		   ex.printStackTrace();
	  }
	  return this.prodStore.saveProduct(prod);	
	}
	
	
}
