package com.htc.spring.boot.domain;

import java.io.Serializable;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class BasicEntity implements Serializable {
     private boolean  deleted;

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public BasicEntity(boolean deleted) {
		super();
		this.deleted = deleted;
	}

	public BasicEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
     
}
