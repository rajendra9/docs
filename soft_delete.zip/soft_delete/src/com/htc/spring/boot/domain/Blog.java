package com.htc.spring.boot.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.Loader;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

@Entity
@Table(name="blog")
@SQLDelete(sql= "update blog set deleted=true where id = ?")
@Loader(namedQuery="findBlogById")
@NamedQuery(name="findBlogById", query="select b from Blog b where b.id=:bid and b.deleted=false")
@NamedQuery(name="all.blogs", query="select b from Blog b")
@Where(clause=" deleted=false")
@SuppressWarnings("serial")
public class Blog extends BasicEntity {

	public Blog() {
		super(false);
	}

	@Override
	public String toString() {
		return "Blog [id=" + id + ", title=" + title + "]";
	}

	public Blog(boolean deleted, String id, String title) {
		super(deleted);
		this.id = id;
		this.title = title;
	}

	@Id
	private String id;
	
	@Column
	private  String title;

	public Blog(String id, String title) {
		super();
		this.id = id;
		this.title = title;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	
	
}
