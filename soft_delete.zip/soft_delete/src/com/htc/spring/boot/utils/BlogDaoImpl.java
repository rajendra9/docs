package com.htc.spring.boot.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import com.htc.spring.boot.domain.Blog;

@SuppressWarnings("serial")
public class BlogDaoImpl implements BlogDao {
	
	EntityManagerFactory factory;
	EntityManager em;
	EntityTransaction trans;
	
	{
		factory = Persistence.createEntityManagerFactory("myDb");
		System.out.println("****" + factory);
		em = factory.createEntityManager();
	}
	
	@Override
	public void showAll() {
		List<Blog> ret = new ArrayList<>();
		   trans = em.getTransaction();
		   trans.begin();
		   try {
			 TypedQuery<Blog> query = em.createNamedQuery("all.blogs",com.htc.spring.boot.domain.Blog.class);		  
			 ret = query.getResultList();        
		   	 trans.commit();  
		    }catch(Exception ex) {
			  ex.printStackTrace();
			  trans.rollback();
		    }
			ret.forEach((b) -> System.out.print("\t"+b.toString()));
	}

	

	@Override
	public Optional<Blog> searchById(String id) {
		Optional<Blog> ret = Optional.empty();
		trans = em.getTransaction();
		trans.begin();
		try {
	      TypedQuery<Blog> query = em.createNamedQuery("findBlogById", com.htc.spring.boot.domain.Blog.class);		  
		  query.setParameter("bid", id);
	        ret = Optional.ofNullable(query.getSingleResult());        
	        trans.commit();  
		  }catch(Exception ex) {
			  ex.printStackTrace();
			  trans.rollback();
		  }
		  return ret;
	}
	

	@Override
	public boolean createBlog(Blog blog) {
		boolean  ret = false;
	     trans = em.getTransaction();
	     trans.begin();
	     try {
	      em.persist(blog);
	      ret = true;
	      trans.commit();
	     }catch(Exception e) {
	       e.printStackTrace();
	       trans.rollback();
	     }
	     return  ret; 
	}

	@Override
	public boolean removeBlog(String id) {
		boolean  ret = false;
	     trans = em.getTransaction();
	     trans.begin();
	     try {
	      Blog blog = em.getReference(com.htc.spring.boot.domain.Blog.class, id);
	      em.remove(blog);
	      ret = true;
	      trans.commit();
	     }catch(Exception e) {
	       e.printStackTrace();
	       trans.rollback();
	     }
	     return  ret; 
	}

}
