package com.htc.spring.boot.utils;

import java.io.Serializable;
import java.util.Optional;

import com.htc.spring.boot.domain.Blog;

public interface BlogDao extends Serializable {
   public boolean createBlog(Blog blog);
   public boolean removeBlog(String id);
   public Optional<Blog> searchById(String id);
   public void showAll();
}
