package  testing;

import java.util.Optional;

import com.htc.spring.boot.domain.Blog;
import com.htc.spring.boot.utils.BlogDao;
import com.htc.spring.boot.utils.BlogDaoImpl;

public class TestBlogDao {
 
     
  public static void main(String[] args)
    throws java.io.IOException {
    boolean  created = false, deleted = false;
    
    System.out.println("\nBegin Inheritance-Client...\n");
    try {

     BlogDao dao =  new BlogDaoImpl();

     System.out.println("\nGot dao object..\n");
     
     Blog blog = new Blog("aaaa", "Movies");
     blog.setDeleted(false);     
     created = dao.createBlog(blog);
     System.out.println("\nStatement Blog Created is...:"
             +created);
     
     blog = new Blog("bbbb", "Cricket");
     blog.setDeleted(false);     
     created = dao.createBlog(blog);
     System.out.println("\nStatement Blog Created is...:"
             +created);
     
     blog = new Blog("cccc", "Climate");
     blog.setDeleted(false);     
     created = dao.createBlog(blog);
     System.out.println("\nStatement Blog Created is...:"
             +created);
     
     blog = new Blog("misc", "SocialSites");
     blog.setDeleted(false);     
     created = dao.createBlog(blog);     
     System.out.println("\nStatement Blog Created is...:"
                         +created);
     dao.showAll();
     deleted = dao.removeBlog("misc");
     
     Optional<Blog> opt = dao.searchById("misc");
     if(opt.isPresent()) {
    	 System.out.println(opt.get());
     }else {
    	 System.out.println("Entity not found");
     }
     dao.showAll();
 
   }catch(Exception e) {
     System.out.println(e.getMessage());
  }
 }

}