drop table if exists blog;

create table blog(id varchar(20) primary key,
deleted bit(1),
title varchar(20));


drop table if exists blog_details;

create table blog_details(details_id bigint(10) primary key,
deleted bit(1),
review varchar(200),
blog_id varchar(20) references blog(id));


