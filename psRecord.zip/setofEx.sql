drop function if exists fetch_data(varchar);

create function fetch_data(in tname varchar(20)) returns text as $htc$

declare
    results text:='';
    erec record;
    myline constant varchar := chr(10); 
begin
    tname := lower(tname);
    if(tname = 'emp') then
      for erec in select *  from emp loop
      results := results || erec.empno || '-' || erec.ename || '-' 
              || erec.job ||'-'|| erec.sal || myline;
      end loop;  
    elsif(tname = 'dept') then
      for erec in select *  from dept loop
      results := results || erec.deptno || '-' || erec.dname || '-' 
              || erec.loc || myline;
      end loop;  
    end if;
    return results;
end;
$htc$ LANGUAGE 'plpgsql';

