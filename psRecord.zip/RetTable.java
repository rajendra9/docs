package forhtc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class RetTable {
   
	public final static String URL = "jdbc:postgresql://localhost:5432/samp";
	public final static String USER = "postgres";
	public final static String PWD = "mother";
	
	
	public Connection getConnection() {
	  Connection conn = null;	
	  try {
	   DriverManager.registerDriver(new org.postgresql.Driver());
	   conn = DriverManager.getConnection(URL,  USER,  PWD);
	  }catch(SQLException sqe) {
			//System.out.println("problem in getting connection");  
			sqe.printStackTrace();
	  }
	  return conn;
	}
	public List<String> executeFunc() {
		List<String> ret = new ArrayList<>();
		ret.add("Employee Table Details");
	  Connection conn = null;
		try {
 		   conn = this.getConnection();
		   String sqlStr = "select fetch_data('emp')";
		   Statement stmt = conn.createStatement();
		   ResultSet rs = stmt.executeQuery(sqlStr);
		   while(rs.next()) {
		     ret.add(rs.getString(1));
		   } 
		   ret.add("\r\n");
		   ret.add("Dept Table Details");
		   rs.close();
		   sqlStr = "select fetch_data('dept')";
		   stmt = conn.createStatement();
		   rs = stmt.executeQuery(sqlStr);
		   while(rs.next()) {
		     ret.add(rs.getString(1));
		   } 
		}catch(SQLException sqe) {
			sqe.printStackTrace();
			System.out.println("problem in getting connection");  
	    }finally {
	    	this.closeConnection(conn);
	    }
	    return ret;
	}	
	
	public void closeConnection(Connection conn) {
	  try {	
		if(conn != null) {
			conn.close();
		}
	  }catch(SQLException sqe) {
		System.out.println("problem in closing connection");  
	  }
	}
	
	public static void main(String ... args) {
		RetTable retTable = new RetTable();		 
		List<String> resultList = retTable.executeFunc();		
	    resultList.forEach(System.out::println);
	}
	
}
