import React, { Component } from 'react';
import Todos from './components/todos';

class App extends Component {
  state = {
    todos: [
      { id: '1', content: 'buy two Pizzas'},
      { id: '2', content: 'buy Fruit Juice'},
      
    ]
  }
  render() {
    return (
      <div className="App">
      </div>
    );
  }
}

export default App;
