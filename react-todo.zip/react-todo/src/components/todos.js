import React  from 'react';

const Todos = () =>{
    return(
        <div className='todos collection'>
            
        </div>
    )

} 

export default Todos;