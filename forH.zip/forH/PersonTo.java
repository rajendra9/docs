package com.htc.jsonb;

import java.io.Serializable;

import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;


@SuppressWarnings("serial")
public class PersonTo implements Serializable {

	private String identity;
	private String firstname;
	private String lastname;
	private String occupation;
	private double income;
	private String address;
	
	public PersonTo() {
		super();		
	}

	public PersonTo(String identity, String firstname, String lastname, String occupation, double income,
			String address) {
		super();
		this.identity = identity;
		this.firstname = firstname;
		this.lastname = lastname;
		this.occupation = occupation;
		this.income = income;
		this.address = address;
	}

	public String getIdentity() {
		return identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public double getIncome() {
		return income;
	}

	public void setIncome(double income) {
		this.income = income;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "PersonTo [identity=" + identity + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", occupation=" + occupation + ", income=" + income + ", address=" + address + "]";
	}

	public static String toJsonString(PersonTo person) {
	   Jsonb jsonb = JsonbBuilder.create();
	   return jsonb.toJson(person);
	}
	
	public static PersonTo fromJsonString(String personAsJson) {
		   Jsonb jsonb = JsonbBuilder.create();
		   return jsonb.fromJson(personAsJson, PersonTo.class);
	}
	
	
}
