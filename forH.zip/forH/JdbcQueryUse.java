package advDay1;
import java.io.IOException;
import java.util.Scanner;
import java.sql.SQLException;

   
public class JdbcQueryUse {

 public static void main(String args[])throws 
   SQLException,IOException,ClassNotFoundException {
  
  JdbcQuery jq = new JdbcQuery();
  Scanner in = new Scanner(System.in);
  System.out.println("enter a table name to query");
  String table = in.nextLine();     
  jq.getRs(table);
  jq.close();
  in.close();
 }

}     