package advDay2;

import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import org.postgresql.ds.PGConnectionPoolDataSource;

public class FSBoundDataSource {

   Properties props = null;
   static final String name = "htcDS";
   Context ctx = null;
	 
	   
   public FSBoundDataSource() {	
     props = new Properties();
     try {
	    props.put(Context.INITIAL_CONTEXT_FACTORY,
	              "com.sun.jndi.fscontext.RefFSContextFactory");
	    props.put(Context.PROVIDER_URL,
	               "file:///c:/temp/postgres");
	    ctx = new InitialContext(props);
	    deployDBSourceServer(ctx,name);
	 }catch(Exception e) {
	   System.out.println("Error in constructor: "+e);
	   System.exit(1);
	 }
  } 

  public void deployDBSourceServer(Context ctx,String name){
   try {
	   PGConnectionPoolDataSource postDS = new PGConnectionPoolDataSource();
	    postDS.setPortNumber(5432);
	    postDS.setServerName("127.0.0.1");
	    postDS.setDatabaseName("samp");
	    postDS.setUser("postgres"); 
	    postDS.setPassword("mother");
        ctx.rebind(name,postDS);
   }catch(Exception e){
	   System.out.println("Error:"+e);
	   System.exit(1);
   }
  }
  public static void main(String ... args) { 
    try {
	    new FSBoundDataSource();
	    System.out.println("source was Bound");
    }catch(Exception e) {
	     System.out.println("Error in main:"+e);
	}
  }

}