package myjunit.utils;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

public class ItemStores implements Serializable {
	Set<ItemTo>  itemSet;
	   
   {
	  itemSet = new HashSet<>();
	  ItemTo item = new ItemTo(100,"Table", 12000.5);
	  itemSet.add(item);
	  
	  item = new ItemTo(200,"Carrom-Board", 6500.5);
	  itemSet.add(item);
	  
	  item = new ItemTo(300,"Easy-Chair", 14500.5);
	  itemSet.add(item);
	  
	  item = new ItemTo(400,"Book-Shelf", 8790.5);
	  itemSet.add(item);
	  
   }
   
   public Optional<ItemTo>   searchItem(int id){
	   Optional<ItemTo> ret = Optional.ofNullable(new ItemTo());
	   if(this.itemSet.contains(new ItemTo(id))) {
		   for(ItemTo item : itemSet) {
			   if(item.getItemId() == id) {
				   ret = Optional.of(item);
			       break;
			   }
		   }		   
	   }
	   return ret;
   }




}
