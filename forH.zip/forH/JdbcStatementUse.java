package advDay1;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import java.util.Scanner;
import jdbc.utils.MyDataSource;

public class JdbcStatementUse {

   public static final String DROP_TBL = 
			   "drop table if exists ap_items";
		   
   public static final String CREATE_TBL = 
	   "create table ap_items(item_id integer primary key,"+
       " item_name  varchar(25), item_cost decimal(8,2))";
   
   Connection conn;    
   
   public void getConnection(String databaseName) 
     throws Exception {
	   MyDataSource ds = 
			new MyDataSource(databaseName);  
       conn = ds.getConnection();	        
   }
	
   public void doCreateTable(Connection conn)
		   throws SQLException {
      Statement stmt = conn.createStatement();
      stmt.execute(DROP_TBL);
      stmt = conn.createStatement();
      stmt.execute(CREATE_TBL);
	  System.out.println("Table created");
	  stmt = null;
   }	   
   
   public Connection getConn() {
	return conn;
   }

   public void setConn(Connection conn) {
	  this.conn = conn;
   }


   public void doInsert(Connection conn, int id, String name, double cost) 
		   throws SQLException {
	  String insertStr = "insert into ap_items(item_id,item_name,item_cost) " +
           " values(" + id + ",'" + name + "'," + cost + ")" ;
	   
	  Statement stmt = conn.createStatement();
      int rows = stmt.executeUpdate(insertStr);
      if(rows>0) {
    	  System.out.println("Insert is successful");
      }
      stmt = null;
   }	
   public void doUpdate(Connection conn, int existingId, double newCost)
		   throws SQLException {
	 String updateStr = "update ap_items set item_cost =" + newCost +
				  " where item_id=" + existingId;
	 Statement stmt = conn.createStatement();
	 int rows = stmt.executeUpdate(updateStr);
	 if(rows>0) {
	  	  System.out.println("Update is successful");
	 }
	 stmt = null;
   }
   
   public void doDelete(Connection conn, int existingId) 
		   throws SQLException {
	  String deleteStr = "delete from  ap_items " +
			  " where item_id=" + existingId;
	  Statement stmt = conn.createStatement();
	  int rows = stmt.executeUpdate(deleteStr);
	  if(rows>0) {
		  System.out.println("Delete is successful");
	  }
	  stmt = null;
   }
   
   public void doQuery(Connection conn, int existingId) 
		   throws SQLException {
	  String qryStr = "select  item_name, item_cost from  ap_items " +
				  " where item_id=" + existingId;
	  Statement stmt = conn.createStatement();
	  ResultSet rs = stmt.executeQuery(qryStr);
	  while(rs.next()) {
	    System.out.println(rs.getInt(1) + "--" + rs.getString(2) + "--" +rs.getDouble(3));
	  }
	  stmt = null;
   }
   public void doQueryAll(Connection conn) 
		   throws SQLException { 
      String qryStr = 
    	"select item_id, item_name, item_cost from  ap_items";
					  
	  Statement stmt = conn.createStatement();
	  ResultSet rs = stmt.executeQuery(qryStr);
	  while(rs.next()) {
	    System.out.println(rs.getInt(1) + "--" + rs.getString(2) + "--" +rs.getDouble(3));
	  }
	  stmt = null;
   }
   public void close() throws SQLException {
	 if(conn != null ) {
	   conn.close();	 
	 }
   }
   public static void main(String[] args) 
      throws Exception {
     JdbcStatementUse statUsage = new JdbcStatementUse();
     statUsage.getConnection("postgres");
     
     Connection conn = statUsage.getConn();
     statUsage.doCreateTable(conn);
     
     statUsage.doInsert(conn, 100, "Sofa", 34600.4);
     statUsage.doInsert(conn, 200, "Chair", 11600.4);
     statUsage.doInsert(conn, 300, "Table", 14680.4);
     
     statUsage.doUpdate(conn, 200, 12300.4);
     
     statUsage.doQueryAll(conn);
     
     statUsage.doDelete(conn, 300);
     
     statUsage.doQuery(conn, 300);
     
     statUsage.doDelete(conn, 300);
       
     statUsage.doQueryAll(conn);
     
   }

}