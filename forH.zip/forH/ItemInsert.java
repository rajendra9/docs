package advDay1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jdbc.utils.MyDataSource;
public class ItemInsert {
	
   private static final String CREATE_SQL = 
	   "create table item1(id integer,name varchar(15),price decimal(10,2))"; 	
   
   private static final String DROP_SQL = 
		         "drop table if exists item1"; 	

   private static final String INSERT_SQL = 
	         "insert into item1 values(?,?,?)";
   private static final String VALIDATE_QRY =
     "select count(1) from item1 where id=";
   Connection con;
   Statement stmt;
   PreparedStatement pstmt;
   ResultSet rs;
   int result;
   MyDataSource ds;  
	  
   public ItemInsert() {
	 try  {
	   ds = new MyDataSource("postgres");
	   
	   con = ds.getConnection();	   	   
	   stmt = con.createStatement();
	   
	   stmt.execute(DROP_SQL);	   
	   stmt = con.createStatement();
	   
	   stmt.execute(CREATE_SQL);
	   System.out.println("table created");
	   
	   pstmt = con.prepareStatement(INSERT_SQL);
	  
	  }catch(Exception e) {        
	   System.out.println(e.toString());
	   System.exit(1);
	  }
	 }

	 public boolean validateId(int num)throws SQLException {
	  stmt = con.createStatement();
	  rs = stmt.executeQuery(VALIDATE_QRY + num);
	  if(rs.next()) {
	      result = rs.getInt(1);
	  }
	   if(result == 0){
	     return true;
	   }
	   else {
	    return false;
	   }
	  }
	  
	  public int insertRecord(int id, String name, double cost)
	   throws SQLException {
	   
	   pstmt.clearParameters();  
	   pstmt.setInt(1, id);
	   pstmt.setString(2, name);
	   pstmt.setDouble(3, cost);
	   return pstmt.executeUpdate();
	  }

	  public void closeCon() {
	    try {
	      this.con.close();
	    }catch(SQLException sqe) {
	    }
	  }
	 
	 }
