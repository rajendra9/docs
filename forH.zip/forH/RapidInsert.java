package advDay1;
import java.util.Scanner;

import java.io.IOException;
import java.sql.SQLException;


 public class RapidInsert {

 public static void main(String[] args)
   throws IOException,SQLException,ClassNotFoundException {
  int no;
  double cost;
  String numStr,costStr,nameStr;
  ItemInsert it = new ItemInsert();
  Scanner in = new Scanner(System.in);
  while(true) {
   System.out.println("Enter item's id or '0' for exit");  
   numStr = in.nextLine();
   no = Integer.parseInt(numStr);
  
   if(no == 0) {
	System.out.println("program over");   
    it.closeCon(); 
    break;
   }
   if(it.validateId(no)) {
    System.out.println("Enter item's name");
    nameStr = in.nextLine();

    System.out.println("Enter item's price");
    costStr = in.nextLine();
    cost= Double.parseDouble(costStr);

    System.out.println("row inserted :"
                  + it.insertRecord(no,nameStr,cost));
   } 
   else {
    System.out.println("This id already exists");
   }
  }  
  in.close();
 }

}   
     
  