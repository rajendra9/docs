package myjunit;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import myjunit.utils.ItemStores;
import myjunit.utils.ItemTo;


public class SearchTest {
  Scanner scan; 
  ItemStores  stores;

  @Before
  public  void init() {
    stores = new ItemStores(); 
    scan = new Scanner(System.in);
  } 

  @After
  public  void storeClose() {
    stores = null;   
    scan.close();
  }
  
  private int takeInput() {
	  System.out.println("Enter ItemId:");
	  int id = Integer.parseInt(scan.nextLine());
	  return id;
  }
  
  @Test
  public void testSearch() {
    int id = this.takeInput();
    Optional<ItemTo> searchOpt = stores.searchItem(id);
    ItemTo searched  = searchOpt.get();
    Assert.assertNotNull(searched.getItemName());
    System.out.println(searched);
    System.out.println("Testing with wrong input");
    id = this.takeInput();
    searchOpt = stores.searchItem(id);
    searched  = searchOpt.get();
    Assert.assertNull(searched.getItemName()); 
  } 


}       