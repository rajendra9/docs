package advDay1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import jdbc.utils.MyDataSource;

public class JdbcTwoSamp {

   Connection conn;
   Statement stmt;
   ResultSet rs;  

   public JdbcTwoSamp() {
	 try {   
	   conn = new MyDataSource("postgres").getConnection();
	   stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
       ResultSet.CONCUR_UPDATABLE);
       rs = stmt.executeQuery("select empno, ename, job, hiredate, sal," +
         " deptno from emp");
	 }catch(Exception e) {
	   System.out.println("Error:"+e);
	   System.exit(1);
	  }
    }

    public void printRec()throws SQLException {
	  System.out.printf("%6s%12s%10s%15s%20s%8s%n",
	           "EmpNo","EmpName","Job","Hiredate","Salary","DeptNo",null);
	  rs.beforeFirst();
	  while(rs.next()) {
	    int eno = rs.getInt("empno");
	    int dno = rs.getInt("deptno");
	    String jb = rs.getString("job");
	    double sa = rs.getDouble("sal");
	    String dt = rs.getString("hiredate");
	    String na = rs.getString("ename");
	    System.out.printf("%6d%12s%15s%14.1f%20s%8d%n",
	          eno,na,jb,sa,dt,dno,null);
	   }
    } 
	
    public int totalRecs()throws SQLException {
      rs.last();
   	  return rs.getRow();
    } 	
    
	public void showAsReceived() throws SQLException{  
	  rs.beforeFirst();
	  System.out.println("printing Retrieved records\n");
	  printRec();
	}
	
	public void showRec(int pos)throws SQLException {  
	  rs.absolute(pos);
	  System.out.println("printing Retrieved records\n");
	  int eno = rs.getInt("empno");
	    int dno = rs.getInt("deptno");
	    String jb = rs.getString("job");
	    double sa = rs.getDouble("sal");
	    String dt = rs.getString("hiredate");
	    String na = rs.getString("ename");
	    System.out.printf("%6d%12s%15s%14.1f%20s%8d%n",
	          eno,na,jb,sa,dt,dno,null);
	}
	
	public  void  insertRow(int newId, String newName, String newJob, java.sql.Date dt,double newSal, int newDeptId)throws SQLException { 
      rs.moveToInsertRow();
	  rs.updateInt("empno", newId);
	  rs.updateString("ename", newName); 
	  rs.updateDouble("sal", newSal);
	  rs.updateDate("hiredate", dt);
	  rs.updateString("job", newJob);
	  rs.updateInt("deptno", newDeptId);
	  rs.insertRow();
	  System.out.println("row inserted\n");
	}  
	
	public  void  updateRow(int empId, String newJob, double newSalary)throws SQLException { 
	  rs.afterLast();
	  while(rs.previous()) {
	    int empNum = rs.getInt(1);
	    if(empNum == empId) {
	      rs.updateDouble("sal", newSalary);
	      rs.updateString("job",newJob);
	      rs.updateRow();
	      break;
	    }
	  }
	  System.out.println("\nrow updated\n");	 
	}  
	public  void  deleteRow(int empId)throws SQLException {  
		rs.beforeFirst();
		while(rs.next()) {
		   int empNum = rs.getInt(1);
		   if(empNum == empId) {
		     	rs.deleteRow();
		     	break;
		   }
		}  
	   System.out.println("\nrow deleted\n"); 
	}	
	public  void  refreshRows()throws SQLException {  
		rs.beforeFirst();
		while(rs.next()) {
		   rs.refreshRow();
		}	 
	}
	
}
