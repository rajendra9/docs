package advDay1;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import jdbc.utils.MyDataSource;

public class JdbcQuery {
	Connection conn;
	  Statement stmt;
	  ResultSet rs;
	  ResultSetMetaData rsmd;
	  MyDataSource ds;

	 public JdbcQuery()
	   throws SQLException, ClassNotFoundException,IOException {
	    ds = new MyDataSource("postgres"); 
	    conn = ds.getConnection();    
	    stmt = conn.createStatement();
	 }

	 public String keepLength(String str, int len) {
	  if(str==null) {
	     str = "";
	  }
	  StringBuffer sb = new StringBuffer(str);
	  sb.setLength(len);
	  return sb.toString();
	 }

	 public void getRs(String table) {
	  int colCount = 0;
	  StringBuffer colBuff = new StringBuffer();
	  String temp = "";

	  try {
	   rs = stmt.executeQuery("select * from "+table);
	   rsmd = rs.getMetaData();

	   colCount = rsmd.getColumnCount();
	     
	   for(int i = 0;i<colCount;i++) {
	    temp = rsmd.getColumnName(i+1);
	    colBuff.append(this.keepLength(temp,11));    
	   }
	   System.out.println(colBuff.toString());
	   colBuff.setLength(0);
	 
	   for(int i = 0;i<75;i++) System.out.print("-");
	  
	   System.out.println();
	   while(rs.next()) {
	    
	    for(int i = 0;i<colCount;i++) {
	     
	     temp = rs.getString(i+1);
	     temp = keepLength(temp,11);
	     colBuff.append(temp);
	    }
	    System.out.println(colBuff.toString());
	    colBuff.setLength(0);    
	   }
	  }
	  catch(Exception e){
	   System.out.println(e.toString());
	  }
	 }

	 public void close()throws SQLException {
	  conn.close();
	 }

}
