package advDay1;
/* the query should not use select * from ... instead should mention the column names specifically else read only OracleResultSet will be resulted */

import  java.sql.SQLException;
import  java.sql.Connection;
import  java.sql.Statement;

import jdbc.utils.MyDataSource;

import  java.sql.ResultSet;
   
public class JdbcTwoTrial {
 
 public static void main(String[] args)throws SQLException {
	 java.sql.Date dt = 
		       java.sql.Date.valueOf("2018-02-11");
		  
	 JdbcTwoSamp samp = new JdbcTwoSamp();     
     System.out.println("Total Records:"+samp.totalRecs());
	 samp.showRec(5);
     samp.insertRow(8000, "SUNDER", "DEVELOPER", dt, 5660.0, 20);
	 samp.insertRow(2234, "NoMAN", "DEVELOPER", dt, 3260.0, 10);
	    
	 samp.printRec();
     samp.updateRow(7654, "ANALYST", 4343.6);
     samp.deleteRow(2234);
     samp.refreshRows();
     samp.printRec();  
     
 }

}