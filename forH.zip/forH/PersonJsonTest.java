package com.htc.jsonb;

public class PersonJsonTest {

  public static void main(String[] args) {
	PersonTo person = 
      new PersonTo("9843234543","Sundara", "Rajan", "Govt Job", 345600.00, "Pudukkotai");
		
	String jsonPerson = 
	  "{\"identity\":\"2324 5435 3434\",\"firstname\":\"Suchitra\"," +
	  "\"lastname\":\"Nandan\",\"occupation\":\"Private Job\","+
	  "\"income\":354667.50,\"address\":\"Madurai\"}";
	
	System.out.println(PersonTo.toJsonString(person));
	System.out.println(PersonTo.fromJsonString(jsonPerson));
	
  }

}
