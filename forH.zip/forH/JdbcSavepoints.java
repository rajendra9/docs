package advDay2;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;

import jdbc.utils.MyDataSource;

public class JdbcSavepoints {

 public static void main(String[] args)throws ClassNotFoundException, SQLException, IOException {
  MyDataSource ds = 
           new MyDataSource("postgres");
  Connection con = ds.getConnection();
  ResultSet rs;     
      
  Statement st1,st2,st3,st4,st5,st6;
      
  Savepoint sp1 = null,sp2 = null;
      
  int res1 = 0, res2 = 0, res3 = 0, res4 = 0, res5 = 0, res6 = 0;
      
  con.setAutoCommit(false);
  try  {
   st1 = con.createStatement();
   res1 = st1.executeUpdate(
           "insert into samp values(32,'ashok')");
   st2 = con.createStatement();
   res2 = st2.executeUpdate(
            "insert into samp values(34,'narayan')");
   try {
     sp1 = con.setSavepoint("SP1");
     st3 = con.createStatement();
     res3 = st1.executeUpdate(
            "insert into samp values(36,'Chandrasekhar')");
     st4 = con.createStatement();
     res4 = st2.executeUpdate(
            "insert into samp values(38,'sujana')");
     try {
       sp2 = con.setSavepoint("SP2");
       st5 = con.createStatement();
       res5 = st1.executeUpdate(
              "insert into samp values(39,'Akbar')");
       st6 = con.createStatement();
       res6 = st2.executeUpdate(
                "insert into samp values(34,'ashok')");
                   
     }
     catch(SQLException sqe1) {
      System.out.println("Inner Most catch Exit");
     try {
      con.rollback(sp2);
     }
     catch(Exception e){}
    }   
   }
   catch(SQLException sqe1) {
    System.out.println("Middle catch Exit");
    try {
     con.rollback(sp1);
    }
    catch(Exception e){}
   }  
           
 }
 catch(SQLException sqe1) {
  System.out.println("Outer most catch Exit");
   try {
    con.rollback();
   }
   catch(Exception e){}
  }
  con.commit();
  con.close();
 }

}