package com.htc.spring.react.service;

import java.io.Serializable;

import org.htc.spring.react.model.Shipment;

public interface ShipmentService extends Serializable {
    public boolean shipmentUpdateLocation(Shipment shipment); 
}
