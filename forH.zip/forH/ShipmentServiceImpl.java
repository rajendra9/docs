package com.htc.spring.react.service;

import org.htc.spring.react.model.Shipment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;


@Service
public class ShipmentServiceImpl implements ShipmentService {
    private final Logger myLogger = LoggerFactory.getLogger("ShipmentService");
	@Override
	public boolean shipmentUpdateLocation(Shipment shipment) {
		String id = shipment.getShipmentId();
		myLogger.info("Logging Data:" + id);
		try {
			Thread.sleep(2000);
		}catch(InterruptedException ex) {
			ex.printStackTrace();
		}
		myLogger.info("Shipment with id "+ id + " reached " + shipment.getDeliveryAddress());
		return true;
	}

}
