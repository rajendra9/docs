package advDay2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import org.postgresql.ds.PGConnectionPoolDataSource;

public class FSBoundDSClient {
  Properties props = null;
  static final String name = "htcDS";
  Context ctx = null;
  Connection conn = null;
  Statement stmt = null;
  ResultSet rs = null;
  ResultSetMetaData rsmd = null;

  public FSBoundDSClient(String tname) {
    props = new Properties();
	try {
	 props.put(Context.INITIAL_CONTEXT_FACTORY,
	          "com.sun.jndi.fscontext.RefFSContextFactory");
	     props.put(Context.PROVIDER_URL,
	            "file:///c:/temp/postgres");
	 ctx = new InitialContext(props);
	 doQuery(ctx,tname); 
    }catch(Exception e) {
	  System.out.println("Error in constructor: "+e);
	  System.exit(1);
	}
  } 
  public String padColumn(String col, int len) {
	  if(col == null) {
		 col = ""; 
	  }
	  StringBuilder sb = new StringBuilder(col);
	  sb.setLength(len);
	  return sb.toString();
  }
  public void doQuery(Context ctx, String tablename) {
   try {
	PGConnectionPoolDataSource postDS  = 
	 (PGConnectionPoolDataSource)ctx.lookup(name);
	  conn = postDS.getConnection();
	  stmt = conn.createStatement();
	  rs = stmt.executeQuery("select * from " + tablename);
	  rsmd = rs.getMetaData();
	  int colcnt = rsmd.getColumnCount();
	  for(int i=0;i<colcnt;i++){
	    System.out.print(this.padColumn(
	                      rsmd.getColumnName(i+1),11));
	  }
	  System.out.println("\n");
	  while(rs.next()) {
       for(int i=0;i<colcnt;i++){
	       System.out.print(this.padColumn(rs.getString(i+1),11));
	   }
	   System.out.println();
	  }
	 }catch(Exception e) {
	     System.out.println("Error:"+e);
	     System.exit(1);
	 }
 }
	  
 public static void main(String[] args){ 
  try {
    new FSBoundDSClient(args[0]);
  }catch(ArrayIndexOutOfBoundsException e) {
	System.out.println("Usage java DBSourceClient <tablename>");
	System.exit(1);
   }catch(Exception e){
	 System.out.println("Error in main:"+e);
   }
  }


}