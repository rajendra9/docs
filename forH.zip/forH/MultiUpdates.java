package advDay1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import jdbc.utils.MyDataSource;

public class MultiUpdates {
  
  public boolean myUpdate(PreparedStatement pstmt,
		  double incre, int eno)throws SQLException   {
    boolean ret = false;
	pstmt.setDouble(1,  incre);
    pstmt.setInt(2,eno);
    int rows = pstmt.executeUpdate();
    if(rows>0) {
       ret = true;
    }
    return ret;
  }
  
  public static void main(String[]  args)throws Exception {
    PreparedStatement pstmt = null;
    MyDataSource mds = new MyDataSource("postgres");
    Connection conn = mds.getConnection();       
     
    pstmt = 
      conn.prepareStatement("update emp  set sal = sal + ? " +
                                " where empno=?");
   
    Scanner scan = new Scanner(System.in);
    MultiUpdates mq = new MultiUpdates(); 
    for(int i=0;i<2;i++){
      System.out.println("Enter empno:");
      int eno  = Integer.parseInt(scan.nextLine());
      System.out.println("Enter increment");
      double incre = Double.parseDouble(scan.nextLine());
      boolean ret = mq.myUpdate(pstmt, incre, eno);
      System.out.println("Row updated is:"+ret);
    }
    scan.close();
    conn.close();
  }

}  