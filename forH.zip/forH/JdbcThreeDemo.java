package advDay2;
import  java.sql.SQLException;
import  java.sql.Connection;
import  java.sql.Statement;

import jdbc.utils.MyDataSource;

import  java.sql.Savepoint;


public class  JdbcThreeDemo {

public void doMasterChildInserts()throws Exception {
  
  MyDataSource ds = new MyDataSource("postgres");
  Connection con = ds.getConnection();
  con.setAutoCommit(false);

  Statement stmt1,stmt2;
  stmt1 = con.createStatement();
  stmt2 = con.createStatement();

  String sqlStr1 =  "insert into dept values(50,'SERVICE','DETROIT')";
  String sqlStr2 =  "insert into emp(empno,ename,sal,deptno) "+
                    "  values(2001,'SANTOSH',1500,50)";

  int result1 = 0,result2 = 0;
  Savepoint s1 = null,s2 = null;
  try {   
   s1 = con.setSavepoint("SP1");
   result1 = stmt1.executeUpdate(sqlStr1);
   try {
    s2 = con.setSavepoint("SP2"); 
    result2 = stmt2.executeUpdate(sqlStr2);   
   }catch(SQLException e) {
    con.rollback(s2);
    System.err.println("Error in insert of emp");
   }      
  }catch(SQLException se) {
    con.rollback(s1);
  }
  con.commit();

  if(result1 != 0 && result2 == 0) {
   System.out.println("Only row in dept has been inserted");
  }
  else if(result1 != 0 && result2 != 0) {
   System.out.println("Rows successfully inserted into dept,emp values");
  } 
  con.close();
 }

  public static void main(String[]  args) {
	JdbcThreeDemo demo = new JdbcThreeDemo();
	try {
		demo.doMasterChildInserts();
	}catch(Exception ex) {
	  ex.printStackTrace();	
	}
  }

}    