package simple;

public class Demo {
    
	public double addDoubles(double d1, double d2){
		return (d1+d2);
	}
}
