package simple;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class DemoTest {

	Demo demo;
	
	@Before
	public void init(){
		demo = new Demo();
	}
	
	@After
	public void finish(){
		demo = null;
	}
	@Test
	public void testAddDoubles() {
        double d1 = 5.51004;
        double d2 = 4.51004;
        double expected = 11.02008;
        double methResult = demo.addDoubles(d1, d2);
       Assert.assertEquals(0.0,expected,methResult);
	}

}
