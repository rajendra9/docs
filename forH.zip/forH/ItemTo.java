package myjunit.utils;

import java.io.Serializable;

public class ItemTo implements Serializable {
  
   private  int     itemId;
   private  String  itemName;
   private  double  itemCost;
   
   public ItemTo() {
	 super();	 
   }

   public ItemTo(int itemId, 
		         String itemName, 
		         double itemCost) {
	  super();
	  this.itemId = itemId;
	  this.itemName = itemName;
	  this.itemCost = itemCost;
   }

   public int getItemId() {
	  return itemId;
   } 

   public void setItemId(int itemId) {
	  this.itemId = itemId;
   }

   public String getItemName() {
	   return itemName;
   }

   public void setItemName(String itemName) {
	  this.itemName = itemName;
   }

   public double getItemCost() {
	  return itemCost;
   }

   public void setItemCost(double itemCost) {
	  this.itemCost = itemCost;
   }

   @Override
   public int hashCode() {
	  final int prime = 31;
	  int result = 1;
	  result = prime * result + itemId;
	  return result;
   }

   @Override
   public boolean equals(Object obj) {
	  if (this == obj)
	     return true;
      if (obj == null)
		 return false;
	  if (getClass() != obj.getClass())
		  return false;
	  ItemTo other = (ItemTo) obj;
	  if (itemId != other.itemId)
	      return false;
	   return true;
    }

    @Override
    public String toString() {
	    return "ItemTo [itemId=" + itemId + ", itemName=" + itemName + ", itemCost=" + itemCost + "]";
    }

	public ItemTo(int itemId) {
		super();
		this.itemId = itemId;
	}   
   
}
