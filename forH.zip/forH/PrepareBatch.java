package advDay2;

import java.io.IOException;
import  java.sql.Connection;
import java.sql.PreparedStatement;
import  java.sql.SQLException;

import jdbc.utils.MyDataSource;

public class PrepareBatch {
  
	int[]  empIds = {4344, 4212, 4543, 4654};
    String[] enames = {"MARVEN", "Samson", "JAGUAR", "ANTMAN"};
    double[] sals = {2800.0, 2900.0, 2780.0, 3050.0 }; 
    int[]	deptIds = {10, 20, 30, 30 }; 
	
    public void doBatchInsert()throws SQLException,IOException,ClassNotFoundException {
     if(this.empIds.length == this.enames.length && this.enames.length==this.sals.length && this.sals.length == this.deptIds.length) {
      Connection conn;
      PreparedStatement pstmt;
      String sqlStr = 
  "insert into jdbcsamp(empno, ename, sal, deptno)  values (?,?,?,?)";
      MyDataSource ds = new MyDataSource("postgres");
      conn = ds.getConnection();
      pstmt = conn.prepareStatement( sqlStr );
      for(int i=0;i<this.empIds.length;i++) {        
    	pstmt.setInt(1,this.empIds[i]);
    	pstmt.setString(2,this.enames[i]);
        pstmt.setDouble(3,this.sals[i]);
        pstmt.setInt(4,  this.deptIds[i]);
    	pstmt.addBatch();
      }	  
   	  int[] results = pstmt.executeBatch();
      for(int i=0;i<results.length;i++){
       System.out.println("affected rows "+results[i]);
      }
      conn.close();
    }
  }  
  
  public static void main(String[] args) {
	PrepareBatch prepareBatch = new PrepareBatch();
	try {
	  prepareBatch.doBatchInsert(); 
    }catch(SQLException |ClassNotFoundException | IOException ex ) {
    	 ex.printStackTrace();
    }
  }
}