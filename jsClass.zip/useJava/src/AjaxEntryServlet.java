package  htcajax;

import  java.io.IOException;
import  java.io.PrintWriter;
import  javax.servlet.http.HttpServletResponse;
import  javax.servlet.http.HttpServletRequest;
import  javax.servlet.ServletException;

import  javax.servlet.http.HttpServlet;

public class AjaxEntryServlet  extends HttpServlet {
   
 public static final String OK = "<message>valid</message>";
 public static final String NOTOK = "<message>invalid</message>";

 public void doGet(HttpServletRequest req,
                   HttpServletResponse res)
    throws IOException,ServletException  {      
   String  uname = req.getParameter("id");
   res.setContentType("application/xml");
   res.setHeader("Cache-Control","no-cache");
   PrintWriter out = res.getWriter();
   if(  uname.equalsIgnoreCase("prasad")
      ||uname.equalsIgnoreCase("santosh")
      ||uname.equalsIgnoreCase("narayanan")
      ||uname.equalsIgnoreCase("venkat")) {
    out.write(OK);
   }
   else {
    out.write(NOTOK);
   }
   out.close(); 
  }
    
 public void doPost(HttpServletRequest req,
                   HttpServletResponse res)
  throws IOException,ServletException {   
  res.setContentType("text/html");  
  PrintWriter out = res.getWriter();
 
  String  createStr = req.getParameter("create");
    
  out.println("<center><h1>Welcome to ajax validation</h1>");
  if(createStr != null) {
   if(createStr.startsWith("create")){
    out.println("<br><b> user added</b>");
   }
  }  
  out.println("</center>");
  out.close(); 
 }

}