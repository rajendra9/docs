package htcajax;

import java.io.Serializable;
import java.util.HashSet;

public final class RegAuthors extends HashSet<AuthorVO>
    implements Serializable {

 AuthorVO auth;
 public RegAuthors() {
  populateAuthors();
 }
    
 private void populateAuthors() {
  auth = new AuthorVO(100, "Vairamuthu", "Social-Life");
  auth.setPublisher("M/s A.N.Publishers");
  this.add(auth);
     
  auth =   new AuthorVO(200, "Vali", "Cinema");
  auth.setPublisher("M/s K.R.Publishers");
  this.add(auth);
     
  auth =   new AuthorVO(300, "Yugandharan", "Politics");
  auth.setPublisher("M/s Popular Publishers");
  this.add(auth);
     
  auth =   new AuthorVO(400, "Cho", "Political Satire");
  auth.setPublisher("M/s Nagesh Publishers");
  this.add(auth);
 }
    
 public boolean addAuthor(AuthorVO author) {
  return this.add(author);
 }
    
 public  boolean isAlreadyPresent(int authorISAN) {
  boolean ret = false;
  for(AuthorVO auth : this) {
   if(auth.getISAN() == authorISAN) {
    ret = true;
    break;
   }
  }
  return ret;
 }
    
 public boolean isValidISBN(int authorISAN) {
  boolean ret = false;
  int len = String.valueOf(authorISAN).length();
  if((len<4) && (authorISAN%10==0)){            
   ret = true;
  }
  return ret;
 }    
    
}