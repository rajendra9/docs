package com.htc.ciber.spring.orm.domain;


import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="store_orders")
public class StoreOrderDto implements Serializable {
 
  private  String      orderId;
  private  LocalDate   orderDate;
  private  double      totalCost;
  private  String      customer;
 
  public StoreOrderDto() {
	 super();
  }
 
  public StoreOrderDto(String orderId, LocalDate orderDate, 
	                   double totalCost, String customer) {
	 super();
	 this.orderId = orderId;
	 this.orderDate = orderDate;
	 this.totalCost = totalCost;
	 this.customer = customer;
  }

  @Id
  @Column(name="order_id")
  public String getOrderId() {
	  return orderId;
  }

  public void setOrderId(String orderId) {
	  this.orderId = orderId;
  }
  
  @Column(name="order_date")
  public LocalDate getOrderDate() {
	  return orderDate;
  }

  public void setOrderDate(LocalDate orderDate) {
	  this.orderDate = orderDate;
  }

  @Column(name="total_cost")
  public double getTotalCost() {
	  return totalCost;
  }

  public void setTotalCost(double totalCost) {
	  this.totalCost = totalCost;
  }

  @Column
  public String getCustomer() {
	  return customer;
  }

  public void setCustomer(String customer) {
	  this.customer = customer;
  }

  @Override
  public int hashCode() {
	 final int prime = 31;
	 int result = 1;
	 result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
	 return result;
  }

  @Override
  public boolean equals(Object obj) {
	  if (this == obj)
		 return true;
	  if (obj == null)
		 return false;
	  if (getClass() != obj.getClass())
	     return false;
	  StoreOrderDto other = (StoreOrderDto) obj;
	  if (orderId == null) {
		  if (other.orderId != null)
			return false;
	  } else if (!orderId.equals(other.orderId))
		  return false;
	  return true;
   }

   @Override
   public String toString() {
	      return "StoreOrderDto [orderId=" + orderId + ", orderDate=" + orderDate + ", totalCost=" + totalCost + ", customer="
			      + customer + "]";
   }

 
}