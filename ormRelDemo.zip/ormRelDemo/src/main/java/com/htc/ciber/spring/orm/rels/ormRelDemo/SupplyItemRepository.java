package com.htc.ciber.spring.orm.rels.ormRelDemo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.htc.ciber.spring.orm.domain.SupplyItemDto;
import org.springframework.stereotype.Repository;

@Repository
public interface SupplyItemRepository extends JpaRepository<SupplyItemDto, String> {

}
