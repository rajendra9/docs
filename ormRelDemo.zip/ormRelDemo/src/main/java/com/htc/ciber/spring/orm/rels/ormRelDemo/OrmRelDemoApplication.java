package com.htc.ciber.spring.orm.rels.ormRelDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.Transactional;

import com.htc.ciber.spring.orm.domain.StoreOrderDto;
import com.htc.ciber.spring.orm.domain.SupplyItemDto;


@SpringBootApplication
@EntityScan(basePackageClasses= {com.htc.ciber.spring.orm.domain.StoreOrderDto.class,
		com.htc.ciber.spring.orm.domain.SupplyItemDto.class})
@EnableJpaRepositories(basePackageClasses= {StoreOrderRepository.class, SupplyItemRepository.class})
public class OrmRelDemoApplication implements CommandLineRunner{

	@Autowired
	StoreOrderRepository storeOrderRepository;
	
	@Autowired
	SupplyItemRepository supplyItemRepository;
	
	@Override
	@Transactional
	public void run(String... args) throws Exception {
		StoreOrderDto storeDto = storeOrderRepository.getOne("c1000");
		System.out.println(storeDto);
		SupplyItemDto supplyItem = supplyItemRepository.getOne("s400");
		System.out.println(supplyItem);
		System.out.println("--------------------------------------------");
		System.out.println(supplyItem.getOrder());
	}

	public static void main(String[] args) {
		SpringApplication.run(OrmRelDemoApplication.class, args);
	}

}

