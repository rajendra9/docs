
package com.htc.ciber.spring.orm.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="item_supply")
@SuppressWarnings("serial")
public class SupplyItemDto implements Serializable {
	
	private String challanId;
	private String itemName;
	private double supplyCost;
	private int    supplyQty;
	
	private StoreOrderDto order = new StoreOrderDto();
	
	public SupplyItemDto() {
		super();	
	}
	
	public SupplyItemDto(String challanId, String itemName, int supplyQty, double supplyCost) {
		super();
		this.challanId = challanId;
		this.itemName = itemName;
		this.supplyQty = supplyQty;
		this.supplyCost = supplyCost;
	}

	@Id
	@Column(name="challan_id")
	public String getChallanId() {
		return challanId;
	}

	public void setChallanId(String challanId) {
		this.challanId = challanId;
	}
    
	@Column(name="item_name")
	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	
	@Column(name="supply_cost")
	public double getSupplyCost() {
		return supplyCost;
	}

	public void setSupplyCost(double supplyCost) {
		this.supplyCost = supplyCost;
	}

	@Column(name="item_qty")
	public int getSupplyQty() {
		return supplyQty;
	}

	@Override
	public String toString() {
		return "SupplyItemDto [challanId=" + challanId + ", itemName=" + itemName + ", supplyCost=" + supplyCost
				+ ", supplyQty=" + supplyQty + ", order=" + order + "]";
	}

	public void setSupplyQty(int supplyQty) {
		this.supplyQty = supplyQty;
	}

	@ManyToOne
	@JoinColumn(name="order_id")
	public StoreOrderDto getOrder() {
		return order;
	}

	public void setOrder(StoreOrderDto order) {
		this.order = order;
	}	
	
}
