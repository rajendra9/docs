drop table if exists item_supply;

drop table if exists store_orders;

create table store_orders(order_id varchar(15) primary key,
order_date date,customer varchar(35),total_cost decimal(8,2));

insert into store_orders values('c1000','2018-12-04', 'M/s Sadgunan Suppliers',6500.5); 
insert into store_orders values('c2000','2019-01-14', 'M/s Murugan Bros',4300.5);
insert into store_orders values('c3000','2019-02-03', 'M/s Samson Enterprises',8500.5);


create table item_supply(challan_id varchar(20) primary key, 
item_name varchar(30) not null, supply_cost float, item_qty integer,
order_id varchar(15),
constraint foreign key(order_id) references store_orders(order_id));

insert into item_supply values('s100','aaaa', 342.0, 5 ,'c1000'); 
insert into item_supply values('s200','bbbb', 232.0, 4 ,'c1000');
insert into item_supply values('s300','cccc', 132.0, 8 ,'c1000');
insert into item_supply values('s400','dddd', 542.0, 3 ,'c2000'); 
insert into item_supply values('s500','bbbb', 112.0, 5 ,'c2000');
insert into item_supply values('s600','eeee', 454.0, 5 ,'c2000');




commit;

