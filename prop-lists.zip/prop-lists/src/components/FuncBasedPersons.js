import React  from  'react';

const FuncBasedPersons = (props)=>{
    const { pers }  = props;
    const personList =  pers.map((person,index)=>{
      return (
       <div className='person' key={index}>
         <div>SSN: {person.ssn}</div>
         <div>Name: {person.name}</div>
         <div>Occupation: {person.ssn}</div>
         <div>Income: {person.income}</div>
         <div><br/></div>
       </div>
      )
    });
    return (
        <div className="PersonList">
        {personList}
        </div>
    )

}

export default FuncBasedPersons;