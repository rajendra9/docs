import React, { Component } from 'react';
import Persons from './components/Persons';
import './App.css';

class App extends Component {
  state = {
    persons: [
      {ssn: 'd324', name: 'Suneet Murugan', occupation: 'Postal Employee', income: 450000.0},
      {ssn: 'd654', name: 'Manoj Vivegan', occupation: 'Excise Employee', income: 540000.0},
      {ssn: 'd546', name: 'Vinay Karthikeyan', occupation: 'Business', income: 340000.0},
      {ssn: 'd876', name: 'Muthu Kumar', occupation: 'Revenue Employee', income: 375000.0},
      ]
  }
  render() {
    return (
      <div className="App">
        <h1>Persons Details</h1>
        <Persons pers={this.state.persons} />
      </div>
    );
  }
}

export default App;
