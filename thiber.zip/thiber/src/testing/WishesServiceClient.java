package testing;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;

import com.spring4.hibers.WishDAO;
import com.spring4.hibers.Wishes;

public class WishesServiceClient {
 
  
  public static void main(String[] args) {
   try {   
    
    
 AnnotationConfigApplicationContext factory =
      new AnnotationConfigApplicationContext(com.spring4.hibers.AppOrmConfig.class);
        
        WishDAO dao = 
            (WishDAO)factory.getBean("wishService"); 
            LocalDate dt = LocalDate.of(2016,Month.APRIL, 21);        
            Wishes wishes =
                new Wishes(180,9834554336L,
                        "RadheShyam",
                        "Congratulations for Success In Exams",
                        dt);
        dao.saveWish(wishes); 
        List<Wishes> wishList = dao.getAllWishes();
        wishList.forEach(System.out::println);
        boolean isUpdated = dao.updateContact("Madhavan", 9865555555L);
        System.out.println("Madhavan contact updated:"+isUpdated);
        wishList = dao.getAllWishes();
        wishList.forEach(System.out::println);
        factory.close();
     }
      catch(Exception e) {
         e.printStackTrace();
      }
    } 

}