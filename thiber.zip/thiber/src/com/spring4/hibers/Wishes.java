package com.spring4.hibers;

import java.time.LocalDate;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Column;
import javax.persistence.Entity;


@Entity
@Table(name="MAILWISHES")
@NamedQuery(name="allWishes",query="select w from Wishes w")
@NamedQuery(name="allPersons",query="select w from Wishes w where w.targetPerson=:per")
@SuppressWarnings("serial")
public class Wishes implements java.io.Serializable {

   private  int      senderId;
   private  String   targetPerson;
   private  long     senderPhoneNum;
   private  String   wishMessage;
   private  LocalDate     sendDate;
   
   public Wishes() {
   }

   public Wishes(
              int senderId,
              long senderPhoneNum,
              String targetPerson,
              String wishMessage,
              LocalDate sendDate) {
    super();
    this.senderId = senderId;
    this.senderPhoneNum = senderPhoneNum;
    this.targetPerson = targetPerson;
    this.wishMessage = wishMessage;
    this.sendDate = sendDate;
  }

  
  @Id
  @Column(name="SENDER_ID")
  public int getSenderId() {
    return this.senderId;
  }

  public void setSenderId(int senderId) {
    this.senderId = senderId;
  }

  @Column(name="TARGET_PERSON")
  public String getTargetPerson() {
    return this.targetPerson;
  }

  public void setTargetPerson(String targetPerson) {
    this.targetPerson = targetPerson;
  }

  @Column(name="SENDER_PHONE_NUM")
  public long getSenderPhoneNum() {
    return this.senderPhoneNum;
  }

  public void setSenderPhoneNum(long senderPhoneNum) {
    this.senderPhoneNum = senderPhoneNum;
  }

  @Column(name="MESSAGE")
  public String getWishMessage() {
    return this.wishMessage;
  }

  public void setWishMessage(String wishMessage) {
    this.wishMessage = wishMessage;
  }

  @Column(name="SEND_DATE")
  public LocalDate getSendDate() {
    return this.sendDate;
  }

  public void setSendDate(LocalDate sendDate) {
    this.sendDate = sendDate;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + this.senderId;
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
        return true;
    if (obj == null)
        return false;
    if (getClass() != obj.getClass())
        return false;
    Wishes other = (Wishes) obj;
    if (this.senderId != other.senderId)
        return false;
    return true;
  }

  @Override
  public String toString() {
    return "Wishes [senderId=" + this.senderId + ", senderPhoneNum="
            + this.senderPhoneNum + ", targetPerson=" + this.targetPerson
            + ", wishMessage=" + this.wishMessage + ", sendDate="
            + this.sendDate + "]";
  }  
 
}