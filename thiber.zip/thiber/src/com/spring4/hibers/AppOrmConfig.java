package com.spring4.hibers;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AdviceMode;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;

@PropertySource("file:./jdbc.properties")
@Configuration
@ComponentScan("com.spring4.hibers")
@EnableTransactionManagement(proxyTargetClass=true,mode=AdviceMode.PROXY)
public class AppOrmConfig {  

    @Autowired Environment env;    


    @Bean
    public LocalSessionFactoryBean sessionFactory() {
     LocalSessionFactoryBean asFactoryBean =
                     new LocalSessionFactoryBean();
     asFactoryBean.setDataSource(dataSource());
     Properties props = new Properties();
     props.put("hibernate.dialect","org.hibernate.dialect.PostgreSQLDialect");
     props.put("hibernate.cglib.use_reflection_optimizer","true");
     props.put("hibernate.format_sql", "true");
     props.put("hibernate.show_sql","true");
     asFactoryBean.setPackagesToScan(
          new String[]{"com.spring4.hibers"});
     asFactoryBean.setHibernateProperties(props);
     System.out.println("HHH"+asFactoryBean);
     return asFactoryBean;
    }
    
    
    @Bean
    public DataSource dataSource() {
     DriverManagerDataSource ds =
             new DriverManagerDataSource();   
     String driverCl = env.getProperty("db.driver");
     ds.setDriverClassName(driverCl);
     ds.setUrl(env.getProperty("db.url"));
     System.out.println(env.getProperty("db.password"));
     ds.setUsername(env.getProperty("db.username"));
     ds.setPassword(env.getProperty("db.password"));
     System.out.println("***"+ds);
     return ds;
    }  
    
    @Bean
    public PlatformTransactionManager annotationDrivenTransactionManager(){
        return new HibernateTransactionManager(sessionFactory().getObject());
    }
   
}