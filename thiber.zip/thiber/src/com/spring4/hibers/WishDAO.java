package com.spring4.hibers;

import java.io.Serializable;
import java.util.List;

public interface WishDAO extends Serializable {

  void saveWish(Wishes wishes);
  List<Wishes> getAllWishes();
  boolean updateContact(String person, long newPhoneNum);
}
