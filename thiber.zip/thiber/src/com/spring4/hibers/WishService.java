package com.spring4.hibers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
@SuppressWarnings("serial")
public class WishService implements WishDAO  {
	
   private HibernateTemplate template;
   
  
   @Autowired
   public void setSessionFactory(SessionFactory sessionFactory) {
       template = new HibernateTemplate(sessionFactory);
   }

   public WishService() {
        super();        
   }  

   public void saveWish(Wishes wish) { 
    try{   
      Serializable obj = template.save(wish);
      if(!Objects.isNull(obj)){
          System.out.println("Object Saved");
      }
    }catch(Exception e){
        e.printStackTrace();
        throw new RuntimeException(e.getMessage());
    }
   }

   @SuppressWarnings("unchecked")
    public List<Wishes> getAllWishes() {
       List<Wishes> ret = new ArrayList<>();
       try{   
           List<Wishes> li =  (List<Wishes>)template.findByNamedQuery("allWishes");
           ret.addAll(li);
       } catch(Exception ex){
          ex.printStackTrace();   
       }
       return ret;
   }

   @SuppressWarnings("unchecked")
   public boolean updateContact(String person, long newPhoneNum) {
    boolean ret = false;
      
    try{   
        List<Wishes> existing = (List<Wishes>)template.findByNamedQueryAndNamedParam("allPersons", "per", person);
       
        for(Wishes wish : existing){
            wish.setSenderPhoneNum(newPhoneNum);
            template.update(wish);
        }
        ret = true;
    } catch(Exception ex){
       ex.printStackTrace();   
    }
    return ret;
}
   
   
}