drop  table if exists  mailwishes;


create table Mailwishes(
 sender_id integer constraint mailwishes_PK primary key,
 sender_phone_num bigint,
 target_person  varchar(30) not null,
 message varchar(80),
 send_date date);

insert into Mailwishes values(100, 9435461154, 'Gopalan','All The best in Exams','2016-09-02');
insert into Mailwishes values(120, 9325461789, 'Madhavan','Pongal Greetings','2016-01-14');
insert into Mailwishes values(110, 23451154, 'Sravanan','Wish You Best Of Luck','2016-08-12');
insert into Mailwishes values(150, 9325461789, 'Madhavan','Happy Birthday wishes','2016-07-22');
commit;

select *  from Mailwishes;