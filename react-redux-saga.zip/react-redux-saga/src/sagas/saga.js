import { delay} from 'redux-saga';
import { takeLatest, put }  from 'redux-saga/effects';
//import { takeEvery} from 'redux-saga/effects';
function* fundsUpAsync(){
    yield delay(4000);
    yield put({ type: 'FUNDS_UP_ASYNC', value: 1000.0})
} 

export function* watchFundsUp(){
    yield takeLatest('FUNDS_UP', fundsUpAsync)
}