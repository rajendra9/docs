

const initialState ={
   funds: 5000.0
}
const fundsReducer = (state = initialState, action) =>{
   const newState = {...state};
   switch(action.type){
     case 'FUNDS_UP_ASYNC':
         newState.funds += action.value;
         break;
     case  'FUNDS_DOWN':
        newState.funds -= action.value;
        break;
     default: newState.funds += 0;   
              break;
   }
   return newState;
}

export default fundsReducer;