import React, { Component } from 'react';
import './App.css';
import {connect} from 'react-redux';

class App extends Component {
  render() {
    return (
      <div className="App">
        <div>Society Amount:<span>{this.props.funds}</span></div><br/>
        <button onClick={this.props.onFundsUp}>Funds Deposit</button><br/><br/>
        <button onClick={this.props.onFundsDown}>Funds Spend</button><br/>         
      </div>
    );
  }
}
const  mapStateToProps = (state)=>{
 return {
   funds: state.funds
 }
};

const mapDispatchToProps = (dispatch)=>{
  return {
    onFundsUp : ()=> dispatch({type: 'FUNDS_UP'}),
    onFundsDown : ()=> dispatch({type: 'FUNDS_DOWN'}),
   }
};



export default connect(mapStateToProps, mapDispatchToProps)(App);
