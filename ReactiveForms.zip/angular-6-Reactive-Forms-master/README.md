Reactive forms is an Angular technique for creating forms in a reactive style.

Angular Reactive Forms: trigger validation on submit

Reactive forms and form validation with Angular

Angular 6 presents two different methods for creating forms, template-driven or reactive. We’re going to explore the absolute fundamentals of the reactive Angular forms, covering ngForm, ngModel, ngModelGroup, submit events, validation and error messages.
