import { ShowBranchesDirective } from './show-branches.directive';

describe('ShowBranchesDirective', () => {
  it('should create an instance', () => {
    const directive = new ShowBranchesDirective();
    expect(directive).toBeTruthy();
  });
});
