import { Component, Input, OnInit } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
  city: string; 
  branches: Array<string>;
  myShow: boolean = false;
  selectedBranch:string = '';
  getBranchesInCity(cty){
   if(cty === 'Chennai'){
      this.branches = []; 
      this.branches.push('Nandanam');
      this.branches.push('Pursuvakkam');
      this.branches.push('Kotturpuram');
      this.branches.push('Guindy');
      this.branches.push('Teynampet');
      this.branches.push('Saidapet');
      this.branches.push('Mambalam');
    }
    else if(cty === 'Hyderabad'){
      this.branches = []; 
      this.branches.push('Saidabad');
      this.branches.push('Moosapet');
      this.branches.push('Gandipeta');
      this.branches.push('Musheerabad');
      this.branches.push('Nallakunta');
      this.branches.push('Ameerpet');
      this.branches.push('Malakpet');
    }
   }
   change(event){
     this.myShow = true;
     console.log(this.city);
     this.getBranchesInCity(this.city);
     console.log(this.branches);
    } 
    
   changeMyShow(event){
     this.myShow = false;
   } 
  
}
