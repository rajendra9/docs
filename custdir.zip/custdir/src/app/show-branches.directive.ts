import { Directive, Input, OnChanges, ViewContainerRef ,TemplateRef } from '@angular/core';

@Directive({
  selector: '[appShowBranches]'
})

export class ShowBranchesDirective implements OnChanges {   
  @Input() appShowBranchesOf:Array<any>
  constructor(private container: ViewContainerRef,
     private template: TemplateRef<any>) { }

 ngOnChanges(){
   for(const input of this.appShowBranchesOf){
    this.container.createEmbeddedView(this.template,{$implicit:input});
  }
 }    
}
