import React, { Component } from 'react';

import './App.css';

class App extends Component {
  constructor(){
    super();
    this.state = {
       persons: [],
       Person: {}
    }
  }
  keyupHandler = (event,lbl)=>{
    let keycode = event.keycode;
    if(keycode === 13){
    switch(lbl){
      case 'fn': this.lnInput.focus();
                 break;
      case 'ln': this.icInput.focus();
                 break;
      case 'ic': this.smInput.focus();
                 break;
      default:  this.fnInput.focus();
                break;
    }
   }
  }
  send(event){
     const person = Object.assign({}, this.state.Person);
     const personsCopy = Object.assign([], this.state.persons); 
     person.firstName = this.fnInput.value;
      person.lastName = this.lnInput.value;
      person.income = this.icInput.value;
      personsCopy.push(person);     
      this.setState({state: {persons: personsCopy}});
      console.log(personsCopy);
  }
  render() {
    return (
      <div className="App">
        <div>
          <table>
           <tbody>
           <tr>
             <td><label>Enter FirstName:</label></td>
             <td>
               <input type="text"
                 ref={(input) => {this.fnInput=input}} 
                 onKeyUp={this.keyupHandler.bind(this,'fn')}  />
              </td>
           </tr>
           <tr>
             <td><label>Enter LastName:</label></td>
             <td>
               <input type="text" 
                 ref={(input) => {this.lnInput=input}} 
                 onKeyUp={this.keyupHandler.bind(this,'ln')} /></td>
           </tr>
           <tr>
             <td><label>Enter Income:</label></td>
             <td>
               <input type="text" 
                 ref={(input) => {this.icInput=input}} 
                 onKeyUp={this.keyupHandler.bind(this,'ic')}
                 /></td>
           </tr>
           <tr>
             <td colSpan="2"><input type="submit" onClick={this.send.bind(this)} ref={(input) => {this.smInput=input}} /></td>
           </tr>
       
          </tbody>
          </table>
          
        </div>
      </div>
    );
  }
}

export default App;
