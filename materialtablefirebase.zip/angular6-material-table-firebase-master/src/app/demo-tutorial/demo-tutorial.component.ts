import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-tutorial',
  templateUrl: './demo-tutorial.component.html',
  styleUrls: ['./demo-tutorial.component.css']
})
export class DemoTutorialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
