drop table if exists class_room;

drop type if exists student_ty;

--systems creates an array type as _student_ty
create type student_ty as (stu_id int,stu_name varchar(15),age int,address varchar(20));


create table class_room(course varchar(10),course_year int,teacher varchar(15),
   students text[],
   constraint class_room_pk primary key(course,course_year));

insert into class_room( course,course_year,teacher,students)
 select 'B.Sc',1,'Pankaj Raj',
                              '{(11,''Uday'',23,''Tambaram''),
                                (25,''HansRaj'',23,''Pammal''),
                                (13,''Vikatan'',23,''ChromePet''),
                                (15,''Venkateshan'',23,''Guindy'')}'; 
insert into class_room( course,course_year,teacher,students)
 select 'B.C.A',1,'Muthu Kumar',
                              '{(21,''Nirmal'',23,''Mambalam''),
                                (44,''VedRaj'',23,''Avadi''),
                                (54,''Varun'',23,''Pallavaram''),
                                (65,''Vinayakan'',24,''Nanganallur'')}'; 
                                                                  
 select  students from class_room where course='B.C.A' and course_year=1     


