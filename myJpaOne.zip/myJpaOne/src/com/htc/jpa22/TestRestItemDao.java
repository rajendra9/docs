package com.htc.jpa22;

public class TestRestItemDao {

	public static void main(String[] args) {
		RestItemDao dao = new RestItemService();
		RestItem item = new RestItem("s3245", "Computer Chair", 4300.5, "M/s Vivegam Decors");
        boolean ret = dao.saveItem(item);
        System.out.println("Item Saved is true");
        dao.close();
	}

}
