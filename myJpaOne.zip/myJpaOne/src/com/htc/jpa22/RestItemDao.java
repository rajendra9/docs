package com.htc.jpa22;

import java.io.Serializable;

public interface RestItemDao extends Serializable {
	
  public boolean saveItem(RestItem item);
  public void close();
  
}
