package com.htc.jpa22;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class RestItemService implements RestItemDao {
    
	EntityManagerFactory factory;
	EntityManager em;
	EntityTransaction trans;
	
	{
		factory = 
		    Persistence.createEntityManagerFactory("myJpaOne");
	    em = factory.createEntityManager();
	}
	
	
	@Override
	public boolean saveItem(RestItem item) {
		boolean ret = false;
		trans = em.getTransaction();
		trans.begin();
		try {
		   em.persist(item);	
		   ret = true;
		   trans.commit();
		}catch(Exception ex) {
			ex.printStackTrace();
			trans.rollback();
		}
		return ret;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

}
