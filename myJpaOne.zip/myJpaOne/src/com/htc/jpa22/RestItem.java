package com.htc.jpa22;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;



@Entity
@Table(name="rest_items")
@NamedQuery(name="RestItem.findAll", query="SELECT r FROM RestItem r")
public class RestItem implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public RestItem(String itemId,  String itemName, double itemPrice, String customer) {
		super();
		this.itemId = itemId;
		this.customer = customer;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
	}

	@Id
	@Column(name="item_id")
	private String itemId;

	private String customer;

	@Column(name="item_name")
	private String itemName;

	@Column(name="item_price")
	private double itemPrice;

	public RestItem() {
	}

	public String getItemId() {
		return this.itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getCustomer() {
		return this.customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getItemName() {
		return this.itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public double getItemPrice() {
		return this.itemPrice;
	}

	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}

	@Override
	public String toString() {
		return "RestItem [itemId=" + itemId + ", customer=" + customer + ", itemName=" + itemName + ", itemPrice="
				+ itemPrice + "]";
	}

}