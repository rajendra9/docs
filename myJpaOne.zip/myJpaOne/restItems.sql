drop table if exists rest_items;

create  table rest_items(item_id varchar(10) primary key, 
item_name  varchar(30),
item_price decimal(8,2),
customer varchar(35));

insert into rest_items values('E121', 'Sony Bravia Mobile', 43000.5, 'M/s ReInvent Happy Mobiles');
insert into rest_items values('E543', 'Nokia 5.1 Mobile', 13800.5, 'M/s Ritu Mobile Sales');
	
insert into rest_items values('E324', 'Htc 380 Mobile', 19500.5, 'M/s Madhavan Electronics');
insert into rest_items values('E453', 'Samsung Galaxy S7', 43000.5, 'M/s Nirmal Marketers');

select *  from rest_items;

	
