<template>
 <header>
     <h2 v-on:click="changeTitle">{{title}}</h2>
     
 </header>
</template>

<script>
 
export default{
   props: {     
   title: {
      type: String      
   } 
 },
    data(){
        return{
          
        }
    },
     methods:{
       changeTitle: function() {
          this.title = 'High Caloried People';
       }    
 }

}

</script>
<style scoped>

</style>