package com.htc.randomaccess.utils;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class StringFieldIO {

	public void writeStringField(DataOutput out, String fld, int howManyChars) {
		StringBuffer sb = new StringBuffer(fld);
		sb.setLength(howManyChars);
		String contentToWrite = sb.toString();
		char ch = '\u0000';
		try {
		  for(int i=0;i<howManyChars;i++) {
			ch = contentToWrite.charAt(i);
			out.writeChar(ch);
		  }
		}catch(IOException ex) {
			ex.printStackTrace();
		}
	}
	public String readStringField(DataInput in, int howManyChars) {
		StringBuffer sb = new StringBuffer();
		char ch = '\u0000';
		try {
		  for(int i=0;i<howManyChars;i++) {
			ch = in.readChar();
			sb.append(ch);
		  }
		}catch(IOException ex) {
			ex.printStackTrace();
		}
		return sb.toString().trim();
	}
	
}
