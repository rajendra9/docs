package com.htc.randomaccess.main;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import com.htc.randomaccess.dao.IProductFileServiceProvider;
import com.htc.randomaccess.dao.ProductFileServiceProviderImpl;
import com.htc.randomaccess.dto.Product;

public class Main {
	
	public static void main(String[] args) throws IOException {
		IProductFileServiceProvider fileService = 
				new ProductFileServiceProviderImpl(); 
		Product[] products = new Product[4];
		products[0] = new Product(125, "Soap", 20.0, 60);
		products[1] = new Product(225, "Biscuit", 10.0, 100);
		products[2] = new Product(325, "Oil", 90.0, 20);
		products[3] = new Product(425, "Rice", 1250.5, 10);
		
		Arrays.stream(products).forEach((p)->{
		try {  
		  fileService.writeProduct(p);
		}catch(IOException ioe) {
			ioe.printStackTrace();
		}});
		
		List<Product> list = fileService.readProducts();
		list.forEach(System.out::println); 
		System.out.println("******Reading***********");
		Product prod = fileService.readProduct(325);
		System.out.println(prod);
		
		System.out.println("*******updation*********");
		prod = new Product(425, "Ponni Boiled Rice", 1450.5, 10);
		fileService.updateProduct(prod);
	   
		list = fileService.readProducts();
		list.forEach(System.out::println); 
		System.out.println("*******deletion********");
		fileService.deleteProduct(225);
		list = fileService.readProducts();
		list.forEach(System.out::println); 
		    
		
		
	}
	
}
