package com.htc.randomaccess.dao;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

import com.htc.randomaccess.dto.Product;
import com.htc.randomaccess.utils.StringFieldIO;

public class ProductFileServiceProviderImpl implements IProductFileServiceProvider {
      
	private final static File PRODS_SRC = new File("products.dat");
	private final static File PRODS_SRC_FOR_DEL = new File("products_new.dat");
	
	RandomAccessFile srcFile; 
	int curLen; 
	StringFieldIO strFldIO;
	
	{	   	
	   	    
	   strFldIO = new StringFieldIO();
	}
	
	
	private int getNumRecs() throws IOException {
		curLen = (int)srcFile.length();
		return curLen/Product.REC_LEN;
	}
	
	public ProductFileServiceProviderImpl()throws IOException {		
	   
	}
	public boolean checkProduct(Product prod) {
	    if(prod.getProdId()<=0) {
		  return false;	
		}
		String name = prod.getName();  
		if(name==null || name.isEmpty()) {
			  return false;	
		}
		if(prod.getPrice()<=0.0) {
			return false;
		}
		if(prod.getQty()<=0) {
			return false;
		}		
		return true;
		
	}
	
	@Override
	public void writeProduct(Product product) throws IOException {
		srcFile = new RandomAccessFile(PRODS_SRC, "rws");
		curLen = (int)srcFile.length(); 
		srcFile.seek(curLen);
		boolean boo = this.checkProduct(product); 
		if(boo) {
		 srcFile.writeInt(product.getProdId());
		 this.strFldIO.writeStringField(srcFile, product.getName(), Product.STR_LEN);
		 srcFile.writeDouble(product.getPrice());
		 srcFile.writeInt(product.getQty());
		 srcFile.close();
		}
	}

	@Override
	public List<Product> readProducts() throws IOException {
		List<Product> ret = new ArrayList<>();
		Product prod = null;
		srcFile = new RandomAccessFile(PRODS_SRC, "rws");
		srcFile.seek(0L);
		int recs = this.getNumRecs();
		for(int i=0;i<recs;i++) {
		   int id = srcFile.readInt();
		   String name = this.strFldIO.readStringField(srcFile, Product.STR_LEN);
		   double price = srcFile.readDouble();
		   int qty = srcFile.readInt();
		   prod = new Product(id, name, price, qty);
		   ret.add(prod);
		}
		srcFile.close();
		return ret;
	}

	@Override
	public Product readProduct(int givenId) throws IOException {
		Product ret = new Product();
		srcFile = new RandomAccessFile(PRODS_SRC, "rws");
		srcFile.seek(0L);
		int recs = this.getNumRecs();
		for(int i=0;i<recs;i++) {
		   int id = srcFile.readInt();
		   if(id == givenId) {
			 ret.setProdId(givenId);
			 String name = this.strFldIO.readStringField(srcFile, Product.STR_LEN);
			 ret.setName(name);
			 double price = srcFile.readDouble();
			 ret.setPrice(price);
			 int qty = srcFile.readInt();
			 ret.setQty(qty); 
		     break;
		   }
		   else {
			 srcFile.seek(srcFile.getFilePointer()+(Product.REC_LEN-4));  
		   }
      	}
		srcFile.close();
		return ret;
	}

	@Override
	public void updateProduct(Product newProduct) throws IOException {
		int givenId = newProduct.getProdId();	
		srcFile = new RandomAccessFile(PRODS_SRC, "rws");
		srcFile.seek(0L);
		int recs = this.getNumRecs();
		for(int i=0;i<recs;i++) {
		   int id = srcFile.readInt();
	       if(id == givenId) {
		     String name = newProduct.getName();
		  	 this.strFldIO.writeStringField(srcFile, name, Product.STR_LEN);
			 double price = newProduct.getPrice();
			 srcFile.writeDouble(price);
			 int qty = newProduct.getQty();
			 srcFile.writeInt(qty); 
		     break;
		   }
		   else {
			 srcFile.seek(srcFile.getFilePointer()+(Product.REC_LEN-4));  
		   }
      	}
		srcFile.close();		
	}

	@Override
	public void deleteProduct(int givenId) throws IOException {
		srcFile = new RandomAccessFile(PRODS_SRC, "rws");
        RandomAccessFile destFile = new RandomAccessFile(PRODS_SRC_FOR_DEL, "rws");
		srcFile.seek(0L);
		int recs = this.getNumRecs();
		for(int i=0;i<recs;i++) {
		   int id = srcFile.readInt();
	       if(id == givenId) {
	    	 srcFile.seek(srcFile.getFilePointer()+(Product.REC_LEN-4));
		   }
		   else {
			  String name = this.strFldIO.readStringField(srcFile, Product.STR_LEN);
			  double price = srcFile.readDouble();
			  int qty = srcFile.readInt();
			  destFile.writeInt(id);
			  this.strFldIO.writeStringField(destFile, name, Product.STR_LEN);
			  destFile.writeDouble(price);
			  destFile.writeInt(qty);				   
		   }
      	}
		srcFile.close();		
		destFile.close();		
		PRODS_SRC.delete();
		PRODS_SRC_FOR_DEL.renameTo(PRODS_SRC);		
	}
	
}
