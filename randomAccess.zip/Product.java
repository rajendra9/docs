package com.htc.randomaccess.dto;

public class Product {

	private int prodId;
	private String name;
	private double price;
	private int qty;
	
	// String length for name field
	public static final int STR_LEN=20;
	
	public static final int REC_LEN = 
			Integer.BYTES + (Character.BYTES * STR_LEN) + Double.BYTES + Integer.BYTES;
	
	public Product(int prodId, String name, double price, int qty) {
		super();
		this.prodId = prodId;
		this.name = name;
		this.price = price;
		this.qty = qty;
	}
	
	public Product() {
		super();
	}
	
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public int getQty() {
		return qty;
	}
	
	public void setQty(int qty) {
		this.qty = qty;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + prodId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (prodId != other.prodId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Product [prodId=" + prodId + ", name=" + name + ", price=" + price + ", qty=" + qty + "]";
	}
	
	
}
