package com.htc.randomaccess.dao;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.List;

import com.htc.randomaccess.dto.Product;

public interface IProductFileServiceProvider {

	public void writeProduct(Product product) throws IOException;

	public List<Product> readProducts() throws IOException;

	public Product readProduct(int givenId) throws IOException;

	public void updateProduct(Product newProduct) throws IOException;

	public void deleteProduct(int prodId) throws IOException;
}
