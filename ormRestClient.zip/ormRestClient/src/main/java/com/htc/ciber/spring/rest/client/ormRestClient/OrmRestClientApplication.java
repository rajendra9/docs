package com.htc.ciber.spring.rest.client.ormRestClient;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class OrmRestClientApplication {
   
	@Bean
	public TestRestMethods getTester() {
		return new TestRestMethods();
	}
	
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(OrmRestClientApplication.class);
		TestRestMethods testRestMethods = ctx.getBean(TestRestMethods.class);
		testRestMethods.tesRest();
		ctx.close();
	}

}

