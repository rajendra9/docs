package testing;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import myWebRest.utils.StudentTO;

public class StudentPostTest {

    public static void main(String[] args) {
       Client client = ClientBuilder.newClient();
       String endpointUrl = "http://localhost:10080/webRest/rest/students/add"; 
       WebTarget target = client.target(endpointUrl);
       StudentTO student = new StudentTO("c700", "Mahesh","Asp.Net","Tirunelveli");
       
       String ret = target.request(MediaType.APPLICATION_XML).post(Entity.xml(student),java.lang.String.class);	   
       System.out.println(ret);
       
    }

}
