package testing;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import myWebRest.utils.StudentTO;

public class StudentPutTest {

    public static void main(String[] args) {
       Client client = ClientBuilder.newClient();
       String endpointUrl = "http://localhost:10080/webRest/rest/students/update"; 
       WebTarget target = client.target(endpointUrl);
       StudentTO student = new StudentTO("c200", "Venkatesh","Asp.Net","Madurai");
       
       String ret = target.request(MediaType.APPLICATION_XML).put(Entity.xml(student),java.lang.String.class);	   
       System.out.println(ret);
       
    }

}
