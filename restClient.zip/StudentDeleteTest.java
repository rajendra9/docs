package testing;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

public class StudentDeleteTest {

    public static void main(String[] args) {
       Client client = ClientBuilder.newClient();
       String endpointUrl = "http://localhost:10080/webRest/rest/students/del";
       WebTarget target = client.target(endpointUrl).path("{id}").resolveTemplate("id", "c100");
       String ret = target.request(MediaType.APPLICATION_XML).delete(java.lang.String.class);	   
       System.out.println(ret);
       
    }

}
