var fs = require('fs');

fs.readFile('D:/myNode/inputs/bigFile.txt',function(err,chunk){
   if(err){
    console.log("problem in reading");
   } 
 console.log(chunk.toString("ascii"));
});
console.log('Continue your work');
/*setTimeout(function(){
console.log('Continue your work2');
},2000);*/