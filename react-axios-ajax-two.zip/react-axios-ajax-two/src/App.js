import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import PersonUpdate from './components/personUpdate';
import PersonDelete from './components/personDelete';

class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <table className="tbl">
          <tbody>
            <tr><td className="tdClass"><PersonUpdate/></td>
            <td className="tdClass"><PersonDelete/></td></tr>
          </tbody>
        </table> 
        <hr/>       
      </div>
    );
  }
}

export default App;
