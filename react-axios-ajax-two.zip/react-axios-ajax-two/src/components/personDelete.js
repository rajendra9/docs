import React  from 'react';
import axios  from 'axios';

class PersonDelete extends React.Component {
   state = {
       oldId: '',      
  }
handleSubmit = (event) => {
    event.preventDefault();
    let url = "http://localhost:10080/reactRest/rest/react/delete/";
    url += this.state.oldId;
   
    axios.delete(url).then(res=>{
        console.log(res);
        console.log(res.data.msg);
    });

}
changeOldId = (event) => {
    this.setState({oldId: event.target.value});
}
 render(){
      return(
        <div align='center'>
         <h1>Person Id For Delete</h1>
         <form onSubmit={this.handleSubmit.bind(this)}>
          <table className="tbl">
           <tbody>   
           <tr>
             <td className="tdComp"><label>Enter AdharId:</label></td>
             <td className="tdComp"><input type="text" 
                className="txtInput" 
                onChange={this.changeOldId.bind(this)}/> </td>
            </tr>
           
            <tr>
             <td><input className="btn" type="submit" value="Delete Person Data" /></td>
             <td><input className="btn" type="reset" value="Reset Data" /> </td>
           </tr>           
           </tbody>
          </table>
          
           
         </form>  
        </div>
      )
  }

}
export default PersonDelete;