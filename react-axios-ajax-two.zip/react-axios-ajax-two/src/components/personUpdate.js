import React  from 'react';
import axios  from 'axios';

class PersonUpdate extends React.Component {
   state = {
      
        oldId: '',
        newJob: '',
        newIncome: 0
      
  }
handleSubmit = (event) => {
    event.preventDefault();
    let url = "http://localhost:10080/reactRest/rest/react/update";
    const person = {
        oldId: this.state.oldId,
        newjob: this.state.newJob,
        newIncome: this.state.newIncome
    }
    console.log(person);
    axios.put(url,{person}).then(res=>{
        console.log(res);
        console.log(res.data.msg);
    });

}
changeOldId = (event) => {
    this.setState({oldId: event.target.value});
}

changeNewJob = (event) => {
    this.setState({newJob: event.target.value});
}

changeNewIncome = (event) => {
    this.setState({newIncome: event.target.value});
}
  render(){
      return(
        <div align='center'>
         <h1>Input for Person</h1>
         <form onSubmit={this.handleSubmit.bind(this)}>
          <table className="tbl">
           <tbody>   
           <tr>
             <td className="tdComp"><label>Enter AdharId:</label></td>
             <td className="tdComp"><input type="text" 
                className="txtInput" 
                onChange={this.changeOldId.bind(this)}/> </td>
            </tr>
                    
            <tr> 
             <td className="tdComp"><label>Enter New Job:</label></td>
             <td className="tdComp"><input type="text" 
               className="txtInput" 
               onChange={this.changeNewJob.bind(this)}/> </td>
            </tr>
            <tr>
             <td className="tdComp"><label>Enter New Income:</label></td>
             <td className="tdComp"><input className="txtInput" 
                type="text" 
                onChange={this.changeNewIncome.bind(this)}/> </td>
           </tr>
           <tr>
             <td><input className="btn" type="submit" value="Update Person Data" /></td>
             <td><input className="btn" type="reset" value="Reset Data" /> </td>
           </tr>       
           
           </tbody>
          </table>
          
           
         </form>  
        </div>
      )
  }

}
export default PersonUpdate;