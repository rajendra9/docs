package com.htc.kafka.consumers;

import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public class SimpConsumerForSamp {
   public final static String TOPIC_NAME= "sampTopic";
	
   private Properties populateProperties() {
     Properties props = new Properties();
	  try {
	   FileReader in = new FileReader("./Consumers.properties");
	    props.load(in);
            System.out.println(props);
		in.close();		
       }catch(IOException ex) {
			ex.printStackTrace();
	    }
	   return props; 		
	}

	public static void main(String[] args) {
		SimpConsumerForSamp simpConsumerForSamp = 
				new SimpConsumerForSamp();
        Properties props = simpConsumerForSamp.populateProperties();
        KafkaConsumer<String,String> kafkaConsumer =
        		new KafkaConsumer<>(props);
        kafkaConsumer.subscribe(Arrays.asList(TOPIC_NAME));
        System.out.println("Consumer is subscribed to " + TOPIC_NAME);
        while(true) {
        ConsumerRecords<String, String> records = kafkaConsumer.poll(1200);
        
         for(ConsumerRecord<String, String> record : records) {
             long offset = record.offset();
             String key = record.key();
             String val = record.value();
           System.out.printf("Offset-%d, key-%s, value-%s\n",offset, key, val);;
         }
         kafkaConsumer.commitAsync();        
        }      
       
     }

}
