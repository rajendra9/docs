package com.htc.kafka.producers;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

public class ProducerForGroup {
   
      private Properties populateProperties(String groupName) {
      Properties props = new Properties();
		try {
		 FileReader in = new FileReader("Prod.properties");
		 props.load(in);
                 props.setProperty("client.id", groupName);
                 in.close();		
	}catch(IOException ex) {
		ex.printStackTrace();
	 }
      return props; 		
	}
	public ProducerRecord[] sendMessages(String topicName) {
		ProducerRecord[] records = new ProducerRecord[500];
		String  message = "";
		for(int i =0;i<records.length;i++) {
                   message = "Hello World-" + (i+1);
		   records[i] = new ProducerRecord(topicName, "key-"+(i), message);
		}  	 
		return records;
	}
	public static void main(String[] args) {
	    ProducerForGroup producerForGroup =
				new ProducerForGroup();
        Properties props = producerForGroup.populateProperties("samp");
        Producer<String,String> sampProducer =
        		new KafkaProducer<>(props);
        ProducerRecord[] recs = producerForGroup.sendMessages("simpTopic");
        for(ProducerRecord rec : recs) {
        	sampProducer.send(rec);
        }
       System.out.println("All Messages aere Sent successfully"); 	
       sampProducer.close();       
        
        
        
	}

}
