$KAFKA_HOME/bin/kafka-topics.sh  --zookeeper localhost:5000 --delete --topic simpTopic
