drop table if exists fx_images;

create table fx_images(image_id  integer primary key,
image_name varchar(35),
fx_image bytea);

