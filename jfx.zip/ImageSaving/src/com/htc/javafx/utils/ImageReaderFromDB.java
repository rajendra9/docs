package com.htc.javafx.utils;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.imageio.ImageIO;

import org.postgresql.jdbc.PgResultSet;
import org.postgresql.largeobject.LargeObject;
import org.postgresql.largeobject.LargeObjectManager;

import javafx.scene.image.Image;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;

public class ImageReaderFromDB {

    private static final String URL = "jdbc:postgresql://localhost:5432/samp";

    private static final String USER = "postgres";

    private static final String PASSWORD = "mother";

    private static final String SQL_STR = "select image_name,fx_image from fx_images "+
                                           " where image_id = ?";

    public WritableImage readImage(int imgId){
        Connection conn = null;
        String sep = File.separator;
        PreparedStatement pstmt;
        WritableImage wrImg = null;
        try{
          DriverManager.registerDriver(new org.postgresql.Driver());
          conn = DriverManager.getConnection(URL, USER, PASSWORD);
          pstmt = conn.prepareStatement(SQL_STR);
          pstmt.setInt(1, imgId);
          ResultSet rs = pstmt.executeQuery();
          PgResultSet pgRs = (PgResultSet)rs;
          if(rs.next()){
             String imgName = pgRs.getString(1);
             InputStream inSt = pgRs.getBinaryStream(2);
             BufferedInputStream in = new BufferedInputStream(inSt);
             List<Byte> byteList = new ArrayList<Byte>();
             int ch = 0;
             while((ch=in.read()) != -1){
               byteList.add((byte)ch);
             }
             in.close();
             int len = byteList.size();
             byte[] imgBytes = new byte[len];
             for(int i=0;i<len;i++){
                 imgBytes[i] = byteList.get(i);
             }
             BufferedImage img = ImageIO.read(new ByteArrayInputStream(imgBytes));
             int width = img.getWidth();
             int height = img.getHeight();
             wrImg = new WritableImage(width, height);
             PixelWriter writer = wrImg.getPixelWriter();
             for(int i=0;i<width;i++){
                 for(int j=0;j<height;j++){
                     writer.setArgb(i, j, img.getRGB(i, j));
                 }
             }

          }//if closes
          System.out.println("retrieved:");
       }catch(SQLException | IOException ex){
           ex.printStackTrace();
       }
        finally{
            try{
               if(conn != null){
                conn.close();
               }
            }catch(SQLException sqe){
                sqe.printStackTrace();
            }
        }
        return wrImg;
    }

    public static void main(String[] args) {
      Scanner scan = new Scanner(System.in);
      System.out.println("Enter image name");
      String path = scan.nextLine();
      ImageReaderFromDB imgReader = new ImageReaderFromDB();
      imgReader.readImage(100);
    }

}
