package com.htc.javafx.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class ImageSaver {

    private static final String URL = "jdbc:postgresql://localhost:5432/samp";

    private static final String USER = "postgres";

    private static final String PASSWORD = "mother";

    private static final String SQL_STR = "insert into fx_images values(?,?,?)";

    public void saveImage(String path, int id){
        Connection conn = null;
        String sep = File.separator;
        PreparedStatement pstmt;
        try{
          File file = new File(path);
          int len = (int)file.length();
          FileInputStream fin = new FileInputStream(file);
          DriverManager.registerDriver(new org.postgresql.Driver());
          conn = DriverManager.getConnection(URL, USER, PASSWORD);
          pstmt = conn.prepareStatement(SQL_STR);
          int lastInd = path.lastIndexOf(sep);
          String imgName = path.substring(lastInd + 1);
          System.out.println(imgName);
          pstmt.setInt(1, id);
          pstmt.setString(2, imgName);
          pstmt.setBinaryStream(3, fin, len);
          int cnt = pstmt.executeUpdate();
          System.out.println("saved:"+cnt);
       }catch(SQLException | IOException ex){
           ex.printStackTrace();
       }
        finally{
            try{
               if(conn != null){
                conn.close();
               }
            }catch(SQLException sqe){
                sqe.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
      Scanner scan = new Scanner(System.in);
      System.out.println("Enter id of Picture");
      int id = Integer.parseInt(scan.nextLine());
      System.out.println("Enter image name");
      String path = scan.nextLine();
      ImageSaver imgSaver = new ImageSaver();
      imgSaver.saveImage(path, id);
    }

}
