package com.htc.javafx;



import com.htc.javafx.utils.ImageReaderFromDB;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

public class ImageLoadController {

    @FXML
    ImageView destView;

    @FXML
    TextField  imageIdTf;

    @FXML
    Button load;

    ImageReaderFromDB dbReader;

    @FXML
    void initialize(){
      dbReader = new ImageReaderFromDB();
      load.setOnAction((e) -> {
        int id = Integer.parseInt(imageIdTf.getText().trim());
        WritableImage img = dbReader.readImage(id);
        destView.setImage(img);
      });
    }

}
