package forPagination;

import java.time.LocalDate;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public class PagingController {
    
    public static final int RECS_PER_PAGE = 10;
    public  int   dataSize;
    
    EmployeeDAO empService;
    ObservableList<EmployeePG> employees;
    
    @FXML
    private Pagination pager;
    
    TableView<EmployeePG>  tbl;
    
    TableColumn<EmployeePG,Integer> eno;
        
    TableColumn<EmployeePG,String> ename;
        
    TableColumn<EmployeePG,String> jb;
        
    TableColumn<EmployeePG,String> dname;
        
    TableColumn<EmployeePG,Double> sal;
    
    TableColumn<EmployeePG,LocalDate> hdate;
    
    private Node createPage(int currIndex){
        int fromIndex = currIndex * RECS_PER_PAGE;
        int toIndex = Math.min(fromIndex + RECS_PER_PAGE, dataSize);
        tbl.setItems(FXCollections.observableArrayList(employees.subList(fromIndex, toIndex)));
        return new BorderPane(tbl);
    }
    
    @FXML
    void initialize(){
        empService = new EmpService();
        employees = empService.getEmployees();
        dataSize = employees.size();  
        tbl = new TableView<EmployeePG>();
        tbl.setFixedCellSize(RECS_PER_PAGE*5);
        eno = new TableColumn<EmployeePG,Integer>("Emp Id");
        eno.setCellValueFactory(new PropertyValueFactory<EmployeePG,Integer>("empId"));
        
        ename = new TableColumn<EmployeePG,String>("Emp Name");
        ename.setCellValueFactory(new PropertyValueFactory<EmployeePG,String>("empName"));
        
        jb = new TableColumn<EmployeePG,String>("Job");
        jb.setCellValueFactory(new PropertyValueFactory<EmployeePG,String>("job"));
        
        dname = new TableColumn<EmployeePG,String>("Dept Name");
        dname.setCellValueFactory(new PropertyValueFactory<EmployeePG,String>("deptName"));
        
        hdate = new TableColumn<EmployeePG,LocalDate>("Hire Date");
        hdate.setCellValueFactory(new PropertyValueFactory<EmployeePG,LocalDate>("hiredate"));
        
        sal = new TableColumn<EmployeePG,Double>("Salary");
        sal.setCellValueFactory(new PropertyValueFactory<EmployeePG,Double>("salary"));
        
        tbl.getColumns().addAll(eno, ename, jb, hdate, sal, dname);
        int pgCnt = (int)Math.round(Math.ceil((double)dataSize/RECS_PER_PAGE));
        pager.setPageCount(pgCnt);
        pager.setCurrentPageIndex(0);
        pager.setPageFactory(this::createPage);
    }


}
