package forPagination;

import java.net.URL;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class PagingShow extends Application {
    Stage stage;
    
    @Override
    public void stop() throws Exception {
        super.stop();
        System.out.println("stopping program");
        stage.close();
        System.exit(1);
    }

    public void start(Stage stage)throws Exception {
      URL location = PagingShow.class.getResource("forPage.fxml");
      
      BorderPane root = (BorderPane)FXMLLoader.load(location);
      stage.setScene(new Scene(root));
      stage.setTitle("Navigation Example");
      this.stage = stage;
      stage.show();
    }
    
    public static void main(String[] args) {
        launch(args);

    }

}
