package forPagination;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;


@Entity
@Table(name="EMPLOYEES_PG")
public class EmployeePG implements Serializable,Comparable<EmployeePG> {

  private  int        empId;
  private  String     deptName;
  private  String     empName;  
  private  LocalDate  hiredate;
  private  String     job; 
  private  double     salary;
  
  
  @Override
  public int compareTo(EmployeePG other) {
    return new Integer(this.empId).compareTo(new Integer(other.empId));
  }


  public EmployeePG() {
    super();
  }

  
  @Id
  @Column
  public int getEmpId() {
     return empId;
  }

  public void setEmpId(int empId) {
     this.empId = empId;
  }
  
  @Column
  public String getDeptName() {
     return deptName;
  }

  public void setDeptName(String deptName) {
      this.deptName = deptName;
  }
  
  @Column
  public String getEmpName() {
      return empName;
  }

  public void setEmpName(String empName) {
     this.empName = empName;
  }

  @Column
  public String getJob() {
      return job;
  }

  public void setJob(String job) {
     this.job = job;
  }

  @Column
  public double getSalary() {
     return salary;
  }

  public void setSalary(double salary) {
     this.salary = salary;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + empId;
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
        return true;
    if (obj == null)
        return false;
    if (getClass() != obj.getClass())
        return false;
    EmployeePG other = (EmployeePG) obj;
    if (empId != other.empId)
        return false;
    return true;
  }

 
  @Override
  public String toString() {
      return "EmployeePG [empId=" + empId + ", deptName=" + deptName + ", empName=" + empName + ", hiredate=" + hiredate
            + ", job=" + job + ", salary=" + salary + "]";
  } 
  
  
}
