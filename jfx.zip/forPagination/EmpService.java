package forPagination;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class EmpService implements EmployeeDAO {

    
    EntityTransaction trans;
    EntityManagerFactory  emFactory;
    EntityManager em;

    public EmpService(){
        emFactory =
                Persistence.createEntityManagerFactory("myDB");        
    }
    
       
    @Override
    public ObservableList<EmployeePG> getEmployees() {
      ObservableList<EmployeePG> ret = FXCollections.observableArrayList();  
      try {
        em = emFactory.createEntityManager();
        trans = em.getTransaction(); 
        trans.begin();
        TypedQuery<EmployeePG> query = em.createQuery("select  e from EmployeePG e order by e",EmployeePG.class);
        List<EmployeePG> li = query.getResultList();
        ret.addAll(li);
        trans.commit();
        em.close();
      }catch(Exception ex){
         trans.rollback(); 
         ex.printStackTrace();
      }  
       return ret;
    }
    
    
}