package forPagination;

import javafx.collections.ObservableList;

public interface EmployeeDAO {
    
   public ObservableList<EmployeePG> getEmployees();     
   



}
