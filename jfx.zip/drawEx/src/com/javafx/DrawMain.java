package com.javafx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;


public class DrawMain extends Application {
  @Override
  public void start(Stage primaryStage) {
     try {
        BorderPane root = (BorderPane)FXMLLoader.load(this.getClass().getResource("drawing.fxml"));;
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setTitle("---------------------Drawing Options----");
        primaryStage.show();
      } catch(Exception e) {
         e.printStackTrace();
      }
  }

  public static void main(String[] args) {
     launch(args);
  }


}
