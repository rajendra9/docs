package com.javafx;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class DrawController {

    @FXML
    Canvas drawCanvas;

    GraphicsContext gc;
    Color color;


    @FXML
    Button circleBtn;

    @FXML
    Button rectBtn;

    @FXML
    Button lineBtn;

    @FXML
    void initialize(){
      gc = drawCanvas.getGraphicsContext2D();

      lineBtn.setOnAction((e) -> {
        gc.setStroke(Color.RED);
        gc.setFill(Color.RED);
        gc.strokeLine(10, 100, 530, 100);
        Font font = new Font("Courier New", 32);
        gc.setFont(font);
        gc.fillText("JavaFx Draw Options", 100, 30);
      });

      circleBtn.setOnAction((e) -> {
          gc.setStroke(Color.MAGENTA);
          gc.setFill(Color.BISQUE);
          gc.fillOval(80, 160, 170, 170);
      });

      rectBtn.setOnAction((e) -> {
          gc.setStroke(Color.BURLYWOOD);
          gc.setFill(Color.CHOCOLATE);
          gc.fillRect(270, 160, 170, 170);
      });


    }


}
