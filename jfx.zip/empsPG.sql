drop table if exists EMPLOYEES_PG;


create table EMPLOYEES_PG as
select employee_id empId,first_name||' '||last_name empName,
job_title job,
hire_date hiredate,
salary,
department_name deptName
from employees e, jobs j,departments d
where e.job_id=j.job_id and 
 d.department_id=e.department_id;
 
alter table EMPLOYEES_PG add primary key(empId);