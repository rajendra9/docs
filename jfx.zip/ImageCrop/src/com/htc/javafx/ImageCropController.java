package com.htc.javafx;


import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;


import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Bounds;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.SnapshotParameters;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.MouseEvent;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeLineCap;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class ImageCropController {



   @FXML
   Group imageLayer;

   @FXML
   ImageView imageView;

   @FXML
   ScrollPane imgScroll;

   PictureBandSelection pictureBandSelection;

   Image image;

   public static class PictureBandSelection {

       final ImageDragContext dragContext = new ImageDragContext();
       Rectangle rect = new Rectangle();

       Group group;


       public Bounds getBounds() {
           return rect.getBoundsInParent();
       }

       public PictureBandSelection( Group group) {

           this.group = group;

           rect = new Rectangle( 0,0,0,0);
           rect.setStroke(Color.BLUE);
           rect.setStrokeWidth(1);
           rect.setStrokeLineCap(StrokeLineCap.ROUND);
           rect.setFill(Color.LIGHTBLUE.deriveColor(0, 1.2, 1, 0.6));

           group.addEventHandler(MouseEvent.MOUSE_PRESSED, onMousePressedEventHandler);
           group.addEventHandler(MouseEvent.MOUSE_DRAGGED, onMouseDraggedEventHandler);
           group.addEventHandler(MouseEvent.MOUSE_RELEASED, onMouseReleasedEventHandler);

       }

       EventHandler<MouseEvent> onMousePressedEventHandler = new EventHandler<MouseEvent>() {

           @Override
           public void handle(MouseEvent event) {

               if( event.isSecondaryButtonDown())
                   return;

               // remove old rect
               rect.setX(0);
               rect.setY(0);
               rect.setWidth(0);
               rect.setHeight(0);

               group.getChildren().remove( rect);


               // prepare new drag operation
               dragContext.mouseAnchorX = event.getX();
               dragContext.mouseAnchorY = event.getY();

               rect.setX(dragContext.mouseAnchorX);
               rect.setY(dragContext.mouseAnchorY);
               rect.setWidth(0);
               rect.setHeight(0);

               group.getChildren().add( rect);

           }
       };

       EventHandler<MouseEvent> onMouseDraggedEventHandler = new EventHandler<MouseEvent>() {

           @Override
           public void handle(MouseEvent event) {

               if( event.isSecondaryButtonDown())
                   return;

               double offsetX = event.getX() - dragContext.mouseAnchorX;
               double offsetY = event.getY() - dragContext.mouseAnchorY;

               if( offsetX > 0)
                   rect.setWidth( offsetX);
               else {
                   rect.setX(event.getX());
                   rect.setWidth(dragContext.mouseAnchorX - rect.getX());
               }

               if( offsetY > 0) {
                   rect.setHeight( offsetY);
               } else {
                   rect.setY(event.getY());
                   rect.setHeight(dragContext.mouseAnchorY - rect.getY());
               }
           }
       };


       EventHandler<MouseEvent> onMouseReleasedEventHandler = new EventHandler<MouseEvent>() {

           @Override
           public void handle(MouseEvent event) {

               if( event.isSecondaryButtonDown())
                   return;

               // remove rectangle
               // note: we want to keep the ruuberband selection for the cropping => code is just commented out
               /*
               rect.setX(0);
               rect.setY(0);
               rect.setWidth(0);
               rect.setHeight(0);

               group.getChildren().remove( rect);
               */

           }
       };
       private static final class ImageDragContext {

           public double mouseAnchorX;
           public double mouseAnchorY;


       }
   }

   private void crop( Bounds bounds) {

       FileChooser fileChooser = new FileChooser();
       FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("image files (*.jpg)", "*.jpg");
       fileChooser.getExtensionFilters().add(extFilter);
       fileChooser.setTitle("Save Image");
       Stage primaryStage = (Stage)imageView.getScene().getWindow();
       File file = fileChooser.showSaveDialog( primaryStage);
       if (file == null)
           return;

       int width = (int) bounds.getWidth();
       int height = (int) bounds.getHeight();

       SnapshotParameters parameters = new SnapshotParameters();
       parameters.setFill(Color.TRANSPARENT);
       parameters.setViewport(new Rectangle2D( bounds.getMinX(), bounds.getMinY(), width, height));

       WritableImage wi = new WritableImage( width, height);
       imageView.snapshot(parameters, wi);

       // save image
       // !!! has bug because of transparency (use approach below) !!!
       // --------------------------------
//       try {
//         ImageIO.write(SwingFXUtils.fromFXImage( wi, null), "jpg", file);
//     } catch (IOException e) {
//         e.printStackTrace();
//     }


       // save image (without alpha)
       // --------------------------------
       BufferedImage bufImageARGB = SwingFXUtils.fromFXImage(wi, null);
       BufferedImage bufImageRGB = new BufferedImage(bufImageARGB.getWidth(), bufImageARGB.getHeight(), BufferedImage.OPAQUE);

       Graphics2D graphics = bufImageRGB.createGraphics();
       graphics.drawImage(bufImageARGB, 0, 0, null);

       try {

           ImageIO.write(bufImageRGB, "jpg", file);

           System.out.println( "Image saved to " + file.getAbsolutePath());

       } catch (IOException e) {
           e.printStackTrace();
       }

       graphics.dispose();

   }


   @FXML
   void initialize(){
       pictureBandSelection = new PictureBandSelection(imageLayer);

       // create context menu and menu items
       ContextMenu contextMenu = new ContextMenu();

       MenuItem cropMenuItem = new MenuItem("Crop");
       cropMenuItem.setOnAction(new EventHandler<ActionEvent>() {
           public void handle(ActionEvent e) {

               // get bounds for image crop
               Bounds selectionBounds = pictureBandSelection.getBounds();

               // show bounds info
               System.out.println( "Selected area: " + selectionBounds);

               // crop the image
               crop( selectionBounds);

           }
       });
       contextMenu.getItems().add( cropMenuItem);

       // set context menu on image layer
       imageLayer.setOnMousePressed(new EventHandler<MouseEvent>() {
           @Override
           public void handle(MouseEvent event) {
               if (event.isSecondaryButtonDown()) {
                   contextMenu.show(imageLayer, event.getScreenX(), event.getScreenY());
               }
           }
       });

   }

}
