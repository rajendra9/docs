package htcfx;

import javafx.fxml.FXML;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import java.util.ArrayList;
import java.util.Collections;

import java.util.List;
import java.time.LocalDate;

import myjavafx.StudentSaver;
import myjavafx.StudentTO;

import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ComboBox;

public class ForStudentCtl {

  StudentSaver stuSaver;

  @FXML //fx:id=stName
  private TextField stName;

  @FXML  //fx:id=stDoj
  private DatePicker stDoj;

  @FXML  //fx:id=stCourse
  private ComboBox<String> stCourse;

  @FXML  //fx:id=parentEmail
  private TextField parentEmail;


  @FXML //fx:id=result
  private Label result;


  @FXML //fx:id=saveBtn
  private Button saveBtn;

  @FXML //fx:id=upBtn
  private Button upBtn;

  public class MyEventHandler implements EventHandler<ActionEvent>{
    public void handle(ActionEvent evt){
      Button btn = (Button)evt.getSource();
      String lbl = btn.getText();
      if(lbl.equalsIgnoreCase("Save")){
        String stuName = stName.getText();
        String course = stCourse.getValue();
        LocalDate dt = stDoj.getValue();
        String email = parentEmail.getText();
        StudentTO student =
               new StudentTO(stuName, dt, course, email);
        boolean boo = stuSaver.addStudent(student);
        System.out.println("JJJJJ"+result);
        if(boo){
          result.setText("saved");
        }
        else{
         result.setText("not saved");
        }
      }
      else if(lbl.equalsIgnoreCase("update")){
          String stuName = stName.getText();
          String course = stCourse.getValue();
          LocalDate dt = stDoj.getValue();
          String email = parentEmail.getText();
          StudentTO student =
                 new StudentTO(stuName, dt, course, email);
          boolean boo = stuSaver.updateStudent(student);
          if(boo){
            result.setText("updated");
          }
          else{
           result.setText("not updated");
          }
      }//else closes
    }//handle method closes
  }//class closes


  @FXML
  public void initialize(){
    stuSaver = new StudentSaver();
    List<String> couList = new ArrayList<>();
    stDoj.setValue(LocalDate.now());
    Collections.addAll(couList, "B.Sc","B.Com","B.C.A","B.B.A","B.A");
    ObservableList<String> courseList = FXCollections.observableArrayList(couList);
    stCourse.setItems(courseList);
    MyDateStringConverter converter =
                    new MyDateStringConverter();
    stDoj.setConverter(converter);
    MyEventHandler evtHandler = new MyEventHandler();
    try{
    if(saveBtn != null) {
      saveBtn.setOnAction(evtHandler);
    }
    if(upBtn != null) {
      upBtn.setOnAction(evtHandler);
    }
   }catch(Exception ex){
     ex.printStackTrace();
   }

  }

}
