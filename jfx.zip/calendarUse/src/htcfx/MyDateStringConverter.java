package htcfx;

import javafx.util.StringConverter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class MyDateStringConverter extends StringConverter<LocalDate> {
    String formatString = "yyyy-MM-dd";
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(formatString);
    
    @Override
    public LocalDate fromString(String dateStr) {
      LocalDate ret = null;
      try{  
          ret = LocalDate.parse(dateStr,formatter);      
      }catch(Exception ex){
        ex.printStackTrace();
      }
     return ret; 
    }

    @Override
    public String toString(LocalDate lDate) {
        return formatter.format(lDate);
    } 

}
