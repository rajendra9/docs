package navigation;

import java.net.URL;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class SceneChangeMain extends Application {

    public void start(Stage stage)throws Exception {
      URL location = SceneChangeMain.class.getResource("first.fxml");
      
      FlowPane root = (FlowPane)FXMLLoader.load(location);
      stage.setScene(new Scene(root));
      stage.setTitle("Navigation Example");
      stage.show();
    }
    
    public static void main(String[] args) {
        launch(args);

    }

}
