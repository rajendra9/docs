package navigation;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class CommonController implements Initializable{
  @FXML
  private Button firstBtn;
  
  @FXML
  private Button secondBtn;
  
  
  @FXML
  private  void buttonActionHandler(ActionEvent evt)throws IOException{
     Parent root;
     Stage mainStage;
     String firstSource = "first.fxml";
     String secondSource = "second.fxml";
     if(evt.getSource()== firstBtn){
         mainStage = (Stage)firstBtn.getScene().getWindow();
         root = (Parent)FXMLLoader.load(getClass().getResource(secondSource));         
     }
     else{
         mainStage = (Stage)secondBtn.getScene().getWindow();
         root = (Parent)FXMLLoader.load(getClass().getResource(firstSource)); 
     }
      Scene scene = new Scene(root);
      mainStage.setScene(scene);
      mainStage.show();     



  }
  
  public void initialize(URL loc, ResourceBundle resources){
     System.out.println("init fired"); 
  }
}
