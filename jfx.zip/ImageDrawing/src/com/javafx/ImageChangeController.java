package com.javafx;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

public class ImageChangeController {

    @FXML
    ImageView srcView;

    @FXML
    ImageView targetView;

    @FXML
    Button drawPicture;


    @FXML
    void initialize(){
      drawPicture.setOnAction((e) -> {
        Image src = srcView.getImage();
        PixelReader reader = src.getPixelReader();
        int srcWidth = (int)src.getWidth();
        int srcHeight = (int)src.getHeight();
        System.out.println(srcWidth+":"+srcHeight);
        WritableImage dest = new WritableImage(srcWidth, srcHeight);
        PixelWriter writer = dest.getPixelWriter();
        Color clr = null;
        for(int i=0;i<srcHeight;i++){
            for(int j=0;j<srcWidth;j++){
              clr = reader.getColor(j, i);
              writer.setColor(j, i, clr.brighter());
            }
        }
        targetView.setImage(dest);
      });
    }

}
