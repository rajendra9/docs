package com.htc.javafx;

import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;

import com.htc.javafx.utils.DBTask;

import javafx.collections.ObservableList;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;

public class ChartController {

   ObservableList<PieChart.Data>  data;

   @FXML
   PieChart deptSalChart;


   @FXML
   Button show;

   @FXML
   void initialize(){
     DBTask task = new DBTask();
     Thread thread = new Thread(task);
     thread.start();
     try{
       Thread.sleep(1000);
       thread.join();
     }catch(InterruptedException ex){
         ex.printStackTrace();
     }
     task.addEventHandler(WorkerStateEvent.WORKER_STATE_SUCCEEDED,
             new EventHandler<WorkerStateEvent>(){
                 public void handle(WorkerStateEvent evt){
                  data = task.getValue();
                 }
     });
     show.setOnAction((e) -> deptSalChart.setData(data));
   }

}
