package com.htc.javafx.utils;

import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.PieChart.Data;

public class DBTask extends Task<ObservableList<PieChart.Data>> {

    @Override
    protected ObservableList<PieChart.Data> call() throws Exception {
        ChartDataProvider dataProvider = new ChartDataProvider();
        dataProvider.init();
        ObservableList<PieChart.Data> ret = dataProvider.getDeptData();
        dataProvider.close();
        return ret;
    }

}
