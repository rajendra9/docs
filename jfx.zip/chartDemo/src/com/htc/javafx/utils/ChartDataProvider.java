package com.htc.javafx.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;

public class ChartDataProvider {

   private static final String URL = "jdbc:postgresql://localhost:5432/samp";

   private static final String USER = "postgres";

   private static final String PASSWORD = "mother";

   private static final String SQL_STR =
           "select d.department_name, sum(e.salary) from employees e," +
           "departments d where e.department_id = d.department_id "+
           "group by d.department_name";

   Connection conn;
   Statement stmt;

   public void init(){
     try{
       DriverManager.registerDriver(new org.postgresql.Driver());
       conn = DriverManager.getConnection(URL, USER, PASSWORD);
       stmt = conn.createStatement();
     }catch(Exception e){
        e.printStackTrace();
        throw new RuntimeException(e.getMessage());
     }
   }

   public void close(){
       try{
         if(conn != null) {
           conn.close();
         }
       }catch(Exception e){
          e.printStackTrace();
          throw new RuntimeException(e.getMessage());
       }
   }

   public ObservableList<PieChart.Data> getDeptData(){
       ObservableList<PieChart.Data> ret =
               FXCollections.observableArrayList();
       PieChart.Data data = null;
       try{
         ResultSet rs = stmt.executeQuery(SQL_STR);
         while(rs.next()){
             data = new PieChart.Data(rs.getString(1), rs.getDouble(2));
             ret.add(data);
         }
         System.out.println(ret);
       }catch(Exception ex){
           throw new RuntimeException(ex.getMessage());
       }
       return ret;
   }
}
