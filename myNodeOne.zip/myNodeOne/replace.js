var fs = require('fs');

var buffToReadAndWrite = fs.readFileSync('inputs/a.txt');
buffToReadAndWrite[10] = 55;

fs.writeFileSync( 'inputs/a.txt', buffToReadAndWrite);    