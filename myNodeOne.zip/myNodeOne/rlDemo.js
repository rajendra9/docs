var readline = require('readline');

var rl = readline.createInterface({
	input:process.stdin,
	output:process.stdout
});

rl.question('Enter empRecord as Number-name-course-location',function(answer){
  console.log(answer);	
  rl.close();
});