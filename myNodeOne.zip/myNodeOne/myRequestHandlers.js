var queryString = require('querystring');
var fs = require('fs');
var formidable = require('formidable');
 
function start(response){
  console.log('Start function in myRequestHandlers');
  var body = '<!DOCTYPE html><html>'+
             '<head><meta charset="UTF-8" /><title>Page for file upload</title></head>'+
             '<body><div align="center"><h1>Choose Files for upload</h1>'+
             '<form method="post" action="upload" enctype="multipart/form-data">'+
             '<label for="upload">'+
             'Select File for upload</label>&nbsp;&nbsp;'+
             '<input type="file" name="upload"></textarea><br/><hr/>'+
             '<input type="submit" value="upload" /></form></div></body></html>';
   
   response.writeHead(200,{'Content-Type' : 'text/html'});
   response.write(body);
   response.end();
}
function upload(response, request){
  console.log('upload function in myRequestHandlers');
  var form = new formidable.IncomingForm();
  console.log('about to parse');
 form.parse(request,function(error, fields, files){
   console.log('parsing done');
   fs.rename(files.upload.path,'images/test.png',function(error){
    if(error){
      fs.unlink('images/test.png');
      fs.rename(files.upload.path,'images/test.png');
    }
   });
  response.writeHead(200,{'Content-Type' : 'text/html'});   
  response.write('received image');
  response.write('<img src="/show" />');
  response.end();
 });
}
function show(response, postedData){
  console.log('Request Handler "show" is called');
  fs.readFile("images/test.png",'binary', function(error, file){
   if(error){
    response.writeHead(500,{'Content-Type' : 'text/plain'});
    response.write(error+'\n');
    response.end();
   }
   else {
    response.writeHead(200,{'Content-Type' : 'image/png'});
    response.write(file,'binary');
    response.end();
   } 
  });
}
exports.start = start;
exports.upload = upload;
exports.show = show;