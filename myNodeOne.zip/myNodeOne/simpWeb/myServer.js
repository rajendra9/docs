var http = require("http");
var url = require("url");

var homeRes = "<div align='center'><H3>Welcome to our Home Page</H3></div>";

http.createServer(function(request,response){
   response.writeHead(200,{"Content-Type":"text/plain"});
   var pathName = url.parse(request.url).pathname;
      if(pathName === "/home"){
        response.writeHead(200,{"Content-Type":"text/html"});  
       response.write(homeRes);
    }
    else {  
      response.write("Hello World");
   }
    response.end();
 }).listen(8888,function(){
    console.log("server Started at port 8888");
});