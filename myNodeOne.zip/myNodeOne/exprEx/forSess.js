var express = require('express');
var bodyParser = require('body-parser');
var expressSession = require('express-session');
var cookieParser = require('cookie-parser');
var path = require('path');
var list = require('collections/List');
var app = new express();
var storeUsersList = 
	new list(['shoba', 'varadarajan', 'vimal kumar', 'sethu raman']);

//must use cookieParser before expressSession
app.use(cookieParser());
app.use(expressSession(
		{secret:'secret',
		 resave:true,
		 saveUninitialized:true
		 }));
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

app.get('/',function(request,response){
   if(!request.session.storeUser){
	response.sendFile('sessWant.html',{root:path.join(__dirname,'./public')});
   }
   else{
	 response.send('Your Store User name from session is:'+
			 request.session.storeUser);  
   }
});

app.post('/',function(request,response){
	console.log('llll');
	var store = request.body.storeUser;
    if(storeUsersList.has(store)){
    	request.session.storeUser = store;	
    } 
    response.redirect('/'); 	
});
var server = app.listen(3000,function(){
	console.log('Server started at 3000');
});