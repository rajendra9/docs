// JavaScript Document
var express = require('express')
var app = express()

app.get('*',function(request,response,next){
  var reqUrl = request.originalUrl;
  console.log(reqUrl);
  if(reqUrl.indexOf('test')>-1 ||reqUrl.indexOf('test')>-1){
    var err = new Error()
    err.status = 404
    next(err);
  }
  else{  
    response.send('from handler');
  }
 },function(err,request,response,next){
   console.error(err.stack);
   response.status(404).send('url not available');
 });


 
var server = app.listen(3000, function(){
   console.log('Server has started at-3000');
  });  
