var express = require('express');
var app = express();

app.get( '/', function(request, response) {
   response.send('<h3 align="center">Welcome to Node Express web Engine</h3>');
});


 
var server = app.listen(3000, function(){
   var addr = 'localhost';
   var port = server.address().port;
   console.log('Server has started at http://%s:%s',addr,port);
  });  
