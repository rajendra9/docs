var express = require('express');
var app = express();

app.use(express.static('public'));


 
var server = app.listen(3000, function(){
   var addr = 'localhost';
   var port = server.address().port;
   console.log('Server has started at http://%s:%s',addr,port);
  });  
