var express = require('Express');
var app = new express();
app.set('views','./views');
app.set('view engine','jade');
forData = 'Welcome to Template Rendering';
app.get('/testJade',function(request,response){
  response.render('simple.jade',{title:'Rendering Jade Template', data : forData});	
});
var server = app.listen(3000,function(){
	console.log('Server started at 3000');
})