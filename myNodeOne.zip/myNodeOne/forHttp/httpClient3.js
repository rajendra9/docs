var request = require("request");

request("http://localhost:8081/start.txt",
function(error,response, body){
  if(error){
   console.error(error.stack);
  }
  else{
    console.log(body);
  }
});