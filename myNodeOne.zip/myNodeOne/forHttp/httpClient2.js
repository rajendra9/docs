var request = require("request");

request({
uri: "http://localhost:8081/start.txt",
method: "GET",
timeout: 10000
},function(error,response, body){
  if(error){
   console.error(error.stack);
  }
  else{
    console.log(body);
  }
});