var child = require('child_process').fork('./child.js');
var server = require('net').createServer();

server.on('Connection',function(socket){
  socket.end('child handled connection');
}); 

});
server.listen(3000,function(){
  child.send('The Parent Message', server);
}); 