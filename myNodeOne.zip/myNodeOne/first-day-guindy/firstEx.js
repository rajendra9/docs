function queryPrice(bookName){

   console.log("Query for " + bookName + " Price");
   findPriceForBook(function(){
      console.log(Math.random()*1000.0);
   });
}

function findPriceForBook(callback){
   setTimeout(callback,2000);
}

queryPrice("JIT");
queryPrice("JEE");
queryPrice("Angular6");
queryPrice("HTML5");
queryPrice("ASP");

