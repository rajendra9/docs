var fs = require('fs');

var buffToReadAndWrite = new Buffer(70);
var len ;

fs.open('inputs/a.txt', 'rs', function(error, fd){
   if(error){ console.log(error); return; }
    buffStart = 0;
    buffLen = buffToReadAndWrite.length;
    fileStart = 0;
    fs.read(fd,
            buffToReadAndWrite,
            buffStart,
            buffLen,               
            fileStart,
         function(err, read){
             if(err){console.log(err); return;}
             len = read; 
             console.log('Read '+read+' bytes');
             console.log(buffToReadAndWrite.toString()); 
     });    
   }); 
 
 buffToReadAndWrite[10] = 55;
 fs.open('inputs/a.txt', 'w', function(error, fd){
    if(error){ console.log(error); return; }
      buffStart = 0;
      fileStart = null;
      fs.write(fd, 
            buffToReadAndWrite, 
            buffStart,
            len, 
            fileStart,
            function(err, written){
             if(err){console.log(err); return;}
             console.log('written '+written+' bytes');  
            });
       fs.close(fd, function(error){
         if(error){console.log(error); return;}
       });
   });    