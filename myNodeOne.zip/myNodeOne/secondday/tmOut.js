console.log("before");


var t = setTimeout(function(){

   console.info("Show function");

   clearInterval(t);

},1500);

