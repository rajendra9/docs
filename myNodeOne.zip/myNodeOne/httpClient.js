var http = require("http");

var url = require("url");


var options = {
    
   host: "localhost",

   port:8081,

   path: "/start.txt" 
   
};


var callback = function(response){
  
 var content = ""; 
   
 response.setEncoding("utf8"); 
 
 response.on("data",function(data){    
 content += data;  
});

response.on("end",function(){
   
  console.log(content); 
  });

}

var req = http.request(options,callback);

req.on("error",function(err)
      {

      console.log("---error---");
 
      console.log(err.stack);  

});

req.end();

