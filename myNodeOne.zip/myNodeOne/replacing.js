var fs = require('fs');

var buffToReadAndWrite = fs.readFileSync('inputs/a.txt');
buffToReadAndWrite[10] = 55;

fs.open('inputs/a.txt', 'w', function(error, fd){
   if(error){ console.log(error); return; }
     buffStart = 0;
     buffLen = buffToReadAndWrite.length;
     fileStart = null; 
     fs.write(fd, 
               buffToReadAndWrite, 
               buffStart,
               buffLen, 
               fileStart,
               function(err, written){
               if(err){console.log(err); return;}
                 console.log('written '+written+' bytes');  
            });
       fs.close(fd, function(error){
         if(error){console.log('uuu'+error); return;}
       });
  
  }); 
 
     