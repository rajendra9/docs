var express = require('express')
var path = require("path");

var bodyParser = require("body-parser");


var app = express()


var multer = require("multer");

app.use(express.static('public'));

var done = false;
app.use(bodyParser.urlencoded({ extended: false }));

var store = multer.diskStorage({
  destination: function(req,file,cb){
     cb(null, __dirname+"/uploaded/");
  },
  filename : function(req, file,cb){
      cb(null, file.originalname+"_new");
  }
});


var upload = multer({storage : store});
 

app.get("/simpUpload", function(req, res) {
  res.sendFile(path.join(__dirname + "/" + "simpUpload.html"));  
});

app.post("/for_file_upload", upload.single("upfile"), function(req,res){
   var fName = req.file.originalname;
   console.log(fName);
   console.log(req.file.fieldname);
   var filePath = req.file.filename;
   console.log(req.file.filename);

   res.send("file uploaded");   
 
 
 
}); 
var server = app.listen(3000, "localhost");
server.on("listening",function(){
   var address = server.address().address;
   var port = server.address().port;
   console.log("Server has started at http://%s:%s",address,port);
  });  
