var express = require('express')
var app = express()
var fs = require("fs");


var fname = __dirname+"/users.json"; 



app.get("/delUser/:num", function(req,res){
  
  var data = fs.readFile(fname,"utf8",function(err,data){
    if(err){
     return console.log(err.stack);
    }
    var jsonData = JSON.parse(data);
    delete jsonData["user"+req.params.num];
    console.log(jsonData);
    fs.writeFileSync(fname,JSON.stringify(jsonData)); 
    res.end("user deleted");    
   });  
});
 
var server = app.listen(3000, "localhost");
server.on("listening",function(){
   var address = server.address().address;
   var port = server.address().port;
   console.log('Server has started at http://%s:%s',address,port);
  });  
