var express = require("express");
var bodyParser = require("body-parser");
var cookieParser = require("cookie-parser");
var path = require("path");
var app = new express();

app.use(cookieParser());

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());


var html = "<div align=center><form action='/' method=post>"+
           "<p>Check to <label>"+
           "<input type=checkbox name=remember/>"+
           "remember me</label><br/>"+
           "<input type=submit value=Submit/>"+
           "</p></form></div>";


app.get("/",function(request,response){
	   if(!request.body.remember){
		response.send(html);
	   }
});  

app.get("/seeCK", function(request,response){
	console.log("....");  
	response.send("Remembered :). Click to <a href='/forget'>forget</a>!.");
});

app.get("/forget", function(request,response){
	 response.clearCookie("remember");
	 console.log("cookie removed");
	 response.send("back");
});


app.post("/", function(request,response){
	var ckLife = 60*1000;
	if(request.body.remember){
	  	response.cookie("remember", 1, {maxAge:ckLife});	
    }
	console.log("hhhh");
	response.redirect("/seeCK"); 	
});

var server = app.listen(3000, "localhost");
server.on("listening",function(){
   var address = server.address().address;
   var port = server.address().port;
   console.log("Server has started at http://%s:%s", address, port);
  });  