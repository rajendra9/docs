var express = require('express')
var app = express()
var fs = require("fs");
var bodyParser = require("body-parser");

var urlEncodeParser = bodyParser.urlencoded({extended: false});

var fname = __dirname+"/users.json"; 


var user4 = {};

app.get("/forAddUser",function(req,res){
  res.sendFile(__dirname + "/" + "addPostUser.html");  
});

app.post("/addUser", urlEncodeParser, function(req,res){
  
  user4["name"] = req.body.username; 
  user4["password"] = req.body.password;
  user4["profession"] = req.body.profession;
  user4["id"] = parseInt(req.body.id); 
  var newUser =  JSON.stringify(user4);
      
  var data = fs.readFileSync(fname,"utf8"); 
  var jsonData = JSON.parse(data);
  jsonData["user4"] = JSON.parse(newUser);
  console.log(jsonData);
  fs.writeFileSync(fname,JSON.stringify(jsonData)); 
  res.end(JSON.stringify(jsonData));
  
});
 
var server = app.listen(3000, "localhost");
server.on("listening",function(){
   var address = server.address().address;
   var port = server.address().port;
   console.log('Server has started at http://%s:%s',address,port);
  });  
