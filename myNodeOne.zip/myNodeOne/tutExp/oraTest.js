var oracle = require("oracledb");
console.log(oracle);