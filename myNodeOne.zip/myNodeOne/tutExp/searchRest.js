var express = require('express')
var app = express()
var fs = require("fs");
app.use(express.static('public'));

app.get("/:num",function(req,res){
  fs.readFile(__dirname+"/users.json","utf8", function(err, data){
   if(err){
     console.log(err.stack);
   }
   var jsonData = JSON.parse(data);
   var user = jsonData["user" + req.params.num];
   res.end(JSON.stringify(user));
  });
});
 
var server = app.listen(3000, "localhost");
server.on("listening",function(){
   var address = server.address().address;
   var port = server.address().port;
   console.log('Server has started at http://%s:%s',address,port);
  });  
