var express = require("express");
var app = new express();

app.set( "view engine",  "ejs");
app.use(express.static(__dirname+"/public"));

app.get("/", function(req, res){
    res.render("pages/index");
});

app.get("/about", function(req, res){
    res.render("pages/about");
});

var serv = app.listen(3000, "127.0.0.1");
serv.on("listening", function(){
   console.log("server stared at localhost at port 3000");
});
