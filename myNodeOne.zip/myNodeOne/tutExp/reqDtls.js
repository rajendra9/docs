var express = require("express");
var app = express();

app.get("/",function(req, res){
   var content = req.accepts("html");
   content +=  req.accepts("text/plain");
   var name =  req.query.name;
   content += name + " , Hello World";
   console.log(content);
   res.send(content); 
});

var server = app.listen(3000, "localhost");
server.on('listening',function(){
    var addr = server.address().address;
    var port = server.address().port;
    console.log("server listening at http://%s:%s",addr,port);    
});

