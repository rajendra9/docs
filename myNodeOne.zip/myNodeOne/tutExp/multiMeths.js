var Exp = require("express");

var app = Exp();



app.get("/", function(req,res){
  
   console.log("Get method invoked");   
   res.send("Hello GET");
});


app.post("/", function(req,res){
  
   console.log("Got POST Request for home page "+res.get("Content-Type"));   
   res.send("Hello POST");
});


app.delete("/delUser", function(req,res){
  
   console.log("Got Delete Request for removing user ");   
  res.send("Hello Delete");
 });

app.get("/listUser", function(req,res){
  
   console.log("Got Get Request for listing users ");   
   res.send("These are Users<br/>Sachin<br/>Prasad<br/>");
});

app.get("/ab*cd", function(req,res){
  
   console.log("Got Get Request for pattern matching ");   
   res.send("This is for ab*cd");
});






var server = app.listen(3000,"localhost");
server.on("listening", function(){
  
  var host = server.address().address;

  var port = server.address().port;
 
  console.log("http://"+host+":"+port);


});