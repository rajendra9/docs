var express = require("express");
var app = express();

app.get("/welcome",function(req, res){
   res.header("Content-Type","text/html");
   res.links({
       STYLESHEET : "http://localhost:3000/welcome/css/myStyle.css"      
   });
   res.send("<h3 align='center'>Welcome to Express Links</h3>");
});
var server = app.listen(3000,'localhost');
server.on('listening',function(){
    var addr = server.address().address;
    var port = server.address().port;
    console.log("server listening at http://%s:%s",addr,port);    
});

