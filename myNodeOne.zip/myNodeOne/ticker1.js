var EventEmitter = require('events').EventEmitter;
var util = require('util');

function Ticker(msg){
 this.msg = msg;
}


Ticker.prototype.ticking = function(period){   
 while(true){
   console.log(this.msg);
   var time = new Date().getTime();
   while(new Date().getTime() < time + period){
    ;
   }
  } 
} 

var ticker = new Ticker('Tick');
ticker.ticking(1000);


    