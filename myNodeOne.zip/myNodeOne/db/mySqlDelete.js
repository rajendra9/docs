var mysql = require('mysql');
function deleteEmps(deptNum){
  var connection = mysql.createConnection({
    host:"localhost",
    port:3306,
    user:"faculty",
    password:"htc"
    });
  
    connection.query("use samp");
    var qryStr = "delete from emp where deptno=?";      
    connection.query(qryStr, [deptNum], function(err, result){
     if(err){
       console.log("Error in fetching");
     }
     else{
      console.log("Number of deleted "+result.affectedRows+" Rows");
     }
    });
    connection.end();    
}
deleteEmps(20);
