var Pool = require("pg-pool");
var qryStr = "insert into node_items(item_id,item_name,item_cost) values($1,$2,$3)";
var params = [1000, 'Sony TV', 35400.5];

var pool = new Pool({
 database: 'samp',
 user: 'postgres',
 password: 'mother',
 port: 5432,
 max: 5,
 min: 2,
 idleTimeoutInMillis: 10
});
pool.query(qryStr, params,(err,res)=>{
  if(err){
    console.error(err);
  }
  else{
   console.log("rows inserted:"+res.rowCount); 
  }
  pool.end();
 }
); 