var mysql = require("mysql");

var connection = mysql.createConnection({
      host:"localhost",
      port:3306,
      user:"faculty",
      password:"htc"
     });

 connection.query("use samp");
 var id = "s800";
 var pname = "Santosh";
 var city = "New Delhi";
 var income = 655000.5; 
  var qryStr = 
   "insert into persons values('"+id+"','"+pname+"','"
   +city+"',"+income+")"; 
 
  connection.query(qryStr,function(err,result){
   if(err){
     console.log("error in inserting values")
   }
   else{
     console.log(result.insertId);
   }
  });

connection.end();
            