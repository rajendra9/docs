var cassandra = require('cassandra-driver');
var async = require('async');

var conn = new cassandra.Client({contactPoints : ['127.0.0.1'], keyspace : 'htc_hr'});
   

     conn.stream('select empno,empname,job,salary,deptname from emp')
      .on('readable',function(err){
    	  if(!err){
    	    var row;
            while(row=this.read()){
            	emp = row;
                console.log(emp.empno+', '+emp.empname+', '+emp.job+', '+emp.salary+', '+emp.deptname);                                  
    	    }                 
           }
           else{
                console.log('some problem in execution');                                  
           } 
          }
     ).on('end',function(){
        console.log('end');
        conn.shutdown();
     });
                  
