const {Pool, Client} = require("pg");
var connectStr = "postgres://postgres:mother@localhost:5432/samp";

var pgClient = new Client({
  connectinString:connectStr,
});
pgClient.connect();

var sep = "::";
pgClient.query("select empno,ename,job,sal,hiredate,deptno  from emp",(err,res) => {
  if(err){
    console.error(err);
  }
  else{
   var empRows = res.rows 
   for(ind in empRows){
    row = empRows[ind]    
    console.log(row.empno + sep + row.ename + sep
             + row.job + sep + row.sal + sep + row.hiredate + sep + row.deptno); 
   }  
  }  
  pgClient.end();
} 
);