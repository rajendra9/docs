var Connection  = require('cassandra-client').Connection;
var async = require('async');

var conn = new Connection({host:['127.0.0.1'],port:9042,keyspace:'htc_hr','cql_version':'2.0.12'});
console.log(conn);
conn.connect(function(err){
	if(err){
	  console.error(err);	
	}
	else{
	  console.info('Success');	
	}
});
conn.close();