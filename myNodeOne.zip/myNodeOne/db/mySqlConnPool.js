var mysql = require("mysql");

var pool = mysql.createPool({
      host:"localhost",
      port: 3306,
      user:"faculty",
      password:"htc"
     });

 
 pool.getConnection(function(err,connection){
   connection.query("use samp");   
   var qryStr = 
     "select bird_id,bird_name,DATE_FORMAT(doi,'%D %M %Y') doi from birds";
   connection.query(qryStr,function(err,rows){
    if(err){
      console.log("error in fetching results")
    }
    else{
       showResults(rows);
    }
   });
  connection.release();
 });
  
 
function showResults(rows){
  var data = '';   
  for(var row in rows){
     data += rows[row].bird_id+'  '+rows[row].bird_name+'  '+
             rows[row].doi+'\r\n';
  }
  console.log(data);
}

               