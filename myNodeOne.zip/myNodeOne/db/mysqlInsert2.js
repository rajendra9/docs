var mysql = require("mysql");

var connection = mysql.createConnection({
      host:"localhost",
      port:3306,
      user:"faculty",
      password:"htc"
     });



 connection.query("use samp");
 var pers = {"adharid":"s750","person_name":"Sandeepan",
 "location":"Srirangam","income":655000.5};
  var insertStr = "INSERT INTO persons SET ?"
 
 var qry = connection.query(insertStr, pers,  function(err,result){
   if(err){
     console.log("error in fetching results")
   }
   else{
     console.log(result.insertId);
   }
  });
console.log(qry);
connection.end();
            