var mysql = require("mysql");

var connection = mysql.createConnection({
      host:"localhost",
      port:3306,
      user:"faculty",
      password:"htc"
     });



 connection.query("use samp");
 
  var updateStr =
    "update  persons SET income = ? where adharid=?";
 
  var qry = connection.query(updateStr, 
            [655000.5,'s100'], 
            function(err,result){
              if(err){
                 console.log("error in fetching results")
              }
              else{
                 console.log(result.insertId);
              }
            });
   console.log(qry);
  connection.end();
            