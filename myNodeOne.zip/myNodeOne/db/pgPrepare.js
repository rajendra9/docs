var pg = require("pg");
var connectStr = "postgres://postgres:password@123@172.16.50.14:5432/samp";


var pgClient = new pg.Client(connectStr);

pgClient.connect();

var eno = 7788;
var query = pgClient.query({
                                                      name:"empQry",
                                                      text: "select ename,job,sal,deptno,hiredate from emp where empno = $1",
                                                      values:[eno]
                                                     });
var data = {};
query.on( "row",  function(row, result){
   data = row;  
});
query.on("end", function(result){
   console.log(data.ename);
   console.log(data.job);
   console.log(data.sal)
   console.log(data.deptno);
   console.log(data.hiredate);
   pgClient.end();
});
