function route(handle, pathName, response, postedData){
  console.log('about to route a request for '+pathName);
  if(typeof handle[pathName] ==='function'){
    handle[pathName](response,postedData);
  }else{
    console.log('No request mapping available for '+pathName);
    response.writeHead(404, {"Content-Type":"text/plain"});
    response.write("404 not found");
    response.end();  
  }

}
exports.route = route;
