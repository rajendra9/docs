var queryString = require('querystring');

function start(response, postedData){
  console.log('start function in requestHandlers');

   var body = "<!DOCTYPE html><html>"+
              "<head><meta charset='UTF-8'/>"+
              "<title>Page for File upload</title></head>"+
              "<body><div align='center'><h1>Choose Files for upload</h1>"+
              "<form method='post' action='upload'><label for='content'>"+
              "Write content for upload</label>&nbsp;&nbsp;"+
              "<textarea cols='30' name='text' rows='5'>"+
              "</textarea><br/><hr/><input type='submit' value='upload'/>"+
              "</form></div></body></html>";   
     response.writeHead(200, {"Content-Type" : "text/html"});
     response.write(body);
     response.end();     
   }

  function upload(response,postedData){
     console.log('upload function in requestHandlers');
     response.writeHead(200, {"Content-Type" : "text/plain"});
     response.write("you Have sent the data  <br/>"+
                  queryString.parse(postedData).text);
     response.end();
  }

exports.start = start;
exports.upload = upload
