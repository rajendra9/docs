var http = require('http');
var url = require('url');

console.log('server starting');
function start(route, handle){
  function onRequest(request,response){
    var postedData = '';
    var pathName = url.parse(request.url).pathname;
    console.log('Request for pathname-'+pathName+" is received");
    request.setEncoding("UTF-8"); 
    request.addListener("data",function(postedDataChunk){
     postedData = postedDataChunk;
     console.log("Received POST data chunk '"+postedDataChunk+"'.");
    }); 
    request.addListener("end",function(){
       route(handle, pathName, response, postedData);     
    }); 
       
  }
  http.createServer(onRequest).listen(8888); 
  console.log("server started");
}
exports.start = start;