var fs = require('fs');

fs.readFile('bigFile.txt',function(err,chunk){
 console.log(chunk.toString()+".......");
});
console.log('Continue your work');
/*setTimeout(function(){
console.log('Continue your work2');
},2000);*/