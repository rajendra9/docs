var fs = require("fs");
var data = "";
var file = "D:/myNode/inputs/input.dat";
fs.readFile(file , function(err,Data){ 
  if(err){
      return console.log(err.stack);
  }   
  console.log("asynchronous read:\n"+data);
});  
data = fs.readFileSync(file);  
console.log("synchronous read:\n"+data); 
console.log("program ended");