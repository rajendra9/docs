var EventEmitter = require('events').EventEmitter;
var util = require('util');

function Ticker(msg){
 this.msg = msg; 
 
}
util.inherits(Ticker, EventEmitter);

Ticker.prototype.tick=function(){
 this.emit('ticking');
}
var ticker = new Ticker('Tick');


ticker.on('ticking',function(){
 setInterval( function(){
        console.log(ticker.msg);
      },1000);
 });

ticker.tick();


    