var buff1 = new Buffer(40);
var buff2 = new Buffer([70,66,78,99]);
var buff3 = new Buffer(" Buffer tutorial","UTF-8");
var buff4 = new Buffer(" Node-js made Simple" ); 
var written = buff1.write("Hello this is node-js tutorial");
console.log("written bytes count is-"+written);
console.log("byff1 contents are-"+buff1.toString("UTF-8"));
console.log("byff2 contents are-"+buff2.toString("UTF-8"));
var buffJson = buff2.toJSON();
console.log(buffJson);
console.log("byff3 contents are-" + buff3.toString("UTF-8"));

var buff5 = Buffer.concat([ buff3, buff4]);
console.log("byff5 contents are-" + buff5.toString());

buff1 = new Buffer("samdeep");
buff2 = new Buffer("Sandeep");
buff3 = new Buffer("sandeep");

var result = buff1.compare(buff2);
console.log(result);
result = buff1.compare(buff3);
console.log(result);
 