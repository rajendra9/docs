var fs = require("fs");

var data = "History of India has very deep Mankind social analysis";

var writeStream = fs.createWriteStream("inputs/simpOut.dat");

writeStream.write(data, "UTF-8" );

writeStream.on("error", function(err) {
   console.log(err.stack);
});
writeStream.on("finish", function() {
  console.log("writing is finished"); 
});



console.log( "Program ended" );