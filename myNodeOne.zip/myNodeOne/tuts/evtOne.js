var events = require("events");
var eventEmitter = new events.EventEmitter();

var  listenFuncA = function(){
  console.log( " listener-1  executed");
};

var  listenFuncB = function(){
  console.log( " listener-2  executed");
};

eventEmitter.addListener("tryConnect", listenFuncA ); 

eventEmitter.on("tryConnect", listenFuncB );

var evtCount = require("events").EventEmitter.listenerCount(eventEmitter,"tryConnect");

console.log("There are " + evtCount + " listeners listening to 'tryConnect' event");

eventEmitter.emit("tryConnect");

eventEmitter.removeListener("tryConnect", listenFuncA);

evtCount = require("events").EventEmitter.listenerCount(eventEmitter,"tryConnect");

console.log("Now there are " + evtCount + " listeners listening to 'tryConnect' event");

eventEmitter.emit("tryConnect");

console.log("program ended");