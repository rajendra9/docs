var fs = require("fs");

var data = "";

var readStream = fs.createReadStream("inputs/input.dat");

readStream.setEncoding("UTF-8");

readStream.on("data", function(dat) {
   data += dat;
});

readStream.on("end", function() {
   console.log(data);
});

readStream.on("error", function(err) {
   console.log(err.stack);
});

console.log( "Program ended" );