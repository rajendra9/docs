//not working
var  request = require('request');
var tough = require('tough-cookie');
var  cookie = tough.Cookie;
cookie.key='country';
cookie.value='India';
var ckJar = new tough.CookieJar();
ckJar.setCookie(cookie,'http://localhost:10080/_session',{strict:false});
request({
     url : 'http://localhost:10080/gen/nodeCK',
     method : 'GET',
      jar : ckJar
  },function(error,response,body){
    console.log(body);
   });