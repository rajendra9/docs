var fs = require('fs');

var fileName ='a.txt'; 
fs.open(fileName, 'r', function(error, fd){
   if(error){ console.log(error); return; }
    var forRead = new Buffer(1700);
    buffStart = 0;
    buffLen = forRead.length;
    targetStart = 0;
   fs.read(fd, 
            forRead, 
            buffStart,
            buffLen, 
            targetStart,
            function(err, read){
             if(err){console.log(err); return;}
             if(read>0) {
                console.log(fileName+" size:"+read+" bytes");
                
             }  
           });
       fs.close(fd, function(error){
        if(error){console.log(error);}
       });
   });    