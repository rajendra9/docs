var http = require("http");
var url = require('url');
var homeReply = '<h3 align="center">Home Page Contents</h3>';
http.createServer(function(request,response){
   var asked = url.parse(request.url).pathname;
   console.log(request.method);
   response.writeHead(200,{"Content-Type":"text/html"});
   console.log(asked);
   if(asked == '/home'){
     response.end(homeReply);
   }
   else{     
    response.end("Hello World");
   }
   }).listen(3000,function(){
  console.log('Server Started at 3000');
});