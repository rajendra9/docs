
var empModule=require('./modEmployee');



var emp=empModule.getEmp(10,"HTC User");



console.log(emp);

console.log(company);