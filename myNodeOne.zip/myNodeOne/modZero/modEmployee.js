function Employee(empNO,empName){
	this.empNO=empNO;
	this.empName=empName;
}

function getEmployee(empNO,empName){
	return new Employee(empNO,empName); 
}
global.company = 'HTC'
//exports={};
//exports=getEmployee;
exports.getEmp=getEmployee;