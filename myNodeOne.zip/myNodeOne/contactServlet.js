var http = require('http');
var options = {
    host:'localhost',
    port:10080,
    path:'/gen/sample?name=dtr+prasad',
    method:'GET'
 };

var req = http.request(options, function(response){
   console.log('response code is:'+response.statusCode);
   console.log('headers:'+JSON.stringify(response.headers));
   response.setEncoding('utf-8');
   response.on('data',function(data){
     console.log(data);
   }); 
}).on('error',function(err){
   console.log(err.message);
});


req.end();