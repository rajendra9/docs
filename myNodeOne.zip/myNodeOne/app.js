var hl= require('./modOne/cust_hello');
var gb = require('./modOne/cust_gb');
var Rect = require('./modTwo/MyRect');

hl.hello();
gb.goodBye();

var rectOne = new MyRect(100,10);
var rectTwo = new MyRect(110,11);

console.log(rectOne.area());
rectOne.show();
console.log(MyRect.compare(rectOne,rectTwo));