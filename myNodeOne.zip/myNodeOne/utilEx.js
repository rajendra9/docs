var util=require('util');
util.log('hello');