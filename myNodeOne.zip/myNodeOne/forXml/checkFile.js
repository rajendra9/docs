var fs = require('fs');
var parse = require('xml-parser');
var xmlContent = fs.readFileSync('./data/AttrDept.xml','UTF-8');
var inspect = require('util').inspect;

var obj = parse(xmlContent);
console.log(inspect(obj, {colors: true, depth: Infinity}));