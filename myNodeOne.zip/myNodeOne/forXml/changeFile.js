var fs = require('fs');

var xml2js = require('xml2js');

var parseJson = require('xml2js').parseString;

var obj = '{ "$" :{"id":"c340"}, "name": "Parvath Rao","email":"parvath@gmail.com"}';


var newFile = './data/AttrDept_new.xml';
var xmlBuilder = xml2js.Builder();


fs.readFile('./data/AttrDept.xml','UTF-8',function(err, data){
  if(err){
    console.error(err);
  }
  console.log(data);
  parseJson(data, function(err, result){
     if(err){
       console.error(err);
     }
     var res= JSON.stringify(result);
     console.log(res);
     var jsonResult = JSON.parse(res);
     console.log(jsonResult);
     //result.root.graph[0].node[3]=obj;
     console.log('HHHH'+jsonResult.dept.emp[0].name);
});
}); 

