var xsdValidator = require("xsd-schema-validator");
var fs = require("fs");

var file = "./data/AttrDept.xml";
var schemaFile = "./data/AttrDept.xsd";
var xmlContent = fs.readFileSync(file); 
xsdValidator.validateXML(xmlContent, schemaFile, function(err,result){
   if(err){
       console.log(err);
   }
   console.log(result.valid);   
});

 