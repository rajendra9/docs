var xmlCheck = require('xmlchecker');


var source ='./data/AttrDept.xml';
try{
    xmlCheck.check(source);
}catch(err){

    console.error(err);
}