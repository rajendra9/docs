var fs = require('fs')
var path = require('path')

//0 will be node 1 will be js file 
askedExt = process.argv[2];

pathStart = '../'

fs.readdir(pathStart,function(err,files){
  if(err){
    console.log('error-'+err);
    throw err;
   } 

//statSync() will return fs.Stats Object 
files.map(function(file){
  return path.join(pathStart,file);
}).filter(function(file){
   var ext = path.extname(file);
  return (fs.statSync(file).isFile() && (ext===askedExt))
}).forEach(function(file){
   console.log(file)
}); 
});     