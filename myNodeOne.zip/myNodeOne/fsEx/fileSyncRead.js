var fs=require('fs');
//console.log(process.argv[2]);
var fileContent=fs.readFileSync(process.argv[2]).toString();
console.log('####' + fileContent);
console.log('No-of-lines:'+fileContent.split('\n').length);
