var fs = require('fs');
if(fs != null){
 console.log('fs is available');
}
var empStream = fs.createReadStream('../inputs/emp.dat');
empStream.on('data',function(data){
 console.log(data.toString());
}); 
empStream.on('end',function(){
 console.log('Reading completed');
}); 
