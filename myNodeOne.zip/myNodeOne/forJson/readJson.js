var jsonf = require('jsonfile');
var file = './data/pers.json';
jsonf.readFile(file,function(er,data){
 if(er){
    console.error(er);
 }else{
    console.log(data);
 }
});