var jsonf = require('jsonfile');

var file = './data/pers.json';

console.log(jsonf.readFileSync(file)); 