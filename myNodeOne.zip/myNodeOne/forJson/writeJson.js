var jsonf = require('jsonfile');

var stu = '{"stuId":"s100","name":"sudhakar","course":"JEE","age":23}';

var fname='./data/students.json';

jsonf.writeFile(fname, stu, function(err){
   if(err){console.error(err);}
 });
console.log('file is written');