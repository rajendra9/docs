var http = require("http");
var url = require("url");
var fs = require("fs");
var socketio = require("socket.io");

//console.log(socketio);
var server = http.createServer(function(request, response){
   response.writeHead(200,{"Content-Type" : "text/html"});
   response.end(fs.readFileSync(__dirname+"/socket.html"));
 }).listen(3000,function(){
   console.log("listening for connections at 3000");
 });
socketio.listen(server).on("connection",function(socket){
 socket.on("message",function(msg){
   console.log("Received Message:",msg);
   socket.broadcast.emit("message",msg);
 });
}); 