console.log('Loop Started');
var i=0;
var beforeLoop=Date.now();
var output=0;
for(i=0;i<10000000;i++){
	output=1000000*10*25*10;
	//process.stdout.write('.');
}
var afterLoop=Date.now();
console.log('Loop Completed after '+i+' iterations in '+((afterLoop-beforeLoop)/1000)+' seconds');