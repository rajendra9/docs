/**
 * New node file
 */
var empModule=require('Employee.js');

var emp=empModule.getEmp(10,"HTC User");

console.log(emp);