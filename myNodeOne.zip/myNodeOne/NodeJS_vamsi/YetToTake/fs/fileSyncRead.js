var fs=require('fs');
//console.log(process.argv[2]);
var fileContent=fs.readFileSync(process.argv[2]).toString();
console.log(fileContent.split('\n').length-1);
