var fs=require('fs');
fs.open('newfile.txt','r',null,function(err,fd){
	var buff=new Buffer(100);
	fs.read(fd,buff,0,null,null,function(err,bytesRead,buffer){
		if(err) throw err;
		console.log(buffer.length);
	})
})