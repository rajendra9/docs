const fs=require('fs');
fs.watch('target.txt',function(event,filename){
	console.log("File "+filename+" just "+event);
});
console.log("Now watching target.txt for changes...");