 module.exports=function(dirPath,ext,printer){
	var fs=require('fs');
	fs.readdir(dirPath,function(err,list){
		if(err)		return printer(err);		
		
		var path=require('path');
		list=list.filter(function(file){
							return path.extname(file)==="."+ext;
						 });
		printer(null,list);				
		
	});
};

