var fs=require('fs');
fs.writeFile('target.txt','This is the new content',function(err){
	if(err) throw err;
	console.log("File Saved.........!");
});