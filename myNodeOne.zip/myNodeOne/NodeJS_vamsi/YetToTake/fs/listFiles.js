var fs=require('fs');
fs.readdir(process.argv[2],function(err,list){
	var path=require('path');
	for(i=0;i<list.length;i++){
		if(path.extname(list[i])=="."+process.argv[3]){
			console.log(list[i]);
		}
	}
});

