var buffer=new Buffer("HTC Global Services");
console.log(buffer.slice(0,3).toString());
buffer.write("Good Morning",5);
console.log(buffer.toString());
console.log(String.fromCharCode(buffer[4]));
console.log(buffer.readUInt8(5))