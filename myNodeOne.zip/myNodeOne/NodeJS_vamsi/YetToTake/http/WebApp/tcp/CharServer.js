var tcp=require('net');
tcp.createServer(function(socket){
	
	socket.on('data',function(data){
		cosole.log(data);
		socket.end();
	});
	
});

tcp.listen(4002);