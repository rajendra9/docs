var http = require('http');
 
http.createServer(function (request, response) {
    response.setHeader('Content-Type', 'text/html; charset=UTF-8');
    response.setHeader('Transfer-Encoding', 'chunked');
	var inTime=Date.now();
    var html =
        '<!DOCTYPE html>' +
        '<html lang="en">' +
            '<head>' +
                '<title>Partial Responses</title>' +
            '</head>' +
            '<body>';
 
    response.write(html);
 
    html = 'Partial Responses<br/>'
 
    response.write(html);
    setTimeout(function(){
        html = 'This comes after 3 seconds.<br/>' 
        response.write(html);
        html ='</body></html>';        
		var outTime=Date.now();
		response.write(""+((outTime-inTime)/1000));
		response.end(html);
    }, 3000);
    setTimeout(function(){
        html = 'This comes after 2 seconds.<br/>'
 
        response.write(html);
 
    }, 2000);
	
}).listen(4002);
