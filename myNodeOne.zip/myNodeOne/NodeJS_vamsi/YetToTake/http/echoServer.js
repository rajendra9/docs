var net = require('net');
var sockets=[];
var server = net.createServer(function(c) { //'connection' listener
	sockets.push(c);
  console.log('client connected');
  c.on('end', function() {
    console.log('client disconnected');
  });
  c.write('hello\r\n');
  c.on('data',function(data){
  //c.write(data.toString());
	sockets.forEach(function(sock){
		sock!==c&&sock.write(data.toString());
	});
  });
});
server.listen(8124, function() { //'listening' listener
  console.log('server bound');
});