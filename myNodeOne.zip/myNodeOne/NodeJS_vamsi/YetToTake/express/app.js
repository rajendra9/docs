var http=require('http');
var express=require('express');
var app=express();
var responseTime=require("response-time");
app.use(express.static(__dirname+'/public'));
app.use(responseTime());
app.get('/index',function(req,res){
	res.sendFile(__dirname+'/public/profile1.1.html');
});
http.createServer(app).listen(1341,function(){
	console.log('Server Started at 1341');
});