var url=require('url');
console.log(url.parse("http://vamsi:vamsipwd@www.sacrumjs.com:8080/vamsi/profle?name=htcglobalservices&dept=training#good/1",true));