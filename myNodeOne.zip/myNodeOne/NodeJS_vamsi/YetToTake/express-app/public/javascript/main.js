window.onload=function(){
	document.getElementById('smile').innerHTMl=':)';
};