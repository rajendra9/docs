/*function Parent(){
	this.firstName="Vamsi";
}
Parent.prototype.secondName="Krishna";

function Child(){
	Parent.call(this);
	this.cFirstName="Arul";
}

Child.prototype.__proto__=Parent.prototype;
Child.prototype.cSecondName="Sundaram";


var parentObj=new Parent();
var childObj=new Child();

console.log(parentObj.firstName);
console.log(parentObj.secondName);
console.log(childObj.cFirstName);
console.log(childObj.cSecondName);
console.log(childObj.firstName);
*/
function Parent(){
	this.firstName="Vamsi";
	this.getFirstName=function(){
		return this.firstName;
	}
}
function Sample(){
	this.firstName="Narayana";
}
var obj=new Parent();
var method=obj.getFirstName;
/*
var value=method.call(new Sample());
console.log(value);
var value=method.call();
console.log(value);
*/
var bindedMethod=method.bind(new Sample());
console.log(bindedMethod());
console.log(bindedMethod());
