function Parent(){
	this.firstName="Vamsi";
}
Parent.prototype.secondName="Krishna";
console.log(new Parent().__proto__);
var oldObj=new Parent();
var obj=Object.create(oldObj);
console.log(Parent.__proto__ === Function.prototype);
console.log(obj.__proto__ ===  oldObj);