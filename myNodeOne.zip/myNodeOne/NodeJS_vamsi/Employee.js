/**
 * New node file
 */
function Employee(empNO,empName){
	this.empNO=empNO;
	this.empName=empName;
}

function getEmployee(empNO,empName){
	return new Employee(empNO,empName); 
}
//exports={};
//exports=getEmployee;
exports.getEmp=getEmployee;