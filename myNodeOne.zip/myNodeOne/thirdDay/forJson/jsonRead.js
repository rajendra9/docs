var jFile = require("jsonfile");

var file = './data/newpers.json';

jFile.readFile(file,function(err,data){
  if(err){
   console.error(err);
  }
  else{
   console.dir(data);
  }
});