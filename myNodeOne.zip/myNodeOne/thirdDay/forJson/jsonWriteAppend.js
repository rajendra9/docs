var jFile = require("jsonfile");

var file = './data/newPers.json';
var rec = {"adharId":"1212 1764 9879",
     "name": "Vadivelan",
     "occupation": "State Govt Service",
     "monthlyIncome":41760.5};


jFile.writeFile(file,rec,{'flag':'a'},function(err,data){
  if(err){
   console.error(err);
  }
  else{
   console.log('rec appended');
  }
});