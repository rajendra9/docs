var fs = require('fs');
var buffToWrite = new Buffer('ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz','UTF-8');

 fs.open('../inputs/a.txt','w',function(error,fd){
    if(error){console.log(error); return;}
    buffStart = 0;
    buffLen = buffToWrite.length;
    fileStart = null;
    fs.write(fd,
             buffToWrite,
             buffStart,
             buffLen,
             fileStart,
             function(error,written){
              if(error){ console.log(error); return; }
              console.log('written ' + written + 'bytes');
             });
     fs.close(fd, function(error) {
      if(error){ console.log(error); return;}
     });
  });       