var myLog = require("log4js");
var logger = myLog.getLogger();

logger.level = "debug";

logger.debug("This is first message");
logger.trace("This is a trace message");