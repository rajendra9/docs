var fs = require("fs");

var data = "Political science is a social science "+ 
           " discipline that deals with systems of "+

           " government and the analysis of political"+
  
           " activity and political behavior.It deals "+

           " extensively with the theory and practice of"+

           " politics which is commonly thought of as the determining"+

           " of the distribution of power and resources"; 
  

var file = "D:/myNode/inputs/polSci.dat";
  
fs.writeFile(file, data, function(err){
  
    if(err){

       return  console.error("error in writing");

    }
 
    console.log("file written successfully");

    console.log("now reading");

    fs.readFile(file, function(err,data){

     if(err){

       return  console.error("error in reading");
 
    }
    console.log("Asynchronous reading " + data.toString());
   
    });

   });


