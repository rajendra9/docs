/*
Writable stream that concatenates all the data from a stream
 and calls a callback with the result.
Use this when you want to collect all the data from a 
stream into a single buffer.
*/

var concat = require('concat-stream');
var fs = require('fs');

var readBuff = fs.readFileSync('../emps.dat');

var writer = concat(function(data){
	console.log(data.toString());
});

writer.write('AAA');
writer.write('\n'+readBuff);
writer.write('\ngggg');
writer.end();