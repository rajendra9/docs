

var fs = require("fs");
var filename = "./data/stores.xml";
var newFilename = "./data/stores_new.xml";

var content = "<item><item-id>400</item-id><item-name>HTC-360</item-name><item-cost>21000.5</item-cost></item></items>";

var existingData;
fs.readFile(filename,"utf-8",function(err, data){
    if(err){
        return console.error(err);
    }
    existingData = data;
    var modData = existingData.toString('ascii');
    modData = modData.replace("</items>", content);
    fs.writeFile(newFilename, modData, "utf-8", function(err,nob){
        if(err){
            return console.error(err);
        }
      console.log("new File  written " + nob + "bytes");    
    });
});
console.log("Program ended");


