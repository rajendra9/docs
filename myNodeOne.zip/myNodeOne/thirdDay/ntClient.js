var net = require("net");
var client = net.connect({port:8090},function(){
   console.log("connected to server at port 8090");
   
});

client.on("data", function(data){
   console.log(data.toString());
   client.end();
}); 

client.on("end", function(){
  console.log("disconnected");
 });