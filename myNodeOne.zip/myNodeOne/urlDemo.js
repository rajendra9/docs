var str2json = require('string-to-json');
var url = require('url');
var str = 'http://google.com:5554/books/mySearch?isbn=c123&author=victor+hugo#java/1'; 
var parsedUrl = url.parse(str,true);
var paramList =str2json.convert(parsedUrl.query);
for (var k in paramList){
   console.log('name is: '+k+' value: '+paramList[k]);
}
console.log('pathname:'+parsedUrl.pathname+'\t');
console.log('search:'+parsedUrl.search+'\t');
console.log('file:'+parsedUrl.hash+'\t');
console.log('host:'+parsedUrl.host+'\t');
console.log('port:'+parsedUrl.port+'\t');
// has resolve(),format()



