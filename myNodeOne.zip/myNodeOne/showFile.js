var path = require('path');
var http = require('http');
var fs = require('fs');

http.createServer(function(request, response){
  var file = path.resolve(request.url);
  console.log(file);  
   fs.exists(file, function(doesExist){
    if(doesExist){
      fs.stat(file,function(err, stat){
        var rdStream; 
        console.log('kkkk');
         if(err){ throw err; }
       
         if(stat.isDirectory()){
           response.writeHead(403);
           response.end('It is not file only directory');
         }
         else{
           rdStream = fs.createReadStream(file);
           response.writeHead(200);
           rdStream.pipe(response);
         }
       });
     }
     else{
       console.log('*****');
       response.writeHead(404);
       response.end('file not found');
     }
   });     
}).listen(3000,function(){
  console.log('file server available at 3000 port');
});

// you have to give http://localhost:8000/myNode/files/simp.txt