<template>
  <div id="app">
   <form-helper>
     <div slot="form-header">
      <h2>Student Information Form</h2>
     </div>
     <div slot="form-fields">
      <table><tr>
        <td>Enter Student Id:</td>
        <td><input type="text" name="stuId" placeholder="Student id" required/></td>
        </tr>
        <tr>
        <td>Enter Student Name:</td>
        <td><input type="text" name="stuName" placeholder="Student Name" /></td>
        </tr> 
        <tr>
        <td>Enter Student Course:</td>
        <td><input type="text" name="course" placeholder="Course" required/></td>
        </tr>
        <tr>
        <td>Enter Student Address:</td>
        <td><textarea rows="5" cols="45" name="address" placeholder="Address" >
          </textarea>
        </td>
        </tr>
        </table>         
     </div>
      <div slot="form-controls">
      <br/><hr/><input type="submit" v-on:click="handleSubmit" value="register Student"/>
     </div>
   </form-helper>

  </div>
</template>

<script>
import FormHelper from './components/formHelper.vue'

export default {
  components: {
    'form-helper': FormHelper
  },
  data(){
    return{
      heading: 'This is a dynamic Title'
    }
  },
  methods:{
    handleSubmit: function(){
      alert('form submitted');  
    }
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 40px;
}
</style>
