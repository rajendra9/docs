package com.jee;

public class TrimVsStrip {

	public void useTrim(String src) {
		System.out.println("Trim usage");
		System.out.println("Before%%%" + src + "%%%");
		src = src.trim();
		System.out.println("After%%%" + src + "%%%");
	} 
	
	public void useStrip(String src) {
		System.out.println("Strip usage");
		System.out.println("Before%%%" + src + "%%%");
		src = src.strip();
		System.out.println("After%%%" + src + "%%%");
	} 
	
	public void useStripLeading(String src) {
		System.out.println("StripLeading usage");
		System.out.println("Before%%%" + src + "%%%");
		src = src.stripLeading();
		System.out.println("After%%%" + src + "%%%");
	} 
	
	public void useStripTrailing(String src) {
		System.out.println("StripTrailing usage");
		System.out.println("Before%%%" + src + "%%%");
		src = src.stripTrailing();
		System.out.println("After%%%" + src + "%%%");
	} 
	
	public static void main(String[] args) {
		String forTrimOne = "     ramesh     ";
		String forStripOne =
		  ""+'\u0020' + '\u0020' + '\u0020' + '\u0020' + '\u0020' + '\u0020' + '\u0041' + '\u0042' + '\u0043' + '\u0044' + '\u0020' + '\u0020' + '\u0020' + '\u0020' + '\u0020' + '\u0020';
		TrimVsStrip trimVsStrip = new TrimVsStrip();
		
		trimVsStrip.useTrim(forTrimOne);
		System.out.println();
		trimVsStrip.useTrim(forStripOne);
		System.out.println();
		
		trimVsStrip.useStrip(forTrimOne);
		System.out.println();
		trimVsStrip.useStrip(forStripOne);
		System.out.println();
		
		trimVsStrip.useStripLeading(forTrimOne);
		System.out.println();
		trimVsStrip.useStripLeading(forStripOne);
		System.out.println();
		
		trimVsStrip.useStripTrailing(forTrimOne);
		System.out.println();
		trimVsStrip.useStripTrailing(forStripOne);
		System.out.println();
	}

}
