package com.jee.spring;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SimpleController {

	@GetMapping("/")
	public String welcome() {
		return "Greetings From Spring Boot";
	}
}
