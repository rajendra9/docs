package com.htc.spring.security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SecurityWebInitializer extends AbstractSecurityWebApplicationInitializer{

    public SecurityWebInitializer() {
        super(SprConfig.class);
    }

}