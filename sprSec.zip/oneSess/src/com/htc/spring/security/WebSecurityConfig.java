package com.htc.spring.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.SessionManagementConfigurer;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;


@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
   
    
    @Autowired
    protected void configureGlobalSecurity(AuthenticationManagerBuilder authBuilder) throws Exception {
      System.out.println("Security method fired");
      authBuilder.inMemoryAuthentication().withUser("prasad").password("pras123").authorities("ROLE_USER");
    }

    private CsrfTokenRepository repository() {
        /*CookieCsrfTokenRepository repository =
                new CookieCsrfTokenRepository(); */
        HttpSessionCsrfTokenRepository repository =
        		new  HttpSessionCsrfTokenRepository();
        repository.setHeaderName("X-XSRF-TOKEN");
        return repository;
    }
    
    @Override
    public void configure(HttpSecurity http)throws Exception {
       SessionManagementConfigurer<HttpSecurity> sessConfigurer = 
                                    http.sessionManagement();
       SessionManagementConfigurer<HttpSecurity>.ConcurrencyControlConfigurer
           concurConfigurer = sessConfigurer.maximumSessions(1);
       concurConfigurer = concurConfigurer.maxSessionsPreventsLogin(true);
       
       http.csrf().csrfTokenRepository(repository());
       http.authorizeRequests()
       .antMatchers("/home").access("hasRole('ROLE_USER')")
       .and()        
       .formLogin().loginPage("/forLogin")
       .defaultSuccessUrl("/home")
       .failureUrl("/forLogin?error=true")
       .usernameParameter("username")
       .passwordParameter("password")
       .and()
       .logout().logoutSuccessUrl("/forLogin?logout=true").clearAuthentication(true);
        
    }
    
  
}