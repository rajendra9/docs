package com.htc.spring.security.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;



@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
   
    
    @Autowired
    protected void configureGlobalSecurity(AuthenticationManagerBuilder authBuilder) throws Exception {
      System.out.println("Security method fired");
      authBuilder.inMemoryAuthentication().withUser("sachin").password("sachi123").authorities("ROLE_USER");
      authBuilder.inMemoryAuthentication().withUser("subbarao").password("sangeet").authorities("ROLE_USER");
    }

     
}