package com.htc.spring.security.config;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class BaseController {
   public static final String VIEW_INDEX = "index";
   private static int counter = 0;

   
   @RequestMapping(value= {"/"},method=RequestMethod.GET)
   public String welcome(ModelMap model){
     System.out.println("contacted");
     return VIEW_INDEX;
   }
   
   
   @RequestMapping(value= {"/home"},method=RequestMethod.GET)
   public String home(ModelMap model){
     System.out.println("contacted");
     model.addAttribute("message","Welcome "+this.getPrincipal());
     model.addAttribute("counter",++counter);
     return "home";
   }   
         
   
   private String getPrincipal(){
     String ret = "";
     Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
     System.out.println("principal " + principal);
     if(principal instanceof UserDetails){
         UserDetails ud = (UserDetails)principal;
         System.out.println("principal " + ud.getUsername());      
         ret = ud.getUsername();
     }
     else{
         ret = principal.toString();
     }
    return ret;
   }

}
