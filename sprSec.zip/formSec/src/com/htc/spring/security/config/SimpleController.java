package com.htc.spring.security.config;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class SimpleController {
   public static final String VIEW_INDEX = "index";

   //org.springframework.validation.support.BindingAwareModelMap
   @RequestMapping(value= {"/"},method=RequestMethod.GET)
   public String welcome(@RequestParam(value="name",required=false,defaultValue="Universe")String name,
                          Model model){
     System.out.println("contacted");
     model.addAttribute("name", name);
     return VIEW_INDEX;
   }
   
   
   @RequestMapping(value= {"/home"},method=RequestMethod.GET)
   public String homePage(Model model){
     System.out.println("contacted home");
     model.addAttribute("sec","Successful in authentication");
     return "home";
   }   
      
   
   @GetMapping("/forLogin")
   public String loginPage(@RequestParam(value="error",required=false)String error,
           @RequestParam(value="logout",required=false)String logout, Model model) {
    if(error != null) {
        model.addAttribute("error", "InvalidCredentials provided");
    }
    if(logout != null) {
        System.out.println("logged out");
        model.addAttribute("message", "Logged out from Domain successfully");
    }
    return "forLogin";
   }
   
}
