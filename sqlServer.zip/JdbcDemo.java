package com.jdbcex;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.htc.jdbc.utils.MyDataSource;


public class JdbcDemo {

 public static void main(String[] args) 
  throws SQLException,ClassNotFoundException {

  Scanner scan = new Scanner(System.in);
  String dbSrc = "",tbl = "";
  MyDataSource ds = null;
  try {

   System.err.println("Enter your DataBase");

   dbSrc = scan.nextLine();
  
   ds = new MyDataSource(dbSrc.toLowerCase());  

   Connection conn = ds.getConnection();
   
   Statement stmt = conn.createStatement();

   System.err.println("Enter your tablename for querying");

   tbl = scan.nextLine();
   
   String sqlStr = "select  *  from "+tbl;

   ResultSet rs = stmt.executeQuery(sqlStr);     

   // for mongodb first column gives ObjectId
   while(rs.next()) {
  
     System.out.println(rs.getString(2) + 
                      " " + rs.getString(3)+ 
                      " " + rs.getString(4));
   }     
   conn.close();
  }catch(Exception e) {
      e.printStackTrace();
  }
 }

}