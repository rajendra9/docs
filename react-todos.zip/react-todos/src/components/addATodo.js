import React, { Component }  from 'react';

class AddTodo extends Component {
    state = {
       content : ''
    }
    handleChange = (event) => {
       this.setState({
          content: event.target.value 
       })
    }
    handleSubmit = (event) => {
       event.preventDefault();
       //console.log(this.state);
       this.props.addTodo(this.state);
       this.setState({
           content: ''
       });
    }
    render(){
        return(
            <div>
               <form onSubmit={this.handleSubmit}>
                 <label>Add A new Todo</label>  
                 <input type="text" onChange={this.handleChange} value={this.state.content} />
                 <button>submit new Todo</button>
               </form> 

            </div>
        )
    }
}

export default AddTodo;