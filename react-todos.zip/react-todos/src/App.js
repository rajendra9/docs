import React, { Component } from 'react';
import Todos from './components/todos';
import AddTodo from './components/addATodo';

class App extends Component {
  state = {
    todos: [
      { id: '1', content: 'buy two Pizzas'},
      { id: '2', content: 'buy Fruit Juice'},
      
    ]
  }
  deleteTodo = (id)=>{
    //console.log(id);
    const filteredTodos = this.state.todos.filter((todo)=>{
      return todo.id !== id
    });
    this.setState({todos: filteredTodos});
  }
  addingTodo = (newTodo) => {
     newTodo.id = Math.random();
     const existingTodos = [...this.state.todos, newTodo];     
     this.setState({todos: existingTodos});
  }
  render() {
    return (
      <div className="todo-app container">
        <h1 className="center blue-text">Todos</h1>
          <Todos todos={this.state.todos} delTodo={this.deleteTodo}/>        
          <hr/>
          <AddTodo addTodo = {this.addingTodo} />

      </div>
    );
  }
}

export default App;
