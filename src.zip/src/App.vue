<template>
  <div>
    <keep-alive>
       <component v-bind:is="component"></component>
    </keep-alive> 
    <div id = "buttons"> 
    <button v-on:click="component = 'add-item' ">Show Add-Item</button>
    &nbsp;&nbsp;
    <button v-on:click="component = 'show-items' ">Show Show-Items</button>
    </div>
  </div>
</template>

<script>
import AddItem from './components/addItem.vue';
import ShowItems from './components/showItems.vue';

export default {
  components: {
    'add-item': AddItem,
    'show-items': ShowItems     
  },
  data(){
    return{
      component: 'show-items'
    }
  }
}
</script>

<style>
body {
  margin-top: 30px;
  font-family: 'Nunito SemiBold';
}
#buttons{
  text-align:center;
  margin: 20px 5px;
  font-size: 16px;
  font-weight: bold;
}
</style>
