<template>
  <div id="rest-items">
      <h2> All Rest Purchased Items </h2>
    <div v-for="(restItem, index) in restItems" v-bind:key="index" id="rest-Item">
      <div class="para"><span>Item Id:{{restItem.item_id}}</span>
      <span>Item Name:{{restItem.item_name}}</span>
      <span>Item Type:{{restItem.item_type}}</span>
      <br/>      
      <span>Item Cost:{{restItem.item_cost}}</span>
      <span>Item Customer:{{restItem.customer}}</span>
      </div>
      <hr/>  
    </div>  
  </div>
</template>

<script>
export default {
    data(){
        return{
          restItems: []
        }
    },
    created(){
        this.$http.get('http://localhost:9090/vuerest/rest/items/all')
                  .then(function(data){
                      this.restItems = data.body;
                  })
    }

}
</script>


<style scoped>
   #rest-items{
       max-width:650px;
       margin: 0 auto;
       text-align: center;
   }

     
   .para{
       padding: 20px;
       margin: 20px 0; 
       box-sizing: border-box;
       background: lightblue;
       border: 2px solid;
       display: block;
   }
   .para span{
        margin: 20x;
        padding: 20px;
        font-size: 16px;
        font-weight: bold;
   }
</style>
