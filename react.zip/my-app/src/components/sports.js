import React , {Component}  from 'react';

class Sports extends Component{
    state={
        sports: ['Cricket', 'Tennis', 'Shuttle', 'Hockey', 'Football', 'Kabbadi']
    }
    render(){
        return(
          <div> <table><tbody>{
          this.state.sports.map((item,index)=>{
              return <tr key={index}><td>{item}</td></tr>
          })
          }
          </tbody>
          </table>
          </div>
        );
    }
}
export default Sports;