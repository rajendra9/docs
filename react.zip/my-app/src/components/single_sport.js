import React  from 'react';

const single_sport  = ({name})=>{  
      return(
          <div><h1>{name}</h1></div>
      )
  }
export default single_sport;