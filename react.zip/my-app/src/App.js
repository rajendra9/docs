import React, { Component } from 'react';

import './App.css';
import Sports from './components/sports';
import SingleSport  from './components/single_sport';

class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
         
          <h3>Component Embedding</h3>
          <SingleSport name="Baseball"/>
          <SingleSport name="Table-Tennis"/>
          <Sports/>
          
        </header>
      </div>
    );
  }
}

export default App;
