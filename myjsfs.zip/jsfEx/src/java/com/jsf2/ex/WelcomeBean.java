package com.jsf2.ex;

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

@Named(value = "welcomeBean")
@RequestScoped
public class WelcomeBean implements java.io.Serializable {
   private String welcome;
    
   public WelcomeBean() {
     this.welcome = "Welcome Prasad, JSF2.1 programming";
   }

    public String getWelcome() {
        return welcome;
    }

    public void setWelcome(String welcome) {
        this.welcome = welcome;
    }
   
    
}
