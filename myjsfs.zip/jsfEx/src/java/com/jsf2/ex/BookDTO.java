package com.jsf2.ex;

import java.util.Objects;
import java.util.logging.Logger;

public class BookDTO implements java.io.Serializable {
    private  String  isbn;
    private  String  bookName;    
    private  String  authorName;
    private  String  publisher;
    private  double  cost;

    public BookDTO(String isbn, String bookName, String authorName, String publisher, double cost) {
        this.isbn = isbn;
        this.bookName = bookName;
        this.authorName = authorName;
        this.publisher = publisher;
        this.cost = cost;
    }

    public BookDTO(String isbn) {
        this.isbn = isbn;
    }
    
    public BookDTO(){}

    public String getIsbn() {
        return isbn;
    }

    public String getBookName() {
        return bookName;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getPublisher() {
        return publisher;
    }

    public double getCost() {
        return cost;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.isbn);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final BookDTO other = (BookDTO) obj;
        if (!Objects.equals(this.isbn, other.isbn)) {
            return false;
        }
        return true;
    }   

    @Override
    public String toString() {
        return "BookDTO{" + "isbn=" + isbn + ", bookName=" + bookName + ", authorName=" + authorName + ", publisherName=" + publisher + ", cost=" + cost + '}';
    }
    
    
    
}
