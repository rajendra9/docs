package com.jsf2.ex;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.inject.Named;
import java.util.Arrays;
import javax.enterprise.context.RequestScoped;
import javax.faces.model.SelectItem;

@Named(value = "smBean")
@RequestScoped
public class StringMethodsBean implements java.io.Serializable  {
    List<SelectItem> strMeths;
    private String  result;
    private String  strMeth;
    private String  input;
    private String  input2;
    private String  input3;

 

    public void setResult(String result) {
        this.result = result;
    }

    public void setStrMeth(String strMeth) {
        this.strMeth = strMeth;
    }

    public void setInput(String input) {
        this.input = input;
    }

    public void setInput2(String input2) {
        this.input2 = input2;
    }

    public void setInput3(String input3) {
        this.input3 = input3;
    }    
    
    public StringMethodsBean() {
      strMeths = new ArrayList<>();
      Collections.addAll(strMeths, 
                         new SelectItem("--choose--"),new SelectItem("upper"),
                         new SelectItem("lower"), new SelectItem("len"),
                         new SelectItem("splitting"), new SelectItem("joining"),
                         new SelectItem("reverse"),new SelectItem("replace"));
    }

    public List<SelectItem> getStrMeths() {
        return strMeths;
    }

    public String getResult() {
        return result;
    }

    public String getStrMeth() {
        return strMeth;
    }

    public String getInput() {
        return input;
    }

    public String getInput2() {
        return input2;
    }

    public String getInput3() {
        return input3;
    }
    
    public String doInvokeMeth(){
      if(strMeth == null || strMeth.isEmpty()){
         strMeth = "len";         
      }  
      switch(strMeth){
       case "len" : result = "length of input is:"+input.length();
                    break;
       case "upper" : result = input.toUpperCase();
                      break;
       case "lower" : result = input.toLowerCase();
                      break;  
       case "reverse" : result = new StringBuilder(input).reverse().toString();                          
                        break;
       case "splitting" : String[] tokens = input.split("[|]");
                      StringBuilder sb = new StringBuilder();
                      if(tokens.length>0){
                       sb.append(tokens.length+" tokens are there");
                       for(String token : tokens){
                          sb.append(token+" ");
                       }
                      }
                      result = sb.toString();
                      break;
       case "joining" : result = String.join("::", input,input2,input3);
                        break;
       case "replace" : result = input.replaceAll(input2, input3);
                        break;
                       
      }
      return "showResult";
    }
    
}
