package com.jsf2.ex;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentHashMap;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.model.SelectItem;

@Named(value = "libBean")
@SessionScoped
public class LibraryBean implements java.io.Serializable {
    List<SelectItem> publishers;
    private  String  isbn;
    private  String  bookName;
    private  String  authorName;
    private  String  publisher;
    private  double  cost;    
    private  int     nob;
    private  List<BookDTO>  books;
    private  String  result;
    
    public String getResult() {
        return result;
    }  

    public void setResult(String result) {
        this.result = result;
    }
     
    ConcurrentMap<BookDTO,Integer> libBooks;
       
    public LibraryBean() {
      publishers = new ArrayList<>();
      Collections.addAll(publishers, 
                         new SelectItem("--choose--"),new SelectItem("M/s Wrox"),
                         new SelectItem("M/s Wiley"), new SelectItem("M/s Packt"),
                         new SelectItem("M/sTata McGrill"), 
                         new SelectItem("M/s Apress"));
      libBooks = new ConcurrentHashMap<>();
      
      BookDTO book = new BookDTO("s2312", "JEE7", "JoshJuncau", "M/s Apress", 450.5);
      libBooks.put(book,12);
  
      book = new BookDTO("s2412", "XML1.1", "Jim Clarke", "M/s Wiley", 540.5);
      libBooks.put(book,12);
      
      book = new BookDTO("s2532", "Asp.Net", "Marlon Samuels", "M/s Packt", 655.5);
      libBooks.put(book,12);      
    
    }

    public void setPublishers(List<SelectItem> publishers) {
        this.publishers = publishers; 
    }
    
    public void setBooks(List<BookDTO> books) {
        this.books = books;
    }

    public void setLibBooks(ConcurrentMap<BookDTO, Integer> libBooks) {
        this.libBooks = libBooks;
    }

    public List<BookDTO> getBooks() {
      List<BookDTO> ret = new ArrayList<>();
      ret.addAll(libBooks.keySet());
      return ret;
    }

    public ConcurrentMap<BookDTO, Integer> getLibBooks() {
        return libBooks;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getBookName() {
        return bookName;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getPublisher() {
        return publisher;
    }

    public double getCost() {
        return cost;
    }

    public int getNob() {
        return nob;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public void setNob(int nob) {
        this.nob = nob;
    }   

    public List<SelectItem> getPublishers() {
        return publishers;
    }

    public void addBook(){
      boolean boo = false;  
      BookDTO book = new BookDTO(this.getIsbn(),this.getBookName(),
                     this.getAuthorName(),this.getPublisher(),this.getCost());
      BookDTO existing = new BookDTO(this.getIsbn());
      if(!libBooks.containsKey(existing)){
        System.out.println("Book not exists");
        libBooks.put(book, this.nob);
       boo = true;
      }
      this.books = this.getBooks();
      if(boo){
       result = "Book added successfully";
      }
      else{
        result = "Problem in adding book";  
      }
    }
    
}
