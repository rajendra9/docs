package com.jsf2.ex;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.time.LocalDate;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

@Named(value = "msgBean")
@SessionScoped
public class ForMessagesBean implements Serializable {
  private   String  content;
  private   int  counter = 0;
  FacesMessage facesMessage;
  public String getContent() {
    return content;
  }

   public void setContent(String content) {
     this.content = content;
   }
   
  
   public ForMessagesBean() {
     content = "";  
     facesMessage = 
         new FacesMessage(FacesMessage.SEVERITY_ERROR,"Bean is Initialized",null);
     FacesContext.getCurrentInstance().addMessage(null, facesMessage);
   }
  
   public void  newMessage(){
     LocalDate locDate = LocalDate.now();
     counter++;
     String hitMsg = counter>1 ? (counter+ "times") : (counter+ "time");
     hitMsg = "You have pressed this button "+hitMsg+" ,today is:"+locDate.toString();
     facesMessage = new FacesMessage(FacesMessage.SEVERITY_INFO, hitMsg, null);
     FacesContext.getCurrentInstance().addMessage(null, facesMessage);
    
     FacesMessage contentMsg = null;
     if(content.equalsIgnoreCase("java")){
       contentMsg = 
            new FacesMessage(FacesMessage.SEVERITY_INFO,"Good entry",null);
     }
     else {
       contentMsg = 
            new FacesMessage(FacesMessage.SEVERITY_ERROR,"Not correct entry ,try again",null);  
     }
     FacesContext.getCurrentInstance().addMessage("msgForm:content", contentMsg);
   }
    
}
