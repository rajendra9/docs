package com.jsf2.ex;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;


@Named(value = "navBean")
@SessionScoped
public class NavigatingBean implements Serializable {
 
  private boolean navFlag = false;

  public boolean isNavFlag() {
    return navFlag;
  }

  public  void  setNavFlag(boolean navFlag){
     System.out.println("####"+navFlag); 
     this.navFlag = navFlag; 
  }
  
  public  String  goToPage2() {
    return "page_2";
  }


  public  String  goBackToPage1() {
     return "page_1";
  }
   
  public  String  actPage3(){
     return "navPage3";       
  }
  
  public void login(){
    this.setNavFlag(true);
    System.out.println("flag method");
  }  
  
  
    
}
