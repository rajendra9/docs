package htcjsfs;

import java.io.Serializable;
import java.util.Objects;
import java.util.Date;

public class PersonBean implements Serializable, Comparable<PersonBean>{

    private String ssn;
    private String phone;
    private String name;
    private String email;
    private Date   dor;
    private double income;
    private String occupation;
    private String city;
    private int age;
    
    public void setDor(Date dor) {
        this.dor = dor;
    }

    public Date getDor() {
        return dor;
    }
    
    @Override
    public int compareTo(PersonBean other) {
       return this.ssn.compareTo(other.ssn);
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCity() {
        return city;
    }
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + Objects.hashCode(this.ssn);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PersonBean other = (PersonBean) obj;
        if (!Objects.equals(this.ssn, other.ssn)) {
            return false;
        }
        return true;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSsn() {
        return ssn;
    }
    
    public int getAge() {
        return age;
    }
    
    public PersonBean() {
    }

    public String getPhone() {
        return phone;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public double getIncome() {
        return income;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    @Override
    public String toString() {
        return "PersonBean{" + "ssn=" + ssn + ", phone=" + phone + ", name=" + name + ", email=" + email + ", dor=" + dor + ", income=" + income + ", occupation=" + occupation + ", city=" + city + ", age=" + age + '}';
    }

   
    
}
