package htcjsfs;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import java.util.Arrays;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

@Named(value = "personReg")
@SessionScoped
public class PersonRegistrarBean implements Serializable {
    SortedSet<PersonBean> persons = new TreeSet<>();
    PersonBean person = new PersonBean();

    public void setPersons(SortedSet<PersonBean> persons) {
        this.persons = persons;
    }

    public SortedSet<PersonBean> getPersons() {
        return persons;
    }
    List<String> occupations = 
       Arrays.asList("Private Service","Computer Service",
                     "Business","State Govt Employee",
                     "Central Govt Employee","Other");
    
    public PersonRegistrarBean() {
    }

    public PersonBean getPerson() {
        return person;
    }

    public List<String> getOccupations() {
        return occupations;
    }

    public void setPerson(PersonBean person) {
        this.person = person;
    }

    public void setOccupations(List<String> occupations) {
        this.occupations = occupations;
    }
    
    public String enroll(){
       System.out.println("****"+person); 
       boolean boo = this.persons.add(person);
       if(boo){
           return "success";
       }
       else{
           return "failure";
       }
    }
    
}
