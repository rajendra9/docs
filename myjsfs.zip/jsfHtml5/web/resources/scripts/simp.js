function validateSsn(){
    var myForm = document.getElementById("myForm");
    var formErr = document.getElementById("formErr");    
    var cityVal = document.getElementById("cityCol").value;
    cityVal = cityVal.toLowerCase();
    console.log(cityVal);
    var ssnVal = document.getElementById("ssnCol").value;
    ssnVal = ssnVal.toLowerCase();
    console.log(ssnVal);
    
    var city2Letters = cityVal.substring(0,2);
    if(ssnVal.startsWith(city2Letters)){
        console.log("form is valid");
        myForm.submit();        
    }
    else{
        console.log('ERROR');
        formErr.innerHTML='SSN value not matching with city given';
        return false;
    }    
}

