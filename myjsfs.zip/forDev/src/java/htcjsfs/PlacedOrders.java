package htcjsfs;


import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import javax.faces.event.ActionEvent;

@Named(value = "placedOrders")
@SessionScoped
public class PlacedOrders implements Serializable {
   private Order order;   
   String  message;   
   List<Order>  orders;
   String  status="...";
   
   private ConcurrentMap<Integer,Order>  ordersMap;
   
   {
     ordersMap = new ConcurrentHashMap<>();   
     this.order = new Order();
     orders = new ArrayList<>();
     GregorianCalendar gc = new GregorianCalendar(2015, Calendar.AUGUST, 23);
     Order purOrder = new Order(1000, gc.getTime(), 3245.0,"M/s Cheran Co");
     ordersMap.put(purOrder.getOrderId(), purOrder);
     
     gc = new GregorianCalendar(2015, Calendar.SEPTEMBER, 30);
     purOrder = new Order(2000, gc.getTime(), 4345.80, "M/s Rally Co" );
     ordersMap.put(purOrder.getOrderId(),purOrder);
     
     gc = new GregorianCalendar(2015, Calendar.JULY, 14);
     purOrder = new Order(3000, gc.getTime(), 3845.80, "M/s Vali Co" );
     ordersMap.put(purOrder.getOrderId(), purOrder);
     
     gc = new GregorianCalendar(2015, Calendar.OCTOBER, 8);
     purOrder = new Order(4000, gc.getTime(), 3812.80, "M/s Velan Co" );
     ordersMap.put(purOrder.getOrderId(), purOrder);
     
     gc = new GregorianCalendar(2015, Calendar.JUNE, 19);
     purOrder = new Order(5000, gc.getTime(),  3245.80, "M/s Alazhan Co" );
     ordersMap.put(purOrder.getOrderId(), purOrder);
     orders.addAll(ordersMap.values());
     
   }
   public String getStatus() {
        return status;
   }

   public String getMessage() {
      return message;
   }   
   
    
   public void setStatus(String status) {
       this.status = status;
   }

   public void setMessage(String message) {
        this.message = message;
   }

   public Order getOrder() {
       return order;
   }

   public void setOrder(Order order) {
        this.order = order;
   }    
    
   public boolean isExisting(int id){
     return ordersMap.containsKey(id);
   }
   
   public List<Order> getOrders() {
        return orders;
   }
   
   public void setOrders(List<Order> orders) {
        this.orders = orders;
   }
   
   public  void  searching(ActionEvent event){
     boolean boo = this.isExisting(order.getOrderId());
     if(boo){
         status = "Not OK,Existing Order";
     }
     else{
         status = "OK, go ahead non-existing Order";
     }
   } 
   
    public String addOrder(ActionEvent evt){
      System.out.println(order);  
      boolean  ret = false;
      Integer id = order.getOrderId();  
      if(!ordersMap.containsKey(id)){
        ordersMap.put(id, order);
        orders = new ArrayList<>();
        orders.addAll(ordersMap.values());
        return "success";
      }
      else{
        return "index";  
      }
    }
}
