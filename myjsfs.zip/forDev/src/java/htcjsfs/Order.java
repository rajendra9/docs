package htcjsfs;

import java.util.Date;
import javax.inject.Named;

@Named("order")
public class Order implements java.io.Serializable {
    private  int     orderId;
    private  double  cost;
    private  String  customer;
    private  Date    orderDate;
    
    public Order(int orderId) {
        this.orderId = orderId;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public Order() {
      System.out.println("HHHH");
    }

    public Order(int orderId, 
                 Date orderDate,
                 double cost, 
                 String customer) {
        this.orderId = orderId; 
        this.orderDate = orderDate;
        this.cost = cost;
        this.customer = customer;
    }

    public int getOrderId() {
        return orderId;
    }

   
    public double getCost() {
        return cost;
    }

    public String getCustomer() {
        return customer;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

   
    public void setCost(double cost) {
        this.cost = cost;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 83 * hash + this.orderId;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Order other = (Order) obj;
        if (this.orderId != other.orderId) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Order{" + "orderId=" + orderId + ", cost=" + cost + ", customer=" + customer + '}';
    }
    
    
    
}
