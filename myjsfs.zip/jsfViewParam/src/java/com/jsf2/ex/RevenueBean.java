package com.jsf2.ex;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import javax.faces.application.FacesMessage;
import java.time.format.DateTimeFormatter;
import javax.faces.context.FacesContext;

@Named(value = "revenueBean")
@SessionScoped
public class RevenueBean implements Serializable {
   private  String     applicantName;
   private  String     serviceName;
   private  double     feesToBePaid;
   private  LocalDate  dateOfIssue;     
   public RevenueBean() {
   }

    public LocalDate getDateOfIssue() {
        return dateOfIssue;
    }

   
   public String getApplicantName() {
      return applicantName;
   }

   public String getServiceName() {
        return serviceName;
   }

   public double getFeesToBePaid() {
      return feesToBePaid;
   }

   public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
   }

   public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
   }

   public void setFeesToBePaid(double feesToBePaid) {
        this.feesToBePaid = feesToBePaid;
   }

   public String  validateFields(){
      String ret = "apply";    
      String msg = "Welcome";  
      if(this.getServiceName() != null){
       String servName = this.getServiceName();
       double fees = this.getFeesToBePaid();
       switch (servName){
         case "Birth_Certificate" :
              System.out.println("KKKK");
            if(fees<65.0){
              msg ="have to pay Rs65/- ,not enough charges";                  
            }
            break;
         case "Death_Certificate" :
            if(fees<50.0){
              msg = "have to pay Rs50/- ,not enough charges";                  
            }
            break;    
         case "Encumberance_Certificate" :
            if(fees<120.0){
              msg ="have to pay Rs120/- not enough charges";                  
            }
            break;    
         } 
         if(msg.equalsIgnoreCase("welcome")){
            return this.addApplicant();           
         }
         else {
           FacesMessage facesMessage = 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg);    
           FacesContext.getCurrentInstance().addMessage(null, facesMessage); 
         }
      }      
      return ret;
    }
    public String addApplicant(){
      CertificateApply certificateApply = new CertificateApply();
      this.dateOfIssue = certificateApply.addApplicant(this.getApplicantName(),
              this.getServiceName(), this.getFeesToBePaid());
      if(this.dateOfIssue!=null){
         return "success";  
      }
      return "apply";
    }
   public void goAhead(){
       System.out.println("kkkkkk");
   }
   
}
