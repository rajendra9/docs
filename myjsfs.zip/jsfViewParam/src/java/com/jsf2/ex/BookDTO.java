package com.jsf2.ex;

import java.io.Serializable;
import java.util.Objects;

public class BookDTO implements Serializable {
    private  String  isbn;
    private  String  bookName;
    private  String  author;
    private  String  publisher;
    private  double  cost;
    private  int     qty;

    public BookDTO(String isbn, 
                   String bookName, 
                   String author, 
                   String publisher, 
                   double cost, 
                   int qty) {
        this.isbn = isbn;
        this.bookName = bookName;
        this.author = author;
        this.publisher = publisher;
        this.cost = cost;
        this.qty = qty;
    }

    public BookDTO(String isbn) {
        this.isbn = isbn;
    }

    public BookDTO() {
    }

    public String getIsbn() {
        return isbn;
    }

    public String getBookName() {
        return bookName;
    }

    public String getAuthor() {
        return author;
    }

    public String getPublisher() {
        return publisher;
    }

    public double getCost() {
        return cost;
    }

    public int getQty() {
        return qty;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 61 * hash + Objects.hashCode(this.isbn);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final BookDTO other = (BookDTO) obj;
        if (!Objects.equals(this.isbn, other.isbn)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "BookDTO{" + "isbn=" + isbn + ", bookName=" + bookName + ", author=" + author + ", publisher=" + publisher + ", cost=" + cost + ", qty=" + qty + '}';
    }   

}
