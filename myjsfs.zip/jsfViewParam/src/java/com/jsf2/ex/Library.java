package com.jsf2.ex;

import java.util.List;

public interface Library extends java.io.Serializable {
  public  String updateBook(String isbn, String publisher, double cost, int qty);
  public  List<AuthorDTO> getAllAuthors();
  public  BookDTO  searchBook(String isbn);
  public List<String> getAllIsbns(); 
}
