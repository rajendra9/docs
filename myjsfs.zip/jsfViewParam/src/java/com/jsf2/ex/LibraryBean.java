package com.jsf2.ex;

import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

@Named(value="libBean")
@SessionScoped
public class LibraryBean implements java.io.Serializable {
   private  BookDTO  currentBook;
   
   private  String  searchId;
   
   private  List<AuthorDTO>  authors;
   private  Library  library;
   private List<String> bookIds; 
 
   public List<String> getBookIds() {
     return bookIds;
   }

   public void setBookIds(List<String> bookIds) {
     this.bookIds = bookIds;
   } 
   
   {
    library = new ChennaiLibrary();
    authors = library.getAllAuthors();
    bookIds = library.getAllIsbns();
   }

    public BookDTO getCurrentBook() {
        return currentBook;
    }

    public String getSearchId() {
        return searchId;
    }

    public void setSearchId(String searchId) {
        System.out.println("----"+searchId);
        this.searching(searchId);
    }   
    
    public List<AuthorDTO> getAuthors() {
        return authors;
    }

    public void setCurrentBook(BookDTO currentBook) {
        this.currentBook = currentBook;
    }

    public void setAuthors(List<AuthorDTO> authors) {
        this.authors = authors;
    }
   
    public void modifyBook(){
        FacesMessage facesMessage = null;
        String ret = library.updateBook(currentBook.getIsbn(),
                                        currentBook.getPublisher(),
                                        currentBook.getCost(),
                                        currentBook.getQty());
        if(!ret.contains("Failed")){
            facesMessage = new FacesMessage(FacesMessage.SEVERITY_INFO, ret, ret);
        }
        else{
          facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR, ret, ret);  
        }
        FacesContext.getCurrentInstance().addMessage(null, facesMessage);
        authors = library.getAllAuthors();
        currentBook = new BookDTO();
    } 
    
    public String  searching(String isbn){
       currentBook = library.searchBook(isbn);
       System.out.println(currentBook);
       return "editBook";
    }
}
