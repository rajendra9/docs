package com.jsf2.ex;

import java.time.LocalDate;
import java.util.Date;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class CertificateApply implements java.io.Serializable {
  Set<Applicant> applicants = new HashSet<>();
  public class Applicant{  
   private  String    applicantName;
   private  String    serviceName;
   private  double    feesToBePaid;
   private  LocalDate dateOfIssue;

   public Applicant(String applicantName, String serviceName, double feesToBePaid) {
        this.applicantName = applicantName;
        this.serviceName = serviceName;
        this.feesToBePaid = feesToBePaid;
   }

    public String getApplicantName() {
        return applicantName;
    }

    public String getServiceName() {
        return serviceName;
    }

    public double getFeesToBePaid() {
        return feesToBePaid;
    }

    public LocalDate getDateOfIssue() {
        return dateOfIssue;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public void setFeesToBePaid(double feesToBePaid) {
        this.feesToBePaid = feesToBePaid;
    }

    public void setDateOfIssue(LocalDate dateOfIssue) {
        this.dateOfIssue = dateOfIssue;
    }

    @Override
    public String toString() {
          return "Applicant{" + "applicantName=" + applicantName + ", serviceName=" + serviceName + ", feesToBePaid=" + feesToBePaid + ", dateOfIssue=" + dateOfIssue + '}';
    } 
    

  }
  
  public LocalDate addApplicant(String name, String service, double fees){
    if(name == null || service ==null || fees<=0.0 ){  
      throw new IllegalArgumentException("not proper arguments");
    }
    Applicant applicant = new Applicant(name, service, fees);
    LocalDate locDate = LocalDate.now();
    LocalDate doi = locDate.plusDays(7);
    applicant.setDateOfIssue(doi);
    this.applicants.add(applicant);
    return doi;
  }
}
