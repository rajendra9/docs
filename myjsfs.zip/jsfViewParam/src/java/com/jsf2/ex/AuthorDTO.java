package com.jsf2.ex;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class AuthorDTO implements Serializable {
    private  String  authorName;
    private  String  workingInstitution;
    private  List<String>  writtenBooks = new ArrayList<>();
    private  String  otherCredits;

    
    public AuthorDTO() {
    }

    public AuthorDTO(String authorName, String workingInstitution) {
        this.authorName = authorName;
        this.workingInstitution = workingInstitution;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getWorkingInstitution() {
        return workingInstitution;
    }

    public List<String> getWrittenBooks() {
        return writtenBooks;
    }

    public void setWrittenBooks(List<String> writtenBooks) {
        this.writtenBooks = writtenBooks;
    }   

    public String getOtherCredits() {
        return otherCredits;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public void setWorkingInstitution(String workingInstitution) {
        this.workingInstitution = workingInstitution;
    }    

    public void setOtherCredits(String otherCredits) {
        this.otherCredits = otherCredits;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 47 * hash + Objects.hashCode(this.authorName);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AuthorDTO other = (AuthorDTO) obj;
        if (!Objects.equals(this.authorName, other.authorName)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = 
              new StringBuilder("authorName=" + authorName + ", workingInstitution=" + workingInstitution + ", otherCredits=" + otherCredits);
        if(this.writtenBooks.size()>0){
          writtenBooks.forEach(b -> sb.append(b+" "));   
        }
        return sb.toString();
    }    
    
}
