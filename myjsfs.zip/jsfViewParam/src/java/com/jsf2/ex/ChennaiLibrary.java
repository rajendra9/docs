package com.jsf2.ex;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ChennaiLibrary implements Library {
    public static final String KAV = "D.G.H.Kavlen";
    public static final String PETER = "H.K.P.Peterson";
    
    public static final String WILEY = "M/S Wiley Publishers, Sanfransisco";
    public static final String WROX = "M/S Wrox Printers, New York";
    public static final String APRESS = "M/S Apress Publications, London";   
    
    private Set<BookDTO> books = new HashSet<>();
    private List<AuthorDTO> authors = new ArrayList<>();
  
            
    {
      BookDTO book = new BookDTO("SH234554","JEE8 Basics", PETER, WILEY, 550.5, 20);
      books.add(book);
      
      book = new BookDTO("NH134562","Asp.Net", KAV, WROX, 575.5, 12);
      books.add(book);
      
      book = new BookDTO("LH642121","JavaScript for Web", PETER, APRESS, 587.0, 12);
      books.add(book);
      
      book = new BookDTO("SH134562","Easy LinQ ", KAV, WILEY, 355.5, 14);
      books.add(book);
      
      AuthorDTO author = new AuthorDTO(PETER, "Google");
      author.setOtherCredits("Awarded For Guiding Java Web Developers");
      List<String> peterBooks = new ArrayList<>();
      Collections.addAll(peterBooks, "LH642121", "SH234554");
      author.setWrittenBooks(peterBooks);
      authors.add(author);
      
      author = new AuthorDTO(KAV, "Bing");
      author.setOtherCredits("Bookler Prize winner for Guidance");
      List<String> kavBooks = new ArrayList<>();
      Collections.addAll(kavBooks, "NH134562", "SH134562");
      author.setWrittenBooks(kavBooks);
      authors.add(author);     
      
      
    }
    @Override
    public String updateBook(String isbn, String publisher, double cost, int qty) {
       String ret = "Updation Failed because found no such book";
       for(BookDTO bk : books){
         if(bk.getIsbn().equalsIgnoreCase(isbn)){
           bk.setPublisher(publisher);
           bk.setCost(cost);
           bk.setQty(qty);
           ret = "Book is successfully updated";
           break;
         }  
       } 
       return ret;
    }

    @Override
    public List<AuthorDTO> getAllAuthors() {
        return this.authors;
    }

    @Override
    public BookDTO searchBook(String isbn) {
      BookDTO ret = new BookDTO();
      for(BookDTO bk : books){
       if(bk.getIsbn().equalsIgnoreCase(isbn)){
         ret = bk;
         break;
       }
      } 
      return  ret;
    }
    
   public List<String> getAllIsbns(){
      List<String> bookIds = new ArrayList<>(); 
      books.forEach(bk -> bookIds.add(bk.getIsbn()));
      return bookIds;
    }
    
}
