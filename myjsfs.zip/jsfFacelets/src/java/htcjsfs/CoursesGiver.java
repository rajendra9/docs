
package htcjsfs;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;


@Named(value="coursesGiver")
@SessionScoped
public class CoursesGiver implements java.io.Serializable {
    List<String>  courses;
    private  String curDate;
    
    {
      courses = new ArrayList<>();
      Collections.addAll(courses,"M.P.C","M.M.P","C.B.Z","B.C.A");
      curDate = (new SimpleDateFormat("yyyy-MM-dd")).format(new Date());
    }

    public List<String> getCourses() {
        return courses;
    }

    public String getCurDate() {
        return curDate;
    }

    public void setCourses(List<String> courses) {
        this.courses = courses;
    }

    public void setCurDate(String curDate) {
        this.curDate = curDate;
    }
    
    
}
