package htcjsfs;

import javax.enterprise.context.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.inject.Inject;
import javax.inject.Named;


@Named(value="userValidator")
@SessionScoped
public class UserValidator implements java.io.Serializable {
   LoginUser loginUser;
   String  message;

   @Inject
   UserRegistrar registrar;
   
   public UserValidator() {
      loginUser = new LoginUser();
   }

   public LoginUser getLoginUser() {
      return loginUser;
   }

   public String getMessage() {
      return message;
   }

   public void setLoginUser(LoginUser loginUser) {
        this.loginUser = loginUser;
   }

   public void setMessage(String message) {
       this.message = message;
   }
   
   public void authenticate(ActionEvent evt){
     String un = loginUser.getUsername();
     String pwd = loginUser.getPassword();
     boolean boo = registrar.authenticate(un, pwd);
     if(boo){
         message = "Reg User welcome";
     }
     else{
         boolean ret = registrar.register(un, pwd);
         if(ret){
           message = "New User Registration is done";  
         }
         else{
           message = "New User Registration Failed";   
         }         
     }
    }  
    
}
