package htcjsfs;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named
@SessionScoped
public class UserRegistrar implements java.io.Serializable {
   ConcurrentMap<Integer,LoginUser> regUsers;
   
   {
     regUsers = new ConcurrentHashMap<>();
     LoginUser user = new LoginUser("SethuRaman", "seth123");
     regUsers.put(user.hashCode(), user);
     
     user = new LoginUser("Madhavan", "madha123");
     regUsers.put(user.hashCode(), user);
     
   }
   public boolean register(String username, String pwd){
       boolean ret = false;
       LoginUser user = new LoginUser(username,pwd);
       int hCode = user.hashCode();
       if(!regUsers.containsKey(hCode)){
         regUsers.put(hCode, user);
         ret = true;        
       }
       return ret;
   }
   public boolean authenticate(String username, String pwd){
       boolean ret = false;
       Collection<LoginUser> users = regUsers.values();
        for(LoginUser lu : users){
         if(  lu.getUsername().equalsIgnoreCase(username)
            &&lu.getPassword().equalsIgnoreCase(pwd)){
           ret = true;
           break;
         }
       }
       return ret;
   }
    
}
