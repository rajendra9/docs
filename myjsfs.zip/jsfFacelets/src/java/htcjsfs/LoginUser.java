
package htcjsfs;

import java.util.Objects;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named(value="loginUser")
@SessionScoped
public class LoginUser implements java.io.Serializable {
   private  String username;
   private  String password;
   
   public LoginUser() {
   }

    public LoginUser(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.username);
        hash = 97 * hash + Objects.hashCode(this.password);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final LoginUser other = (LoginUser) obj;
        if (!Objects.equals(this.username, other.username)) {
            return false;
        }
        if (!Objects.equals(this.password, other.password)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "LoginUser{" + "username=" + username + ", password=" + password + '}';
    }
 
   
   
}
