drop table examentries;

create  table examentries(hallticket  varchar2(10) primary key,
candidate  varchar2(20),examName varchar2(40) not null,doe date,fees number,training varchar2(12),
hall_area varchar2(20),hall_city varchar2(20),hall_state  varchar2(20));

insert into examentries values('A1100','Nanda Gopal','Java Web Certification',
'12-SEP-2014',1550.5,'NEEDED','Tambaram','Chennai','Tamilnadu');


commit;