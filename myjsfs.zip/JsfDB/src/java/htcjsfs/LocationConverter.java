package  htcjsfs;

import  javax.faces.application.FacesMessage;
import  javax.faces.component.UIComponent;
import  javax.faces.context.FacesContext;
import  javax.faces.convert.Converter;
import  javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;
import java.util.Map;
import java.util.HashMap;

@FacesConverter("locConverter")
public class LocationConverter implements Converter {
  Map<String,String> areaMap = new HashMap<>();
  Map<String,String> cityMap = new HashMap<>();
  Map<String,String> stateMap = new HashMap<>();
  
  {
     areaMap.put("TAM","Tambaram");
     areaMap.put("CHR","Chromepet");
     areaMap.put("TNG","TNagar");
     areaMap.put("BSR","Besant Road");
     areaMap.put("JAN","Jaya Nagar");
     areaMap.put("AMR","AmeerPet");
     areaMap.put("SAN","SanathNagar");
     areaMap.put("GDY","Guindy");  
     areaMap.put("ELR","Eloor");  
     areaMap.put("LP","Lajpat Nagar");  
     
  
     cityMap.put("VJA","Vijayawada");
     cityMap.put("HYD","Hyderabad");
     cityMap.put("BAN","Bangalore");
     cityMap.put("COC","Cochin");
     cityMap.put("CHE","Chennai");
     cityMap.put("DL","New Delhi");
     
      
     stateMap.put("TN","Tamilnadu");
     stateMap.put("AP","AndhraPradesh");
     stateMap.put("TA","Telangana");
     stateMap.put("KT","Karnataka");
     stateMap.put("KL","Kerala");
     stateMap.put("DH","Delhi"); 
  }  
    
 public  Object getAsObject(FacesContext  ctx,
                            UIComponent comp,
                            String value) {
  HallLocVO  loc = null;
  if(value.trim().length()==0) {
   loc = new HallLocVO();
  }
  else {
   int  dashFirst  =  value.indexOf('-');
   int   dashLast  =  value.lastIndexOf('-');       
  
   String   areaCode  =  value.substring(0,dashFirst);
   String area = this.getAreaName(areaCode.toUpperCase());
      
   String   cityCode = value.substring(dashFirst+1,dashLast);
   String city = this.getCityName(cityCode.toUpperCase());
      
   String stateCode = value.substring(dashLast+1);
   String state = this.getStateName(stateCode.toUpperCase());
     
   loc = new   HallLocVO(area,city,state);
   System.out.println("..."+loc);
  }
  if(value == null){
   FacesMessage  fMessage = 
         new FacesMessage(FacesMessage.SEVERITY_ERROR,
                          "unrecognizedLocation",
                          "Location code  "+value+
                          " is not recognized" );
   throw new ConverterException(fMessage);        
  }
  return  loc;  
 }

  public String getAsString(FacesContext ctx,
                            UIComponent comp,
                            Object obj) {
   
  String ret = "",objVal = "";
   if(obj != null){
     objVal = obj.toString();
     int  dashFirst  =  objVal.indexOf('-');
     int   dashLast  =  objVal.lastIndexOf('-');       
     String   areaName  =  objVal.substring(0,dashFirst);
     String areaCode = this.getAreaCode(areaName.toUpperCase());
     
     String cityName = objVal.substring(dashFirst+1,dashLast);
     String cityCode = this.getCityCode(cityName.toUpperCase());
     
     String stateName = objVal.substring(dashLast+1);
     String stateCode = this.getStateCode(stateName.toUpperCase());
     ret = areaCode+"-"+cityCode+"-"+stateCode;
     return ret;
   }
   else {
    FacesMessage  fMessage = 
         new FacesMessage(FacesMessage.SEVERITY_ERROR,
                          "unrecognizedLocation",
                          "Location code  "+obj+
                          " is not recognized" );
    throw new ConverterException(fMessage);        
    }
  }

  private String getStateName(String stateCode) {
   String ret = stateCode;
   if(this.stateMap.containsKey(stateCode)){
       ret = this.stateMap.get(stateCode);
   }
   return ret;
  }

  private String getStateCode(String  stateName) {
   String ret = stateName;
   if(this.stateMap.containsValue(stateName)){
    for(Map.Entry<String,String> entry:this.stateMap.entrySet()){
       if(entry.getValue().equalsIgnoreCase(stateName)){
           ret = entry.getKey();
           break;
       }
    }
   }
   return ret;
  }
  
  private String getCityName(String  cityCode) {
   String ret = cityCode;
   if(this.cityMap.containsKey(cityCode)){
       ret = this.cityMap.get(cityCode);
   }
   return ret;  
  }
  
  private String getCityCode(String  cityName) {
   String ret = cityName;
   if(this.cityMap.containsValue(cityName)){
    for(Map.Entry<String,String> entry:this.cityMap.entrySet()){
       if(entry.getValue().equalsIgnoreCase(cityName)){
           ret = entry.getKey();
           break;
       }
    }
   }
   return ret;
  }

  private String getAreaName(String   areaCode) {
   String ret = areaCode;
   if(this.areaMap.containsKey(areaCode)){
       ret = this.areaMap.get(areaCode);
   }
   return ret;  
  }
 
  private String getAreaCode(String  areaName) {
   String ret = areaName;
   if(this.areaMap.containsValue(areaName)){
    for(Map.Entry<String,String> entry:this.areaMap.entrySet()){
       if(entry.getValue().equalsIgnoreCase(areaName)){
           ret = entry.getKey();
           break;
       }
    }
   }
   return ret;
  }

}