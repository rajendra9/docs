package htcjsfs;

import java.io.Serializable;
import java.util.List;
import java.util.Date;

public interface ExamEntriesDAO extends Serializable {
   public String  saveEntry(String candidate, String examName, Date doe, double fees, String training,HallLocVO hallLocation);
   public List<String>  getTrainingTypes();
   public List<ExamEntry> getExamEntries();   
}
