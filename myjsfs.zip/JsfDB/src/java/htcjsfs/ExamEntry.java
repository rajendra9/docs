package htcjsfs;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Embedded;

@Entity
@Table(name="EXAMENTRIES")
@NamedQuery(name="plain.all",query="select e from ExamEntry e")
public class ExamEntry implements Serializable {
    private  String  hallTicket;
    private  String  entrant;
    private  String  examName;   
    private  Date    doe;
    private  double  fees;
    private  ExamTraining  examTraining;
    private  HallLocVO     examHall;
    
    @Embedded
    public HallLocVO getExamHall() {
        return examHall;
    }

    public void setExamHall(HallLocVO examHall) {
        this.examHall = examHall;
    }
    
    public ExamEntry() {
       this.examHall = new HallLocVO();
    }

    public ExamEntry(String hallTicket, 
                     String entrant, 
                     String examName,
                     Date doe, 
                     double fees,
                     ExamTraining examTraining) {
        super();
        this.hallTicket = hallTicket;
        this.entrant = entrant;
        this.examName = examName;
        this.doe = doe;
        this.fees = fees;
        this.examTraining = examTraining;
        this.examHall = new HallLocVO();
     
    }
    
    @Id
    @Column
    public String getHallTicket() {
        return hallTicket;
    }

    public void setHallTicket(String hallTicket) {
        this.hallTicket = hallTicket;
    }  
    
    @Column(name="candidate")
    public String getEntrant() {
        return entrant;
    }
    
    public void setEntrant(String entrant) {
        this.entrant = entrant;
    }
   
    @Column
    public String getExamName() {
        return examName;
    }

    public void setExamName(String examName) {
        this.examName = examName;
    }
    
    @Temporal(TemporalType.DATE)
    @Column
    public Date getDoe() {
        return doe;
    }

    public void setDoe(Date doe) {
        this.doe = doe;
    }
    
    @Column
    public double getFees() {
        return fees;
    }

    public void setFees(double fees) {
        this.fees = fees;
    }
    
    @Enumerated(EnumType.STRING)
    @Column(name="TRAINING")
    public ExamTraining getExamTraining() {
        return examTraining;
    }

    public void setExamTraining(ExamTraining examTraining) {
        this.examTraining = examTraining;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((hallTicket == null) ? 0 : hallTicket.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ExamEntry other = (ExamEntry) obj;
        if (hallTicket == null) {
            if (other.hallTicket != null)
                return false;
        } else if (!hallTicket.equals(other.hallTicket))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "ExamEntry{" + "hallTicket=" + hallTicket + ", entrant=" + entrant + ", examName=" + examName + ", doe=" + doe + ", fees=" + fees + ", examTraining=" + examTraining + ", examHall=" + examHall + '}';
    }
    
}
