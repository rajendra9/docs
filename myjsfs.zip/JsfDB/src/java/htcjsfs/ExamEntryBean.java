package htcjsfs;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

@Named(value = "examEntry")
@SessionScoped
public class ExamEntryBean implements java.io.Serializable{
   private  String     entrant;
   private  String     examName;
   private  Date       doe;
   private  double     fees;
   private  String     training;
   private  HallLocVO  examHall;
   private  List<SelectItem>  trainingTypes;
   private  List<ExamEntry>    entries;
   
   ExamEntriesDAO  entriesDao;
    
   {
     entriesDao = new ExamEntriesService();
     entries = entriesDao.getExamEntries();
     trainingTypes = new ArrayList<>();
     List<String> trgTypes = entriesDao.getTrainingTypes();
     trgTypes.forEach((s)-> trainingTypes.add(new SelectItem(s)));
     examHall = new HallLocVO();
   } 

    public String getEntrant() {
        return entrant;
    }

    public Date getDoe() {
        return doe;
    }

    public String getExamName(){
       return examName;
    }
    
    public void setExamName(String examName){
        this.examName = examName;
    }
    
    public double getFees() {
        return fees;
    }

    public String getTraining() {
        return training;
    }

    public List<SelectItem> getTrainingTypes() {
        return trainingTypes;
    }

    public List<ExamEntry> getEntries() {
        return entries;
    }

    public void setEntrant(String entrant) {
        this.entrant = entrant;
    }

    public void setFees(double fees) {
        this.fees = fees;
    }

    public void setDoe(Date doe) {
        this.doe = doe;
    }

    public void setTraining(String training) {
        this.training = training;
    }

    public void setTrainingTypes(List<SelectItem> trainingTypes) {
        this.trainingTypes = trainingTypes;
    }

    public void setEntries(List<ExamEntry> entries) {
        this.entries = entries;
    }
   
    public void saveEntry(){
      String result = entriesDao.saveEntry(this.getEntrant(), this.getExamName(),
               this.getDoe(), this.getFees(), this.getTraining(),this.getExamHall());
      FacesMessage facesMessage = null;
      if(!result.contains("problem")){
        facesMessage = new  FacesMessage(FacesMessage.SEVERITY_INFO, result, result); 
      }
      else{
        facesMessage = new  FacesMessage(FacesMessage.SEVERITY_ERROR, result, result);             
      }
      FacesContext.getCurrentInstance().addMessage(null, facesMessage);
      entries = entriesDao.getExamEntries();
      setEntrant("");
      setExamName("");
      setDoe(null);
      setTraining("");
      setFees(0.0);
      this.setExamHall(null);
      
    }

    public void setExamHall(HallLocVO examHall) {
        this.examHall = examHall;
    }

    public HallLocVO getExamHall() {
        return examHall;
    }
   
}
