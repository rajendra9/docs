package htcjsfs;
import javax.persistence.Embeddable;
import javax.persistence.Column;

@Embeddable
public class HallLocVO implements java.io.Serializable {

 private  String  state  ="";
 private  String  city = "";
 private  String  area = "";
     
 public HallLocVO(String area, String city, String state) {
  this.state = state;
  this.city = city;
  this.area = area;
 }
      
 public HallLocVO() {
  super();  
 }
      
 @Column(name="HALL_AREA")
 public String getArea() {
  return this.area;
 }

 
 public void setArea(String area){
  this.area = area;
 }
 @Column(name="HALL_CITY")     
 public String getCity(){
  return this.city;
 }
      
 public void setCity(String city){
  this.city = city;
 }
 @Column(name="HALL_STATE")     
 public String getState(){
  return this.state;
 }
      
 public void setState(String state){
  this.state = state;
 }

 public String toString() {
  return this.area+"-"+this.city+"-"+this.state;
 }

}