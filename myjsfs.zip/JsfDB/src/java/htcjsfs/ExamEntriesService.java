package htcjsfs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.Query;




public class ExamEntriesService implements ExamEntriesDAO {
   EntityManagerFactory factory;
   EntityManager em;
   EntityTransaction trans;
   
   public ExamEntriesService() {
     factory = Persistence.createEntityManagerFactory("myDB");
     em = factory.createEntityManager();
   }

   
   public String saveEntry(String candidate, String examName, Date doe,
          double fees, String training,HallLocVO hallLocation) {
      String ret = "problem in creating exam entry";
      trans = em.getTransaction();
      trans.begin();
      String hallTicket = this.getNextHallTicket();
      ExamEntry entry = new ExamEntry(hallTicket, candidate, examName, doe,
                             fees, ExamTraining.valueOf(training));
      entry.setExamHall(hallLocation);
      try {
        em.persist(entry);
        ret = "Exam Entry Successfully saved";
        trans.commit();
      }catch(Exception ex){
         trans.rollback(); 
         throw new RuntimeException(ex.getMessage());
      }
      return ret;
   }

   @Override
   public List<String> getTrainingTypes() {
      List<String> ret = new ArrayList<>(); 
      ret.add("--Choose--");
      Arrays.stream(ExamTraining.values()).forEach((s)->ret.add(s.toString()));
      return ret;
   }

    @Override
    public List<ExamEntry> getExamEntries() {
        List<ExamEntry> ret = new ArrayList<>();
        trans = em.getTransaction();
        trans.begin();
        try {
         TypedQuery<ExamEntry> query = em.createNamedQuery("plain.all",ExamEntry.class);
          ret = query.getResultList();
          trans.commit();
        }catch(Exception ex){
           trans.rollback(); 
           throw new RuntimeException(ex.getMessage());
        }
        return ret;
    }

  
    private String getNextHallTicket() {
      String ret = "";
      String qryStr = "select max(to_number(substr(e.hallticket,2),'99999.99'))+1 from examentries e";   
      try {
         Query query = em.createNativeQuery(qryStr);
         Number num = (Number)query.getSingleResult();
         ret = "A"+num;
       }catch(Exception ex){
           throw new RuntimeException(ex.getMessage());
        }
        return ret;
    }
    
    public static void main(String[] args){
      ExamEntriesService  service = new ExamEntriesService();
      System.out.println(service.getNextHallTicket());
    }

}
