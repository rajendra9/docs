package htcjsfs;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator("examNameValidator")
public class ExamNameValidator implements Validator {
   
    public void validate(FacesContext context,
                         UIComponent component,
                         Object value)
     throws ValidatorException {
       String entered = value.toString().toLowerCase();
       String[] valids = {"java","microsoft","oracle","mainframes"};
       boolean isValid = false;
       for(String valid : valids){
         if(entered.contains(valid)){
             isValid = true;
             break;
         }  
       }
       if(!isValid){
         String msgText = "Eamination is for any one of 'java'/'microsoft'/'oracle'/'mainframes' only";  
         FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR,msgText,msgText);  
         throw new ValidatorException(facesMsg);
       } 
    } 

}


