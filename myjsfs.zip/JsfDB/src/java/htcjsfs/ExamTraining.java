package htcjsfs;

import java.io.Serializable;

public enum ExamTraining implements Serializable {
  NEEDED, NOT_NEEDED, ONLINE_NEEDED;
}
