package htcjsfs;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import javax.faces.event.ValueChangeEvent;


@Named(value = "custSupport")
@SessionScoped
public class CustomerSupportBean implements Serializable {
    String supportRequest;
    Date requestDate;
    String details;
    String environment;
    String allotedTechnician="----------";
    
    List<SupportMember> members = new ArrayList<>();

    public CustomerSupportBean() {
      members.add(new SupportMember("Patrick Oneil","Spring-Security"));
      members.add(new SupportMember("GatesBerg","Grails"));
      members.add(new SupportMember("Mandrick Powell","Spring-Web"));
      members.add(new SupportMember("Robinson Gothe","Java Server Faces"));
      members.add(new SupportMember("Stuart Curtis","Struts2-Model"));
      members.add(new SupportMember("Neil Connoly","Struts2-Views"));     
    }

    public String getSupportRequest() {
        return supportRequest;
    }

    public void setSupportRequest(String supportRequest) {
        this.supportRequest = supportRequest;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public void setAllotedTechnician(String allotedTechnician) {
        this.allotedTechnician = allotedTechnician;
    }

    public void setMembers(List<SupportMember> members) {
        this.members = members;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public String getDetails() {
        return details;
    }

    public String getEnvironment() {
        return environment;
    }

    public String getAllotedTechnician() {
        return allotedTechnician;
    }

    public List<SupportMember> getMembers() {
        return members;
    }
    
    
    
    
}
