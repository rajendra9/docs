package htcjsfs;

public class SupportMember implements java.io.Serializable {
    private String memberName;
    private String javaTopic;

    public SupportMember(String memberName, String javaTopic) {
        this.memberName = memberName;
        this.javaTopic = javaTopic;
    }  
    
    
    public String getMemberName() {
        return memberName;
    }

    public String getJavaTopic() {
        return javaTopic;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public void setJavaTopic(String javaTopic) {
        this.javaTopic = javaTopic;
    }

    @Override
    public String toString() {
        return "SupportMember{" + "memberName=" + memberName + ", javaTopic=" + javaTopic + '}';
    }
    
    
        
}
