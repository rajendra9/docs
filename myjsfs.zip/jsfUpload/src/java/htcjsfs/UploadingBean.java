
package htcjsfs;

import java.io.InputStream;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.Part;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;


@Named(value = "uploading")
@RequestScoped
public class UploadingBean {
    Part upFile1;
    Part upFile2;
    Part upFile3;
    
    String destPath = "\temp"; 
    String sep = "";
    public UploadingBean() {
      FileSystem fileSystem = FileSystems.getDefault();
      sep = fileSystem.getSeparator();
    }

    public Part getUpFile1() {
        return upFile1;
    }

    public Part getUpFile2() {
        return upFile2;
    }

    public Part getUpFile3() {
        return upFile3;
    }

    public void setUpFile1(Part upFile1) {
        this.upFile1 = upFile1;
    }

    public void setUpFile2(Part upFile2) {
        this.upFile2 = upFile2;
    }

    public void setUpFile3(Part upFile3) {
        this.upFile3 = upFile3;
    }

    
    public String upload(){
      System.out.println("method invoked");
      Part[] upFiles = new Part[]{upFile1, upFile2,upFile3}; 
      String ret = ""; 
      for(Part part : upFiles){
        try{
          destPath = part.getSubmittedFileName();
          Path file = Paths.get("c:" + sep + "temp" + sep + destPath);
          System.out.println("****" + file.toString());
          InputStream input = part.getInputStream();
          Files.copy(input, file, StandardCopyOption.REPLACE_EXISTING);
          ret = "success";
        }catch(Exception ioe){
            ioe.printStackTrace();
            ret = "failure";
         }
       } 
       return ret;
    }  
    
    
}
