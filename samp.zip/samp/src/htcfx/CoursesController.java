package htcfx;


import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;

public class CoursesController {

  CourseSubjectsMapper subsMapper;
  @FXML //fx:id=courses
  private ToggleGroup courses;


  @FXML //fx:id=ta
  private TextArea ta;




  @FXML
  public void initialize(){
	 this.subsMapper = new CourseSubjectsMapper();
	 if(this.courses != null){
       ChangeListener chListener =
	      new ChangeListener<Toggle>(){
	        public void changed(ObservableValue<? extends Toggle> ov,
	                   Toggle oldValue, Toggle newValue){
	           ta.setText("");
	           if(courses.getSelectedToggle() != null){
		        RadioButton button = (RadioButton)newValue;
		        System.out.println(button.getId());
		        String course = button.getId();
		           String subs = subsMapper.getSubjects(course);
		           ta.appendText(subs);
		        }
		      }
		    };
        courses.selectedToggleProperty().addListener(chListener);
    }


  }

}
