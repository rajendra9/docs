package htcfx;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@SuppressWarnings("serial")
public class CourseSubjectsMapper implements Serializable {

	ConcurrentMap<String,List<String>> courseSubjects;

	{
	   courseSubjects = new ConcurrentHashMap<>();
	   List<String> bscList = new ArrayList<>();
	   Collections.addAll(bscList,
			   "English", "Tamil", "Maths",
			   "Physics", "Chemistry");
	   courseSubjects.put("bsc",  bscList);

	   List<String> baList = new ArrayList<>();
	   Collections.addAll(baList,
			   "English", "Tamil", "Maths",
			   "Economics", "History");
	   courseSubjects.put("ba",  baList);
	   List<String> bcomList = new ArrayList<>();
	   Collections.addAll(bcomList,
			   "English", "Tamil", "Commerce",
			   "Company Law", "Accounts");
	   courseSubjects.put("bcom",  bcomList);
	   List<String> bcaList = new ArrayList<>();
	   Collections.addAll(bcaList,
			   "English", "Tamil", "Mainframes",
			   "Javascript", "JEE");
	   courseSubjects.put("bca",  bcaList);
	}

	public String getSubjects(String course){
		StringBuffer sb = new StringBuffer();
		if(this.courseSubjects.containsKey(course)){
		   List<String> subs = this.courseSubjects.get(course);
		   for(String sub : subs){
			   sb.append(sub + " ");
		   }
		}
		return sb.toString().trim();
	}

}
