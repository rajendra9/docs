package htcfx;

import java.net.URL;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class CoursesMain extends Application {
	Logger logger = Logger.getLogger("htcfx");
  @Override
  public void start(Stage primaryStage)throws Exception {
	try {
	  URL location = CoursesMain.class.getResource("samp.fxml");
		AnchorPane root = (AnchorPane)FXMLLoader.load(location);
		Scene scene = new Scene(root, 385, 420);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	} catch(Exception e) {
		logger.setLevel(Level.SEVERE);
        logger.addHandler(new FileHandler("simp.log"));
        logger.throwing("CoursesMain","start", e);
		e.printStackTrace();
	}
  }

  public static void main(String[] args) {
		launch(args);
  }
}
