import { Component } from '@angular/core';
import Community from './community';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  community:Community = {registerNum:'',
   name:'',
   area:'',
   commuEmail: '',
   dtOfEsta:''};
  
  onSubmit(){      
    alert(JSON.stringify(this.community));
  }
}
