 interface Community {
    registerNum: string,
    name: string,
    area: string,
    commuEmail: string,
    dtOfEsta: string
}
export default Community;