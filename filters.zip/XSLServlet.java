import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import xmlbeans.XslDAO;

public class XSLServlet extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    XslDAO myDAO;

    public XSLServlet()
    {
        myDAO = new XslDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
        response.setContentType("application/xml");
        PrintWriter out = response.getWriter();

        String reply = "", id = "";

        String act = request.getParameter("act");
        if (act.equalsIgnoreCase("list"))
        {
            reply = myDAO.getAllBooksInXML();
        } else if (act.equalsIgnoreCase("one"))
        {
            id = request.getParameter("bkId");
            reply = myDAO.getOneBookInXML(id);
        }
        out.write(reply);
        out.close();
    }

}
