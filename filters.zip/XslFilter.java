import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponseWrapper;

public class XslFilter implements Filter
{
    FilterConfig fConfig;

    public XslFilter()
    {

    }

    public void destroy()
    {

    }

    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException
    {
        fConfig.getServletContext().log("before Request");
        HttpServletRequest req = (HttpServletRequest) request;
        String act = req.getParameter("act");
        HttpServletResponseWrapper wrapper = null;
        if (act.equalsIgnoreCase("one"))
        {
            String id = req.getParameter("bkId");
            wrapper = new XslSingleResponseWrapper(response, id);
        } else
        {
            wrapper = new XslAllResponseWrapper(response);

        }
        chain.doFilter(request, wrapper);

        PrintWriter writer = wrapper.getWriter();
        writer.close();

        response.setContentType("text/html");
        ChangeStream cStream = (ChangeStream) wrapper.getOutputStream();
        byte[] result = cStream.getResult();
        response.setContentLength(result.length);

        ServletOutputStream outStream = response.getOutputStream();
        outStream.write(result);
        fConfig.getServletContext().log("before Response");
    }

    /**
     * @see Filter#init(FilterConfig)
     */
    public void init(FilterConfig fConfig) throws ServletException
    {
        this.fConfig = fConfig;
    }

}
