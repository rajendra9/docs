import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletOutputStream;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

public class XslSingleResponseWrapper extends HttpServletResponseWrapper
{
    private final PrintWriter writer;
    private final XslSingleConverterStream xslStream;

    public XslSingleResponseWrapper(ServletResponse response, String id)
    {
        super((HttpServletResponse) response);
        xslStream = new XslSingleConverterStream(id);
        writer = new PrintWriter(xslStream, true);
    }

    @Override
    public ServletOutputStream getOutputStream() throws IOException
    {
        return xslStream;
    }

    @Override
    public PrintWriter getWriter() throws IOException
    {
        return writer;
    }

}
