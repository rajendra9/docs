import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletOutputStream;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

public class MailResponseWrapper extends HttpServletResponseWrapper
{
    private final PrintWriter writer;
    private final AddMailStream mailStream;

    public MailResponseWrapper(ServletResponse response)
    {
        super((HttpServletResponse) response);
        mailStream = new AddMailStream();
        writer = new PrintWriter(mailStream, true);
    }

    @Override
    public ServletOutputStream getOutputStream() throws IOException
    {
        return mailStream;
    }

    @Override
    public PrintWriter getWriter() throws IOException
    {
        return writer;
    }

}
