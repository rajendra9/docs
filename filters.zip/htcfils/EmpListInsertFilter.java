package htcfils;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EmpListInsertFilter implements Filter {

    FiltersEmpDAO dao;
    ArrayList<FiltersEmpVO> list;
    FilterConfig fConfig;
    
    public void init(FilterConfig fConfig) throws ServletException {
     this.fConfig = fConfig;
     dao = new FiltersEmpDAO();
     list = dao.getEmps();
    }

    public EmpListInsertFilter() {

    }

	public void destroy() {
      this.fConfig = null;
      try {
        this.dao.closeConn();
	  }
      catch(Exception e) {
       e.printStackTrace();
      }
      this.list.clear();
      this.dao = null;
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

	    HttpServletRequest req = (HttpServletRequest)request;
	    HttpServletResponse res = (HttpServletResponse)response;
               
        String path = req.getRequestURI();
        String resMsg = "";
        if(path.contains("XML"))
        {
          resMsg = dao.getDetailsInXML(list);
          System.out.println(resMsg);
          req.setAttribute("result", resMsg);                
        }
        else if(path.contains("HTML"))
        {
          resMsg = dao.getDetailsInHTML(list);
          req.setAttribute("result", resMsg);                
        }
	    chain.doFilter(req, res);
	}

	

}
