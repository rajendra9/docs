package htcfils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import javax.naming.InitialContext;
import java.io.Serializable; 
import java.lang.reflect.Field;

import javax.sql.DataSource;

public class FiltersEmpDAO implements   Serializable {

 Connection conn;
 ResultSet rs;
 ResultSetMetaData rsmd;
 PreparedStatement pstmt = null;
 int result = 0;
 ArrayList<FiltersEmpVO> emps;
 
 DataSource ds;
 
 public FiltersEmpDAO() {
  try {     
    InitialContext ctx = new InitialContext();     
    ds = (DataSource)ctx.lookup("java:comp/env/jdbc/myOracle");  
    conn = ds.getConnection();
    System.out.println("..."+conn);
    emps = this.getEmployees(); 
    System.out.println("&&&"+emps);
  }     
  catch(Exception e) {
   System.out.println(e.getMessage());
  }
 }

 public void closeConn()throws SQLException {
  if(conn != null) {
   conn.close();
  }
 }
 
 public ArrayList<FiltersEmpVO> getEmps() {
     return emps;
 }

 public void setEmps(ArrayList<FiltersEmpVO> emps) {
     this.emps = emps;
 }
 

 public String getDetailsInXML(ArrayList<FiltersEmpVO> list) {
  StringBuffer sb = new StringBuffer(4000);
  try {
     sb.append("<employees>");
    
   for(int i=0;i<list.size();i++) {
    
    FiltersEmpVO emp = list.get(i);
    Field[] fds = emp.getClass().getDeclaredFields(); 
    sb.append("<employee>"); 
     
     for(int j=0;j<fds.length;j++) {
      String col = fds[j].getName();
      fds[j].setAccessible(true); 
      String colValue = fds[j].get(emp).toString();
      sb.append("<" + col + ">" + colValue + "</" + col +">");
     }
     sb.append("</employee>");
    }
   sb.append("</employees>");
  
  }
  catch(Exception sqe) {
      sb.append("<emps>No Information</emps>");  
  }  
  return sb.toString();
 }

 public String getDetailsInHTML(ArrayList<FiltersEmpVO> list) {
     StringBuffer sb = new StringBuffer(4000);
     try {
       
      sb.append("<table cellspacing='5' cellpadding='5' bgcolor='cyan'>");
       
      Class cl = htcfils.FiltersEmpVO.class;
      Field[] fds = cl.getDeclaredFields(); 
      sb.append("<tr>");
      for(int j=0;j<fds.length;j++) {
       String colHead = fds[j].getName();  
       sb.append("<th>" + colHead + "</th>");
      }
      sb.append("</tr>");
      
      for(int i=0;i<list.size();i++) {
       sb.append("<tr>");
       FiltersEmpVO emp = list.get(i);
       for(int j=0;j<fds.length;j++) {
         fds[j].setAccessible(true);  
        String colVal = fds[j].get(emp).toString();  
        sb.append("<td>" + colVal +  "</td>");
       }
       sb.append("</tr>");
      }
      sb.append("</table>"); 
     }
     catch(Exception sqe) {
         sb.append("<h2>No Information</h2>");  
     }  
     return sb.toString();
    }

 
 private ArrayList<FiltersEmpVO> getEmployees()  
  throws SQLException  {
     
  ArrayList<FiltersEmpVO> list = new ArrayList<FiltersEmpVO>();
   
  try {
   
   String sql = "select empno,ename,job,hiredate," +
                "sal,deptno from emp ";
   
   pstmt = conn.prepareStatement(sql);
   rs = pstmt.executeQuery();
   rsmd = rs.getMetaData();
   while(rs.next()) {
    FiltersEmpVO emp = new FiltersEmpVO();
    emp.setEmpId(rs.getInt(1));
    emp.setEmpName(rs.getString(2));
    emp.setJob(rs.getString(3));
    emp.setHiredate(rs.getDate(4));
    emp.setSalary(rs.getDouble(5));
    emp.setDeptId(rs.getInt(6));
    list.add(emp);      
   }   
  }
  catch(Exception sqe) {
   System.out.println("eno not there");    
  }  
  return list;
 }
  
   
}
 