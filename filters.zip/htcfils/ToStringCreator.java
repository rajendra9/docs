package htcfils;

import java.lang.reflect.Field;

public class ToStringCreator {

  public ToStringCreator() { }
  
  public static String toStringForWeb(Object ob) {
   Class cl = ob.getClass();
   Field[] flds = cl.getDeclaredFields();
   StringBuffer sb = new StringBuffer();
   boolean start = true;
   try {
    for(Field f : flds) { 
      f.setAccessible(true);  
     Object val = f.get(ob);  
     if(val!=null) {    
      if(start) {
       sb.append(f.getName()+":"+val.toString()+"<br>");
      }
      else {
       sb.append(" "+f.getName()+":"+val.toString()+"<br>");
      }
     } 
     start = false;
     }
   }
   catch(Exception e) {
       e.printStackTrace();
   }
    return sb.toString();
  } 
  public static String toString(Object ob) {
   Class cl = ob.getClass();
   Field[] flds = cl.getDeclaredFields();
   StringBuffer sb = new StringBuffer();
   try {
    for(Field f : flds) {
     f.setAccessible(true);  
     Object val = f.get(ob);  
     if(val!=null) {    
       sb.append(f.getName()+":"+val.toString()+"\r\n");
     } 
    }
   }
   catch(Exception e) {
       e.printStackTrace();
   }
    return sb.toString();
  }
  public static String toStringInLine(Object ob) {
   Class cl = ob.getClass();
   Field[] flds = cl.getDeclaredFields();
   StringBuffer sb = new StringBuffer();
   boolean start = true;
   try {
    for(Field f : flds) { 
     f.setAccessible(true);  
     Object val = f.get(ob);  
     if(val!=null) {    
      if(start) {
       sb.append(f.getName()+":"+val.toString());
      }
      else {
       sb.append(" "+f.getName()+":"+val.toString());
      }
     } 
     start = false;
     }
   }
   catch(Exception e) {
    e.printStackTrace();
   }
    return sb.toString();
  } 
  
}