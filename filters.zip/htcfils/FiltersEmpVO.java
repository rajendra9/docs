package htcfils;

import java.io.Serializable;
import java.sql.Date;

public class FiltersEmpVO implements Serializable {

   @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + empId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        FiltersEmpVO other = (FiltersEmpVO) obj;
        if (empId != other.empId)
            return false;
        return true;
    }

    private  int      empId;
    private  String   empName;
    private  String   job;
    private  Date     hiredate;
    private  double   salary;
    private  int      deptId;
    
    public FiltersEmpVO(int empId, String empName, String job, int deptId,
            Date hiredate, double salary) {
        super();
        this.empId = empId;
        this.empName = empName;
        this.job = job;
        this.deptId = deptId;
        this.hiredate = hiredate;
        this.salary = salary;
    }

    public FiltersEmpVO() {
    }
    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public Date getHiredate() {
        return hiredate;
    }

    public void setHiredate(Date hiredate) {
        this.hiredate = hiredate;
    }
    
    @Override
    public String toString() {
         return ToStringCreator.toStringForWeb(this);
    }

    public FiltersEmpVO(int empId) {
        super();
        this.empId = empId;
    }


    
}
