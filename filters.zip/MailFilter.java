import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class MailFilter implements Filter
{

    FilterConfig fConfig;

    public MailFilter()
    {
    }

    public void destroy()
    {

    }

    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException
    {
        fConfig.getServletContext().log("before Request");

        MailResponseWrapper mailResponse = new MailResponseWrapper(response);

        chain.doFilter(request, mailResponse);

        PrintWriter writer = mailResponse.getWriter();
        writer.close();

        response.setContentType(mailResponse.getContentType());
        ChangeStream chStream = (ChangeStream) mailResponse.getOutputStream();
        byte[] result = chStream.getResult();
        System.out.println("..." + new String(result));
        response.setContentLength(result.length);
        ServletOutputStream outStream = response.getOutputStream();

        outStream.write(result);
        fConfig.getServletContext().log("before Response");

    }

    public void init(FilterConfig fConfig) throws ServletException
    {
        this.fConfig = fConfig;
    }

}
