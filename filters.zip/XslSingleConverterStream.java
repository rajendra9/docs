import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;

public class XslSingleConverterStream extends ChangeStream
{
    String bookId;

    public XslSingleConverterStream(String id)
    {
        bookId = id;
    }

    public Document getDocument(byte[] content)
    {
        Document doc = null;
        try
        {
            DocumentBuilderFactory dFactory = DocumentBuilderFactory
                    .newInstance();
            dFactory.setNamespaceAware(true);
            DocumentBuilder builder = dFactory.newDocumentBuilder();
            InputStream in = new ByteArrayInputStream(content);
            doc = builder.parse(in);
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        return doc;
    }

    @Override
    public byte[] replaceContent(byte[] content) throws Exception
    {
        System.out.println(new String(content));
        String xslLoc = "C:" + File.separator + "praeelipse" + File.separator
                + "myservlets" + File.separator + "singlebook.xsl";
        Document doc = getDocument(content);
        DOMSource src = new DOMSource(doc);
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer(new StreamSource(
                xslLoc));
        transformer.setParameter("arg1", bookId);
        ByteArrayOutputStream outStream = new ByteArrayOutputStream(2048);
        StreamResult result = new StreamResult(outStream);
        transformer.transform(src, result);
        ByteArrayOutputStream oStream = (ByteArrayOutputStream) result
                .getOutputStream();
        return oStream.toByteArray();
    }
}
