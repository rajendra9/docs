import java.io.IOException;

public class AddMailStream extends ChangeStream
{

    public AddMailStream()
    {
        super();
    }

    @Override
    public byte[] replaceContent(byte[] content) throws IOException
    {
        StringBuffer sb = new StringBuffer(content.length);
        String s = new String(content);
        s = s.toLowerCase();
        int bodyCloseIndex = s.indexOf("</body>");
        if (bodyCloseIndex > -1)
        {
            String previous = s.substring(0, bodyCloseIndex);
            sb.append(previous);
            sb.append("Email is :dtrprasad@gmail.com");
            sb.append(s.substring(bodyCloseIndex));
        } else
        {
            sb.append(s);
        }
        return sb.toString().getBytes();
    }

}
