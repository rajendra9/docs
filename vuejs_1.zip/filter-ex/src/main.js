import Vue from 'vue'
import App from './App.vue'
import VueResource from 'vue-resource';
import { SSL_OP_DONT_INSERT_EMPTY_FRAGMENTS } from 'constants';

Vue.use(VueResource);

//filters
Vue.filter('to-uppercase',function(value){
  return value.toUpperCase();
});
Vue.filter('snippet', function(value){
 return value.slice(0, 100) + '. . . .';
 
  // return value.substring(0,100);
})

new Vue({
  el: '#app',
  render: h => h(App)
})
