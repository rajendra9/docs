drop table if exists booktrans;

create table booktrans (trans_id  serial primary key,username varchar(30),
dot  date,items varchar(100), total_cost float8);
