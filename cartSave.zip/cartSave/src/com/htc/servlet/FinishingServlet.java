package com.htc.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.htc.servlet.utils.BookCart;

@WebServlet("/finish")
public class FinishingServlet extends HttpServlet {
	private static final long serialVersionUID = 1912099L;


	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		
		BookCart bookCart = (BookCart)session.getAttribute("cart");
		String info = bookCart.getDetails();
		session.invalidate();
	    response.setContentType("text/html");
	    PrintWriter out = response.getWriter();
	    out.println(info);
	    out.close();
	
	}

}
