package com.htc.servlet.utils;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.DoubleAdder;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import javax.sql.DataSource;

public class BookCart implements Serializable,HttpSessionBindingListener {
    Map<String,Double> existingBooks;
    DoubleAdder accumalatedCost;
    
    String sqlStr = "insert into bookTrans(username,dot,items,total_cost) values(?,?,?,?)";
    
    @Override
	public void valueBound(HttpSessionBindingEvent event) {
    	System.out.println("Value bound");
    	existingBooks = new LinkedHashMap<>();
	    accumalatedCost = new DoubleAdder();
	    selectedBooks = new ArrayList<>();
	    
	    existingBooks.put("Material Science", 355.5);
	    existingBooks.put("ThermoDynamics", 675.5);
	    existingBooks.put("Advanced Calculus", 432.5);
	    
	    existingBooks.put("Chengez Khan", 543.5);
	    existingBooks.put("American Civil War", 765.5);
	    existingBooks.put("Wuthering Heights", 598.5);
	    
	    existingBooks.put("Practical Cobol", 322.5);
	    existingBooks.put("CICS", 435.5);
	    existingBooks.put("DataScience", 658.5);
	    existingBooks.put("R Programming", 745.5);
    }
	private String convertList(List<String> items) {
		StringBuffer sb = new StringBuffer();
		if(items.size() > 0) {
		   for(String item : items) {	
			sb.append(item);
		    sb.append("|");
		   }
		}
	    String ret = sb.toString();
	    ret = ret.substring(0, ret.length()-1);
	    return ret;
	}
    
    @Override
	public void valueUnbound(HttpSessionBindingEvent event) {
      System.out.println("Value unbound");
      DataSource ds; 
	  String items = this.convertList(this.selectedBooks);
	  System.out.println(items);
	  java.sql.Date dt = java.sql.Date.valueOf(LocalDate.now()); 
	  Connection conn;
	  try {
		 Context ctx = new InitialContext();
		 ds = (DataSource)ctx.lookup("java:comp/env/jdbc/myPostgres");
		 conn = ds.getConnection();
		 PreparedStatement pstmt = conn.prepareStatement(sqlStr);
	     pstmt.setString(1,  this.user);
	     pstmt.setDate(2,  dt);
	     pstmt.setString(3, items);
	     pstmt.setDouble(4, this.accumalatedCost.doubleValue());
	     int rows = pstmt.executeUpdate();
	     System.out.println("data saved " + rows);
	     conn.close();
	     ds = null;
	  }catch(Exception ex) {
		  ex.printStackTrace();
	  }
	}
	List<String>  selectedBooks;
    String user;
	
    public BookCart() {
	       
	}
    private double getCost(String bkName) {
    	if(existingBooks.containsKey(bkName)) {
    		return this.existingBooks.get(bkName);
    	}
    	else {
          throw new RuntimeException("selected book out of stock");		
    	}
    }
    public void addBook(String bookName) {
    	double cost = this.getCost(bookName);
    	selectedBooks.add(bookName);
    	this.accumalatedCost.add(cost);
    	System.out.println(this.selectedBooks);
    }

    public String getDetails() {
    	StringBuffer sb = new StringBuffer("<div align='center' style='margin-top:30px;color:blue;'>Selected Books are <br/>");
    	sb.append("User is: " + user);
    	sb.append("<br/>");
    	for(String book : this.selectedBooks) {
    		sb.append(book);
    		sb.append("<br/>");
    	}
    	sb.append("Total Cost: " + this.accumalatedCost.doubleValue());
    	sb.append("</div>");
    	return sb.toString();
    }
	public DoubleAdder getAccumalatedCost() {
		return accumalatedCost;
	}
	public void setAccumalatedCost(DoubleAdder accumalatedCost) {
		this.accumalatedCost = accumalatedCost;
	}
	public List<String> getSelectedBooks() {
		return selectedBooks;
	}
	public void setSelectedBooks(List<String> selectedBooks) {
		this.selectedBooks = selectedBooks;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
}
