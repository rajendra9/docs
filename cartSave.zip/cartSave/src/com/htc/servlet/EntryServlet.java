package com.htc.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.htc.servlet.utils.BookCart;

@WebServlet("/entry")
public class EntryServlet extends HttpServlet {
	private static final long serialVersionUID = 21912099L;


	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       String authType = request.getAuthType();
	   String username = "";
	   BookCart bookCart = new BookCart();
       System.out.println("**"+authType);
	   if(authType.equals("BASIC")) {
	    java.security.Principal PL = request.getUserPrincipal();
	    username = PL.getName(); 
	    System.out.println("UUUUU" + username);
	    bookCart.setUser(username);
	    HttpSession session = request.getSession(true);
	    session.setMaxInactiveInterval(7200);
	    session.setAttribute("cart", bookCart);
	   }
	   response.sendRedirect("fictionBooks.html");
	}

}
