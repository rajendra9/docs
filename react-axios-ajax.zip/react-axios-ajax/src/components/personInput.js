import React  from 'react';
import axios  from 'axios';

class PersonInput extends React.Component {
   state = {
      
        id: '',
        persName: '',
        dobAsStr: '',
        job: '',
        income: 0
      
  }
handleSubmit = (event) => {
    event.preventDefault();
    let url = "http://localhost:10080/reactRest/rest/react/add";
    const person = {
        adharId: this.state.id,
        pName: this.state.persName,
        dobStr: this.state.dobAsStr,
        job: this.state.job,
        income: this.state.income
    }
    console.log(person);
    axios.post(url,{person}).then(res=>{
        console.log(res);
        console.log(res.data.msg);
    });

}
changeId = (event) => {
    this.setState({id: event.target.value});
}
changeName = (event) => {
    this.setState({persName: event.target.value});
}
changeDob = (event) => {
    this.setState({dobAsStr: event.target.value});
}

changeJob = (event) => {
    this.setState({job: event.target.value});
}

changeIncome = (event) => {
    this.setState({income: event.target.value});
}
  render(){
      return(
        <div align='center'>
         <h1>Input for Person</h1>
         <form onSubmit={this.handleSubmit.bind(this)}>
          <table className="tbl">
           <tbody>   
           <tr>
             <td><label>Enter AdharId:</label></td>
             <td><input type="text" className="txtInput" onChange={this.changeId.bind(this)}/> </td>
            </tr>
            <tr>
             <td><label>Enter Person Name:</label></td>
             <td><input type="text" className="txtInput" onChange={this.changeName.bind(this)}/> </td>
            </tr>
            <tr>
             <td><label>Enter Date-of-Birth:as [yyyy-MM-dd]</label></td>
             <td><input type="text" className="txtInput" onChange={this.changeDob.bind(this)}/> </td>
            </tr>
            <tr> 
             <td><label>Enter Job:</label></td>
             <td><input type="text" className="txtInput" onChange={this.changeJob.bind(this)}/> </td>
            </tr>
            <tr>
             <td><label>Enter Income:</label></td>
             <td><input className="txtInput" type="text" onChange={this.changeIncome.bind(this)}/> </td>
           </tr>
           <tr>
             <td><input className="btn" type="submit" value="Submit Person Data" /></td>
             <td><input className="btn" type="reset" value="Reset Data" /> </td>
           </tr>           
           </tbody>
          </table>
          
           
         </form>  
        </div>
      )
  }

}
export default PersonInput;