import React  from 'react';
import axios  from 'axios';

class PersonList extends React.Component {
   state = {
       persons: []
   }
   componentDidMount(){
    let url = 'http://localhost:10080/anguRest/rest/ang/all';   
    axios.get(url).then(res => {
        console.log(res);
        this.setState({persons: res.data});
    })
   }
   render(){
       return (
           <table><tbody><tr><td>AdharId</td><td>Person Name</td><td>Job</td><td>Date-Of-Birth</td><td>Income</td></tr>
            {
               this.state.persons.map(person => 
                <tr><td>{person.adharId}</td><td>{person.personName}</td><td>{person.job}</td><td>{person.dob}</td><td>{person.income}</td></tr>)
                        
            }           
           </tbody></table>
       );
    }
}


export default PersonList;