<template>
  <div class="home">
     <h1>{{title}}</h1>
  </div>
</template>

<script>


export default {
  components: {
   
  },
  data(){
    return{
      title: 'Welcome to Router Application'
    }
  }
}
</script>
