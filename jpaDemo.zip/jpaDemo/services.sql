drop table if exists services;

create table services(trans_id integer
primary key, 
service_name  varchar(20) not null,pay_date date,
charges float); 

select *  from services;