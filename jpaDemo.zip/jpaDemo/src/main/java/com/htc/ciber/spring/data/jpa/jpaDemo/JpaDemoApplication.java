package com.htc.ciber.spring.data.jpa.jpaDemo;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.htc.ciber.spring.domain.ServiceDto;



@SpringBootApplication
@EntityScan(basePackageClasses=com.htc.ciber.spring.domain.ServiceDto.class)
@EnableJpaRepositories(basePackageClasses=ServicesRepository.class)
public class JpaDemoApplication {
  private static final Logger log = LoggerFactory.getLogger(JpaDemoApplication.class);

  public static void main(String[] args) {
		SpringApplication.run(JpaDemoApplication.class, args);
  }
  
  @Bean  
  public CommandLineRunner doTest(ServicesRepository repo) {
	  return (args) -> {
		  ServiceDto dto = new ServiceDto(100, "aaaa", LocalDate.of(2018, Month.DECEMBER, 20), 850.5);
	  	  repo.save(dto);
	  dto = new ServiceDto(110, "bbbb", LocalDate.of(2018, Month.NOVEMBER, 24), 987.5);
	  repo.save(dto);
	  dto = new ServiceDto(120, "cccc", LocalDate.of(2019, Month.JANUARY, 12), 1080.5);
	  repo.save(dto);
	  dto = new ServiceDto(130, "dddd", LocalDate.of(2019, Month.JANUARY, 12), 1080.5);
	  repo.save(dto);
	  dto = new ServiceDto(140, "eeeee", LocalDate.of(2019, Month.JANUARY, 12), 1080.5);
	  repo.save(dto);
	  dto = new ServiceDto(150, "ffff", LocalDate.of(2019, Month.JANUARY, 14), 1250.5);
	  repo.save(dto);
	  log.info("Services Created");
	  log.info("-------------------------");
	  log.info("finding all");
	  Iterable<ServiceDto> services = repo.findAll();
	  services.forEach(System.out::println);
	  List<ServiceDto> list = repo.findByPayDate(LocalDate.of(2019, Month.JANUARY, 12));
	  log.info("-------------------------");
	  log.info("finding by date");
	  list.forEach(System.out::println);
	 };
  }

}

