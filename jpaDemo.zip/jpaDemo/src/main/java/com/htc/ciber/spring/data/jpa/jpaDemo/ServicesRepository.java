package com.htc.ciber.spring.data.jpa.jpaDemo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.htc.ciber.spring.domain.ServiceDto;

@Repository
public interface ServicesRepository extends CrudRepository<ServiceDto, Integer> {
     public List<ServiceDto>  findByPayDate(LocalDate dt);
}
