package com.htc.ciber.data.jpa.jpaDemo;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.htc.ciber.spring.domain.ServiceDto;
import com.htc.ciber.spring.utils.ServicesRepository;

@SpringBootApplication
@EnableJpaRepositories(basePackageClasses=ServiceDto.class)
@ComponentScan({"com.htc.ciber.data.jpa.jpaDemo", "com.htc.ciber.spring.utils"})
public class JpaDemoApplication {
  private static final Logger log = LoggerFactory.getLogger(JpaDemoApplication.class);

  public static void main(String[] args) {
		SpringApplication.run(JpaDemoApplication.class, args);
  }
  
  @Bean  
  public CommandLineRunner doTest(ServicesRepository repo) {
	  return (args) -> {
		  ServiceDto dto = new ServiceDto("aaaa", LocalDate.of(2018, Month.DECEMBER, 20), 850.5);
	  	  repo.save(dto);
	  dto = new ServiceDto("bbbb", LocalDate.of(2018, Month.NOVEMBER, 24), 987.5);
	  repo.save(dto);
	  dto = new ServiceDto("cccc", LocalDate.of(2019, Month.JANUARY, 12), 1080.5);
	  repo.save(dto);
	  dto = new ServiceDto("dddd", LocalDate.of(2019, Month.JANUARY, 12), 1080.5);
	  repo.save(dto);
	  dto = new ServiceDto("eeeee", LocalDate.of(2019, Month.JANUARY, 12), 1080.5);
	  repo.save(dto);
	  dto = new ServiceDto("ffff", LocalDate.of(2019, Month.JANUARY, 14), 1250.5);
	  repo.save(dto);
	  log.info("Services Crerated");
	  log.info("-------------------------");
	  log.info("finding all");
	  Iterable<ServiceDto> services = repo.findAll();
	  services.forEach(System.out::println);
	  List<ServiceDto> list = repo.findByDate(LocalDate.of(2019, Month.JANUARY, 12));
	  log.info("-------------------------");
	  log.info("finding by date");
	  list.forEach(System.out::println);
	 };
  }

}

