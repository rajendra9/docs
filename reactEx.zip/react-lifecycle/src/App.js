import React, { Component } from 'react';
import Child  from './components/child';
import './App.css';

class App extends Component {
    state = {
      name : 'SRM',
      
    }

   constructor(){
     super();
     this.state={
       name: 'Panimalar'
     }
     console.log('Constructor fired ' + this.state.name);
   }
   componentWillMount(){
    console.log('you can change state based on props');
  
    if(window.innerWidth<700){
      this.setState({innerWidth: window.innerWidth});
      
    }
    console.log('Component gets ready to mount')
   }
   componentDidMount(){
    console.log('Component gets mounted')
   }
   componentWillReceiveProps(){
    console.log('Component receives props')
   }
   shouldComponentUpdate(nextProps, nextState){
    console.log('decides whether you want to go for rerendering or not')
    return true;
   }
   componentWillUpdate(){
    console.log('will update and not change state here')    
   }

   componentDidUpdate(previosProps,previousState){
    console.log('Rerendering occured ')    
   }

   componentWillUnmount(){
    console.log('Component is unmounting')
   }
   makeChange(){
     this.setState({name: 'John Miller'});  
   }

  unmountChild(){
    this.setState({name: 'packup'});
  }
  render() {
    console.log('Rendering,avoid calling setState here');
    if(this.state.name === 'packup'){
      return (<div/>)
    }
    return (    
      <div className="App">
       <h4>{this.state.name}&nbsp;&nbsp;&nbsp;{this.state.innerWidth}</h4>
       <button onClick={this.makeChange.bind(this)}>Make some change</button><br/>
       <button onClick={this.unmountChild.bind(this)}>unmount the child</button>
      <hr/>
      <Child/>
      </div>
    );
  }
}

export default App;
