import React, { Component } from 'react';



class Child extends Component {
    
    constructor(){
     super();
     this.state={
       childName: 'SRM'
     }
     console.log('Child Constructor fired ' + this.state.childName);
   }
   componentWillMount(){
    console.log('child component ready to mount');
   }
   componentDidMount(){
    console.log('Child Component gets mounted')
   }
   componentWillReceiveProps(){
    //do not use it to change props   
    console.log('child Component receives props')
   }
   shouldComponentUpdate(nextProps, nextState){
    console.log('child decides whether you want to go for rerendering or not')
    return true;
   }

   componentWillUnmount(){
    console.log('child Component is unmounting')
   }
  render() {
    console.log('Child will update,avoid calling setState here');
    return (
      <div>
       <h4>{this.state.childName}</h4>
      </div>
    );
  }
}

export default Child;
