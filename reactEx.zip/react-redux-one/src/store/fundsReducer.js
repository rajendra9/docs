

const initialState ={
   funds: 5000.0
}
const fundsReducer = (state = initialState, action) =>{
   const newState = {...state};
   if(action.type === 'Funds_Up'){
     newState.funds += 1000.0;
   }
   else if(action.type === 'Funds_Down'){
      newState.funds -= 800.0;
   }
   return newState;
}

export default fundsReducer;