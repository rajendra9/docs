

import btnStyles from './../styles/btnStyles';

const translateProps = (props)=>{
    let _styles = {...btnStyles.default}
    if(props.disable){
        _styles = {...btnStyles, ...btnStyles.disable}
    }
   const newProps = {...props,styles:_styles}
   return newProps;
}

export default (WrapperComponent) => {
   return  function wrappedRender(args){
       return WrapperComponent(translateProps(args));
   } 
}