package testing;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import myWebRest.utils.OrderVO;


public class OrderServiceClient {

    public static void main(String[] args) {
      String endpointUrl = "http://localhost:10080/webRest/rest/order";
      Client client = ClientBuilder.newClient();
      WebTarget target = client.target(endpointUrl);
      target = target.queryParam("ordId", new Integer(1000));
      Invocation.Builder invocationBuilder = 
    		  target.request(MediaType.APPLICATION_XML_TYPE);
      invocationBuilder.header("Content-Type", "application/xml");
      Response response = invocationBuilder.get();
      System.out.println(response.getStatus());
      System.out.println(response.readEntity(OrderVO.class));
	}

}
