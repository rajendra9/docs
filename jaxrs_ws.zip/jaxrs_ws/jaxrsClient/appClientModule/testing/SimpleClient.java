package testing;

import java.util.concurrent.Future;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;


public class SimpleClient {

    public static void main(String[] args) throws Exception{
      Client client = ClientBuilder.newClient();  
      String url = "http://localhost:10080/webRest/rest/students";
      Invocation invocation = client.target(url).request("text/plain").buildGet();
      Class<?> cl = "hh".getClass();
              
      Future<?> future = invocation.submit(cl);
      System.out.println(future.get());
    }

}
