package testing;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

public class TestEnvironService {
   WebTarget target;
    
   {
       Client client = ClientBuilder.newClient();
       this.target = client.target("http://localhost:10080/webRest/rest/environ");
   }
   public static void main(String[] args) {
       TestEnvironService environService = new TestEnvironService();
       Invocation invocation = 
    		   environService.target.request().accept("text/plain").build("GET");
       Response response = invocation.invoke();
       System.out.println(response.readEntity(java.lang.String.class));
   }

}
