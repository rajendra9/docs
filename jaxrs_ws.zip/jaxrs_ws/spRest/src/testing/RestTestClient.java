package testing;
 
import java.net.URI;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;
import java.util.List;
 
import org.springframework.web.client.RestTemplate;
 
import mywebrest.utils.OrderTO;
 
public class RestTestClient {
 
 public static final String REST_SERVICE_URI = 
		                       "http://localhost:10080/spRest";
     
    /* GET */
    @SuppressWarnings("unchecked")
    private static void listAllOrders(){
        System.out.println("Testing listAllOrders API-----------");
         
        RestTemplate restTemplate = new RestTemplate();
        List<LinkedHashMap<String, Object>> ordersLinkMap = 
restTemplate.getForObject(REST_SERVICE_URI+"/showAll/", List.class);
         
   if(ordersLinkMap!=null){
     for(LinkedHashMap<String, Object> map : ordersLinkMap){
         System.out.println("Order : id="+map.get("orderId")+", OrderDate="+map.get("orderDate")+", Customer="+map.get("customer")+", Cost="+map.get("cost"));;
     }
    } else {
       System.out.println("No Order exist----------");
    }
   }
     
    /* GET */
    private static void getOrder(){
        System.out.println("Testing getOrder API----------");
        RestTemplate restTemplate = new RestTemplate();
        OrderTO order = 
        	restTemplate.getForObject(REST_SERVICE_URI+"/getOrder/1000", OrderTO.class);
        System.out.println(order);
    }
     
    /* POST */
    private static void createOrder() {
        System.out.println("Testing create OrderTO API----------");
        RestTemplate restTemplate = new RestTemplate();
 GregorianCalendar gc = 
          new  GregorianCalendar(2016, Calendar.FEBRUARY, 22);
        Date dt = gc.getTime();
 OrderTO newOrder = new OrderTO(6000,dt,"M/s Kumkum & Bros",2354.7);
URI uri = 
restTemplate.postForLocation(REST_SERVICE_URI+"/addOrder/", newOrder, OrderTO.class);
        System.out.println("Location : "+uri.toASCIIString());
    }
 
    /* PUT */
    private static void updateOrder() {
        System.out.println("Testing update Order API----------");
        RestTemplate restTemplate = new RestTemplate();
        GregorianCalendar gc = 
                new  GregorianCalendar(2016, Calendar.MARCH, 24);
        Date dt = gc.getTime();
        OrderTO changed = new OrderTO(3000,dt,"M/s ChennaiKutty & Bros",1854.7);
        restTemplate.put(REST_SERVICE_URI+"/changeOrder/3000", changed);
        System.out.println(changed);
    }
 
    /* DELETE */
    private static void deleteOrder() {
        System.out.println("Testing delete Order API----------");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(REST_SERVICE_URI+"/delete/2000");
    }
 
 
    
 
    public static void main(String args[]){
        listAllOrders();
        getOrder();
        createOrder();
        listAllOrders();
        updateOrder();
        listAllOrders();
        deleteOrder();
        listAllOrders();
    }
}
