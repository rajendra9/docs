package mywebrest.config;


import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration.Dynamic;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

public class SprWebStarter implements WebApplicationInitializer {

    @Override
    public void onStartup(ServletContext ctx) throws ServletException {
       AnnotationConfigWebApplicationContext webCtx =
               new AnnotationConfigWebApplicationContext();
        webCtx.register(SpringWebConfiguration.class);
        webCtx.setServletContext(ctx);
        
        Dynamic servlet = ctx.addServlet("dispatcher",new DispatcherServlet(webCtx));
        servlet.addMapping("/");
        servlet.setLoadOnStartup(1);
    }

}
