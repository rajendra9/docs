package mywebrest.utils;

import java.io.Serializable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;

@Component
public class OrdersMap implements Serializable {
  
  ConcurrentMap<Integer,OrderTO> orders = new ConcurrentHashMap<>();   
  public OrdersMap() {
   this.populate();
  }

  
  private void populate() {
   GregorianCalendar gc = 
      new  GregorianCalendar(2008, Calendar.FEBRUARY, 12);
   Date dt = gc.getTime();
   OrderTO order = new OrderTO(1000, dt, "M/s Cheran Co", 3245.80);
   orders.put(new Integer(order.getOrderId()), order);
     
   gc = new  GregorianCalendar(2008, Calendar.MARCH, 18);
   dt = gc.getTime();
   order = new OrderTO(2000, dt, "M/s Rally Co", 4345.80);
   orders.put(new Integer(order.getOrderId()),order);
     
   gc = new  GregorianCalendar(2008, Calendar.MARCH, 28);
   dt = gc.getTime();
   order = new OrderTO(3000, dt, "M/s Vali Co", 3845.80);
   orders.put(new Integer(order.getOrderId()), order);
     
   gc = new GregorianCalendar(2006, Calendar.APRIL, 12);
   dt = gc.getTime();
   order = new OrderTO(4000, dt, "M/s Velan Co", 3812.80);
   orders.put(new Integer(order.getOrderId()), order);
     
   gc = new  GregorianCalendar(2006, Calendar.MAY, 13);
   dt = gc.getTime();
   order = new OrderTO(5000, dt, "M/s Alazhan Co", 3245.80);
   orders.put(new Integer(order.getOrderId()), order);
     
  }

  public OrderTO getOrder(int  id) {
   if(orders.containsKey(id)){   
     return orders.get(new Integer(id));
   }
   return new OrderTO();
  }
  
  public boolean addOrder(OrderTO order) {
    int id = order.getOrderId();  
    if(!orders.containsKey(id)){  
        orders.put(id, order);
        return true;
    }
    return false;
  }
 
  public boolean updateOrder(int ordId, OrderTO changed) {
    if(orders.containsKey(ordId)){  
      orders.put(ordId,changed);
        return true;
    }
    return false;
  }
  
  public boolean removeOrder(int ordId) {
      if(orders.containsKey(ordId)){  
        orders.remove(ordId);
        return true;
      }
      return false;
    }
  
  public List<OrderTO> getOrders() {
    List<OrderTO> ret = new ArrayList<>();
    ret.addAll(orders.values());
    return ret;
  }
  
  public boolean isOrderExists(OrderTO order){
    Collection<OrderTO> cols = orders.values();
    return cols.contains(order);
  }
  
}