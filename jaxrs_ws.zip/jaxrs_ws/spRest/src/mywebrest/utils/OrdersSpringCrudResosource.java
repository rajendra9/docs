package mywebrest.utils;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

@RestController
public class OrdersSpringCrudResosource {

   @Autowired
   OrdersMap ordersMap;
    
   @RequestMapping(value="/showAll",method=RequestMethod.GET)
   public ResponseEntity<List<OrderTO>> getAllOrders(){
     List<OrderTO>  orders = ordersMap.getOrders();
     if(orders.size()==0){
         return new ResponseEntity<List<OrderTO>>(HttpStatus.NO_CONTENT);
     }
     else{
        return new ResponseEntity<List<OrderTO>>(orders,HttpStatus.OK);  
     }
   }
   
   @RequestMapping(value="/getOrder/{id}",method=RequestMethod.GET)
   public ResponseEntity<OrderTO> getOrder(@PathVariable("id")int ordId){
     OrderTO  order = ordersMap.getOrder(ordId);
     if(order.getOrderDate()==null){
         return new ResponseEntity<OrderTO>(HttpStatus.NO_CONTENT);
     }
     else{
        return new ResponseEntity<OrderTO>(order,HttpStatus.OK);  
     }
   }
 
   @RequestMapping(value="/addOrder",method=RequestMethod.POST)
   public ResponseEntity<Void> addOrder(@RequestBody OrderTO order,
           UriComponentsBuilder ucBuilder) {
      System.out.println("adding a Order");
      if(ordersMap.isOrderExists(order)){
        System.out.println("order already exists");
        return new ResponseEntity<Void>(HttpStatus.CONFLICT);  
      }
      else {
        ordersMap.addOrder(order);
        HttpHeaders headers = new HttpHeaders();
headers.setLocation(
ucBuilder.path("/getOrder/{id}").buildAndExpand(order.getOrderId()).toUri());
      return new ResponseEntity<Void>(headers,HttpStatus.CREATED);
      }
    }
   
   @RequestMapping(value="/changeOrder/{id}",method=RequestMethod.PUT)
   public ResponseEntity<OrderTO> updateOrder(@PathVariable("id") int ordId,
		   @RequestBody OrderTO changed) {
      System.out.println("changing an order");
      OrderTO current = ordersMap.getOrder(ordId);
      if(current.getOrderDate()==null){
        return new ResponseEntity<OrderTO>(HttpStatus.NOT_FOUND);   
      }
      else {
        ordersMap.updateOrder(ordId, changed);
        return new ResponseEntity<OrderTO>(changed,HttpStatus.OK);
      }
    }
   
   @RequestMapping(value="/delete/{id}",method=RequestMethod.DELETE)
   public ResponseEntity<OrderTO> removeOrder(@PathVariable("id")int ordId){
     boolean boo = ordersMap.removeOrder(ordId);
     if(!boo){
         return new ResponseEntity<OrderTO>(HttpStatus.NOT_FOUND);
     }
     else{
        return new ResponseEntity<OrderTO>(HttpStatus.NO_CONTENT);  
     }
   }
   
   
}
