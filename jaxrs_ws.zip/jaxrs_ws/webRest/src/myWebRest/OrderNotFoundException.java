package myWebRest;

public class OrderNotFoundException extends RuntimeException {
   String  cause;
   
   public OrderNotFoundException(String cause) {
	   this.cause = cause;
   }
   
   public String  getMessage() {
	   return "OrderNotFoundException occured because of " + cause;
   }
}
