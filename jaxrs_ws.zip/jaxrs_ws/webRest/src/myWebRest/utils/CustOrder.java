package myWebRest.utils;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;


public class CustOrder implements Serializable {
 private  int       orderId;
 private  Date      orderDate;
 private  double    cost;
 private  String    customer;

 public CustOrder(int orderId, Date orderDate,
         String customer, double cost) {
  super();
  this.orderId = orderId;
  this.orderDate = orderDate;
  this.customer = customer;
  this.cost = cost;
 }

 public CustOrder(){}

 public double getCost() {
  return cost;
 }

 public void setCost(double cost) {
  this.cost = cost;
 }

 public String getCustomer() {
  return customer;
 }

 public void setCustomer(String customer) {
  this.customer = customer;
 }

 public Date getOrderDate(){
  return orderDate;
 }

 public void setOrderDate(Date orderDate) {
  this.orderDate = orderDate;
 }

 public int getOrderId() {
  return orderId;
 }

 public void setOrderId(int orderId) {
  this.orderId = orderId;
 }

 @Override
 public String toString(){        
  String ret = "\r\n Order-Id:"+this.orderId+
               "\r\n Ordered-Date:"+this.orderDate;
  ret = ret+"\r\n Cost:"+this.cost+
       "\r\n Customer:"+this.customer;        
  return ret;
 }

 @Override
 public int hashCode() {
  final int PRIME = 31;
  int result = 1;
  result = PRIME * result + orderId;
  return result;
 }

 @Override
 public boolean equals(Object obj) {
  if (this == obj)
   return true;
  if (obj == null)
   return false;
  if (getClass() != obj.getClass())
   return false;
   final CustOrder other = (CustOrder) obj;
   if (orderId != other.orderId)
    return false;
  return true;
 }

}