package myWebRest;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ErrorShowEntity implements Serializable {

	private String statusCode;
	private String errMessage;
	
	public ErrorShowEntity() {
		super();	
	}

	public ErrorShowEntity(String statusCode, String errMessage) {
		super();
		this.statusCode = statusCode;
		this.errMessage = errMessage;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getErrMessage() {
		return errMessage;
	}

	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}
	
	
	
}
