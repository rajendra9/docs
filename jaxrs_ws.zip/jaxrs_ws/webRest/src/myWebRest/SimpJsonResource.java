package myWebRest;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import myWebRest.utils.StudentDelegate;
import myWebRest.utils.StudentTO;

import java.io.InputStream;

import javax.json.JsonObject;
import javax.json.Json;
import javax.json.JsonReader;
import javax.json.JsonObjectBuilder;


@Path("/sJson")
public class SimpJsonResource {

  private JsonObject getJsonStudent(StudentTO student){
    JsonObjectBuilder objBuilder =
             Json.createObjectBuilder();
    objBuilder.add("stuId",student.getStuId());
    objBuilder.add("stuName",student.getStuName());
    objBuilder.add("course",student.getCourse());
    objBuilder.add("address",student.getAddress());
    return objBuilder.build();
  }
    
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public String receiveJson(InputStream in){
    String ret = "";
    String stId = "";
    try{
      JsonReader reader = Json.createReader(in);
      JsonObject jsonObject = reader.readObject();
      stId = jsonObject.getString("stuId");
    }catch(Exception ex){
        throw new RuntimeException(ex.getMessage());
    }
    System.out.println(">>>>"+stId);
    StudentDelegate delegate = new StudentDelegate();
    StudentTO searched = delegate.searchStudent(stId);
    JsonObject retObj = this.getJsonStudent(searched);
    return retObj.toString();
  }
  
}
