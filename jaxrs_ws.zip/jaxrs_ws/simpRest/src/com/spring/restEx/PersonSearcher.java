package com.spring.restEx;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

@Component
public class PersonSearcher implements Serializable {
   
   Set<Person> persons = new HashSet<>();
   
   {
       Person person = new Person("ch2134TN","Sangeeta","Guindy",350000.5);
       persons.add(person);
       person = new Person("ma2344TN","Dhruvan","kalasupatti",430000.5);
       persons.add(person);
       person = new Person("tr4334TN","Vasanthan","BhelTownship",750000.5);
       persons.add(person);
       person = new Person("ch2156TN","Maruthi","Tambaram",530000.5);
       persons.add(person);
       person = new Person("ch2378TN","Madhavan","ChromePet",456000.5);
       persons.add(person);
   }
   
    public Person searchPerson(String adharId){
       Person ret = new Person();
       for(Person pers : persons){
         if(pers.getAdharId().equalsIgnoreCase(adharId)){
             ret = pers;
             break;
         }
       }
      return ret; 
    }
    
    public Set<String> getAdharIds(){
      return persons.stream().map(p->p.getAdharId()).collect(Collectors.toSet());          
    }
}
