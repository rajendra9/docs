package com.spring.restEx;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Person implements Serializable {
    private  String  adharId;
    private  String  name;
    private  String  address;
    private  double  income;
    
    public Person() {
        super();        
    }

    public Person(String adharId, 
                  String name, 
                  String address, 
                  double income) {
        super();
        this.adharId = adharId;
        this.name = name;
        this.address = address;
        this.income = income;
    }

    public String getAdharId() {
        return adharId;
    }
   
    @XmlAttribute
    public void setAdharId(String adharId) {
        this.adharId = adharId;
    }

    public String getName() {
        return name;
    }
    @XmlAttribute
    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }
    @XmlAttribute
    public void setAddress(String address) {
        this.address = address;
    }

    public double getIncome() {
        return income;
    }
    @XmlAttribute
    public void setIncome(double income) {
        this.income = income;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((adharId == null) ? 0 : adharId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Person other = (Person) obj;
        if (adharId == null) {
            if (other.adharId != null)
                return false;
        } else if (!adharId.equals(other.adharId))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "Person [adharId=" + adharId + ", name=" + name + ", address="
                + address + ", income=" + income + "]";
    } 
    
    
}
