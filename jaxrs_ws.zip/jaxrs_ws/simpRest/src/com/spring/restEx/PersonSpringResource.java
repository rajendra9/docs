package com.spring.restEx;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.http.HttpStatus;

@RestController
public class PersonSpringResource {

    @Autowired
    PersonSearcher searcher;
    
    public PersonSpringResource(){
        System.out.println("KKKK");
    }
    @RequestMapping(value="/search",method=RequestMethod.GET,produces={"application/xml","application/json"})
    @ResponseStatus(HttpStatus.OK)
    public Person getPerson(@RequestParam(value="adhar",required=false,defaultValue="ch2378TN")String adharId){
        System.out.println("HHHHHH");
        return searcher.searchPerson(adharId); 
    }
    
    public String input(){
        Set<String> adharIds = searcher.getAdharIds();
        StringBuffer sb = new StringBuffer();
        sb.append("<html><body><div align='center'>");
        for(String id : adharIds){
         sb.append("<br/><a href='search.json?adhar="+id+"'>Search "+id+" [Json]</a>");
         sb.append("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
         sb.append("<a href='search.xml?adhar="+id+"'>Search "+id+" [xml]</a><br/>");
        }
        sb.append("</div></body></html>");
        return sb.toString();
    }
    
    @RequestMapping(value="/",method=RequestMethod.GET,produces="text/html")
    @ResponseStatus(HttpStatus.OK)
    public String getPersonHtml(@RequestParam(value="adhar",required=false,defaultValue="ch2378TN")String adharId){
       return this.input(); 
    }
}
