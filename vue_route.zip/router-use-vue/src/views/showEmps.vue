<template>
  <div id="vue-emps">
   <table>
   <tbody>
     <tr v-for="(emp,index) in employees" v-bind:key="index">  
       <td>{{emp.emp_id}}</td>
       <td>{{emp.emp_name}}</td>
       <td>{{emp.job}}</td>
       <td>{{emp.hire_date}}</td>
       <td>{{emp.salary}}</td>
       <td>{{emp.dept_name}}</td>
       <td>{{emp.city}}</td>
     </tr>
   </tbody>
   </table>
  </div>
</template>

<script>

export default{
data(){
    return {
      employees:[]  
    }
 },
 created(){
     this.$http.get('http://localhost:9090/vuerest/rest/vuemps/allEmps')
               .then(function(data){
                   console.log(data.body);
                   this.employees = data.body;
               });
 }
}
</script>

<style scoped>

</style>