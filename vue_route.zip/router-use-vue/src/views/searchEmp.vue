<template>
 <div class="searching">
    <h3>Welcome to Router Application<br/>
       Search An Employee</h3>
  <div id="search-emp">
  <form >
   <table>
    <tbody>
     <tr>
       <td><label>Enter Emp Id for Search:</label></td>
       <td><input type="text" v-model.lazy="emp_id" /></td>
     </tr>  
      
    </tbody>
    </table>
    <br/>
    <hr/>
    <div class="buttons">
      <button v-on:click.prevent="searchEmp">Search Emp</button>
    </div>
    </form> 
    <div v-if="isSearched" class="searched">
        {{searchResult}}
    </div>    
 </div>
</div>
</template>

<script>


export default {
  components: {
   
  },
  data(){
    return{
         emp_id: 0,
         isSearched: false,
         searchResult: ''     
    }
  },
  methods:{
      searchEmp: function(){
          this.$http.get('http://localhost:9090/vuerest/rest/vuemps/'+this.emp_id)
                    .then(function(data){
                        this.isSearched = true;
                        this.searchResult=data.body;
                    });
      }
   }
}
</script>
<style scoped>
.searching *{
    box-sizing: border-box;
}
#search-emp{
    margin: 30px auto;
    max-width: 450px;
}
label{
    display: block;
    margin: 20px 0 10px;
}
input[type="text"] {
    display: block;
    width: 100%;
    padding: 8px;
}
h3{
    text-decoration:underline;    
}
.searched{
  margin-top: 3px;
  border: 2px dashed green;
}
button{
    margin-top: 2px;
    width: 110px;
    height: 40px;
    border: 2px solid;
    text-align: center;
}
.buttons{
    margin-left: 100px;
    margin-top: 5px;
}
</style>
