package com.htc.rest.utils;


import java.io.Serializable;
import java.time.LocalDate;

import javax.json.bind.annotation.JsonbProperty;
import javax.json.bind.annotation.JsonbPropertyOrder;
import javax.json.bind.config.PropertyOrderStrategy;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@JsonbPropertyOrder(PropertyOrderStrategy.LEXICOGRAPHICAL)
@SuppressWarnings("serial")
public class VueEmpJson implements Serializable {
	  
	  @JsonbProperty("emp_id")
      private int empId;
    
	  @JsonbProperty("emp_name")
	  private String empName;
	  
	  @JsonbProperty("job")
	  private String job;
	  
	  @JsonbProperty("salary")
      private double salary;
	  
	  @JsonbProperty("dept_name")
      private String deptName;
	  
	  @JsonbProperty("hire_date")
	  private LocalDate hiredate;
	  
	  @JsonbProperty("city")
      private String city;      
      
      public VueEmpJson() {
		super();
	  }

	  
      public LocalDate getHiredate() {
		  return hiredate;
	  }

	  public void setHiredate(LocalDate hiredate) {
		   this.hiredate = hiredate;
	  }

      public VueEmpJson(int empId, String empName, String job, LocalDate hiredate, double salary, String deptName,
		         String city) {
		this.empId = empId;
		this.empName = empName;
		this.job = job;
		this.hiredate = hiredate;
		this.salary = salary;
		this.deptName = deptName;
		this.city = city;
      }


	  public int getEmpId() {
	      return empId;
      }

	  public void setEmpId(int empId) {
		  this.empId = empId;
	  }
    
	  public String getEmpName() {
	      return empName;
	  }

	  public void setEmpName(String empName) {
		  this.empName = empName;
	  }

	  
	  public String getJob() {
		  return job;
	  }

	  public void setJob(String job) {
		  this.job = job;
	  }
	 	
	  
	  public double getSalary() {
		  return salary;
	  }

	  public void setSalary(double salary) {
		   this.salary = salary;
	  }

	  
	  public String getDeptName() {
		  return deptName;
	  }

	  public void setDeptName(String deptName) {
		   this.deptName = deptName;
	  }
	  
	  public String getCity() {
		   return city;
	  }
      
	  
	  public void setCity(String city) {
		  this.city = city;
	  }
	
	  @Override
	  public int hashCode() {
		  final int prime = 31;
		  int result = 1;
		  result = prime * result + empId;
		  return result;
	  }

	  @Override
	  public boolean equals(Object obj) {
		 if (this == obj)
	 		return true;
	     if (obj == null)
	        return false;
		 if (getClass() != obj.getClass())
		   	return false;
		 VueEmpJson other = (VueEmpJson) obj;
		 if (empId != other.empId)
			return false;
		  return true;
	  }

	@Override
	public String toString() {
		return "VueEmpForJson [empId=" + empId + ", empName=" + empName + ", job=" + job + ", salary=" + salary + ", deptName="
				+ deptName + ", hiredate=" + hiredate + ", city=" + city + "]";
	}

	
	public String toShortString() {
		return "VueEmpForJson [empId=" + empId + ", empName=" + empName + ", salary=" + salary + ", deptName="
				+ deptName + " , city=" + city + "]";
	}    
}
