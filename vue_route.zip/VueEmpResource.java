package com.htc.rest;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.json.bind.JsonbBuilder;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import com.htc.rest.utils.VueEmpJson;
import com.htc.rest.utils.VueEmpsManager;

@Path("/vuemps")
public class VueEmpResource {
    
	VueEmpsManager empsMgr = new VueEmpsManager();
    
	@GET
	public String contact() {
		return "<h2 align='center'>Welcome to JaxRs-2.1 Vue Emp Resource</h2"; 
	}
	
	@GET
	@Path("/{empId}")
	public VueEmpJson  searchVueEmp(@PathParam("empId") int empId) {
	     return empsMgr.searchEmp(empId);	
	}
	
	@GET
	@Path("/allEmps")
	public VueEmpJson[]  searchforAll() {
	     return empsMgr.retrieveAll();	
	}
	
	@POST
	@Path("/saveEmp")
	public String  saveEmp(InputStream inStream) {
		System.out.println("Contacted");
		VueEmpJson empJson = new VueEmpJson();
      try { 
		BufferedReader in = 
	    		new BufferedReader(new InputStreamReader(inStream));
	    String jsonStr = in.readLine();
	    empJson = JsonbBuilder.create().fromJson(jsonStr, VueEmpJson.class);;
	    System.out.println(empJson); 
	  }catch(Exception ex) {
		   ex.printStackTrace();
	  }
	  return this.empsMgr.saveEmp(empJson);	
	}
	
	@PUT
	@Path("/updateEmp")
	public String updateEmp(InputStream inStream) {
		System.out.println("Contacted");
		VueEmpJson empJson = new VueEmpJson();
      try { 
		BufferedReader in = 
	    		new BufferedReader(new InputStreamReader(inStream));
	    String jsonStr = in.readLine();
	    empJson = JsonbBuilder.create().fromJson(jsonStr, VueEmpJson.class);;
	    System.out.println(empJson); 
	  }catch(Exception ex) {
		   ex.printStackTrace();
	  }
	  return this.empsMgr.updateEmp(empJson);	
	}
	
}
