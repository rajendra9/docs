package com.htc.rest.utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;


public class VueEmpsManager implements Serializable {
  
	EntityTransaction trans;
    EntityManagerFactory factory;
    EntityManager em;
    
    {
    	factory = Persistence.createEntityManagerFactory("myDb");
        em = factory.createEntityManager();	
    }
    
    public VueEmpJson toEmpJson(VueEmp emp) {
    	return new VueEmpJson(emp.getEmpId(),
    			              emp.getEmpName(),
    			              emp.getJob(),
    			              emp.getHiredate(),
    			              emp.getSalary(),
    			              emp.getDeptName(),
    			              emp.getCity());    			
    }
    
    public VueEmp fromVueEmpJson(VueEmpJson emp) {
    	return new VueEmp(emp.getEmpId(),
	              emp.getEmpName(),
	              emp.getJob(),
	              emp.getHiredate(),
	              emp.getSalary(),
	              emp.getDeptName(),
	              emp.getCity());    			
    }
    public VueEmp readPartialJson(VueEmpJson emp) {
    	return new VueEmp(emp.getEmpId(),
	                     emp.getJob(),
	                     emp.getSalary(),
	                     emp.getDeptName());    			
    }
    
    public VueEmpJson searchEmp(int id) {
	  trans = em.getTransaction();
	  trans.begin();
	  VueEmp vueEmp = new VueEmp();
	  try {
		vueEmp = em.getReference(VueEmp.class, new Integer(id));
		trans.commit();
	  }catch(Exception ex) {
		 ex.printStackTrace();
		 trans.rollback();
	  }	 
	  VueEmpJson empJson = this.toEmpJson(vueEmp);
	  return empJson;
    }
    
   public VueEmpJson[] retrieveAll() {
  	  trans = em.getTransaction();
  	  trans.begin();
  	  List<VueEmpJson> list = new ArrayList<>();
  	  try {
  		TypedQuery<VueEmp> qry = em.createNamedQuery("all.emps", VueEmp.class);  
  		List<VueEmp>  empList = qry.getResultList();
  		for(VueEmp emp : empList) {
  			list.add(this.toEmpJson(emp));
  		}
  		
  		trans.commit();
  	  }catch(Exception ex) {
  		 ex.printStackTrace();
  		 trans.rollback();
  	  }	   	  
  	  return list.toArray(new VueEmpJson[] { new VueEmpJson()});
      }
    
    public String saveEmp(VueEmpJson empJson) {
	   String ret = "Problems in saving";
	   trans = em.getTransaction();
	   trans.begin();
	   try {
		 VueEmp emp = this.fromVueEmpJson(empJson); 
		 em.persist(emp);
		 trans.commit();
		 ret = empJson.toString() + " is saved.";
	   }catch(Exception ex) {
		  ex.printStackTrace();
		  trans.rollback();
	   }	  
	   return ret;
     }
 
    public String updateEmp(VueEmpJson empJson) {
 	   String ret = "Problems in updating";
 	   trans = em.getTransaction();
 	   trans.begin();
 	   try {
 		 VueEmp emp = this.readPartialJson(empJson); 
 		 int id = emp.getEmpId();
 		 VueEmp forUpdate = em.getReference(com.htc.rest.utils.VueEmp.class, new Integer(id));
 		 forUpdate.setJob(emp.getJob());
 		 forUpdate.setSalary(emp.getSalary());
 		 forUpdate.setDeptName(emp.getDeptName());
		 em.merge(forUpdate);		 
 		 trans.commit();
 		 ret = empJson.toString() + " is Updated.";
 	   }catch(Exception ex) {
 		  ex.printStackTrace();
 		  trans.rollback();
 	   }	  
 	   return ret;
      }
  
  
}
