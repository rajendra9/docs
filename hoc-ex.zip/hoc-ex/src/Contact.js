import React from 'react';
import Rainbow from './hoc/Rainbow';

const Contact = () => {
   return(
       <div className='container'>
         <h4 className='center'>
             This is Contacts Page
         </h4>
         <p> This is Contacts Page for demonstrating  routes</p>     
       </div>
   )
}

export  default Rainbow(Contact);