import React, { Component } from 'react';
import Contact from './Contact';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Contact />       
      </div>
    );
  }
}

export default App;
