import Vue from 'vue'
import App from './App.vue'
import VueResource from 'vue-resource';

Vue.use(VueResource);

//custom directives
Vue.directive('randColor',{
  bind(el, binding, vnode){
    el.style.color = '#' + Math.random().toString().slice(2,8);
  }
})



Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
