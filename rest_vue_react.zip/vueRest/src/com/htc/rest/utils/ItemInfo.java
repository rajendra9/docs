package com.htc.rest.utils;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


@Entity
@Table(name="rest_items")
@SuppressWarnings("serial")
@NamedQuery(name="all.items", query="select t from ItemInfo t")
public class ItemInfo  implements Serializable {

   private String    itemId;
   
   private String itemName;
   
   private double  itemPrice;

    private String  customer;
   
   public ItemInfo(){}   

   public ItemInfo(String itemId, String itemName, double itemPrice, String customer) {
	  super();
	  this.itemId = itemId;
	  this.itemName = itemName;
	  this.itemPrice = itemPrice;
	  this.customer = customer;
   }
   
   @Column
   public String getCustomer() {
	 return customer;
   }

   public void setCustomer(String customer) {
	  this.customer = customer;
   }

   @Id
   @Column(name="item_id")
   public String getItemId() {
     return  itemId;
   }
   
   public void setItemId(String id){
      this.itemId = id;
   }

   @Column(name="item_name")
   public String getItemName() {
     return  itemName;
   }
   
   public void setItemName(String name){
     this.itemName = name;
   }

   @Column(name="item_price")
   public double getItemPrice() {
      return  itemPrice;
   }
   
   public void setItemPrice(double price){
      this.itemPrice = price;
   }
        
   public String toString(){
      return this.itemId + ":" + this.itemName + ":" + this.itemPrice + ":" + this.customer;
   }

   @Override
   public int hashCode() {
	  final int prime = 31;
	  int result = 1;
	  result = prime * result + ((itemId == null) ? 0 : itemId.hashCode());
	  return result;
   }

   @Override
   public boolean equals(Object obj) {
	  if (this == obj)
		 return true;
	  if (obj == null)
		 return false;
	  if (getClass() != obj.getClass())
		 return false;
	  ItemInfo other = (ItemInfo) obj;
	  if (itemId == null) {
		  if (other.itemId != null)
			return false;
	  } else if (!itemId.equals(other.itemId))
		return false;
	   return true;
    }

   
}
       
