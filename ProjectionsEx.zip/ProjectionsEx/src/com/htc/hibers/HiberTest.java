package  com.htc.hibers;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;  

@SuppressWarnings("serial")
public class HiberTest  implements ProdDao {
 
 
 static SessionFactory sf;
 static {
  try {
   sf = HibernateBoot.getFactory();
  }
  catch(Exception e) {
   e.printStackTrace();
  }
 }

 public void updateProduct(Product p){
  Session session = sf.openSession();
  Transaction tx = session.beginTransaction();
  try {
   session.update(p);
   session.flush();
  }
  catch(Exception e){
   tx.rollback();
  }
  tx.commit(); 
  session.close();
 }   

 public void persistProduct(Product p) {
  Session session = sf.openSession();
  Transaction tx = session.beginTransaction();
  try {
   session.save(p);
   session.flush();
  } 
  catch(Exception e) {
   tx.rollback();
  } 
  tx.commit(); 
  session.close();
 } 

 public void removeProduct(Product p) {
  Session session = sf.openSession();
  Transaction tx = session.beginTransaction();
  try {
   session.delete(p);
   session.flush();
  }
  catch(Exception e) {
   tx.rollback();
  }
  tx.commit(); 
  session.close();
 }
 
 public List<Product> getProducts(){
  Session session = sf.openSession();
  List<Product> ret = null;
  Transaction tx = session.beginTransaction();
  try {
   Query<Product> qry = session.createQuery(" from Product "+
              " prod order by prod"); 
   ret =  qry.list();
   session.flush();
   tx.commit(); 
  }
  catch(Exception e) {
   tx.rollback();
  }  
  session.close();
  return ret;
 }

 public ArrayList<Product>  getProdsByType(String type) {
  Session session = sf.openSession();
  Transaction tx = session.beginTransaction();
  ArrayList<Product> prods = new ArrayList<Product>();
  try {
   Query qry = session.getNamedQuery("prodByType");
   qry = qry.setParameter("pt",type);    
   List li = qry.list();
   prods.addAll(li); 
   tx.commit();
  }
  catch(Exception e) {
   e.printStackTrace();  
   tx.rollback();
  }
  session.close();
  return prods;
 }   
 
 
 public List<Product> getProductsCostlierThan(double d) {
  Session session = sf.openSession();
  Transaction tx = session.beginTransaction();
  List<Product> list = new ArrayList<Product>();
  try {    
    /*List li = 
   session.createCriteria(com.htc.javaee.Product.class).add(
                  Restrictions.gt("cost",new Double(d))).list(); */

   Criteria crit = session.createCriteria(com.htc.jee.Product.class);

   Criterion crton =
             Restrictions.gt("cost",new Double(d));
    
   crit = crit.add(crton);

   List li = crit.list();

   list.addAll(li);
   tx.commit(); 
   session.flush();   
  }
  catch(Exception e) {
   tx.rollback();
  }
  
  session.close();
  return list;
 }

 public static void main(String[] args)throws Exception {
  HiberTest ht = new HiberTest();
  
  Product p1 = new Product("Lux","N",19.50);
  Product p2 = new Product("Pears","R",25.80);        
  Product p3 = new Product("Cinthol","N",19.80);
  Product p4 = new Product("Dove","R",32.80); 
  Product p5 = new Product("Fa","R",35.80);           
  Product p6 = new Product("Marvel","R",23.50); 
   
  ht.persistProduct(p1);
  ht.persistProduct(p2);
  ht.persistProduct(p3);
  ht.persistProduct(p4);
  ht.persistProduct(p5);
  ht.persistProduct(p6);

  System.out.println("Products created");

  p1.setCost(24.50);
  ht.updateProduct(p1);
  System.out.println("\nProduct updated\n");

  System.out.println("Before Removal\n");
  System.out.println(ht.getProducts());
  ht.removeProduct(p2); 
  System.out.println("\nProduct removed,after removal\n");
  System.out.println(ht.getProducts());
   
  System.out.println("\nshowing Product with id '3' \n");
  int id = 3;
  System.out.println(ht.getProductById(id));
  System.out.println("\nShowing products by 'Rare'"+
                     " productType\n");
  System.out.println(ht.getProdsByType("R")+"\n");

  System.out.println("\nShowing products by cost "+
                     " higher than Rs30/-\n");
  double limit = 30.00f;
  System.out.println(ht.getProductsCostlierThan(limit));

 
 }

}
   
/* org.hibernate.Query is having methods 
    int <-- executeUpdate() for update or delete
    List <-- list()
    Iterator <-- iterator()
    overloaded set... methods for providing values to bind 
    variables of query

org.hibernate.Criteria is an interface ,whose object will be the result of method createCriteria(...class...) on session object.
 when you add(Criterion) will return again org.hibernate.Criteria object that has list() to give java.util.List object ,also have uniqueResult() that returns Object

org.hibernate.criterion.Criterion  is an interface
    org.hibernate.criterion.SimpleExpression is a class that implements
   when you call Restrictions.ge or le or eq methods , this class object will be returned ,that should be used above */
    