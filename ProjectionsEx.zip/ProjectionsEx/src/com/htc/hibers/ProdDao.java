package com.htc.hibers;

import java.io.Serializable;
import java.util.ArrayList;

public interface ProdDao extends Serializable {
	 public void updateProduct(Product p);
	 public void persistProduct(Product p);
	 public void removeProduct(Product p)
	 public ArrayList<Product>  getProdsByType(String type) {

}
