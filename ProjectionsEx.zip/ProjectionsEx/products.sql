drop table if exists htc_products;


create table htc_products(prodid integer primary key,
pname varchar(20),
prod_type varchar(1),
cost decimal(8,2));



