<template>
  <div id="app">        
    <Header/>
    <Celebrities/>
    <Footer/>
  </div>
</template>

<script>
import Header from './components/Header.vue';
import Footer from './components/Footer.vue';
import Celebrities from './components/Celebrities.vue';
export default {  
  components:{
     Header,
     Celebrities,
     Footer
  },
  data () {
    return {
      
    }
  }
}

</script>

<style scoped>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
