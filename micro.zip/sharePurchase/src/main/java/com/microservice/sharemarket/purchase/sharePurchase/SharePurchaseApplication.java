package com.microservice.sharemarket.purchase.sharePurchase;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients("com.microservice.sharemarket.purchase.sharePurchase")
@SpringBootApplication
public class SharePurchaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SharePurchaseApplication.class, args);
		System.out.println("Press 'Enter' to terminate");
		Scanner scan = new Scanner(System.in);
        scan.nextLine();
        System.out.println("Exiting");
        scan.close();
        System.exit(1);
	}

}

