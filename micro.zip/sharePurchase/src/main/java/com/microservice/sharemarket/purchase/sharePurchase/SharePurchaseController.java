package com.microservice.sharemarket.purchase.sharePurchase;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/*
 * First we have connect to shareFindService and get the cost of shareValue
 * given a company id
 */

@RestController
public class SharePurchaseController {
	
	@Autowired
	SharePriceProxy proxy;
	
	@GetMapping("/purchase/company/{companyId}/quantity/{qty}")
	public PurchasableShare purchaseShares(@PathVariable("companyId") long id,@PathVariable("qty") int qty) {
		
		Map<String, Long> params = new HashMap<>();
		params.put("companyId", Long.valueOf(id));
		String url = "http://localhost:8000/sharePrice/company/{companyId}";
		ResponseEntity<PurchasableShare> responseEntity = 
		   new RestTemplate().getForEntity(url, PurchasableShare.class, params);
		
		System.out.println("Client interacted");
		PurchasableShare purchaseShare = responseEntity.getBody();
		
		return new PurchasableShare(purchaseShare.getCompanyId(),purchaseShare.getSharePrice(),qty, purchaseShare.getPort());
	}
	
	@GetMapping("/purchaseFeign/company/{companyId}/quantity/{qty}")
	public PurchasableShare purchaseSharesFeign(@PathVariable("companyId") long id,@PathVariable("qty") int qty) {
		
		System.out.println("Client interacted");
		PurchasableShare purchaseShare = proxy.findSharePrice(id);
		return new PurchasableShare(purchaseShare.getCompanyId(),purchaseShare.getSharePrice(),qty, purchaseShare.getPort());
	}
}
