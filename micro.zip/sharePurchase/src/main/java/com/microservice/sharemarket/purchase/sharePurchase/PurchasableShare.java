package com.microservice.sharemarket.purchase.sharePurchase;

import java.io.Serializable;
import java.math.BigDecimal;


@SuppressWarnings("serial")
public class PurchasableShare implements Serializable {
	private long companyId;
    private BigDecimal sharePrice;
    private int soldQty;
    private double totalPurchaseCost;
    int port;
   
    public int getPort() {
		return port;
	}


	public void setPort(int port) {
		this.port = port;
	}

	
    public PurchasableShare() {
		super();
	}
	 
	
    public PurchasableShare(long companyId, BigDecimal sharePrice, int soldQty, int port) {
		super();
		this.companyId = companyId;
		this.sharePrice = sharePrice;
		this.soldQty = soldQty;
		this.totalPurchaseCost = sharePrice.doubleValue()*soldQty;
		this.port = port;
	}


	public long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(long companyId) {
		this.companyId = companyId;
	}

	public BigDecimal getSharePrice() {
		return sharePrice;
	}

	public void setSharePrice(BigDecimal sharePrice) {
		this.sharePrice = sharePrice;
	}

	public int getSoldQty() {
		return soldQty;
	}

	public void setSoldQty(int soldQty) {
		this.soldQty = soldQty;
		this.totalPurchaseCost = this.sharePrice.doubleValue()*soldQty;
	}

	public double getTotalPurchaseCost() {
		return totalPurchaseCost;
	}


	@Override
	public String toString() {
		return "PurchasableShare [companyId=" + companyId + ", sharePrice=" + sharePrice + ", soldQty=" + soldQty
				+ ", totalPurchaseCost=" + totalPurchaseCost + ", port=" + port + "]";
	}
	 
     
}
