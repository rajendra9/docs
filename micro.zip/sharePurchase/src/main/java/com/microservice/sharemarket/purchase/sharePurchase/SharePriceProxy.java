package com.microservice.sharemarket.purchase.sharePurchase;



import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.cloud.netflix.ribbon.RibbonClient;



@FeignClient(name="share-service",url="localhost:8000")
public interface SharePriceProxy {

	@GetMapping("/sharePrice/company/{companyId}")
	public PurchasableShare findSharePrice(@PathVariable("companyId")long companyId);
}
