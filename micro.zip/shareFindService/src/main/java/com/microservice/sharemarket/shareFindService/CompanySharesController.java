package com.microservice.sharemarket.shareFindService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CompanySharesController {

	@Autowired
	Environment env;
	
	@Autowired
	SharePricesRepository sharesRepository;
	
	@GetMapping("/sharePrice/company/{companyId}")
	public CompanyShare findSharePrice(@PathVariable("companyId")long companyId) {
		CompanyShare share = sharesRepository.findById(companyId);
		System.out.println("%%%%"+share);
		//CompanyShareTO ret = this.convert(share);
		share.setPort(Integer.parseInt(env.getProperty("local.server.port")));
		return share;
	}
	
	
}
