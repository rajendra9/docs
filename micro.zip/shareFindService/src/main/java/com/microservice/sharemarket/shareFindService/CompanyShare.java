package com.microservice.sharemarket.shareFindService;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="company_shares")
public class CompanyShare implements Serializable {
	
    @Id
    @Column(name="company_id")
    private long companyId;
    
    public long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(long companyId) {
		this.companyId = companyId;
	}

	@Column(name="company_name")
	private String companyName;
    
    @Column(name="published_date")
    private LocalDate pubDate; 
    
    @Column
    private String location;
    
    @Column(name="share_price")
    private BigDecimal sharePrice;

    private int port;
    
	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public CompanyShare() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CompanyShare(long id,String companyName, String location, LocalDate pubDate, BigDecimal sharePrice) {
		super();
		this.companyId = id;
		this.companyName = companyName;
		this.location = location;
		this.pubDate = pubDate;
		this.sharePrice = sharePrice;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public LocalDate getPubDate() {
		return pubDate;
	}

	public void setPubDate(LocalDate pubDate) {
		this.pubDate = pubDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public BigDecimal getSharePrice() {
		return sharePrice;
	}

	public void setSharePrice(BigDecimal sharePrice) {
		this.sharePrice = sharePrice;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (companyId ^ (companyId >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CompanyShare other = (CompanyShare) obj;
		if (companyId != other.companyId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CompanyShare [companyId=" + companyId + ", companyName=" + companyName + ", pubDate=" + pubDate
				+ ", location=" + location + ", sharePrice=" + sharePrice + ", port=" + port + "]";
	}

	
    
	
}
