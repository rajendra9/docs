import { Component } from '@angular/core';
import {FormBuilder, FormGroup, Validators }  from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  personForm: FormGroup;
  personId:string = '';
  name: string = '';
  phone: string = '';
  personMail: string = '';
  income: number = 0.0;
  posting: any;
  constructor(fb: FormBuilder){
    this.personForm = fb.group({
      'personId': [null, Validators.required],
      'name': [null,[Validators.required,Validators.minLength(6)]],
      'phone': [null, Validators.required],
      'personMail': [null,[Validators.required,Validators.email]],
      'income': [null,[Validators.required,Validators.min(1800)]]
    });
  }
  savePerson(posting){
    alert(JSON.stringify(posting));
  }
}
