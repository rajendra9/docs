package com.htc.ciber.spring.rest.utils;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.htc.ciber.spring.rest.domain.OrderDto;
import com.htc.ciber.spring.rest.domain.OrderTo;

@Transactional
@SuppressWarnings("serial")
public class OrdersOrmService implements OrdersOrmDao  {
	
   private HibernateTemplate template;
   private SessionFactory sessionFactory;
   DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
   
   public void setSessionFactory(SessionFactory sessionFactory) {
	   this.sessionFactory = sessionFactory;
	   this.template = new HibernateTemplate(sessionFactory);
	   System.out.println("&&&&"+template);
   }   
   
   public boolean isOrderExists(String ordId) {
	   Optional<OrderDto> dtoOpt = this.template.execute((Session session)->{
			 Query<OrderDto> qry = session.createNamedQuery("order.byId", OrderDto.class);
			 qry.setParameter("oid", ordId);
			 return qry.uniqueResultOptional();
		 });
		 if(dtoOpt.isPresent()) {
			 return false;
		 }
		 else {
			return true; 
		 }  
   }
   public OrderDto translateAsDto(OrderTo order) {
	   OrderDto orderEntity = new OrderDto();
	   orderEntity.setCost(order.getCost());
	   orderEntity.setCustomer(order.getCustomer());
	   orderEntity.setItems(order.getItems());
	   orderEntity.setOrderId(order.getOrderId());
	   LocalDate dt = LocalDate.parse(order.getOrderDate(), formatter);
	   orderEntity.setOrderDate(dt);
	   return  orderEntity;    
   }
   
   public OrderTo translateAsTo(OrderDto orderEntity) {
	   OrderTo order = new OrderTo();
	   order.setCost(orderEntity.getCost());
	   order.setCustomer(orderEntity.getCustomer());
	   order.setItems(orderEntity.getItems());
	   order.setOrderId(orderEntity.getOrderId());
	   LocalDate dt = orderEntity.getOrderDate();
	   String dtStr = formatter.format(dt);
	   order.setOrderDate(dtStr);
	   return  order;    
   }
   
   public OrdersOrmService() {
       super();        
   }   
   
   
   @Override
   public List<OrderTo> getAllOrders() {
	  List<OrderTo> ret = new ArrayList<>(); 
	  List<OrderDto> dtoList = this.template.execute((Session session)->{
  			 Query<OrderDto> qry = session.createNamedQuery("all.orders", OrderDto.class);
  			 return qry.list();
  		 });       
       for(OrderDto orderEntity : dtoList ) {
    	   ret.add(this.translateAsTo(orderEntity));
       }
       return ret; 
   }

   @Override
   public Optional<OrderTo> getOrder(String orderId) {
		 Optional<OrderDto> dtoOpt = this.template.execute((Session session)->{
			 Query<OrderDto> qry = session.createNamedQuery("order.byId",OrderDto.class);
			 qry.setParameter("oid", orderId);
			 return qry.uniqueResultOptional();
		 });
		 if(dtoOpt.isPresent()) {
			 OrderTo order = this.translateAsTo(dtoOpt.get());
			 return Optional.of(order);
		 }
		 else {
			return Optional.empty(); 
		 }
   }

   

   @Override
   public boolean saveOrder(OrderTo order) {
	   boolean  ret = false;
	   OrderDto orderEntity = this.translateAsDto(order);
	   try{   
	     Serializable obj = template.save(orderEntity);
	     if(!Objects.isNull(obj)){
	      System.out.println("Object Saved");
	      ret = true;
	     }
	    }catch(Exception e){
	      e.printStackTrace();	      
	    }
	    return ret;
	 }



   @Override
   public boolean updateOrder(String ordId, String newCustomer, double newCost) {
	   boolean ret = false;        
       try {
        OrderDto searched = template.get(OrderDto.class, ordId);
        searched.setCustomer(newCustomer);
        searched.setCost(newCost);
        template.update(searched);
        ret = true;
       }catch(Exception ex){
         ex.printStackTrace();  
       }
       return ret;
   }



   @Override
   public boolean deleteOrder(String ordId) {
	   boolean ret = false;        
       try {
        OrderDto searched = template.get(OrderDto.class, ordId);
        template.delete(searched);
        ret = true;
       }catch(Exception ex){
         ex.printStackTrace();  
       }
       return ret;
	 
   }



   

 
 
   
   
}