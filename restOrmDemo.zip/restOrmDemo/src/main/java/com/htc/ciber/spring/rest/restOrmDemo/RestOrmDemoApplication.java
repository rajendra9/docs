package com.htc.ciber.spring.rest.restOrmDemo;

import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import com.htc.ciber.spring.rest.utils.OrdersOrmDao;
import com.htc.ciber.spring.rest.utils.OrdersOrmService;

@PropertySource("file:./jdbc.properties")
@SpringBootApplication
@ComponentScan
public class RestOrmDemoApplication {
		 	  
	public static void main(String[] args) {
		SpringApplication.run(RestOrmDemoApplication.class, args);
	}

}

