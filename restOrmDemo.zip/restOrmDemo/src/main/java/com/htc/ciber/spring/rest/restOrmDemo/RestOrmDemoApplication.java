package com.htc.ciber.spring.rest.restOrmDemo;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import com.htc.ciber.spring.rest.utils.OrdersOrmDao;
import com.htc.ciber.spring.rest.utils.OrdersOrmService;

@PropertySource("file:./jdbc.properties")
@SpringBootApplication
@ComponentScan({"com.htc.ciber.spring.rest.utils","com.htc.ciber.spring.rest.restOrmDemo"})
public class RestOrmDemoApplication {
	@Autowired
	Environment env;
	
	@Bean
    public DataSource dataSource() {
		DriverManagerDataSource ds =
             new DriverManagerDataSource(); 
		System.out.println("fired");
     String driverCl = env.getProperty("db.driver");
     ds.setDriverClassName(driverCl);
     ds.setUrl(env.getProperty("db.url"));
     System.out.println(env.getProperty("db.password"));
     ds.setUsername(env.getProperty("db.username"));
     ds.setPassword(env.getProperty("db.password"));
     System.out.println("***"+ds);
     return ds;
    }  	
	
    @Bean
	public HibernateJpaVendorAdapter jpaVendorAdapter(){
	    HibernateJpaVendorAdapter jpaVendorAdapter =
	                        new HibernateJpaVendorAdapter();
	    jpaVendorAdapter.setDatabase(Database.POSTGRESQL);
	    jpaVendorAdapter.setShowSql(true);
	    jpaVendorAdapter.setGenerateDdl(false);
	    return jpaVendorAdapter;
     }

	 @Bean(name = "entityManagerFactory")
	 public EntityManagerFactory entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean emf = new LocalContainerEntityManagerFactoryBean();
		emf.setDataSource(dataSource());
		emf.setJpaVendorAdapter(this.jpaVendorAdapter());
		emf.setPackagesToScan("com.htc.ciber.spring.rest.domain");
		emf.setPersistenceUnitName("default");
		emf.afterPropertiesSet();
		return emf.getObject();
	  }
	 
      @Bean
	  public SessionFactory sessionFactory() {
		 if (this.entityManagerFactory().unwrap(SessionFactory.class) == null) {
		     throw new NullPointerException("factory is not a hibernate factory");
	      }
		  return entityManagerFactory().unwrap(SessionFactory.class);
      }

	  @Bean
	  public HibernateTransactionManager transactionManager() {
		    HibernateTransactionManager txManager = new HibernateTransactionManager();
		    txManager.setSessionFactory(sessionFactory());  
		    return txManager;
	   }
		  
	  @Bean
	  public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
	     return new PersistenceExceptionTranslationPostProcessor();
	  }
	    
	  @Bean
	  public OrdersOrmDao ordersOrmService() {
	    OrdersOrmDao ordersOrmDao = new  OrdersOrmService();
	    ordersOrmDao.setSessionFactory(sessionFactory());
	    return ordersOrmDao;
	  }
	public static void main(String[] args) {
		SpringApplication.run(RestOrmDemoApplication.class, args);
	}

}

