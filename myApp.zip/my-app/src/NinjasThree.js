import React from 'react';

const NinjasThree = (props) => {
     const ninjas = props.ninjas;
     return(
          < table align='center'>
            <tbody>
          {
              ninjas.map((ninja)=>{
              return <tr key={ninja.id}><td>{ninja.name}</td>
              <td>{ninja.course}</td>
              <td>{ninja.belt}</td>
              </tr>
            })              
          }   
          </tbody>
          </table> 
      )
  
}

export  default NinjasThree;