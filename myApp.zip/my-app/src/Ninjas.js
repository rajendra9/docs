import React from 'react';

const Ninjas = () => {
      return(
          <div className="ninjas">
            <div>Name: Sandeep</div>
            <div>Course: Karate</div>   
            <div>Belt: Black</div>
          </div>    
      )
}

export  default Ninjas;