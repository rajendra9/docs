import React from 'react';

const NinjasTwo = (props) => {
      /*console.log(this.props);
      to make them (props) available as  
      should have same names
      */
     const { name, course, belt} = props;
     return(
          <div className="ninjas">
            <div>Name: {name}</div>
            <div>Course: {course}</div>   
            <div>Belt: {belt}</div>
          </div>    
      )
  
}

export  default NinjasTwo;