package com.jsf2.ex;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;

@Named(value="faceletsBean")
@SessionScoped
public class FaceletsBean implements java.io.Serializable {
    private  String  bookStore;
    Set<String> authors;
    List<String> publishers;
    List<String> books;
    
    public Set<String> getAuthors() {
        return authors;
    }

    public List<String> getBooks() {
        return books;
    }
    
    public FaceletsBean() {
      this.bookStore = "M/s Compuware Earn Books"; 
      authors = new HashSet<>();
      Collections.addAll(authors, "John Rodson", "H.K.P.Peterson","Josh Juneau","D.G.H.Kavlen");
      books = new ArrayList<>();
      Collections.addAll(books,"Spring-IOC", "Oracle12c Basics","JEE7 Receipes","ASP.NET Basics");
      publishers = new ArrayList<>();
      Collections.addAll(publishers,"M/S Wiley Publishers, Sanfransisco",
              "M/S Wrox Printers, New York","M/S Apress Publications, London");
    
    }

    public void setBookStore(String bookStore) {
        this.bookStore = bookStore;
    }

    public String getBookStore() {
        return bookStore;
    }
    
    public String  showAuthors(){
        return "authors";
    }

    public void setAuthors(Set<String> authors) {
        this.authors = authors;
    }

    public void setBooks(List<String> books) {
        this.books = books;
    }
    
    public String showBooks(){
       return  "books"; 
    }

    public List<String> getPublishers() {
        return publishers;
    }

    public void setPublishers(List<String> publishers) {
        this.publishers = publishers;
    }  
    
    
}
