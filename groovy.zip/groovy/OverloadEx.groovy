abstract class Person {
String name
}

class Parent extends Person {}

class Child extends Person {}

def printName(Person person) { println "Method in Person: $person.name" }

def printName(Child child) { println "Method in Child: $child.name" }

def printName(p) { println "printName(p): $p.name" }

Person parent1 = new Parent(name: 'parent1')

Person child1 = new Child(name: 'child1')

printName(parent1)
printName(child1)

