package forDB

public class SqInsert {

   def takeInput(colName, colType){
     Scanner scan = new Scanner(System.in)
     if(colType == "date"){
        println "Enter value for " + colName + " as " + colType + "[yyyy-MM-dd]"
     }
     else {
        println "Enter value for " + colName + " as " + colType
     }
     def input = scan.nextLine()
     input = input.trim()
     if(colType == "int"){
       return Integer.parseInt(input)
     }
     else if(colType == "double"){
       return Double.parseDouble(input)
     }
     else if(colType == "date"){
       return "to_date('"+input+"','yyyy-mm-dd')"
     }
     else if(colType == "string"){
         return "'"+input+"'"
     }
   }
   def insertRec(tblName, colMap){
      def insertSql = "insert into " + tblName + "("
      colMap.each{
          insertSql += "${it.key},"
      }
      insertSql = insertSql.substring(0, insertSql.length()-1)+") values ("
      colMap.each{
           insertSql += takeInput("${it.key}","${it.value}")+","
      }
      insertSql = insertSql.substring(0, insertSql.length()-1)+")"
      println insertSql
      def sql = SqlRet.readProps("oracle")
      def result = sql.executeUpdate(insertSql)
      println "rows inserted-${result}"
   }
  
   static void main(args){
      def sqInsert = new SqInsert()
      sqInsert.insertRec("dept",["deptno":"int","dname":"string","loc":"string"])
   }

}