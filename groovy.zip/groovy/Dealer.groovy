package mytraits


trait Dealer {
    long shelfLifeHours;
    def store(){
        return "proper storage required to get Bank Credits"
    }

    def provideCredibility(){
        println "should have good credibility in Market"
    }
    abstract void setShelfLife()
    abstract void offerDiscount()
}
