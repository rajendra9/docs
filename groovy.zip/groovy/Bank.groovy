package forxml

class Bank {
    String name
    int estbYear
    ArrayList branches

    public Bank(String na, Integer estYr, ArrayList brancs) {
        name = na
        estbYear = estYr
        branches = brancs
    }

    String toString() {
        "Name:" + name + ", Estblished tear:" + estbYear + ", branches:" + branches
    }
 }