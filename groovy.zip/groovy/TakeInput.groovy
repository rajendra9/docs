

Scanner scan = new Scanner(System.in);
println "Enter name"
def name = scan.nextLine()
println "hello $name "

println "Enter Age"

def age = Integer.parseInt(scan.nextLine())


if(age<10){
  println "Learning Groovy is difficult"
}
else{
  println "Learning Groovy is Very Easy"
}
