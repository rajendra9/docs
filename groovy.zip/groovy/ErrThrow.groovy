package dyna

class ErrThrow {
    
   static int instCount = 1
   def static useMeth(){
     println this.instCount     
   }
   def static readFile(){
     def fin = null  
     try{  
       fin = new FileReader("htc2.dat")
      
     }catch(ex){
        println ex.message
        fin = new FileReader("htc.dat")
     }  
     println fin.text
   } 
   static main(args) {
      useMeth()
      readFile()  
   }

}
