
class DefParam {

   def accessWeb(address, port=80){
       println "site is available at $address and at port-$port"
   }

   static void main(args){
       def df = new DefParam()
       df.accessWeb("www.msn.com");
       df.accessWeb("www.sun.com", 8080);
   }
}
