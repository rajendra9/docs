class StringAsArr{
   String src
   int start, end
 
   def printRange(src = "", start = 0, end = src.length()-1){
     println src[start .. end]
   }
  
   def invokeRanges(){
     def strSrc = "How old are you"
     printRange(src = strSrc, start = 4)
     println "reverse" 
     printRange(src = strSrc, start = -1, end = -(src.length()))
     printRange(strSrc, -1, -(src.length()))
   }
   static void main(args){
     def obj = new StringAsArr()
     obj.invokeRanges()
   }
 
}