package forjson

import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import groovy.json.JsonParserType
import groovy.json.JsonSlurper

class JsonEx {

    static def populate() {
        def list = []
        list << new Item("s234", "mobile", 11000.0)
        list << new Item("s452", "Tray", 5000.0)
        list << new Item("s651", "Dining Table", 15000.0)
        list << new Item("s337", "Sofa", 29000.0)
        list << new Item("s918", "Table", 7000.0)
        list
    }

    static void main(args){
       def jsonParser = new JsonSlurper()
       jsonParser.setType(JsonParserType.LAX)
       def src = '{item:{"itemId": "s234", "itemName": "mobile", "itemCost": 11000.5}}'
       def myItem = jsonParser.parseText(src)
       println "obj=" + myItem.toString()
       src = '{"itemId": "s234", "itemName": "mobile", "itemCost": 11000.5}'

       myItem = jsonParser.parseText(src)
       println "reading fields"
       println myItem.itemCost + "," + myItem.itemId + "," + myItem.itemName

       def content = '{itemid: "d324",itemName:"laptop",itemCost:54000.5}'
       def result = JsonOutput.toJson(content)
       println result

       content ='''[{itemid: "d324",itemName:"laptop",itemCost:54000.5},
                    {itemid: "e544",itemName:"easychair",itemCost:12000.0}]'''
       result = JsonOutput.toJson(content)
       println result

       def li = populate()
       def builder = new JsonBuilder(li)

       result = builder.toPrettyString()
       println result



    }
}
