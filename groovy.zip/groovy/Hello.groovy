println "Welcome To groovy"

numbers = [32,43,54,65]

for(num in numbers){
  print num+" "
}
println ""
numbers.add(230)
numbers.add(2,430)

for(num in numbers){
  print num+" "
}
println ""