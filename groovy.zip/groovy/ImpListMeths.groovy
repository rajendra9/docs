package cols

class ImpListMeths {
   static main(args) {
       def coll = [3,5,6].collect{it+3}
       println coll

       coll = [3, [5, 6], 7, [21, 14, 23]].flatten()
       println coll

       coll = [3, 5, 6, 7, 6, 5, 3].unique()
       def cnt = [3, 5, 6, 7, 6, 5, 3].unique().size()
       println coll
       println cnt

       cnt = [3, 5, 6, 7, 6, 5, 6].count(6)
       println cnt

       //what common elements are found
       println ([2,5,6].disjoint([5, 7, 2, 12]))
       println  ([2,5,6].disjoint([7, 9, 12]))

       println ([2,5,6].intersect([5, 6, 7, 2, 12]))

       coll = [2, 5, 6, 9].reverse()
       println coll

       def maxElt = [43, 93, 65, 42, 56, 67, 87, 92].max()
       def minElt = [43, 93, 65, 42, 56, 67, 87, 92].min()
       println maxElt + "::" + minElt

       coll = [2, 25, 43 ,6, 14, 71, 32, 9].sort()
       println coll

   }
}
