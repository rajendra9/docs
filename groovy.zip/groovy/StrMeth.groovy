
class StrMeth {

    def void takeUse(){
       def src = "HigginBothams"
       println src.take(1)
       println src.take(2)
       println src.take(5)
       println src.take(8)
       println src.take(20)+"*****"
    }

    def void dropUse(){
        def src = "HigginBothams"
        println src.drop(1)
        println src.drop(2)
        println src.drop(5)
        println src.drop(8)
        println "****" + src.drop(20) + "*****"
    }

    def void rangeUse(){
        def src = "HigginBothams"
        println "[0..3]->" + src[0..3]
        println "[1..10]-->" + src[1..10]
        println "[1..src.length()-1]=>" + src[1..src.length()-1]
        println "[-6..0]->" + src[-6..0]
        println "[src.length()-1..0]->" + src[src.length()-1..0]
        println "[-4..-1]->" + src[-4..-1]
    }

    static void main(args){
        def strMeth = new StrMeth()
        println "take usage"
        strMeth.takeUse()
        println "*************************************"
        println "drop use"
        strMeth.dropUse()
        println "*************************************"
        println "range use"
        strMeth.rangeUse()

    }

}
