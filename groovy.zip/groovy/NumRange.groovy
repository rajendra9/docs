class NumRange{
   def srcList = [12, 11, 24,6, 8, 23, 7, 9, 32, 10, 4, 9, 32, 31, 8]
   
   def findRange(start, end){
     def range = start .. end
     println srcList.grep(range)
   }
   
   def searchElem(elem){
     println srcList.contains(elem)
   }
  
   def search(){
     findRange(1,10)
     searchElem(24)
     searchElem(17)
     searchElem(25)
   } 
   static void main(args){
     def obj = new NumRange()
     obj.search()
   }


}