
public class Employee {
     int empNum
     String empName,job,address
     double salary

     Employee(){
     }

     Employee(String name){
         this.empName = name
     }

     String getEmpName(){
         "EmpName:"+this.empName
     }

     boolean equals(other){
       this.empNum == other.empNum
     }

     int hashCode(){
         empNum+1000
     }

     String toString(){
        "EmpNum : " + this.empNum + ", EmpName : " + this.empName + ", Job : " + this.job + ", Salary : " + this.salary
        + ", Address : " + this.address
     }

     public static Employee createEmp(eno, en, jb, addr, sa){
         return new Employee(empNum : eno, empName:en, job:jb, address:addr, salary:sa)
     }

     def bonus(percentage){
         if(percentage == null){
             percentage = 0.20
         }
         return this.salary*percentage
     }

}
