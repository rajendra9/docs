package mytraits

trait Vehicle {
      
      def drive(){
             println "moving forward"
      }  
}