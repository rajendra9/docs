package dyna

class AddMethod {
   
   def langsDuration = [:]
   
   private AddMethod(){
      langsDuration["C++"] = 45
      langsDuration["Java"] = 75
      langsDuration["Oracle"] = 40
      langsDuration["Net"] = 75
      langsDuration["Javascript"] = 25
      langsDuration["Python"] = 30 
      def mc = new ExpandoMetaClass(AddMethod.class, false, true)
      mc.initialize()
      this.metaClass = mc                  
   } 
    
   def  getDuration(lang){
      if(langsDuration[lang]){
        return langsDuration[lang]  
      } 
   }
    
   def methodMissing(String name, args){
       if(name.startsWith("get")){
         def namePart = name[3..-1]  
         println namePart
         def result = this.getDuration(namePart)
         this.metaClass."$name" =  {-> namePart + "[cache]" }  
         return result
       }
       else {
         throw new MissingMethodException(name, this.class, args)
       }
   }
   
   static main(args) {
      def aMeth = new AddMethod()
      println aMeth.getPython() 
      println aMeth.getJava()
      println aMeth.getOracle()
      println aMeth.getNet()
      println aMeth.someMethod()
      assert "Net[cache]" == aMeth.getNet()

   }

}
