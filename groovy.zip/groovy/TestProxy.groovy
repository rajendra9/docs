package dyna

def intercept = new dyna.SimpIntercept()
    def proxy = ProxyMetaClass.getInstance(dyna.FinInst.class)
    proxy.interceptor = intercept
    def fin = new dyna.FinInst()

    proxy.invokeConstructor()
    def result = proxy.invokeMethod(fin, "doCredit", new Double(5000.9))
    proxy.invokeMethod(fin, "show",null)
    result = proxy.invokeMethod(fin, "doDebit", new Double(2000.9))
    result = proxy.invokeMethod(fin, "show",null)

