package mytraits

class Car implements Vehicle {

    static void main(args){
        def car = new Car()
        car.drive()
    }

}