package ios

public class FileRead{
   String sep = File.separator
   def path = "D:" + sep + "myGroovy" + sep + "files" + sep + "student.dat"

   def void fileAsLines(){
       new File(path).eachLine{
           println it
       }
   }

   def void fileText(){
     def file = new File(path)
     println "length of the file-${file.length()}"
     println "absolute path of the file-${file.absolutePath}"
     println file.text
   }

    def void fileList(){
       def file = new File(path)
       def linesList = file.readLines()
       println linesList.getClass()
       println linesList.getAt(3)
       linesList.each { line -> (line.split("\\s")).each {println "$it"}}
    }

    def void writeAndRead(){
       def locPath = "D:" + sep + "myGroovy" + sep + "files" + sep + "newData.dat"
       def file = new File(locPath)
       file << "Hi How are you\r\n"
       file << "Have you gone to any Mall Recently\r\n"
       file << "Has Your Purse become more lighter\r\n"
       file << "And Hands got burdened of shopped things\r\n"
       println file.text
       locPath = "D:" + sep + "myGroovy" + sep + "files" + sep + "simpData.dat"
       file = new File(locPath)
       file.text = "Sachin\r\nSandeep\r\nVenkat\r\nNarasimha\r\nMannan"
    }
    def void useReader(){
      def file = new File(path)
      def line = ""
      def lineNum = 1
      file.withReader { reader -> while((line=reader.readLine()) != null){
        println "$lineNum-$line"
        lineNum++
       }
      }
    }
    static void main(args){
     def fileRead = new FileRead()
     fileRead.fileAsLines()
     println "**********************************************"

     fileRead.fileText()
     println "**********************************************"

     println "tokenizing as words"
     fileRead.fileList()
     println "**********************************************"

     fileRead.writeAndRead()
     println "**********************************************"

    fileRead.useReader()
    }

}