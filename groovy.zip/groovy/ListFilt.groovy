package cols

class ListFilt {

   class Employee {
     String name
     int age
     double salary
   
     String toString(){
       "Name is:"+name+" ,age is: "+age+", salary: "+salary
     }

    }     

    def empList = [new Employee(name:"Sargun",age:26,salary:21400.5),
                   new Employee(name:"Vivek",age:25,salary:24000.5),
                   new Employee(name:"Sachin",age:24,salary:27000.5),
                   new Employee(name:"Narayanan",age:24,salary:20800.5),
                   new Employee(name:"Vimala",age:24,salary:25000.5),
                   new Employee(name:"Sameer",age:25,salary:27500.5)
    ]
   
    def filterEmpsOnAge(ag){
      def filtList = empList.findAll { it.age == ag}
      filtList.each{ println it }   
    } 


    static void main(args){
      def codeTest = new ListFilt()
      codeTest.filterEmpsOnAge(24)           
    } 
  
}   