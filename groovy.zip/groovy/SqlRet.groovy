package forDB

import groovy.sql.Sql
class SqlRet {
    public static Sql readProps(dbName){
        String url, user, pwd, dsClass
        dbName = dbName.toLowerCase()
        def sep = File.separator
        def path = ""
        if(dbName == "oracle") {
            path = "D:" + sep + "myGroovy" + sep + "db" + sep + "orasource.properties"
            def count = 0
            new File(path).eachLine {
                if (count == 0) {
                    url = it
                } else if (count == 1) {
                    user = it
                } else if (count == 2) {
                    pwd = it
                } else if (count == 3) {
                    dsClass = it
                }
                count += 1
            }
        }
        return Sql.newInstance(url, user, pwd,dsClass)
    }


}
