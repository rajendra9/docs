package dyna


class MethodAbsent {

    def invokeMethod(String name, Object args){
        println name + " is not present invoke example"
    }

    def simpTest(){
        println "Test method"
    }

    static void main(args){
      def methNo = new MethodAbsent()
      methNo.simpTest()
      methNo.someOther()
    }

}
