package dyna
class FinInst {
    double deposits = 0.0

    def void doCredit(double amt) {
        deposits += amt
        println deposits
    }

    def void doDebit(double amt) {
        deposits -= amt
        println deposits
    }

    def show() {
       println "currently deposits are:$deposits"
    }
}