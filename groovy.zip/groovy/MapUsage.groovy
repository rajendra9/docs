package cols


class MapUsage {
    def categories = [:]


    MapUsage(){
       def shirts = [
                      new MallItem(brand: "Arrow", size :42, cost: 894.5),
                      new MallItem(brand: "Bare", size :40, cost: 765.5),
                      new MallItem(brand: "Vivaldi" ,size :44, cost: 543.5),
                      new MallItem(brand: "Hero" ,size :42, cost: 465.5)
                    ]
       def trousers = [
                         new MallItem(brand: "Arrow" ,size :36, cost: 1121.5),
                         new MallItem(brand: "Bare" ,size :38, cost: 985.5),
                         new MallItem(brand: "Vivaldi", size :34, cost: 783.5),
                         new MallItem(brand: "Lee" ,size :42, cost: 1225.5)
                      ]

       categories["shirts"] = shirts
       categories["trousers"] = trousers
    }

    def getCategoryTypes(fabType) {
        def cat = categories.find { it.key == fabType }
        if (cat) {
            return cat.value
        }
        else {
            return 'na'
        }
    }
    def getCategories() {
        return categories.keySet()
    }

    static void main(args){
        def mapUsage = new MapUsage();
        println mapUsage.getCategories()
        def catTypes = (ArrayList)mapUsage.getCategoryTypes("shirts")
        println catTypes.size()

    }

}
