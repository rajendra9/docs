/**
 * Created by PRASAD on 25-01-2016.
 */
class CommArgs {
    static void main(args){
       args.each { println "value is:${it}"}
    }
}
