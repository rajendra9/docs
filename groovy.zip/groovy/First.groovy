
class First {

    static void main(args) {
       for(int i=0;i<10;i++) {
           print " " + i
       }
       println "\n-------------------------"
       def n = 1
       10.times {
           print " " + n++
       }
       println "\n"
       20.upto(40) { print "  ${it}" }
       println "\n "
       40.step(50,2){print "  ${it}" }

        for(char k = 'a'; k<='z'; k++){
            print "  " + k
        }
        println ""

        for(k in ('A'..'Z')) {
            print " "+k
        }

    }

}
