package forDB

public class SqlRowQuery {

   /* singleRow  will come like Map where key is column Name, value as column's value */
   def printResults(qry, paramValue){
     def sql = SqlRet.readProps("oracle")
     def singleRow = sql.firstRow(qry,[paramValue])
     singleRow.each {  println "${it.key}-${it.value} " }
     println "----------------"
   } 
  
   static void main(args){
      def sqlQuery = new SqlRowQuery()
       sqlQuery.printResults("select ename,job,hiredate,sal,deptno from emp where empno=?",7788)
       sqlQuery.printResults("select dname,loc from dept where deptno=?", 40)
      }

}