
class ForDemo {
 static main(args){
   for(num in 2..50){
       print num + " "
   }
   println ""
   println "-------------------------"
   (30..<50).each{ print it + " "}
 }
}
