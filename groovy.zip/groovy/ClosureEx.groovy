class ClosureEx {
   
  def useClosure(num){
    def n = 5
    def cl = { n += 5 }
    num.times cl
    println "now n's value is $n" 
  }
  def useClosure2(num){
    def cl = { index -> println "index is:$index"}
    num.times cl  
  }
  def useClosure3(num){
    def cl = { println "index is:${it}"}
    num.times cl  
  }
  def useClosure4(){
    def person = [AdharId:'c321400',Name:'SomaSundaram',
                  Job:'Analyst',Salary:45600.5,
                  Company:'HTC',Location:'Chennai']
    person.each{key,value -> println "$key --- $value"} 
  }

 static void main(args){
   def codeTest = new ClosureEx()
   codeTest.useClosure(4);
   codeTest.useClosure2(4);
   codeTest.useClosure3(5);
   codeTest.useClosure4();
 }


}