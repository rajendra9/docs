
class UseSamp {
    static void main(args){
       def samp = new Samp()
       samp.setName("Dhanush")
       println samp.getName()
    }
}
