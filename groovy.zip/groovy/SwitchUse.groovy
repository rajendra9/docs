class SwitchUse {
  /* using ranges in switch */
  def void rangeSwitch(num){
      switch (num){
        case 1..10: println "given is within 10"
                    break;
        case 11..20: println "given is between 11 and 20"
                    break;
        case 21..50: println "given is between 21 and 50"
                     break;
        case 50..100: println "given is within 100"
                      break;
        default: println "other number above 100"
                 break
      }
  }

    /* using conditions in switch */
  def void conditionSwitch(num){
        switch (num){
            case {it%2==0 && it<100}: println "given is even less than 100"
                                      break;
            case {it%2!=0 && it<100}: println "given is odd less than 100"
                                      break;
            case {it%2==0 && it>100}: println "given is even higher than 100"
                                      break;
            case {it%2!=0 && it>100}: println "given is odd higher than 100"
                                      break;
        }
  }

    def void classSwitch(obj){
        switch (obj){
            case String: println "given is String"
                         break;
            case Integer: println "given is Integer"
                          break;
            case Double: println "given is Double"
                         break;
            case BigDecimal: println "given is BigDecimal"
                             break;
        }
    }

  static void main(args){
      def switchUse = new SwitchUse()
      switchUse.rangeSwitch(32)
      switchUse.conditionSwitch(98)
      switchUse.conditionSwitch(169)
      switchUse.classSwitch("Sachin")
      switchUse.classSwitch(230)
      switchUse.classSwitch(53.5)
      double d = 9.6
      switchUse.classSwitch(d)
  }

}
