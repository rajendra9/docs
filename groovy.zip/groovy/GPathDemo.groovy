
public class GPathDemo {

    def employees = []
    def populate(){
       employees.add(Employee.createEmp(4564, "Parasuraman", "Analyst", "Tambaram", 25500.5))
       employees.add(Employee.createEmp(4566, "Sudhakar", "Developer", "ChromePet", 32500.5))
       employees.add(Employee.createEmp(4789, "Nanban Nandu", "Developer", "Pallavaram", 28900.5))
       employees.add(Employee.createEmp(4234, "Swaroopa", "Team Leader", "Guindy", 42500.5))
       employees.add(Employee.createEmp(4120, "Sandeepan", "Tester", "Tambaram", 22500.5))
    }

    def pathInvoker(){
        def allMembers = employees.job
        allMembers.each { println "${it}"}
        println "-----------------------"

        allMembers = employees*.bonus(0.22)
        allMembers.each { println "${it}"}
        println "-----------------------"

        allMembers = employees*.bonus()
        allMembers.each { println "${it}"}
        println "-----------------------"
    }

    static void main(args){
        def demo = new GPathDemo()
        demo.populate()
        demo.pathInvoker()
    }


}
