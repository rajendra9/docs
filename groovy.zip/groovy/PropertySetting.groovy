package dyna

class PropertySetting {
   def property
   def location
   def salary
   def void setProperty(String name, Object value){
      this.@"$name" = "HTC"
      if(name == "salary"){
          this.@"$name" = value
      }
   }
   def propertyMissing(String name){
     println name + " is not present"
     name;
   }
   static void main(args){
     def propSet = new PropertySetting()
     propSet.property = "hhhh"
     propSet.location = "Tambaram"
     propSet.salary = 50000.0
     println propSet.property + "," + propSet.salary+","+propSet.location
     println propSet.address

   }
}
