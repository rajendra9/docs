import groovy.util.logging.Slf4j

@Slf4j
class LogEx {

  def findAvg(int ... ints){
     log.info "given inputs are ${ints}"
     def tot = 0
     ints.each { tot += $it }
      (tot/ints.length)
  }

  static void main(args){
    def logEx = new LogEx()
    log.info "Invoking the method"
    println logEx.findAvg(43, 16, 32, 12, 14, 15, 17)
  }
}
