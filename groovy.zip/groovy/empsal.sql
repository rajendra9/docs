drop table empsalary;

create table empsalary as
select employee_id empId, first_name||' '||last_name empName,
salary, hire_date hiredate, job_title,department_name from
employees e,jobs j,departments d
where e.department_id = d.department_id
and j.job_id =e.job_id;  