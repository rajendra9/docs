package mytraits


class Druggist implements Dealer{

    @Override
    void setShelfLife() {
       this.shelfLifeHours = 3 * 31 * 24
    }

    @Override
    void offerDiscount() {
      println "10% on general types"
    }

}

