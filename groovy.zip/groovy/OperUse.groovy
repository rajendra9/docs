package opers


class OperUse {
    String name
    double  salary

    OperUse(String name, double salary) {
        this.name = name
        this.salary = salary
    }

    @Override
    public String toString() {
        return "OperUse{" +
                "name='" + name + '\'' +
                ", salary=" + salary +
                '}';
    }

    static def populate(){
        def list = []
        list<< new OperUse("gambhir", 32000.0)
        list<< new OperUse("sucharita", 28000.0)
        list<< new OperUse("manohar",  33000.0)
        list<< new OperUse("raman",  43000.0)
        list<< new OperUse("naresh", 21000.0)
        list
    }

    static def testSort(){
        def li = populate()
        def sortLi = li.sort {it.name}
        sortLi.each { println it}
        println "based on salary"
        sortLi = li.sort {it.salary}
        sortLi.each { println it}
    }
    def plus(OperUse other){
        new OperUse(this.name, this.salary + other.salary)
    }
    static void main(args) {
       def e1 = new OperUse("Santosh", 32000.0)
       def e2 = new OperUse("Sandeep", 29000.0)
       def e3 = e2 + e1
       println e3
       def simpName
       def result = simpName?:e1.getName()
       println result
       testSort()
    }
}
