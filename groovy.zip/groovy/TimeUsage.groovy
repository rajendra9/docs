package categories

import groovy.time.TimeCategory

use(TimeCategory){
  println 2.day.from.now
  println 45.second.from.now
  println new Date()+4.months
}



