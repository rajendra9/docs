package threads

class GroovyThread implements Runnable {
    String name

    GroovyThread(String name) {
        this.name = name
    }

    @Override
    void run() {
        println name + "is sleeping first time"
        Thread.sleep(1000)
        println name + "is sleeping second time"
        Thread.sleep(1000)
        println name + "is sleeping third time"
        Thread.sleep(1000)
    }

    static void main(args) {
        def threadOne = new Thread(new GroovyThread("A"))
        def threadTwo = new Thread(new GroovyThread("B"))
        def threadThree = new Thread(new GroovyThread("C"))
        threadOne.start()
        threadTwo.start()
        threadThree.start()
    }
}