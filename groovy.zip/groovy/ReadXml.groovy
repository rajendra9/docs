package forxml

class ReadXml {

  static void main(args){
    def parser = new XmlParser()
    def doc = parser.parse("books.xml")
    println "Root Node is: " + doc.name()
    doc.book.each {
      bk ->
       println "Publisher: ${bk['@publisher']}"
       println "Book-Code: ${bk.code[0].text()}"
       println "Category: ${bk.category[0].text()}"
       println "Release-Date: ${bk.'release-date[0]'.text()}"
       println "Title: ${bk.title[0].text()}"
       println "Price: ${bk.price[0].text()}"
       println "#################################"



    }


  }
}