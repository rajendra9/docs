
class ArrUse {

    def void show(arr){
        arr.each { println "$it"}
    }

    def void defineArrays() {
        def charArr = ['G', 'A', 'M', 'B', 'H', 'I', 'R']
        show(charArr)

        def strArr = ["Santosh", "Sandeep", "Kathyani", "Devarajan", "Madhavan"] as String[]
        println "array length is:" + strArr.length + "::" + strArr.size()
        println "3 rd element is-" + strArr.getAt(2)
        println("Before Sorting")
        show(strArr)
        def sortArr = strArr.sort()
        println("After Sorting")
        show(sortArr)

        def intArr = [54, 41, 89, 31, 76, 25].toArray(new Integer[0])
        println intArr.getClass()
        println "Max is-" + intArr.max() + ":: Min is-" + intArr.min()
        println("Before Reversing")
        show(intArr)
        def revArr = intArr.reverse()
        println("After Reversing")
        show(revArr)

        def bdArr =
                [34.5, 24.6, 33.4, 18.3, 12.4, 26.8].toArray(new BigDecimal[BigDecimal.valueOf(0.0)])
        println bdArr.getClass()
        show(bdArr)

        //to get double array
        double d1 = 34.5, d2 = 24.6, d3 = 33.4, d4 = 18.3, d5 = 12.4, d6 = 26.8
        def dbArr = new double[6]
        dbArr[0] = d1
        dbArr[1] = d2
        dbArr[2] = d3
        dbArr[3] = d4
        dbArr[4] = d5
        dbArr[5] = d6
        println dbArr.getClass()
        show(dbArr)
    }

    static void main(args){
        def arrUse = new ArrUse()
        arrUse.defineArrays()
    }

}
