package mytraits

class TestDealer {

  static void main(args){
      def dealer = new Druggist()
      dealer.setShelfLife()
      dealer.provideCredibility()
      println dealer.store()
      dealer.offerDiscount()
      println "----------------------------"
      dealer = new FoodMall()
      dealer.setShelfLife()
      dealer.provideCredibility()
      println dealer.store()
      dealer.offerDiscount()
  }
}
