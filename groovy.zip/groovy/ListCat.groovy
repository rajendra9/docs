package categories

class ElemFrequency {
   static findFrequency(list, val){
     def searched = list.findAll { it == val }
     return searched.size()
   }

}     
use (ElemFrequency){
  def li = [5, 8, 6, 2, 4, 7, 2, 11, 2, 56, 14, 17, 2]
  println li.findFrequency(2) 
}
   