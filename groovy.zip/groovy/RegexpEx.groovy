import java.util.regex.Pattern
import java.util.regex.Matcher

class RegexpEx {

    static void main(args){
       def src = """The Ajanta Caves in Aurangabad district of Maharashtra, India are about
                 30 rock-cut Buddhist cave monuments which date from the 2nd century BCE to
                 about 480 or 650 CE.The caves include paintings and sculptures described by
                 the government Archaeological Survey of India, as "the finest surviving
                 examples of Indian art, particularly painting",which are masterpieces of
                 Buddhist religious art, with figures of the Buddha and depictions of the
                 Jataka tales.The caves were built in two phases starting around the 2nd
                 century BCE, with the second group of caves built around 400-650 CE according
                 to older accounts, or all in a brief period of 460 to 480 according to the
                 recent proposals of Walter M. Spink.The site is a protected monument in the
                 care of the Archaeological Survey of India, and since 1983,
                 the Ajanta Caves have been a UNESCO World Heritage Site."""
       /* src==~/regexp/ for total matching */
       Matcher matcher = src=~/[0-9]+/
       while(matcher.find()){
         println "start-" + matcher.start() + ", end-" + matcher.end() + ", group-" + matcher.group()
       }
    }
 /*The regex find operator =~
The regex match operator ==~
The regex Pattern operator ~String */
}
