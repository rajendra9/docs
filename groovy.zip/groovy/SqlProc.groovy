package forDB

import groovy.sql.Sql

public class SqlProc {

   /* singleRow  will come like Map where key is column Name, value as column's value */
   def printResults(){
     def sql = SqlRet.readProps("oracle")
     def procCall = "{ call SENDPAYDTLS(?,?,?) }"
     sql.call(procCall, [7654, Sql.DOUBLE, Sql.DOUBLE],{
         d1,d2 -> println "Employee 7654's total Salary is ${d1} and Total Commission is : ${d2} "
     })

   } 
  
   static void main(args) {
       def sqlProc = new SqlProc()
       sqlProc.printResults()
   }

}