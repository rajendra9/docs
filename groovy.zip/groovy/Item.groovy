package forjson


class Item {

    String itemId
    String itemName
    float itemCost

    Item(String itemId, String itemName, float itemCost) {
        this.itemId = itemId
        this.itemName = itemName
        this.itemCost = itemCost
    }

    @Override
    public String toString() {
        return "Item{" +
                "itemId='" + itemId + '\'' +
                ", itemName='" + itemName + '\'' +
                ", itemCost=" + itemCost +
                '}';
    }
}