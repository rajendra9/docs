/* cmd /c invokes windows command shell */

println "cmd /C dir".execute().text
println "cmd /C type gvyRun.bat".execute().text
