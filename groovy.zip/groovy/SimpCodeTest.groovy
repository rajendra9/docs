class SimpCodeTest {
    def sayHello(String name){
        return "Hello $name"
    }
    
    def showDiffClasses(){
       def response = []
       def myVar = "prasad"
       response.add(myVar.class)
       myVar = 124
       response.add(myVar.class)
       myVar = 1240000000
       response.add(myVar.class)
       myVar = 12400000000000000000
       response.add(myVar.class)
       myVar = 124.7654530000000
       response.add(myVar.class)
       myVar = ["Samuel","Martand"]
       response.add(myVar.class)
       response.each{println it}
     }
     static void main(args){
      def codeTest = new SimpCodeTest()
      println codeTest.sayHello("prasad")
      codeTest.showDiffClasses()
      }   
    }   