package categories


@Category(String)
class StreetTalk {

    String appendBothSides() {
        "Hello, Hello, Mr.${this} Groovy is fun!"

    }
}

 use(StreetTalk) {
   assert "Hello, Hello, Mr.Venkat Groovy is fun!" == "Venkat".appendBothSides()
 }

