package dyna


class UsingMeta {
   private String name = "SomeName"
   String location

   void setLocation(String newLocation){
       this.location = newLocation
   }

   static void main(args){
     def obj = new UsingMeta();
     println obj.name;
     obj.setLocation("Chromepet")
     println obj.location

     obj.metaClass.setAttribute(obj, "name", "Madhavan")
     obj.metaClass.setAttribute(obj, "location", "Tambaram")
     println obj.name;
     println obj.location

   }
}
