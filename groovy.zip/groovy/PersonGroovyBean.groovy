public class PersonGroovyBean {
   String name
   double income
   String address
   
   String toString(){
      "Name:" + name + ", Income:" + income+", Address:"+ address 
   }
  
   static void  main(args){
     def person = new PersonGroovyBean(name:"Surendran", income:467600.5, address:"Tambaram")
     println "details are : $person"
   }

}