package cols

class ListColl {
      
   def myObjects = []
    // different types can be added
   def doDiffAdds(){
       myObjects = ["Details"]
       myObjects.add("name is Raman")
       myObjects += "stays in Medavakkam"
       myObjects << "rent paid is 6550"
       myObjects << "recorded in"
       myObjects.add(2016)
       myObjects.each { println it} 
     }
    
   def doDiffRemovals(){
       myObjects = [65, 56, 72, 78, 94, 112, 'AAA', 32, 72, 43]
       myObjects.each { print it+" "} 
       println ""
       myObjects -= 72
       myObjects.remove(3)
       myObjects.remove 'AAA' // works only for strings
       myObjects.each { print it+" "} 
       println ""        
    }

    def searchAll(){
      def myObjs = [65, 76, 54, 32, 65, 87, "AAA", 102, 34, 65, 95]
      def filtList = myObjs.findAll { it == 65}
      println "fillList"
      filtList.each { print it +" " }
      println ""
    }
    def iterWithIndex(){
       myObjects = [65, 56, 72, 78, 94, 112, 'AAA', 32, 43]
       myObjects.eachWithIndex {obj, ind-> println "object at $ind is $obj"}
       myObjects.each {  println "$it " }
    }
     static void main(args){
      def codeTest = new ListColl()
      codeTest.doDiffAdds()
      codeTest.doDiffRemovals()
      codeTest.iterWithIndex() 
      codeTest.searchAll()
         
     }   
    }   