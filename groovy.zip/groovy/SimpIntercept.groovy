package dyna

class SimpIntercept implements Interceptor{
    def interceptable = false

    @Override
    Object beforeInvoke(Object obj, String meth, Object[] objects) {
        if (meth.contains("Credit") || meth.contains("Debit")) {
            println("before:" + meth)
            interceptable = true
        }else {
            interceptable = false
        }

    }

    @Override
    Object afterInvoke(Object obj, String meth, Object[] objects, Object result) {
        interceptable = false;
        result = meth+" method invoked"
        result
    }

    @Override
    boolean doInvoke() {
        return interceptable
    }
}
