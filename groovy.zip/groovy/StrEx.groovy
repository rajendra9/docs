
String.metaClass.isPalindrome(){
    -> delegate == delegate.reverse()
}
word = "malayalam"
println "${word} is a palindrome ? ${word.isPalindrome()}"
word = "groovy"
println "${word} is a palindrome ? ${word.isPalindrome()}"
