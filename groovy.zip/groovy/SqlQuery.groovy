package forDB

import groovy.sql.Sql

public class SqlQuery {

   def printResults(qry){
     def sql = SqlRet.readProps("oracle")
     sql.eachRow(qry){
       for(int i=0;i<it.getMetaData().getColumnCount();i++) {
           print "${it[i]} "
       }
       println ""
     }
     println "----------------"
   } 
  
   static void main(args){
      def sqlQuery = new SqlQuery()
      sqlQuery.printResults("select empno,ename,job,hiredate,sal,deptno from emp")
      sqlQuery.printResults("select deptno,dname,loc from dept")
   }

}