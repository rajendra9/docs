

abstract class Person {
  String name;
  public void setName(String n){
    this.name = n;
  }

}

class Parent extends Person {
}

class Child extends Person {
}

public class OverloadEx2 {
 
public void  printName(Person person) {
  System.out.println("Method in Person: "+ person.name);
}

public void printName(Child child) {
 System.out.println("Method In Child: "+ child.name);
}

public static void main(String[] args){
  OverloadEx2 ex2 = new OverloadEx2();
  Person parent1 = new Parent();
  parent1.setName("Parent1");   
  Person child1 = new Child();
  child1.setName("child1");
  ex2.printName(parent1);
  ex2.printName(child1); 
}
 

}