/**
 * Created by PRASAD on 25-01-2016.
 */
class SimpAdd {
    def mlineStr  = '''gggggggggggg
                       hhhhhhhhhhhhhhhh
                       ssssssssssssssssss'''
    static void main(args){
        def x = 5, y = 22
        println "Welcome $x + $y gives result: "+(x+y)
        println new SimpAdd().mlineStr
    }
}
