package categories
//fiename should not be same as class name
class VerifyNum {
     static boolean  isTenDivisor(Integer n) {
          n%10==0
     }
     static boolean isEven(Integer n){
         n%2==0
     }
} 
use (VerifyNum) {
     println 60.isTenDivisor()
     println 62.isTenDivisor()
     println 12.isEven()
}    
 
 