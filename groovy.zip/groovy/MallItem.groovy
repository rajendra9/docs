package cols


class MallItem {
   String brand
   int size
   double cost


    @Override
    public String toString() {
        return "MallItem{" +
                "brand='" + brand + '\'' +
                ", size=" + size +
                ", cost=" + cost +
                '}';
    }
}
