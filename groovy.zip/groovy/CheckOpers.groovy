package opers

public class CheckOpers {

  class Item{
    String itemId
    String itemName
    float itemCost

    @Override
    public String toString() {
      return "Item{" +
              "itemId='" + itemId + '\'' +
              ", itemName='" + itemName + '\'' +
              ", itemCost=" + itemCost +
              '}';
    }
  }
  def a = 8, b = 3, c = 8
  def  d = 8.0
  def j = null
  def item = new Item(itemId: "s232", itemCost: 32.4, itemName: "calculator" )
  Item item2
  def showOpers(){
    def num = "5432".toInteger()
    println num

    println a.previous() //a--
    println a.next()
    println a.power(b)
    println a.equals(c)
    println a.compareTo(b)
    println a.toDouble()
    println a.plus(6)
    println a.mod(b)
    println a.asType(Boolean.class)
    /*Elvis operator if j==null it will be assigned 12
      a shortcut for ternary operator  */
    def k = j?:12
    println k
    /* null safe operation as it avoids NullPointerException
       just assigning null silently
       */
    def myItem = item2?.itemCost
    assert myItem == null
    def val = item?.itemCost
    println val
    /* direct field access normal field if referred
      will invoke getter but using .@field will read property value
      directly
       */
    def e1 = new Employee("Sukumaran")
    println e1.empName + "::" + e1.@empName
    //will give BigDecimal class
    def x = 6/7
    println x.getClass()
    // g or G will give BigInteger
    num = 2G + 7G
    println num + "::" + num.getClass()

  }
  static main(args){
      def check = new CheckOpers()
      check.showOpers()
  }

}
