/* normal inner clas problems */
public class XmlBuilder {
 
   public class Bank {
      String name
      int estbYear
      List branches
      public Bank(na, estYr, brancs){
        name = na
        estbYear = estYr
        branches = brancs
      }
      String toString(){
          "Name:" + name + ", Estblished tear:" + estbYear+", branches:"+ branches 
      }
   }

   public static Bank createBank(XmlBuilder builder,String na, int estYr, List brancs){
    return new Bank(builder,na, estYr,brancs)
   }

   def buildBk(bk, bk2){
     def builder = new groovy.xml.MarkupBuilder()
     builder.banks{
       bank("name":bk.name, "established":bk.estbYear){
        bk.branches.each{branch(it)}
       }
       bank("name":bk2.name, "established":bk2.estbYear){
        bk2.branches.each{branch(it)}
       }
     }  
    }
   
    static void  main(args){
     def builder = new XmlBuilder()
     def brancs = ["Guindy", "Pallavaram", "ChromePet", "Tambaram"]
     def brancs2 = ["Chembur", "Malabar Hills", "Santa Gruz", "Kalyan"]
     def bk = createBank(builder, "Indian Bank",1937, brancs)
     def bk2 = createBank(builder, "Bank Of India",1942, brancs2)
     builder.buildBk(bk, bk2)
    }

}