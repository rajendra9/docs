import org.codehaus.groovy.runtime.InvokerHelper

class ScriptExt extends Script {
    @Override
    def Object run() {
        println "Groovy Script"
    }
    static void main(args){
        InvokerHelper.runScript(ScriptExt, args)
    }
}
