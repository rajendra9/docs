package forDates

import static java.util.Calendar.*;

import groovy.time.DatumDependentDuration

class SimpDateManip {

  def  parseFormat(){
      def dt = new Date().parse("yyyy-MM-dd", "2016-01-31")
      println "date is $dt"
      println "next date is ${++dt}"
      println "previous date of next date is ${--dt}"
      println "year is ${dt[YEAR]}"
      println "Month is ${dt[MONTH]}"
      println "Day is ${dt[DAY_OF_MONTH]}"
      println "Day is ${dt[DAY_OF_WEEK]}"
      println "Formatted " + dt.format("d 'th' MMMMM yyyy")
      println dt.getDateString()
  }
  def void change(){
    def date = new Date()
    date[YEAR] = 2014
    date[MONTH] = NOVEMBER
    date[DAY_OF_MONTH] = 21
    println date

    date.set year: 2012, month: JUNE, date:12
    println date
    date.clearTime()
    println date

    def cal = date.toCalendar();
    println "as calendar-$cal"

    cal = Calendar.instance
    cal[YEAR] = 2014
    cal[MONTH] = JANUARY
    cal[DAY_OF_MONTH] = 12
    println cal.getTime()

  }
  def void definePeriods(){
    def period = new DatumDependentDuration(2, 1, 15, 0, 0, 0, 0)
    def dt = new Date()
    dt.set year:2000,month:JANUARY, date:14
    println "----"+dt.toString()
    println period.plus(dt).toString()
  }

  def void printRanges(){
    def fromDate = new Date()
    fromDate.set year:2016,month:JANUARY, date:14
    def  nextDate = fromDate + 6
    nextDate.downto(fromDate){
       println it.format("EEEE")
    }
    /* fromDate.upto(nextDate) can also be used */
  }

  static void main(args){
    def dateDemo = new SimpDateManip()
    dateDemo.parseFormat();
    dateDemo.change()
    dateDemo.definePeriods()
    dateDemo.printRanges()
  }

}
