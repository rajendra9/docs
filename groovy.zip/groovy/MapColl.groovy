package cols

class MapColl {
      
   def myObjects = [:]
    // you canot add numberic keys like this
   def addEntry(){
      myObjects.cricket="Sachin"
   }
   def addEntry(key,val){
       myObjects[key] = val
   }
    
   def show(){
       myObjects.each{key, value -> println "value at $key is $value"}
   }   
    
   static void main(args){
    def codeTest = new MapColl()
    codeTest.addEntry()
    codeTest.addEntry(100, "Karthi")
    codeTest.addEntry(200, "Manohar")
    codeTest.addEntry(300, "Ganesh")
    codeTest.addEntry(400, "Suresh")
    codeTest.show() 
   }   
   
 }   