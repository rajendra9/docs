package forDB

import com.gmongo.GMongoClient
import com.mongodb.DB
import com.mongodb.DBObject
import com.mongodb.DBObject
import com.mongodb.BasicDBObject
import com.mongodb.ServerAddress
import com.mongodb.MongoCredential
import com.mongodb.DBCursor
import com.mongodb.DBCollection
import java.math.BigDecimal

class MongQuery {

    def GMongoClient getClient(){
        def credentials = MongoCredential.createCredential("scott","samp","tiger".toCharArray())
        def addr = new ServerAddress("127.0.0.1", 27017)
        GMongoClient mongoClient = new GMongoClient(addr, [credentials])
        return mongoClient
    }

    def void makeQuery(mongoClient){
        DB db = mongoClient.getDB("samp")
        DBCollection coll = db.getCollection("samp.persons")
        DBObject query = new BasicDBObject().put("adharId", 5454)
        DBCursor cursor = coll.find(query)
        if(cursor.hasNext()){
            println "yes"
            DBObject obj =  cursor.next()
            println "Name:" + obj.get("name") + " Salary:" + obj.get("salary")
        }
    }

    def void addPerson(mongoClient){
        DB db = mongoClient.getDB("samp")
        DBCollection coll = db.getCollection("samp.persons")
        DBObject dmlObj = new BasicDBObject()
        dmlObj.put("adharId","2213")
        dmlObj.put("name","Maruthi")
        dmlObj.put("salary",new Double(54230.5))
        DBObject dmlObj2 = new BasicDBObject()
        dmlObj2.put("adharId","2283")
        dmlObj2.put("name","Swaroopa")
        dmlObj2.put("salary",new Double(41200.5))
        coll.insert(dmlObj,dmlObj2)
        println "objects inserted"
    }

    def void updatePerson(mongoClient){
        DB db = mongoClient.getDB("samp")
        DBCollection coll = db.getCollection("samp.persons")
        DBObject dmlQry = new BasicDBObject()
        dmlQry.put("adharId","5323")
        DBObject dmlObj = new BasicDBObject()
        dmlObj.put("adharId","5323")
        dmlObj.put("name","Sangeetha")
        dmlObj.put("salary",new Double(32200.5))
        coll.findAndModify(dmlQry, dmlObj)
        println "object updated"
    }

    def void close(mongoClient){
        mongoClient.close()
    }

    static void main(args){
       def mongoQuery = new MongQuery();
       def mongoClient = mongoQuery.getClient()
       mongoQuery.makeQuery(mongoClient)
       mongoQuery.addPerson(mongoClient)
       mongoQuery.updatePerson(mongoClient)
       mongoQuery.close(mongoClient)
    }

}
