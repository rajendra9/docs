package mytraits


class FoodMall implements Dealer {
    @Override
    void setShelfLife() {
        this.shelfLifeHours = 48
    }

    @Override
    void offerDiscount() {
        if(this.shelfLifeHours<44){
            println "30% on general types"
        }
        else {
          println "10% on general types"
        }
    }
}
