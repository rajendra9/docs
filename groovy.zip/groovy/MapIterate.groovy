package cols

class MapIterate {
    def simpMap = [:]

    def populate() {
        simpMap["one"] = 1000
        simpMap["klm"] = 2000
        simpMap["three"] = 3000
        simpMap["pqr"] = 4000
        simpMap["five"] = 5000
        simpMap["abc"] = 5000

    }
    def show(){
        println simpMap.size()
        println simpMap.keySet()
        simpMap.each { println "${it.key}-${it.value}"}
        def keySortMap = simpMap.sort({a,b -> a.key <=> b.key})
        println "after sort"
        keySortMap.each { println "${it.key}-${it.value}"}
        def valueSortMap = simpMap.sort({a,b -> a.value <=> b.value})
        println "after value sort"
        valueSortMap.each { println "${it.key}-${it.value}"}
    }

    static void main(args){
        def mapIterate = new MapIterate()
        mapIterate.populate()
        mapIterate.show()
    }
}