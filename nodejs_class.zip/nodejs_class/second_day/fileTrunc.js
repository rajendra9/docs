var fs = require("fs");

var buff = new Buffer(1024);


var data = "";


var file = "C:/myNode/inputs/forTrunc.dat";

data = fs.readFileSync(file);

console.log("synchronous read:\n"+data);


fs.open(file, "r+", function(err, fd){
  
  if(err){

       return  console.error("error in writing");
   
  }

  console.log("file is going to be read through fd");


  fs.ftruncate(fd, 20, function(err){

      if(err){

        console.log("Error in truncating");  
 
      }
  
    console.log("truncated successfully");

    });

    buff = new Buffer(1024);
 
    fs.read(fd, buff, 0, buff.length, 0, function(err,bytes){
 
     if(err){

        console.log("Error in reading");  
  
     }
     console.log(buff.slice(0,bytes).toString());

    });

    
 
});


