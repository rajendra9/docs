var fs = require('fs');

var buff = fs.readFileSync('../inputs/a.txt');

buff[10] = 55;

fs.writeFileSync('../inputs/a.txt',buff);
console.log('replaced');