var express = require('express');
var app = express();

app.use('/samp/:name', function(req,res,next){
   console.log('Hi! ');
   next();
});
app.use('/samp/:name', function(req,res,next){
   console.log(req.params.name);
   res.end();
});
app.listen(3000,function(){
  console.log('server started at 3000');
});