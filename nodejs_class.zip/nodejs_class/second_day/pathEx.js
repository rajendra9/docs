var path = require("path"); 

var p = path.normalize("D:\\myNode\\db");

console.log(p);

console.log(path.resolve(p, "birds.sql"));

console.log("Dirname-"+path.dirname(p))
;


