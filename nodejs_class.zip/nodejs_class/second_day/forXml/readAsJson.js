var fs = require("fs");
var xml2js = require("xml2js");
var parseJson = require("xml2js").parseString;

fs.readFile('./data/AttrDept.xml','UTF-8', function(err, data){
    if(err){
        console.error(err);
    }
    console.log(data);
    parseJson(data, function(err, result){
        if(err){
            console.error(err);
        }
        var res = JSON.stringify(result);
        console.log(res);
    });
});