var fs = require("fs");


var parentPath = "C:/temp/forNode";


var dirPath = "c:/temp/forNode/forRemove";


fs.rmdir(dirPath, function(err){

    if(err){

       return console.error(err.stack);
   
 }
   
 console.info("going to read directory");
 fs.readdir(parentPath,function(err, files){
   
   if(err){

    return console.error(err.stack);

   } 
   files.forEach(function(file){
  
      console.log(file);  
   });

  });


});