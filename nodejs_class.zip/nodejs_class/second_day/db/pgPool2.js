var Pool = require("pg-pool");

var qry = "select empno,ename,job,sal,hiredate,deptno  from emp";
 var pool = new Pool({
 database: 'samp',
 user: 'postgres',
 password: 'mother',
 port: 5432,
 max: 5,
 min: 2,
 idleTimeoutInMillis: 10 
});
var sep = "::";
pool.query(qry, (err,res)=>{
  if(err){
    console.error(err);
  }
  else{
   var empRows = res.rows 
   for(ind in empRows){
    row = empRows[ind]    
    console.log(row.empno + sep + row.ename + sep
             + row.job + sep + row.sal + sep + row.hiredate + sep + row.deptno); 
   }  
  }
  pool.end();
 }
); 