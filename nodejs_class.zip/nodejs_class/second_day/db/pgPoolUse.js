var  pg = require("pg");
var genPool = require("generic-pool");
var connectStr = "postgres://postgres:password@123@172.16.50.14:5432/samp";

var pool = genPool.Pool({
      name: "postgres",
      create : function(callback){
        var Client = pg.Client;
         var pgClient = new Client();
         pgClient.connect(connectStr);
   
         
         callback(null,pgClient);
         
      },
    destroy : function(client) {
       client.end(); },
    max: 3,
    min: 2,
    idleTimeoutMillis: 30000,
    log: true
});    

 
   
 
