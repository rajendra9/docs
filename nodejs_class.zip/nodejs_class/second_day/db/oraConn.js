var oracle = require("oracle");

var connOptions = {
      hostname:"172.16.50.20",
      port:1521,
      database:"orcl11g",
      user:"trng11g",
      password:"trng$11g"
     };

oracle.connect(connOptions,function(err,connection){
   if(err){
     console.log("problem in getting connection");
   }
   connection.execute("select currenttimestamp  from dual",
    function(err,results){
      if(err){
        console.log("problem in query execution");
        return;
      }
     console.log(results);
     connection.close();
    });
 });  
        
          