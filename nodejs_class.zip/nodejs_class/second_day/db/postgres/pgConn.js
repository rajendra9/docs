var pg = require("pg");
var connectStr = "postgres://172.16.50.14:5432/samp";

var results = [];
var pgClient = new pg.Client(connectStr);

pgClient.connect("postgres","password@123");

var query = pgClient.query("select enmpno,ename,job,sal,deptno from emp");

query.on( 'row',  function(row){
   results.push(row);
});
console.log(JSON.stringify(results));