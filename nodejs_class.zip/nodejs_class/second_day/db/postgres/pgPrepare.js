var pg = require("pg");
var readline = require("readline");
var connectStr = "postgres://postgres:mother@localhost:5432/samp";

 function getData(empNum){
   var pgClient = new pg.Client(connectStr);
   pgClient.connect();

   var query = pgClient.query({
                          name: "empQry",
                          text: "select ename,job,sal,hiredate,deptno  from emp where empno = $1",
                          values: [eno]
                          });


   var  data = {};

   query.on("row",function(row,result){
       data = row;
   });

   query.on("error",function(err){
     console.log(err.stack);
   });

   query.on("end", function(result){
      console.log(data.ename);
      console.log(data.job);
      console.log(data.sal);
      console.log(data.hiredate);
      console.log(data.deptno);
      pgClient.end();
    });
}

var rl = readline.createInterface({input:process.stdin,
                                   output:process.stdout}); 
var eno = 0;

rl.question("Enter empnum for whom details are required",function(answer){
   eno = parseInt(answer);
   getData(eno);
   rl.close();
});
 