var pg = require("pg");
var connectStr = "postgres://postgres:password@123@172.16.50.14:5432/samp";

var pgClient = new pg.Client(connectStr);

pgClient.connect();

var eNums = [7788, 7654];
var query = pgClient.query({
                                                      name:"empQry",
                                                      text: "select ename,job,sal,deptno,hiredate from emp where empno = $1",
                                                      values:[eNums[0]]
                                                     });
var data = [];
query.on( "row",  function(row, result){
   data.push(JSON.stringify(row));  
});
query = pgClient.query({
                                                      name:"empQry",
                                                      values:[eNums[1]]
                                                     });
query.on( "row",  function(row, result){
   data.push(JSON.stringify(row));  
});

query.on("end", function(result){
   data.forEach(function(row,ind){
          console.log(row);
   });
    pgClient.end();
});
