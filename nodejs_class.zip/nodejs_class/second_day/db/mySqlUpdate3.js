var mysql = require('mysql');
function updateEmps(deptNum, increment){
  var connection = mysql.createConnection({
    host:"localhost",
    port:3306,
    user:"faculty",
    password:"htc"
    });
  
    connection.query("use samp");
    var qryStr = "update emp set sal = sal+? where deptno= ?";      
    connection.query(qryStr, [increment, deptNum],function(err, result){
     if(err){
       console.log("Error in fetching");
     }
     else{
      console.log("Updated "+result.changedRows+" rows.");
     }
    });
    connection.end();    
}
updateEmps(30,100);
