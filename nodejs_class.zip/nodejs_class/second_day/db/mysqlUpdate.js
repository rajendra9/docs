var mysql = require("mysql");

var connection = mysql.createConnection({
      host:"localhost",
      port:3306,
      user:"faculty",
      password:"htc"
     });



 connection.query("use samp");
   var ic = 528000.5;
   var id = "s100";  
  var updateStr =
    "update  persons SET income = "+ic+" where adharid='"+id+"'";
 
  var qry = connection.query(updateStr,            
            function(err,result){
              if(err){
                 console.log("error in fetching results")
              }
              else{
                 console.log(result.insertId);
              }
            });
   console.log(qry);
  connection.end();
            