drop table if exists node_items;

create table node_items(item_id integer primary key,
item_name varchar(30),
item_cost decimal(10,2));


