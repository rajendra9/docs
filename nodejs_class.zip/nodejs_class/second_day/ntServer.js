var net = require("net");
var server = net.createServer(function(connection){
   console.log("client connected now");
   connection.on("end", function(){
     console.log("client is exiting");
   });
   connection.write("Hello Client\r\n");
   connection.pipe(connection);
});

server.listen(8090, function(){
   console.log("Waiting for connections on port 8090");
}); 