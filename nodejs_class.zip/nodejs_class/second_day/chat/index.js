var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

app.get('/',function(request,response){
  response.sendFile(__dirname + '/chat.html');
});

io.on('connection', function(socket){
   socket.on('chatMessage', function(msg){
      io.emit('chatMessage',msg);
   });
   socket.on('disconnect' , function(){
     console.log('a user has got disconnected');  
   });
   
});


http.listen(3000,function(){
  console.log('Server started at 3000 port');
});