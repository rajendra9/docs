console.log("before");

function stop(){
    
 clearInterval(t);

}

var t = setInterval(function(){

   console.info("Interval function");

   setTimeout(stop,4000);

},1000);

