var fs = require('fs');
var buffToRead = new Buffer(650);
filename = '../inputs/buffDetails.dat';
 fs.exists(filename,function(exists){
  if(exists){
     fs.open(filename,'r',function(error,fd){
        if(error){console.log(error); return;}
        buffStart = 0;
        buffLen = buffToRead.length;
        fileStart = 0;
        fs.read(fd,
              buffToRead,
              buffStart,
              buffLen,
              fileStart,
              function(error, read){
                 if(error){ console.log(error); return; }
                    console.log('read ' + read + 'bytes');
                    console.log(buffToRead.slice(0,read).toString());                 
              });
         fs.close(fd, function(error) {
           if(error){ console.log(error); return;}
        });
      });
     }
     else{
       console.log('file does not exist');
     }
    });   

 