console.log(__dirname);
console.log(__filename);
