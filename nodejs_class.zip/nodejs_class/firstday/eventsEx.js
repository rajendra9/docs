var events = require("events");

var emitter = new events.EventEmitter();


emitter.on("myFire", function(){
  
  console.log("Fired an Event");

});

emitter.emit("myFire");

