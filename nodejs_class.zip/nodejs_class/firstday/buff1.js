var sampBuffer = new Buffer(26);
for(var i=65;i<92;i++){
  sampBuffer[i-65] = i;
}

console.log(sampBuffer.toString('ascii'));
console.log(sampBuffer.toString('base64'));

sampBuffer = new Buffer('We appreciate your big heartedness very much in this regard');
 var mySlice = new Buffer(10);
 var srcStart = 3;
 var srcEnd = 13;
 var targetStart = 0;
 sampBuffer.copy(mySlice, targetStart, srcStart, srcEnd);
 console.log(mySlice.toString());
