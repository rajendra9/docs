const BufferList = require('bl');
const fs = require('fs');
var bufList = new BufferList();
var readline = require('readline');

var rl = readline.createInterface({
	input:process.stdin,
    output:process.stdout
});

function addToBuffer(buffList){
	rl.question('Enter emprecord as Number-name-course-location',function(answer){
		buffList.append(answer);
		console.log(buffList.length);
		buffList.pipe(fs.createWriteStream("emps_new.dat"));
		console.log('new file created');
		rl.close();
	});	
}
var inStream = fs.createReadStream('emps.dat');
inStream.on('data',function(data){
  bufList.append(data.toString());
  bufList.append(new Buffer('\r\n'));	
});
inStream.on('end',function(){
	  addToBuffer(bufList);	
});

