console.info('This file is:' + __filename);
console.info('This directory is:' + __dirname);